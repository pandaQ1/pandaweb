/* ============================================================
   Panda 设计语言 —— M1b 主题控制器（theme.js）
   本项目适配版：与设计语言模块的 WHTheme 同一套契约（init / apply / set / get / onChange），
   只把存储落到本扩展自己的设置结构上（chrome.storage.sync 的 `theme` 键），
   并把偏好镜像到 localStorage 的 `wh_theme` —— theme-boot.js 在 <head> 里同步读这一份。

   为什么必须只有这一份：此前 popup.js / options.js / wordlist.js / learn.js / pdf-reader.js
   各自写了一遍「三态偏好 → 主题属性」，四份代码四个形状，于是行为也不一样：
     · 只有 wordlist/learn 写了 data-wh-theme-pref，popup/设置页没有；
     · 谁都没有监听系统主题变化 —— 偏好选「跟随系统」时，系统切深色页面不动，必须刷新；
     · 谁都没有监听 storage.onChanged —— 在设置页改了主题，已经开着的生词本/学习页不跟着变。
   收敛到这一份之后，五个界面共用一套解析、持久化与广播。

   与 theme-boot.js 的分工：
     boot 管首帧（同步、无存储 IO、只读 localStorage 镜像），本文件管之后的解析、持久化、同步。

   用法（放在 storage.js 之后、页面自身脚本之前）：
     WHTheme.init({ fallback: "light" });
     WHTheme.onChange((theme, pref) => paintThemeButton(pref));
     WHTheme.set("dark");          // 用户点了「夜间」：写盘 + 镜像 + 重绘 + 广播
     WHTheme.apply("auto");        // 只重绘不写盘（读到的状态已经是对的，别回写）
     WHTheme.get();                // { pref, theme, ready }
   ============================================================ */
(function (global) {
  "use strict";

  var SETTINGS_KEY = "theme";      // 本扩展设置里的键（chrome.storage.sync）
  var MIRROR_KEY = "wh_theme";     // 给 theme-boot.js 的镜像键（两侧必须同键同值）
  var VALID = { light: 1, dark: 1, auto: 1 };
  var FALLBACK = "light";
  var COLORS = { dark: "#0a0a0a", light: "#ffffff" };

  var pref = null;                 // 用户偏好：light | dark | auto
  var ready = false;
  var listeners = [];
  var mql = global.matchMedia ? global.matchMedia("(prefers-color-scheme: dark)") : null;

  function root() { return document.documentElement; }

  function resolve(p) {
    if (p === "auto") return mql && mql.matches ? "dark" : "light";
    return p === "dark" ? "dark" : "light";
  }

  function mirror(p) {
    try { global.localStorage && localStorage.setItem(MIRROR_KEY, p); } catch (e) { /* 隐私模式忽略 */ }
  }

  /** 落主题：属性 + colorScheme + 内联底色 + 独立页的 body.dark，再广播出去 */
  function paint(p) {
    var theme = resolve(p);
    var r = root();
    var dark = theme === "dark";

    r.setAttribute("data-wh-theme", theme);
    r.setAttribute("data-wh-theme-pref", p); // 记录"偏好"，样式可区分 auto

    /* 内联底色会盖过样式表里的 html{background:var(--ui-bg)}，
       主题一变必须跟着改，否则切到夜间后画布边角仍是白的 */
    r.style.backgroundColor = dark ? COLORS.dark : COLORS.light;
    r.style.colorScheme = theme;

    if (document.body) document.body.classList.toggle("dark", dark);

    for (var i = 0; i < listeners.length; i++) {
      try { listeners[i](theme, p); } catch (e) { /* 单个监听器出错不影响其他 */ }
    }
    try {
      document.dispatchEvent(new CustomEvent("wh:themechange", { detail: { theme: theme, pref: p } }));
    } catch (e) { /* 老浏览器忽略 */ }
    return theme;
  }

  /* ---------- 存储：优先走共享 storage.js（扩展/网页两套都覆盖） ---------- */
  function read(done) {
    var defs = {};
    defs[SETTINGS_KEY] = FALLBACK;
    try {
      if (global.WH_STORE && WH_STORE.syncGet) {
        WH_STORE.syncGet(defs).then(function (o) {
          var v = o && o[SETTINGS_KEY];
          done(VALID[v] ? v : FALLBACK);
        }).catch(function () { done(FALLBACK); });
        return;
      }
    } catch (e) { /* 落到 localStorage */ }
    var v2 = null;
    try { v2 = global.localStorage && localStorage.getItem(MIRROR_KEY); } catch (e) { v2 = null; }
    done(VALID[v2] ? v2 : FALLBACK);
  }

  function write(p) {
    mirror(p); // 先镜像：即使 chrome.storage 报错，下次首屏也不会读错
    var patch = {};
    patch[SETTINGS_KEY] = p;
    try {
      if (global.WH_STORE && WH_STORE.syncSet) { WH_STORE.syncSet(patch); return; }
    } catch (e) { /* 已镜像 */ }
  }

  function init(options) {
    if (options && VALID[options.fallback]) FALLBACK = options.fallback;
    ready = true;

    // 系统主题变化：仅当偏好是 auto 时重绘（此前五个页面都没做，切了系统主题必须刷新）
    if (mql && mql.addEventListener) {
      mql.addEventListener("change", function () { if (pref === "auto") paint("auto"); });
    } else if (mql && mql.addListener) {
      mql.addListener(function () { if (pref === "auto") paint("auto"); });
    }

    read(function (p) {
      pref = p;
      mirror(p);
      paint(p);
    });

    // 别的页面（设置页 / 弹窗 / 生词本）改了偏好：已打开的页面立刻跟上
    try {
      if (global.chrome && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener(function (changes, area) {
          if (area !== "sync" || !changes[SETTINGS_KEY]) return;
          var v = changes[SETTINGS_KEY].newValue;
          if (VALID[v] && v !== pref) { pref = v; mirror(v); paint(v); }
        });
      }
    } catch (e) { /* ignore */ }

    return WHTheme;
  }

  /** 只重绘（页面自己已经从存储读到状态时用，避免无谓回写） */
  function apply(p) {
    var v = VALID[p] ? p : FALLBACK;
    if (v !== pref) {
      pref = v;
      mirror(v);
    }
    return paint(v);
  }

  /** 用户显式选择：写盘 + 镜像 + 重绘 */
  function set(p) {
    var v = VALID[p] ? p : FALLBACK;
    pref = v;
    write(v);
    return paint(v);
  }

  function get() {
    return { pref: pref || FALLBACK, theme: resolve(pref || FALLBACK), ready: ready };
  }

  function onChange(fn) {
    if (typeof fn === "function") listeners.push(fn);
    return function () {
      var i = listeners.indexOf(fn);
      if (i >= 0) listeners.splice(i, 1);
    };
  }

  var WHTheme = { init: init, apply: apply, set: set, get: get, onChange: onChange, resolve: resolve };
  global.WHTheme = WHTheme;
})(typeof window !== "undefined" ? window : globalThis);
