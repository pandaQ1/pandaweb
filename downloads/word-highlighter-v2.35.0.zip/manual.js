/*! Panda 设计语言 · M1d 手册导航控制器（manual.js）
 *
 *  为什么有这个文件：
 *  「使用手册」是设置页里最长、最容易被读者来回跳的一页。它有两个必须靠 JS 的行为：
 *  ① 目录胶囊点一下要跳到对应小节（页面滚动容器是文档本身）；
 *  ② 读的过程中目录要标出「当前在第几节」，否则用户滑到一半就不知道自己在哪。
 *  这两件事每个插件都会各写一遍，而且都会踩同一个坑：
 *  **目录按钮写的是 data-scroll="#man-07"，正文小节的 id 一旦改名，点击就静默失效**——
 *  按钮有按下反馈、页面不动，看着像"坏了"。所以这里把锚点核对也一起做了：对不上的锚点
 *  会在控制台点名（开发期一眼看到），而不是让用户去猜。
 *
 *  用法（放在 </body> 前；自动接管 .man-toc / .man-sec / [data-scroll] / [data-goto]）：
 *
 *    <script src="manual.js"></script>
 *
 *  显式接管（类名变体或需要程序化跳转）：
 *
 *    const api = WHManual.bind({ pane: "#pane-manual" });
 *    api.activate("#man-05");   // 跳到第 5 节（复用同一套滚动与高亮）
 *
 *  契约：
 *  1. 目录跳转用 `scrollIntoView({ block: "start" })`，平滑滚动，**不**改 `location.hash`
 *     （改 hash 会污染地址栏，也会和「分区直达」的 hash 机制打架）；
 *  2. 当前小节的判定不能靠"最后一条 intersecting"——两节同时命中时后写覆盖前写，高亮就会
 *     偏一节（点第 5 节却标成第 6 节）。这里改成确定性判定：**取最后一个"顶部已越过判读线"的小节**，
 *     判读线默认 96px（sticky 头部下方），滚动用 rAF 节流。同一位置永远只有一个答案。
 *  3. 正文里的 `[data-goto="<paneId>"]` 是「跳到某个设置分区」，交给侧栏 nav 的 click；
 *     `[data-scroll="#man-xx"]` 才是「跳到本页另一节」——两种语义不要混用；
 *  4. 锚点对不上时控制台点名，不静默。
 */
(function (global) {
  "use strict";

  const DEFAULT_PANE = "#pane-manual";
  /** 判读线：小节顶部越过这条线就算"已经读到这里"（约等于 sticky 头的高度） */
  const READ_LINE = 96;
  const bound = new WeakSet();
  const boundPanes = new WeakMap();
  const teardown = new WeakMap();

  function resolveTarget(pane, selector) {
    if (!selector) return null;
    try {
      return pane.querySelector(selector);
    } catch (e) {
      return null; // 选择器写错也是一种"对不上"，由校验统一报
    }
  }

  /**
   * 接管一个手册 pane。
   * @param {{pane?: string, offset?: number}} [opts] offset = 判读线（默认 96px）
   */
  function bind(opts) {
    const o = { pane: DEFAULT_PANE, offset: READ_LINE, ...(opts || {}) };
    const pane = document.querySelector(o.pane);
    if (!pane || bound.has(pane)) return boundPanes.get(pane) || null;

    const buttons = Array.from(pane.querySelectorAll("[data-scroll]"));
    const sections = [];
    const missing = [];

    for (const btn of buttons) {
      const el = resolveTarget(pane, btn.dataset.scroll);
      if (el) {
        if (!sections.includes(el)) sections.push(el);
      } else {
        missing.push(btn.dataset.scroll || "(空)");
      }
    }
    if (missing.length) {
      console.warn("[Panda 手册] 目录锚点对不上正文，这些按钮点了不会动：", missing.join("、"));
    }

    /** 目录胶囊的高亮：同一个 data-scroll 可能出现在目录与正文里，一起标 */
    function markCurrent(id) {
      const key = "#" + id;
      buttons.forEach((b) => b.classList.toggle("is-current", b.dataset.scroll === key));
    }

    /** 确定性判定：最后一个"顶部已越过判读线"的小节；一个都没越过就是第一节 */
    function pickCurrent() {
      if (!sections.length) return null;
      const de = document.scrollingElement || document.documentElement;
      // 已经滚到页面底部：直接标最后一节——最后一节常常顶不到判读线，不这样处理就永远高亮倒数第二节
      if (de && Math.ceil(global.scrollY + global.innerHeight) >= de.scrollHeight - 2) {
        return sections[sections.length - 1];
      }
      let best = sections[0];
      for (const s of sections) {
        if (s.getBoundingClientRect().top - o.offset <= 0) best = s;
        else break;
      }
      return best;
    }

    function syncCurrent() {
      const el = pickCurrent();
      if (el) markCurrent(el.id);
    }

    function jumpTo(selector, behavior) {
      const el = resolveTarget(pane, selector);
      if (!el) return false;
      el.scrollIntoView({ behavior: behavior || "smooth", block: "start" });
      markCurrent(el.id);
      return true;
    }

    for (const btn of buttons) {
      if (bound.has(btn)) continue;
      bound.add(btn);
      btn.addEventListener("click", (e) => {
        // 正文里的按钮如果同时带 data-goto，语义仍以 data-scroll 为准（本页内跳）
        e.preventDefault();
        jumpTo(btn.dataset.scroll, "smooth");
      });
    }

    // 跨分区跳转：交给侧栏 nav（pane-scroll 会接管滚动位置）
    for (const link of pane.querySelectorAll("[data-goto]")) {
      if (bound.has(link)) continue;
      bound.add(link);
      link.addEventListener("click", () => {
        const nav = document.querySelector('.nav-item[data-pane="' + link.dataset.goto + '"]');
        if (nav) nav.click();
      });
    }

    // 滚动时更新当前小节：rAF 节流，一帧最多算一次
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        syncCurrent();
      });
    };
    global.addEventListener("scroll", onScroll, { passive: true });
    global.addEventListener("resize", onScroll, { passive: true });
    syncCurrent();

    const api = {
      /** 跳到某一节（传 "#man-05"） */
      activate(selector) {
        return jumpTo(selector, "smooth");
      },
      /** 立即跳（不做平滑动画，截图/自检时用） */
      jump(selector) {
        return jumpTo(selector, "auto");
      },
      /** 手动重算一次当前小节 */
      sync: syncCurrent,
      sections: sections.map((s) => "#" + s.id),
      missing,
      destroy() {
        global.removeEventListener("scroll", onScroll);
        global.removeEventListener("resize", onScroll);
      },
    };
    boundPanes.set(pane, api);
    teardown.set(pane, api.destroy);
    return api;
  }

  function auto() {
    const panes = document.querySelectorAll(".man-sec, .man-toc");
    if (!panes.length) return null;
    return bind({ pane: document.querySelector(".man-toc") ? closestPane(document.querySelector(".man-toc")) : DEFAULT_PANE });
  }

  /** 目录可能在 pane 之外（独立页），向上找最近的分区容器 */
  function closestPane(el) {
    const pane = el.closest(".pane, .s-tab-pane, [data-manual]");
    if (!pane) return DEFAULT_PANE;
    if (pane.id) return "#" + pane.id;
    return DEFAULT_PANE;
  }

  global.WHManual = { bind, auto, READ_LINE };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", auto, { once: true });
  } else {
    auto();
  }
})(typeof window !== "undefined" ? window : globalThis);
