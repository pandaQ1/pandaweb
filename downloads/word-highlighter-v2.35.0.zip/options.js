/* 生词高亮 & 翻译助手 —— 选项页逻辑 v2.1 */
"use strict";

const DEFAULTS = {
  enabled: true,
  autoSpeak: true,
  minLength: 3,
  color: "#fff1a8",
  underline: true,
  userWords: [],
  knownWords: [],
  level: "none",          // 兼容字段：已选等级里的第一个（单值读取方仍用它）
  levels: null,           // 【v2.25.0】已选等级数组（[] = 主动清空；null = 老版本存档→沿用 level）
  theme: "light",
  quickTip: true,
  translateEnabled: false,
  translateService: "auto",
  translateMode: "replace",
  ytCaptionSingleLine: true,
  ytCaptionTrMode: "sentence",
  ytHoverPause: false,
  ytSentencePause: false,
  compatMode: false,      // 兼容模式：框架页面内跳过高亮（翻译不受影响）
  /* 【v2.20.0】截图 OCR 翻译 */
  ocrEnabled: true,
  ocrHotkey: "Alt+X",     // 兼容字段：读取时若没有 hotkeys 存档则沿用它（真实键位存在 hotkeys.bindings.ocrShot）
  ocrEngine: "offline",
  ocrAiId: "",
  ocrAutoSpeak: true,     // 【v2.20.2】识别翻译完成后自动朗读英文侧
  ocrLang: "auto",
  /* 【v2.24.0】快捷键中心：{ enabled, bindings: 动作 → 按键组合数组, notes: 默认操作说明（可改可删可停用） }
     【v2.34.2】rightClickCard：鼠标右键是否打开释义卡片（在「默认操作说明」里删/恢复那一行） */
  hotkeys: null,
  rightClickCard: true,
  customAIs: [],
  ttsVoice: "",           // ""=自动(本地优先)；auto:local/auto:online/online:服务/本地语音名
  ttsRate: 0.85,          // 语速
  ttsProvider: "youdao",  // 自动模式的在线服务：youdao | google | openai
  ttsOnlineUrl: "",       // 在线 TTS 接口（OpenAI 兼容 audio/speech）
  ttsOnlineKey: "",
  ttsOnlineVoice: ""
};

const $ = (sel) => document.querySelector(sel);
const VOCAB = (typeof window.__WH_VOCAB__ !== "undefined") ? window.__WH_VOCAB__ : null;

/* ---------- 存储（使用共享 storage.js 模块） ---------- */
const IS_EXT = WH_STORE.IS_EXT;
const STORE = {
  async get(defs) { return WH_STORE.syncGet(defs); },
  async set(patch) { return WH_STORE.syncSet(patch); }
};

/* ---------- 等级 UI（v2.25.0：单选 + 多选） ---------- */
/** 已选等级（空 = 「无」：页面不高亮任何等级词）。单选/多选都落在这个数组里。 */
let currentLevelVals = [];

/** 归档里的 level（旧，单值）/ levels（新，数组）→ 规范数组。
 *  levels 存在时以它为准（空数组＝用户主动清空，不要再用旧的 level 复活）；没有 levels 才回落到 level。 */
function normalizeLevels(level, levels) {
  const all = (VOCAB && VOCAB.order) || [];
  const out = [];
  if (Array.isArray(levels)) {
    for (const lv of levels) if (all.includes(lv) && !out.includes(lv)) out.push(lv);
  } else if (level && level !== "none" && all.includes(level)) {
    out.push(level);
  }
  return out;
}

function levelLabel(lv) {
  return (VOCAB && VOCAB.labels && VOCAB.labels[lv]) || lv;
}

function levelCount(lv) {
  return ((VOCAB && VOCAB.lists && VOCAB.lists[lv]) || []).length;
}

function levelSummary(vals) {
  return vals.length ? "已选 " + vals.length + " 个等级（" + vals.map(levelLabel).join(" + ") + "）" : "已关闭生词高亮（未选等级）";
}

/** 改等级 → 立即写回 storage 并通知已打开的网页（与旧行为一致：点即生效） */
function applyLevels(next, note) {
  currentLevelVals = next.slice();
  renderLevelButtons();
  updateLevelStats();
  // level 继续写「首个等级」：背单词/生词本/PDF 阅读器这些单值读取方仍能正常工作
  STORE.set({ levels: currentLevelVals.slice(), level: currentLevelVals[0] || "none" }).then(() => {
    setStatus((note || levelSummary(currentLevelVals)) + "，网页生词已刷新");
    broadcast();
  });
}

function renderLevelButtons() {
  document.querySelectorAll("#levels .level-btn").forEach((b) => {
    const lv = b.dataset.level;
    b.classList.toggle("active", currentLevelVals.includes(lv));
  });
}

function renderLevels(level, levels) {
  currentLevelVals = normalizeLevels(level, levels);
  const box = $("#levels");
  if (!box) return;
  box.textContent = "";
  if (!VOCAB || !VOCAB.order) {
    const warn = document.createElement("div");
    warn.className = "env-warn";
    warn.textContent = "词库数据未加载（vocab-data.js 缺失）。";
    box.appendChild(warn);
    updateLevelStats();
    return;
  }
  // v2.25.3：去掉「无（默认）」按钮——等级按钮本身就是开关（点＝选中，再点＝取消）
  for (const lv of VOCAB.order) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "level-btn";
    btn.dataset.level = lv;
    btn.textContent = levelLabel(lv);
    btn.title = "词库 " + levelCount(lv) + " 词 · 点一下选中，再点一下取消";
    btn.addEventListener("click", () => {
      const wasIn = currentLevelVals.includes(lv);
      const next = wasIn ? currentLevelVals.filter((x) => x !== lv) : currentLevelVals.concat([lv]);
      next.sort((a, b) => VOCAB.order.indexOf(a) - VOCAB.order.indexOf(b));
      applyLevels(next, (wasIn ? "已取消「" : "已选中「") + levelLabel(lv) + "」，" + levelSummary(next));
    });
    box.appendChild(btn);
  }
  renderLevelButtons();
  updateLevelStats();
}

function updateLevelStats() {
  const el = $("#level-stats");
  if (!el || !VOCAB) return;
  const vals = currentLevelVals;
  if (!vals.length) {
    el.textContent = "当前没有选中任何等级：页面不高亮等级词（收藏的生词仍强制高亮）。点等级即可选中，再点一次取消，可以同时选中多个。";
    return;
  }
  const names = vals.map(levelLabel).join(" + ");
  const total = vals.reduce((n, lv) => n + levelCount(lv), 0);
  const line1 = vals.length === 1
    ? "当前仅高亮「" + names + "」：该等级词库 " + total + " 词；"
    : "当前选中 " + vals.length + " 个等级「" + names + "」：合计 " + total + " 词（各等级词库已去重，不会重复高亮）；";
  const line2 = "未选中的等级（无论高于还是低于）、词库未收录的词汇均不高亮；手动收藏的生词仍强制高亮。";
  const line3 = "各等级词数（已去重）：" + VOCAB.order.map((lv) => levelLabel(lv) + " " + levelCount(lv)).join(" / ") + "。";
  el.textContent = line1 + line2 + line3;
}

/* ---------- 主题分段 ---------- */
function renderThemeSeg(theme) {
  document.querySelectorAll("#theme-seg button").forEach((b) => {
    b.classList.toggle("active", b.dataset.theme === theme);
  });
}

/* ---------- 【v2.20.0】截图翻译（OCR）设置 UI ---------- */
function renderOcrAiSelect(selected) {
  const sel = $("#ocrAiId");
  if (!sel) return;
  sel.textContent = "";
  if (!customAIs.length) {
    const o = document.createElement("option");
    o.value = "";
    o.textContent = "（还没有自定义 AI：请到「自定义 AI」页添加）";
    sel.appendChild(o);
    sel.disabled = true;
    return;
  }
  sel.disabled = false;
  for (const ai of customAIs) {
    const o = document.createElement("option");
    o.value = ai.id;
    o.textContent = ai.name || ai.id;
    if (ai.id === selected) o.selected = true;
    sel.appendChild(o);
  }
}

/** 引擎切换：本地识别显示"识别语言"，AI 识别显示"AI 接口" */
function renderOcrUi() {
  const engine = getVal("#ocrEngine") || "offline";
  const aiRow = $("#row-ocr-ai");
  const langRow = $("#row-ocr-lang");
  if (aiRow) aiRow.classList.toggle("hidden", engine !== "ai");
  if (langRow) langRow.classList.toggle("hidden", engine !== "offline");
}

/* ============================================================
 * 【v2.24.0】快捷键中心
 *   解析规则全部在 hotkeys_util.js（与 content.js 共用），这里只负责：
 *   录制、展示、冲突拦截、增删、恢复默认，以及把结果写回 storage。
 * ============================================================ */
const HKU = (typeof window !== "undefined" && window.WH_HOTKEYS) || null;
const hotkeyState = { enabled: true, bindings: {}, notes: [], rightClickCard: true };
let hkRecording = null; // { actionId, index }  index === null 表示「追加」

/* ---------- 【v2.34.2】默认操作说明：既是说明，也是这些操作的开关 ----------
 * v2.34.1 把这张表做成了可编辑的「说明文字」，但踩到一个体验问题：
 *   用户把「鼠标右键」那行删了，网页里右键照样弹卡片——因为删的只是文字，功能没动。
 * 现在内置那 4 行带 b（builtin）标记，直接绑到真实功能上：
 *   · 删除内置行 = 真的停用对应操作（右键→关右键取词；A / Alt+X→清空该动作的键）；
 *   · 停用行会留在表里显示「已停用」，点「恢复」就能开回来；
 *   · 行里的按键不再是死文字，跟着快捷键绑定实时显示（改了键表就跟着变）；
 *   · Esc 是保留键（关卡片 / 取消拉框 / 取消录制），没有可关的开关，删它只删说明。
 * 存档：hotkeys.notes = [{ k, t, b? }]；右键开关存 settings.rightClickCard。
 */
const HK_NOTE_BUILTIN = {
  rightClick: { name: "右键取词" },
  openCard: { name: "取词卡片" },
  ocrShot: { name: "截图翻译" },
  esc: { name: "Esc" }
};

const HK_NOTE_DEFAULTS = [
  { k: "鼠标右键", t: "打开详细释义卡片 / 再次右键同一单词关闭（点击卡片外部或按 Esc 也可关闭）", b: "rightClick" },
  { k: "A", t: "与右键同功能：在鼠标停留处的单词上打开/关闭详细释义卡片（Ctrl/Alt+A 等组合键、输入框内打字不受影响）", b: "openCard" },
  { k: "Alt+X", t: "截图翻译：光标变十字，按住左键拉框，松开即识别并翻译", b: "ocrShot" },
  { k: "Esc", t: "关闭卡片 / 取消截图拉框 / 取消快捷键录制", b: "esc" }
];
/** 正在编辑哪一行：{ index: 数字 } 改已有行；{ index: null } 新增行；null 没在编辑 */
let hkNoteEditing = null;

function hkNoteDefaults() {
  // 深拷一份，别让运行时改动污染出厂常量
  return HK_NOTE_DEFAULTS.map((n) => ({ k: n.k, t: n.t, b: n.b }));
}

/** 存档 → 规范说明数组（字段缺失用出厂说明；空数组保留为空）
 *  notesVer：v2.34.2 起才写 2。老存档（2.34.1 及以前）里那几行没有 b 标记，
 *  说明里也允许"整行删掉"，所以必须迁移：把缺失的内置行补回来，否则用户
 *  在旧版删掉「鼠标右键」后升级上来，右键功能还在、表里却没有能关它的那一行了。 */
function hkNormalizeNotes(raw, notesVer) {
  if (!Array.isArray(raw)) return hkNoteDefaults();
  const cleaned = [];
  for (const n of raw) {
    if (!n || typeof n !== "object") continue;
    const k = String(n.k == null ? "" : n.k).trim();
    const t = String(n.t == null ? "" : n.t).trim();
    const b = n.b && HK_NOTE_BUILTIN[n.b] ? String(n.b) : "";
    if (!k && !t) continue;
    cleaned.push(b ? { k, t, b } : { k, t });
  }
  if (Number(notesVer) >= 2) return cleaned; // 新版存档：原样信任（包括"全删光"）
  return hkMigrateNotes(cleaned);
}

/** 老存档迁移：内置 4 行补齐（保留用户改过的说明文字），自定义行原样排在后面 */
function hkMigrateNotes(legacy) {
  const out = [];
  const used = new Set();
  for (const def of HK_NOTE_DEFAULTS) {
    let idx = legacy.findIndex((n, i) => !used.has(i) && n.b === def.b);
    if (idx < 0) {
      // 旧存档没有 b：按按键文字认领（老表里就写 "鼠标右键" / "A" / "Alt+X" / "Esc"）
      const want = hkNoteKeyText(def.k);
      idx = legacy.findIndex((n, i) => !used.has(i) && !n.b && hkNoteKeyText(n.k) === want);
    }
    if (idx >= 0) {
      used.add(idx);
      out.push({ k: legacy[idx].k || def.k, t: legacy[idx].t || def.t, b: def.b });
    } else {
      out.push({ k: def.k, t: def.t, b: def.b });
    }
  }
  legacy.forEach((n, i) => { if (!used.has(i)) out.push(n); });
  return out;
}

/** 这一行是不是内置操作（可开关） */
function hkNoteIsBuiltin(note) {
  return !!(note && note.b && HK_NOTE_BUILTIN[note.b]);
}

/** 内置行当前显示的按键：跟着真实绑定走，改了键这里立刻同步 */
function hkNoteLiveKey(note) {
  if (!hkNoteIsBuiltin(note)) return hkNoteKeyText(note && note.k);
  switch (note.b) {
    case "rightClick": return "鼠标右键";
    case "esc": return "Esc";
    case "openCard":
    case "ocrShot": {
      const list = (hotkeyState.bindings && hotkeyState.bindings[note.b]) || [];
      return list.length ? list.map((c) => (HKU ? HKU.formatCombo(c) : c)).join(" / ") : "";
    }
    default: return hkNoteKeyText(note.k);
  }
}

/** 内置行当前是否启用（状态直接派生自真实数据，不另存一个会失同步的标记） */
function hkNoteLiveOn(note) {
  if (!hkNoteIsBuiltin(note)) return true;
  switch (note.b) {
    case "rightClick": return hotkeyState.rightClickCard !== false;
    case "openCard":
    case "ocrShot": return ((hotkeyState.bindings && hotkeyState.bindings[note.b]) || []).length > 0;
    case "esc": return true; // Esc 是保留键，永远有效
    default: return true;
  }
}

/** 用户输入的组合键 → 统一显示（"alt+x" → "Alt + X"；"鼠标右键" 这类原样保留） */
function hkNoteKeyText(text) {
  const raw = String(text || "").trim();
  if (!raw) return "";
  if (HKU) {
    const combo = HKU.normalizeComboText(raw);
    if (combo) return HKU.formatCombo(combo);
  }
  return raw;
}

function hkActionById(id) {
  if (!HKU) return null;
  return HKU.ACTIONS.find((a) => a.id === id) || null;
}

function hkLabel(id) {
  const a = hkActionById(id);
  return a ? a.label : id;
}

function hkSetStatus(text, isErr) {
  const el = $("#hkStatus");
  if (!el) return;
  el.textContent = text || "";
  el.classList.toggle("err", !!isErr);
}

function hkResetAddHint() {
  const hint = $("#hkAddHint");
  if (hint) hint.textContent = "选一个动作 → 点「录制按键」→ 按下组合键";
}

/** 读存档 → 界面（enabled 勾选、下拉、胶囊列表、默认操作说明） */
function hkLoad(s) {
  if (!HKU) return;
  const raw = s && s.hotkeys;
  hotkeyState.enabled = !(raw && raw.enabled === false);
  hotkeyState.bindings = HKU.normalizeBindings(raw && raw.bindings, s && s.ocrHotkey);
  hotkeyState.notes = hkNormalizeNotes(raw && raw.notes, raw && raw.notesVer);
  hotkeyState.rightClickCard = !(s && s.rightClickCard === false);
  const en = $("#hkEnabled");
  if (en) en.checked = hotkeyState.enabled;
  hkFillActions();
  hkRender();
  hkRenderNotes();
  hkUpdateOcrLabel();
}

function hkFillActions() {
  const sel = $("#hkAddAction");
  if (!sel || !HKU) return;
  const keep = sel.value;
  sel.textContent = "";
  for (const a of HKU.ACTIONS) {
    const o = document.createElement("option");
    o.value = a.id;
    o.textContent = a.group + " · " + a.label;
    sel.appendChild(o);
  }
  if (keep && HKU.ACTIONS.some((a) => a.id === keep)) sel.value = keep;
}

/** 单个动作行 */
function hkRow(action) {
  const row = document.createElement("div");
  row.className = "row hk-row";
  row.dataset.action = action.id;

  const info = document.createElement("div");
  info.className = "row-info";
  const title = document.createElement("div");
  title.className = "row-title";
  title.textContent = action.label;
  const desc = document.createElement("div");
  desc.className = "row-desc";
  desc.textContent = action.desc;
  info.append(title, desc);
  row.appendChild(info);

  const chips = document.createElement("div");
  chips.className = "hk-chips";
  const list = hotkeyState.bindings[action.id] || [];
  if (!list.length) {
    const empty = document.createElement("span");
    empty.className = "hk-empty";
    empty.textContent = "未设置";
    chips.appendChild(empty);
  }
  list.forEach((combo, i) => {
    const recording = !!hkRecording && hkRecording.actionId === action.id && hkRecording.index === i;
    const conflict = HKU.findConflict(hotkeyState.bindings, combo, action.id);
    const wrap = document.createElement("span");
    wrap.className = "hk-chip" + (recording ? " recording" : "") + (conflict ? " conflict" : "");

    const keyBtn = document.createElement("button");
    keyBtn.type = "button";
    keyBtn.className = "hk-chip-key";
    keyBtn.textContent = recording ? "按下按键…" : HKU.formatCombo(combo);
    keyBtn.title = conflict
      ? "已被「" + hkLabel(conflict) + "」占用，点一下改掉"
      : "点击重新录制";
    keyBtn.addEventListener("click", () => hkStartRecording(action.id, i));

    const del = document.createElement("button");
    del.type = "button";
    del.className = "hk-chip-x";
    del.textContent = "×";
    del.title = "移除这个按键";
    del.addEventListener("click", () => hkRemoveBinding(action.id, i));

    wrap.append(keyBtn, del);
    chips.appendChild(wrap);
  });

  const appending = !!hkRecording && hkRecording.actionId === action.id && hkRecording.index == null;
  if (list.length < HKU.MAX_PER_ACTION) {
    const add = document.createElement("button");
    add.type = "button";
    add.className = "hk-chip-add" + (appending ? " recording" : "");
    add.textContent = appending ? "按下按键…" : "＋ 添加";
    add.title = "给这个动作再加一个按键";
    add.addEventListener("click", () => hkStartRecording(action.id, null));
    chips.appendChild(add);
  }

  row.appendChild(chips);
  return row;
}

/** 重绘整个列表（按动作分组） */
function hkRender() {
  const box = $("#hk-groups");
  if (!box || !HKU) return;
  box.textContent = "";
  const groups = [];
  for (const a of HKU.ACTIONS) if (!groups.includes(a.group)) groups.push(a.group);
  for (const g of groups) {
    const head = document.createElement("div");
    head.className = "hk-group-title";
    head.textContent = g;
    box.appendChild(head);
    for (const a of HKU.ACTIONS) {
      if (a.group === g) box.appendChild(hkRow(a));
    }
  }
  // 说明表里的内置行显示的是「真实按键」，绑定变了要跟着重绘（否则改键后表还写着老键）
  hkRenderNotes();
}

function hkUpdateOcrLabel() {
  const el = $("#ocrHotkeyLabel");
  if (!el) return;
  const list = (hotkeyState.bindings && hotkeyState.bindings.ocrShot) || [];
  el.textContent = list.length ? list.map((c) => (HKU ? HKU.formatCombo(c) : c)).join(" / ") : "未设置";
}

/* ---------- 【v2.34.2】默认操作说明：渲染 / 编辑 / 停用 / 删除 / 新增 ---------- */
function hkRenderNotes() {
  const body = $("#hk-notes");
  if (!body) return;
  body.textContent = "";
  const notes = hotkeyState.notes || [];
  if (!notes.length && !hkNoteEditing) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 3;
    td.className = "hk-note-empty";
    td.textContent = "说明已经全部删掉了。点下面的「＋ 添加一行」可以写自己的备忘，「恢复默认」可以拿回出厂那张表。";
    tr.appendChild(td);
    body.appendChild(tr);
    return;
  }
  notes.forEach((n, i) => body.appendChild(hkNoteRow(n, i)));
  // 新增行排在最下面
  if (hkNoteEditing && hkNoteEditing.index == null) body.appendChild(hkNoteRow({ k: "", t: "" }, null));
  // 编辑态自动对焦（只在编辑中执行，避免每次重绘抢焦点）
  const editing = body.querySelector(".hk-note-editing input");
  if (editing) editing.focus();
}

/** 一行说明：普通态（kbd + 文字 + 操作按钮）或编辑态（说明输入框 + 保存/取消） */
function hkNoteRow(note, index) {
  const editing = !!hkNoteEditing && hkNoteEditing.index === index;
  const builtin = hkNoteIsBuiltin(note);
  const on = hkNoteLiveOn(note);
  const tr = document.createElement("tr");
  if (editing) tr.className = "hk-note-editing";
  else if (!on) tr.className = "hk-note-disabled";

  const tdK = document.createElement("td");
  const tdT = document.createElement("td");
  const tdOps = document.createElement("td");
  tdOps.className = "hk-note-ops";

  const keyText = builtin ? hkNoteLiveKey(note) : hkNoteKeyText(note.k);

  if (editing) {
    // 内置行的按键由真实绑定决定，不给改（改了也不生效＝又一处骗人的东西）
    if (builtin) {
      const kbd = document.createElement("kbd");
      kbd.textContent = keyText || "—";
      kbd.title = note.b === "rightClick" ? "右键取词由下面的开关控制" : "按键在「按动作设置」里改";
      tdK.appendChild(kbd);
    } else {
      const inK = document.createElement("input");
      inK.className = "hk-note-input hk-note-input-k";
      inK.type = "text";
      inK.value = note.k || "";
      inK.placeholder = "按键（如 Alt+X，可留空）";
      tdK.appendChild(inK);
    }

    const inT = document.createElement("input");
    inT.className = "hk-note-input";
    inT.type = "text";
    inT.value = note.t || "";
    inT.placeholder = "说明文字";
    tdT.appendChild(inT);

    const save = document.createElement("button");
    save.type = "button";
    save.className = "hk-note-btn primary";
    save.textContent = "保存";
    save.addEventListener("click", () => hkNoteCommit(index, tdK.querySelector("input") ? tdK.querySelector("input").value : note.k, inT.value));

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "hk-note-btn";
    cancel.textContent = "取消";
    cancel.addEventListener("click", () => { hkNoteEditing = null; hkRenderNotes(); });

    // 回车＝保存，Esc＝取消（说明表里的键盘操作不该和「录制快捷键」抢事件）
    inT.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); save.click(); }
      else if (e.key === "Escape") { e.preventDefault(); cancel.click(); }
    });
    tdOps.append(save, cancel);
  } else {
    const kbd = document.createElement("kbd");
    kbd.textContent = keyText || (on ? "—" : "已移除");
    if (!on) kbd.classList.add("is-off");
    tdK.appendChild(kbd);

    if (!on) tdT.classList.add("hk-note-off");
    tdT.textContent = (on ? "" : "已停用 · ") + (note.t || "");
    if (!keyText) tdT.classList.add("hk-note-only-text");

    const edit = document.createElement("button");
    edit.type = "button";
    edit.className = "hk-note-btn";
    edit.textContent = "编辑";
    edit.title = builtin ? "改这一行的说明文字" : "改这一行的按键文字与说明";
    edit.addEventListener("click", () => { hkNoteEditing = { index }; hkRenderNotes(); });

    // 内置且已停用 → 「恢复」+「删除此说明」；内置且在跑 → 「删除」＝真停用；其余 → 真删
    if (builtin && !on) {
      const resume = document.createElement("button");
      resume.type = "button";
      resume.className = "hk-note-btn primary";
      resume.textContent = "恢复";
      resume.title = "把这个操作重新打开";
      resume.addEventListener("click", () => hkNoteEnable(index));
      const drop = document.createElement("button");
      drop.type = "button";
      drop.className = "hk-note-btn danger";
      drop.textContent = "删除";
      drop.title = "连这一行说明也去掉（功能保持停用）";
      drop.addEventListener("click", () => hkNoteRemove(index));
      tdOps.append(edit, resume, drop);
    } else {
      const del = document.createElement("button");
      del.type = "button";
      del.className = "hk-note-btn danger";
      del.textContent = "删除";
      if (builtin && note.b !== "esc") {
        del.title = "删除＝真的停用这个操作（不是只删一行字）";
      } else if (note.b === "esc") {
        del.title = "Esc 是保留键，删掉只去掉这行说明";
      } else {
        del.title = "删掉这一行说明";
      }
      del.addEventListener("click", () => hkNoteRemove(index));
      tdOps.append(edit, del);
    }
  }

  tr.append(tdK, tdT, tdOps);
  return tr;
}

/** 保存一行（index === null 表示新增）。内置行只改说明文字，按键由真实绑定决定 */
async function hkNoteCommit(index, keyText, descText) {
  const notes = (hotkeyState.notes || []).map((n) => (n.b ? { k: n.k, t: n.t, b: n.b } : { k: n.k, t: n.t }));
  const current = index == null ? null : notes[index];
  const builtin = hkNoteIsBuiltin(current);
  const k = builtin ? current.k : hkNoteKeyText(keyText);
  const t = String(descText || "").trim();
  if (!builtin && !k && !t) {
    hkSetStatus("按键和说明至少填一项，不然这一行是空的", true);
    return;
  }
  if (builtin && !t) {
    hkSetStatus("说明不能留空：想关掉这个操作请点「删除」，它会真的停用", true);
    return;
  }
  const patch = builtin ? { k: current.k, t, b: current.b } : { k, t };
  if (index == null || index >= notes.length) notes.push(patch);
  else notes[index] = patch;
  hotkeyState.notes = notes;
  hkNoteEditing = null;
  hkRenderNotes();
  hkSetStatus("已保存操作说明");
  await hkPersist("已保存操作说明");
}

/** 删除一行：内置操作＝真停用；普通说明 / Esc＝只删文字 */
async function hkNoteRemove(index) {
  const notes = (hotkeyState.notes || []).slice();
  if (index < 0 || index >= notes.length) return;
  const note = notes[index];
  hkNoteEditing = null;
  if (hkNoteIsBuiltin(note) && note.b !== "esc" && hkNoteLiveOn(note)) {
    await hkNoteDisable(note.b);
    return;
  }
  const gone = notes.splice(index, 1)[0];
  hotkeyState.notes = notes;
  hkRenderNotes();
  hkSetStatus(
    hkNoteIsBuiltin(gone)
      ? "已删除这行说明（Esc 是保留键，功能不受影响）"
      : "已删除说明「" + (gone.k || gone.t || "") + "」"
  );
  await hkPersist("已删除一条操作说明");
}

/** 停用内置操作（真的关功能，不是删文字） */
async function hkNoteDisable(actionId) {
  if (actionId === "rightClick") {
    hotkeyState.rightClickCard = false;
    hkRenderNotes();
    hkSetStatus("已停用右键取词：网页里右键恢复浏览器原生菜单（这一行点「恢复」可开回来）");
    await hkPersist("已停用右键取词");
    return;
  }
  const before = ((hotkeyState.bindings && hotkeyState.bindings[actionId]) || []).slice();
  hotkeyState.bindings[actionId] = [];
  hkRender();
  hkRenderNotes();
  const shown = before.length ? before.map((c) => (HKU ? HKU.formatCombo(c) : c)).join(" / ") : "（本来就没绑键）";
  hkSetStatus("已停用「" + hkLabel(actionId) + "」：移除了 " + shown + "，这一行点「恢复」可开回来");
  await hkPersist("已停用「" + hkLabel(actionId) + "」");
}

/** 恢复内置操作（右键开关打开 / 键盘动作没键了就给回出厂键） */
async function hkNoteEnable(index) {
  const note = (hotkeyState.notes || [])[index];
  if (!hkNoteIsBuiltin(note)) return;
  if (note.b === "rightClick") {
    hotkeyState.rightClickCard = true;
  } else if (note.b === "openCard" || note.b === "ocrShot") {
    const list = (hotkeyState.bindings[note.b] || []).slice();
    if (!list.length) {
      const defs = (HKU && HKU.defaultBindings()) || {};
      const want = (defs[note.b] || []).slice();
      // 出厂键可能被别的动作占了，那就别硬塞，交给用户自己录
      const clash = want.find((c) => HKU && HKU.findConflict(hotkeyState.bindings, c, note.b));
      if (clash) {
        hkRenderNotes();
        hkSetStatus("出厂键 " + (HKU ? HKU.formatCombo(clash) : clash) + " 已被别的动作占用：请到上面「按动作设置」里给它录一个键", true);
        return;
      }
      hotkeyState.bindings[note.b] = want;
    }
    hkRender();
  }
  hkRenderNotes();
  hkSetStatus("已恢复「" + (HK_NOTE_BUILTIN[note.b] || {}).name + "」");
  await hkPersist("已恢复「" + (HK_NOTE_BUILTIN[note.b] || {}).name + "」");
}

/* ---------- 录制 ---------- */
function hkStartRecording(actionId, index) {
  if (!HKU) return;
  hkStopRecording();
  const list = hotkeyState.bindings[actionId] || [];
  if (index == null && list.length >= HKU.MAX_PER_ACTION) {
    hkSetStatus("「" + hkLabel(actionId) + "」最多 " + HKU.MAX_PER_ACTION + " 个按键，先移除一个再添加", true);
    return;
  }
  hkRecording = { actionId, index };
  hkRender();
  document.addEventListener("keydown", hkOnKey, true);
  document.addEventListener("mousedown", hkOnOutside, true);
  const cur = index == null ? "" : list[index];
  hkSetStatus(
    "正在录制「" + hkLabel(actionId) + "」" + (cur ? "（替换 " + HKU.formatCombo(cur) + "）" : "") +
    "：请按下组合键，Esc 取消"
  );
  const hint = $("#hkAddHint");
  if (hint) hint.textContent = "正在录制：" + hkLabel(actionId) + "（Esc 取消）";
}

function hkStopRecording() {
  if (!hkRecording) return;
  document.removeEventListener("keydown", hkOnKey, true);
  document.removeEventListener("mousedown", hkOnOutside, true);
  hkRecording = null;
  hkRender();
  hkResetAddHint();
}

function hkOnOutside(e) {
  if (!hkRecording) return;
  // 点胶囊区域内的按钮属于「继续操作」，不取消
  if (e.target && e.target.closest && e.target.closest(".hk-chips,#hkAddRecord")) return;
  hkStopRecording();
  hkSetStatus("已取消录制");
}

function hkOnKey(e) {
  if (!hkRecording) return;
  e.preventDefault();
  e.stopPropagation();
  if (e.key === "Escape") {
    hkStopRecording();
    hkSetStatus("已取消录制");
    return;
  }
  if (HKU.isModifierOnly(e)) return; // 等真正的键
  const combo = HKU.comboFromEvent(e);
  if (!combo) {
    hkSetStatus("这个按键不支持录制，试试字母、数字、F1~F12 或标点", true);
    return;
  }
  hkApplyRecorded(combo);
}

/** 录制到结果 → 校验冲突 → 写入绑定 */
function hkApplyRecorded(combo) {
  const rec = hkRecording;
  if (!rec) return;
  const norm = HKU.normalizeComboText(combo);
  if (!norm) {
    hkStopRecording();
    hkSetStatus("这个按键不支持（Esc 是保留键，用于关闭卡片/取消录制）", true);
    return;
  }
  const owner = HKU.findConflict(hotkeyState.bindings, norm, rec.actionId);
  if (owner) {
    hkStopRecording();
    hkSetStatus("「" + HKU.formatCombo(norm) + "」已被「" + hkLabel(owner) + "」占用：先去那边移除再录", true);
    return;
  }
  const list = (hotkeyState.bindings[rec.actionId] || []).slice();
  if (rec.index == null || rec.index >= list.length) list.push(norm);
  else list[rec.index] = norm;
  hotkeyState.bindings[rec.actionId] = list.filter((c, i) => list.indexOf(c) === i);
  hkStopRecording();

  const notes = [];
  const risky = HKU.riskyReason(norm);
  if (risky) notes.push(risky);
  else if (!HKU.hasModifier(norm)) notes.push("单键快捷键只在网页正文生效，输入框里不会触发");
  hkSetStatus(
    "已把「" + hkLabel(rec.actionId) + "」设为 " + HKU.formatCombo(norm) + (notes.length ? "。" + notes.join("；") : ""),
    risky ? true : false
  );
  hkPersist("「" + hkLabel(rec.actionId) + "」→ " + HKU.formatCombo(norm));
}

function hkRemoveBinding(actionId, index) {
  const list = (hotkeyState.bindings[actionId] || []).slice();
  if (index < 0 || index >= list.length) return;
  const removed = list.splice(index, 1)[0];
  hotkeyState.bindings[actionId] = list;
  hkRender();
  hkSetStatus("已移除 " + (HKU ? HKU.formatCombo(removed) : removed));
  hkPersist("移除「" + hkLabel(actionId) + "」的 " + (HKU ? HKU.formatCombo(removed) : removed));
}

/** 写入 storage（即时生效：options 页自己 broadcast 重扫，content 侧 onChanged 也会热更新） */
async function hkPersist(msg) {
  const primary = (hotkeyState.bindings.ocrShot || [])[0] || "";
  try {
    await STORE.set({
      hotkeys: { enabled: hotkeyState.enabled, bindings: hotkeyState.bindings, notes: hotkeyState.notes, notesVer: 2 },
      rightClickCard: hotkeyState.rightClickCard !== false,
      ocrHotkey: primary
    });
  } catch (e) { /* ignore */ }
  hkUpdateOcrLabel();
  broadcast();
  if (msg) setStatus("✓ " + msg + "（已保存，网页即时生效）");
}


/* ---------- 加载 ---------- */
let customAIs = [];

async function load() {
  const s = await STORE.get(DEFAULTS);
  customAIs = Array.isArray(s.customAIs) ? s.customAIs : [];
  // 元素缺失时跳过（防御：避免单元素缺失导致整页功能不可用）
  const setCheck = (sel, v) => { const el = $(sel); if (el) el.checked = v; };
  const setVal = (sel, v) => { const el = $(sel); if (el) el.value = v; };
  setCheck("#enabled", s.enabled);
  setCheck("#quickTip", s.quickTip);
  setCheck("#autoSpeak", s.autoSpeak);
  setCheck("#compatMode", !!s.compatMode);
  setCheck("#translateEnabled", s.translateEnabled);
  setCheck("#ytCaptionSingleLine", !!s.ytCaptionSingleLine);
  setVal("#ytCaptionTrMode", ["word", "sentence", "word2"].includes(s.ytCaptionTrMode) ? s.ytCaptionTrMode : "sentence");
  setCheck("#ytHoverPause", !!s.ytHoverPause);
  setCheck("#ytSentencePause", !!s.ytSentencePause);
  renderTranslateService(s.translateService || "auto");
  setVal("#translateMode", s.translateMode || "replace");
  renderCustomAIList();
  // 【v2.20.0】截图翻译
  setCheck("#ocrEnabled", s.ocrEnabled !== false);
  hkLoad(s); // 【v2.24.0】快捷键中心（含截图翻译那把键）
  setVal("#ocrEngine", s.ocrEngine === "ai" ? "ai" : "offline");
  setVal("#ocrLang", ["auto", "eng", "chi_sim"].includes(s.ocrLang) ? s.ocrLang : "auto");
  setCheck("#ocrAutoSpeak", s.ocrAutoSpeak !== false);
  renderOcrAiSelect(s.ocrAiId || "");
  renderOcrUi();
  setVal("#minLength", String(s.minLength));
  setVal("#color", s.color);
  setCheck("#underline", s.underline);
  setVal("#userWords", (s.userWords || []).join("\n"));
  renderLevels(s.level, s.levels);
  renderThemeSeg(s.theme);
  applyPageTheme(s.theme);

  // TTS 设置（v2.10.9 统一 TTS 下拉；旧 ttsVoice=语音名/空 自动兼容）
  setVal("#ttsRate", String(s.ttsRate || 0.85));
  setVal("#ttsOnlineUrl", s.ttsOnlineUrl || "");
  setVal("#ttsOnlineKey", s.ttsOnlineKey || "");
  setVal("#ttsOnlineVoice", s.ttsOnlineVoice || "");
  setVal("#ttsProvider", s.ttsProvider || "youdao");
  buildTtsOptions(s.ttsVoice || "");
  renderTtsUi();

  document.querySelectorAll(".color-dot").forEach((dot) => {
    dot.classList.toggle("active", dot.dataset.color === s.color);
  });
}

/* ---------- 主题应用到设置页自身 ---------- */
/* 【v2.34.0】收敛到 Panda 设计语言 M1b 的 theme.js（WHTheme）：
   三态偏好解析、持久化、跨页同步、跟随系统变化、pref 属性与首屏镜像都只在那里面做一份。
   这里只负责"把读到的状态画上去"，不回写存储。 */
function applyPageTheme(theme) {
  if (typeof WHTheme !== "undefined") {
    WHTheme.apply(theme);
    return;
  }
  // 兜底（theme.js 没加载时，行为与旧版一致）
  let resolved = theme;
  if (theme === "auto") {
    resolved = (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light";
  }
  document.documentElement.setAttribute("data-wh-theme", resolved);
  try { localStorage.setItem("wh_theme", theme); } catch (e) { /* 无痕模式忽略 */ }
}

/* 别的页面改了主题（弹窗 / 生词本 / 学习页）或系统主题变了：分段控件与页面一起跟上 */
if (typeof WHTheme !== "undefined") {
  WHTheme.init({ fallback: "light" });
  WHTheme.onChange((theme, pref) => {
    renderThemeSeg(pref);
  });
}

/* ---------- TTS 统一下拉（v2.10.9：两种自动策略 + 本地语音 + 在线服务） ---------- */
function buildTtsOptions(selected) {
  const sel = $("#ttsVoice");
  if (!sel) return;
  sel.textContent = "";
  const mk = (label, value, group) => {
    const o = document.createElement("option");
    o.value = value;
    o.textContent = label;
    if (value === selected) o.selected = true;
    (group || sel).appendChild(o);
  };
  const gLocal = document.createElement("optgroup");
  gLocal.label = "本地语音（离线可用）";
  const gOnline = document.createElement("optgroup");
  gOnline.label = "在线服务";
  mk("自动（本地优先：本地不可用时联网）", "auto:local");
  mk("自动（在线优先：联网失败时用本地）", "auto:online");
  const voices = ("speechSynthesis" in window) ? window.speechSynthesis.getVoices() : [];
  const en = voices.filter((v) => v.lang && v.lang.toLowerCase().startsWith("en"));
  const list = en.length ? en : voices;
  for (const v of list) {
    mk((v.name || v.lang) + (v.localService ? "（本地）" : "（在线）"), v.name || v.lang, gLocal);
  }
  mk("有道 TTS（免 Key，美音，支持整句）", "online:youdao", gOnline);
  mk("谷歌翻译 TTS（免 Key，需能访问谷歌）", "online:google", gOnline);
  mk("OpenAI 兼容接口（自定义地址 + Key）", "online:openai", gOnline);
  sel.appendChild(gLocal);
  sel.appendChild(gOnline);
}
/** 依 TTS 选择联动显示：自动模式的服务下拉、OpenAI 兼容字段 */
function renderTtsUi() {
  const sel = ($("#ttsVoice") && $("#ttsVoice").value) || "auto:local";
  const isAuto = sel === "auto:local" || sel === "auto:online" || sel === "";
  const prov = ($("#ttsProvider") && $("#ttsProvider").value) || "youdao";
  const provRow = $("#auto-provider-row");
  if (provRow && provRow.style) provRow.style.display = isAuto ? "" : "none";
  const fields = $("#openai-tts-fields");
  if (fields && fields.style) fields.style.display = (sel === "online:openai" || (isAuto && prov === "openai")) ? "" : "none";
  const box = $("#online-tts-box");
  if (box && box.style) box.style.display = (isAuto || sel.startsWith("online:")) ? "" : "none";
}
if ("speechSynthesis" in window) {
  window.speechSynthesis.onvoiceschanged = () => buildTtsOptions(document.querySelector("#ttsVoice") ? document.querySelector("#ttsVoice").value : "");
}

/* ---------- 自定义 AI 翻译 ---------- */
function renderTranslateService(selected) {
  const sel = $("#translateService");
  if (!sel) return;
  sel.textContent = "";
  const mkOpt = (v, label) => {
    const o = document.createElement("option");
    o.value = v;
    o.textContent = label;
    if (v === selected) o.selected = true;
    sel.appendChild(o);
  };
  const mkGroup = (label, items) => {
    const g = document.createElement("optgroup");
    g.label = label;
    for (const [v, text] of items) {
      const o = document.createElement("option");
      o.value = v;
      o.textContent = text;
      if (v === selected) o.selected = true;
      g.appendChild(o);
    }
    sel.appendChild(g);
  };
  mkOpt("auto", "自动（Edge 优先 + 国内直连兜底 + 国外并发，全部失败用有道）");
  mkGroup("国内可直连（无需代理）", [
    ["edge", "微软 Edge 翻译（推荐，免 token、批量、全语种）"],
    ["mymemory", "MyMemory（免费，多语种，无需代理）"],
    ["youdao", "有道翻译（国内接口，限频约 4 秒/句）"]
  ]);
  mkGroup("国外服务（部分网络需代理）", [
    ["microsoft", "微软 Bing 翻译（token 流程，Edge 不可用时备用）"],
    ["google", "Google 翻译（需代理，超时自动降级）"]
  ]);
  if (customAIs.length) {
    mkGroup("自定义 AI", customAIs.map((a) => ["custom:" + a.id, "⚡ " + (a.name || a.id)]));
  }
  // 兜底：仅对"已失效的自定义 AI id"补一个占位项（其余选项已在上方分组列出）
  if (selected && !["auto", "edge", "mymemory", "youdao", "microsoft", "google"].includes(selected) && !customAIs.some((a) => "custom:" + a.id === selected)) {
    mkOpt(selected, selected);
  }
}

function renderCustomAIList() {
  const box = $("#custom-ai-list");
  if (!box) return;
  box.textContent = "";
  if (!customAIs.length) {
    box.innerHTML = '<div class="env-warn">尚未添加自定义 AI。填写下方信息后点击「添加」。</div>';
    return;
  }
  for (const ai of customAIs) {
    const row = document.createElement("div");
    row.className = "custom-ai-item";
    const nameSpan = document.createElement("span");
    nameSpan.className = "ai-name";
    nameSpan.textContent = ai.name || ai.id;
    const urlSpan = document.createElement("span");
    urlSpan.className = "ai-url";
    urlSpan.textContent = (ai.url || "") + (ai.model ? " · " + ai.model : "");
    const del = document.createElement("button");
    del.type = "button";
    del.textContent = "删除";
    del.addEventListener("click", () => {
      customAIs = customAIs.filter((x) => x.id !== ai.id);
      renderCustomAIList();
      renderTranslateService($("#translateService") ? $("#translateService").value : "mymemory");
      // 【v2.20.0】被删掉的接口不能继续挂在"截图翻译 → AI 接口"上
      renderOcrAiSelect(getVal("#ocrAiId"));
      STORE.set({ customAIs }).then(() => setStatus("已删除「" + (ai.name || ai.id) + "」"));
    });
    row.appendChild(nameSpan);
    row.appendChild(urlSpan);
    row.appendChild(del);
    box.appendChild(row);
  }
}

function addCustomAI() {
  const name = $("#aiName").value.trim();
  const url = $("#aiUrl").value.trim();
  const key = $("#aiKey").value.trim();
  const model = $("#aiModel").value.trim();
  if (!name || !url) {
    setStatus("请填写名称与 API 地址");
    return;
  }
  if (customAIs.length >= 6) { setStatus("最多添加 6 个自定义 AI"); return; }
  const id = "ai" + Date.now().toString(36);
  customAIs.push({ id, name, url, key, model });
  ["aiName", "aiUrl", "aiKey", "aiModel"].forEach((x) => { const el = $("#" + x); if (el) el.value = ""; });
  renderCustomAIList();
  renderTranslateService("custom:" + id);
  // 【v2.20.0】新加的接口要立刻能选进"截图翻译 → AI 接口"
  renderOcrAiSelect(id);
  STORE.set({ customAIs }).then(() => setStatus("已添加「" + name + "」，可在「翻译服务」中选择"));
}

/* ---------- 保存 ---------- */
function currentTheme() {
  const btn = document.querySelector("#theme-seg button.active");
  return btn ? btn.dataset.theme : "light";
}

/* 模块级读取辅助（save 与自检共用；此前仅定义在 save 内，自检调用报 ReferenceError） */
function getCheck(sel) { const el = $(sel); return el ? el.checked : DEFAULTS[sel.replace("#", "")]; }
function getVal(sel) { const el = $(sel); return el ? el.value : ""; }

async function save() {
  const words = $("#userWords").value
    .split(/[\n,;，；]+/)
    .map((w) => w.trim())
    .filter(Boolean);

  await STORE.set({
    enabled: getCheck("#enabled"),
    quickTip: getCheck("#quickTip"),
    compatMode: getCheck("#compatMode"),
    autoSpeak: getCheck("#autoSpeak"),
    translateEnabled: getCheck("#translateEnabled"),
    ytCaptionSingleLine: getCheck("#ytCaptionSingleLine"),
    ytCaptionTrMode: ["word", "sentence", "word2"].includes(getVal("#ytCaptionTrMode")) ? getVal("#ytCaptionTrMode") : "sentence",
  ytHoverPause: getCheck("#ytHoverPause"),
  ytSentencePause: getCheck("#ytSentencePause"),
    translateService: getVal("#translateService") || "auto",
    translateMode: getVal("#translateMode") || "inline",
    ocrEnabled: getCheck("#ocrEnabled"),
    ocrHotkey: (hotkeyState.bindings.ocrShot || [])[0] || "", // 兼容字段：与快捷键中心里的「截图翻译」保持一致
    hotkeys: { enabled: hotkeyState.enabled, bindings: hotkeyState.bindings, notes: hotkeyState.notes, notesVer: 2 },
    rightClickCard: hotkeyState.rightClickCard !== false, // 【v2.34.2】右键取词开关（在「默认操作说明」里删/恢复那一行）
    ocrEngine: getVal("#ocrEngine") === "ai" ? "ai" : "offline",
    ocrAiId: getVal("#ocrAiId") || "",
    ocrAutoSpeak: getCheck("#ocrAutoSpeak"),
    ocrLang: ["auto", "eng", "chi_sim"].includes(getVal("#ocrLang")) ? getVal("#ocrLang") : "auto",
    customAIs: customAIs,
    ttsProvider: getVal("#ttsProvider") || "youdao",
    ttsVoice: getVal("#ttsVoice") || "",
    ttsRate: parseFloat(getVal("#ttsRate")) || 0.85,
    ttsOnlineUrl: getVal("#ttsOnlineUrl") || "",
    ttsOnlineKey: getVal("#ttsOnlineKey") || "",
    ttsOnlineVoice: getVal("#ttsOnlineVoice") || "",
    minLength: parseInt(getVal("#minLength"), 10) || 3,
    color: getVal("#color") || DEFAULTS.color,
    underline: getCheck("#underline"),
    userWords: words,
    level: currentLevelVals[0] || "none",
    levels: currentLevelVals.slice(),
    theme: currentTheme()
  });
  setStatus(IS_EXT ? "✓ 已保存并立即生效" : "✓ 已保存（预览环境，未写入扩展）");
  broadcast();
}

function broadcast() {
  if (!IS_EXT) return;
  try {
    // 向所有标签页广播重扫（不依赖"活动标签"，避免设置页自身成为活动页时漏发）
    chrome.tabs.query({}, (tabs) => {
      for (const t of tabs || []) {
        if (t.id != null) {
          try { chrome.tabs.sendMessage(t.id, { type: "WH_RESCAN" }).catch(() => {}); } catch (e) { /* ignore */ }
        }
      }
    });
  } catch (e) { /* ignore */ }
}

let statusTimer = null;
function setStatus(text) {
  const st = $("#status");
  st.textContent = text;
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => (st.textContent = ""), 2600);
}

/* ---------- 自检 ---------- */
async function runSelfTest() {
  const box = $("#selftest-result");
  box.innerHTML = '<div class="info spin">正在检测…</div>';
  const lines = [];

  // 1. 分级词库 + 内置释义（检测词用词库内真实存在的词）
  if (VOCAB && VOCAB.order && VOCAB.order.length === 8 && VOCAB.meta) {
    const probes = ["hello", "silent", "explosive"];
    const hasTrans = probes.every((w) => VOCAB.meta[w] && VOCAB.meta[w][0] && VOCAB.meta[w][0].length);
    const hasPhone = probes.some((w) => VOCAB.meta[w] && VOCAB.meta[w][1]);
    lines.push([hasTrans ? "ok" : "fail",
      (hasTrans ? "✓ " : "✗ ") + "分级词库：8 级 " + VOCAB.order.reduce((n, lv) => n + VOCAB.lists[lv].length, 0) +
      " 词，内置释义 " + (hasTrans ? "正常" : "缺失（" + probes.join("/") + "）") +
      "，音标 " + (hasPhone ? "正常" : "缺失")]);
  } else {
    lines.push(["fail", "✗ 分级词库未加载"]);
  }

  // 2. 有道翻译接口（真实查词）
  const t0 = Date.now();
  try {
    const r = await new Promise((resolve) => {
      if (!IS_EXT) { resolve({ ok: false, error: "非扩展环境" }); return; }
      chrome.runtime.sendMessage({ type: "WH_DICT", word: "hello" }, resolve);
    });
    if (r && r.ok) {
      lines.push(["ok", "✓ 有道词典 API：正常（" + (Date.now() - t0) + "ms） hello → " + ((r.translations && r.translations[0]) || "")]);
    } else {
      lines.push([r && r.error && r.error === "非扩展环境" ? "info" : "fail",
        (r && r.error === "非扩展环境" ? "· 有道 API 需在扩展环境检测（当前为预览页）" : "✗ 有道词典 API：失败 " + ((r && r.error) || ""))]);
    }
  } catch (e) {
    lines.push(["fail", "✗ 有道词典 API 异常：" + e.message]);
  }

  // 3. AI 机器翻译兜底（直接测 MyMemory 翻译接口连通性）
  const t1 = Date.now();
  try {
    const r = await new Promise((resolve) => {
      if (!IS_EXT) { resolve({ ok: false, error: "非扩展环境" }); return; }
      chrome.runtime.sendMessage({ type: "WH_AI_TEST" }, resolve);
    });
    if (r && r.ok) {
      const aiTxt = (r.translations && r.translations[0]) || "";
      lines.push(["ok", "✓ AI 翻译兜底：正常（" + (Date.now() - t1) + "ms） → " + aiTxt.replace(/^\[AI 翻译\] /, "").slice(0, 30)]);
    } else {
      lines.push(["info", "· AI 兜底不可用（" + ((r && r.error) || "未知") + "），极端生僻词可能无释义"]);
    }
  } catch (e) {
    lines.push(["info", "· AI 兜底异常：" + e.message]);
  }

  // 4. 语音合成
  lines.push(["speechSynthesis" in window ? "ok" : "fail",
    ("speechSynthesis" in window ? "✓ 语音合成 TTS：可用（优先本地离线语音）" : "✗ 语音合成不可用")]);

  // 4.3 发音（v2.10.9 统一 TTS 下拉）
  const ttsSel = getVal("#ttsVoice") || "auto:local";
  const ttsProv = getVal("#ttsProvider") || "youdao";
  const ttsUrl = getVal("#ttsOnlineUrl") || "";
  const provLabel = ttsProv === "youdao" ? "有道免 Key" : ttsProv === "google" ? "谷歌免 Key" : "OpenAI 兼容";
  if (ttsSel === "auto:local" || ttsSel === "") {
    lines.push(["ok", "✓ TTS：自动（本地优先，失败切" + provLabel + "）"]);
  } else if (ttsSel === "auto:online") {
    lines.push(["ok", "✓ TTS：自动（在线优先【" + provLabel + "】，失败切本地）"]);
  } else if (ttsSel === "online:openai") {
    if (ttsUrl) lines.push(["ok", "✓ TTS：OpenAI 兼容（" + ttsUrl + "）"]);
    else lines.push(["fail", "✗ TTS 为 OpenAI 兼容但未填写接口地址"]);
  } else if (ttsSel.startsWith("online:")) {
    lines.push(["ok", "✓ TTS：在线服务（" + provLabel + "）"]);
  } else {
    lines.push(["ok", "✓ TTS：本地语音「" + ttsSel + "」（离线可用）"]);
  }

  // 4.5 自定义 AI
  lines.push([customAIs.length ? "ok" : "info",
    customAIs.length ? "✓ 自定义 AI：已配置 " + customAIs.length + " 个（" + customAIs.map((a) => a.name || a.id).join("、") + "）" : "· 自定义 AI：未配置（可在上方添加 OpenAI 兼容接口）"]);

  // 4.6 网页翻译服务链路（content → background → 翻译服务整条通道）
  try {
    const cfg = await STORE.get({ translateService: "auto", translateMode: "replace" });
    const svc = cfg.translateService || "auto";
    const mode = cfg.translateMode || "inline";
    const r = await new Promise((resolve) => {
      if (!IS_EXT) { resolve({ ok: false, error: "非扩展环境" }); return; }
      chrome.runtime.sendMessage({ type: "WH_TRANSLATE", text: "Hello world. This is a quick test.", service: svc, lang: "en" }, resolve);
    });
    if (r && r.ok) {
      lines.push(["ok", "✓ 网页翻译链路（" + svc + "/" + mode + "）：正常 → " + String(r.text).slice(0, 34)]);
    } else {
      lines.push([r && r.error === "非扩展环境" ? "info" : "fail",
        (r && r.error === "非扩展环境" ? "· 网页翻译链路需在扩展环境检测（当前为预览页）" : "✗ 网页翻译链路（" + svc + "）：" + ((r && r.error) || "失败") + "，可在弹窗切换翻译服务后重试")]);
    }
  } catch (e) {
    lines.push(["fail", "✗ 网页翻译链路异常：" + e.message]);
  }

  // 5. 存储
  try {
    await STORE.set({ __selftest: 1 });
    await STORE.set({ __selftest: 0 });
    lines.push(["ok", IS_EXT ? "✓ 扩展存储：可读写" : "✓ 本地存储：可读写（预览环境降级）"]);
  } catch (e) {
    lines.push(["fail", "✗ 存储异常：" + e.message]);
  }

  // 自检结果里可能包含翻译接口/自定义 AI 返回的文本，必须用 textContent 渲染，
  // 不能拼 innerHTML（扩展页 XSS 可直接读取 chrome.storage 中的登录 token）。
  box.textContent = "";
  for (const [cls, txt] of lines) {
    const div = document.createElement("div");
    div.className = String(cls || "info").replace(/[^\w-]/g, "");
    div.textContent = String(txt);
    box.appendChild(div);
  }
}

/* ---------- 事件 ---------- */
document.querySelectorAll(".color-dot").forEach((dot) => {
  dot.addEventListener("click", () => {
    $("#color").value = dot.dataset.color;
    document.querySelectorAll(".color-dot").forEach((d) => d.classList.toggle("active", d === dot));
  });
});
$("#color").addEventListener("input", () => {
  document.querySelectorAll(".color-dot").forEach((dot) => {
    dot.classList.toggle("active", dot.dataset.color === $("#color").value);
  });
});
document.querySelectorAll("#theme-seg button").forEach((b) => {
  b.addEventListener("click", () => {
    document.querySelectorAll("#theme-seg button").forEach((x) => x.classList.toggle("active", x === b));
    const apply = () => {
      applyPageTheme(b.dataset.theme);
      setStatus("主题已切换为「" + (b.dataset.theme === "dark" ? "夜间" : b.dataset.theme === "light" ? "日间" : "自动") + "」，设置页与悬浮卡片已同步");
      broadcast();
    };
    // 走统一主题控制器：写盘 + 镜像 + 重绘 + 广播一次到位
    if (typeof WHTheme !== "undefined") {
      WHTheme.set(b.dataset.theme);
      apply();
    } else {
      STORE.set({ theme: b.dataset.theme }).then(apply);
    }
  });
});
// 【v2.10.9】TTS 选择联动：自动模式显示服务下拉；OpenAI 兼容显示地址/Key 字段
const ttsVoiceSel = $("#ttsVoice");
if (ttsVoiceSel) ttsVoiceSel.addEventListener("change", renderTtsUi);
const providerSel = $("#ttsProvider");
if (providerSel) providerSel.addEventListener("change", renderTtsUi);
// 版本号
const verEl = $("#ver");
if (verEl) {
  verEl.textContent = (IS_EXT && chrome.runtime && chrome.runtime.getManifest)
    ? "v" + chrome.runtime.getManifest().version
    : "预览版";
}
$("#save").addEventListener("click", save);
$("#selftest").addEventListener("click", runSelfTest);
const ocrEngineSel = $("#ocrEngine");
if (ocrEngineSel) ocrEngineSel.addEventListener("change", renderOcrUi);
const aiAdd = $("#aiAdd");
if (aiAdd) aiAdd.addEventListener("click", addCustomAI);

/* ---------- 【v2.24.0】快捷键中心交互 ---------- */
const hkEnabledEl = $("#hkEnabled");
if (hkEnabledEl) {
  hkEnabledEl.addEventListener("change", () => {
    hotkeyState.enabled = hkEnabledEl.checked;
    hkPersist(hotkeyState.enabled ? "快捷键已启用" : "快捷键已关闭（网页内不再响应）");
  });
}

const hkAddRecordBtn = $("#hkAddRecord");
if (hkAddRecordBtn) {
  hkAddRecordBtn.addEventListener("click", () => {
    if (!HKU) { hkSetStatus("快捷键模块未加载，请刷新设置页", true); return; }
    const sel = $("#hkAddAction");
    const actionId = sel && sel.value;
    if (!actionId) { hkSetStatus("请先选择一个动作", true); return; }
    const list = hotkeyState.bindings[actionId] || [];
    if (list.length >= HKU.MAX_PER_ACTION) {
      hkSetStatus("「" + hkLabel(actionId) + "」已经有 " + HKU.MAX_PER_ACTION + " 个按键，先移除一个再添加", true);
      return;
    }
    hkStartRecording(actionId, null);
    // 让用户看到正在为哪个动作录制
    const row = document.querySelector('.hk-row[data-action="' + actionId + '"]');
    if (row && row.scrollIntoView) row.scrollIntoView({ block: "center", behavior: "smooth" });
  });
}

const hkResetAllBtn = $("#hkResetAll");
if (hkResetAllBtn) {
  hkResetAllBtn.addEventListener("click", () => {
    if (!HKU) return;
    hkStopRecording();
    hotkeyState.bindings = HKU.defaultBindings();
    hkRender();
    hkSetStatus("已恢复默认快捷键（A 取词卡片 / Alt + X 截图翻译）");
    hkPersist("已恢复默认快捷键");
  });
}

const hkClearAllBtn = $("#hkClearAll");
if (hkClearAllBtn) {
  hkClearAllBtn.addEventListener("click", () => {
    if (!HKU) return;
    const ok = window.confirm("清空所有快捷键？\n\n· 键盘快捷键会全部失效（包括 A 取词、Alt+X 截图翻译）\n· 右键菜单、悬停简译不受影响\n· 之后可以随时「恢复默认」或重新录制");
    if (!ok) return;
    hkStopRecording();
    const empty = {};
    for (const a of HKU.ACTIONS) empty[a.id] = [];
    hotkeyState.bindings = empty;
    hkRender();
    hkSetStatus("已清空全部快捷键");
    hkPersist("已清空全部快捷键");
  });
}

// 「截图翻译」页的按钮 → 跳到快捷键中心并定位到截图翻译那一行
/* ---------- 【v2.34.1】默认操作说明：新增一行 / 恢复出厂说明 ---------- */
const hkNoteAddBtn = $("#hkNoteAdd");
if (hkNoteAddBtn) {
  hkNoteAddBtn.addEventListener("click", () => {
    hkNoteEditing = { index: null };
    hkRenderNotes();
    hkSetStatus("正在新增一条说明：填按键（可留空）与说明文字，回车保存、Esc 取消");
  });
}

const hkNoteResetBtn = $("#hkNoteReset");
if (hkNoteResetBtn) {
  hkNoteResetBtn.addEventListener("click", () => {
    const ok = window.confirm("恢复默认？\n\n· 这张表回到出厂那 4 行，自己改过 / 加过的说明会被覆盖\n· 被停用的操作也会一起打开（右键取词、取词卡片、截图翻译）\n· 你自己换过的按键不会动；只有被清空的才补给出厂键");
    if (!ok) return;
    hkNoteEditing = null;
    hotkeyState.notes = hkNoteDefaults();
    hotkeyState.rightClickCard = true;
    const defs = (HKU && HKU.defaultBindings()) || {};
    for (const id of ["openCard", "ocrShot"]) {
      if (!((hotkeyState.bindings[id] || []).length)) hotkeyState.bindings[id] = (defs[id] || []).slice();
    }
    hkRender();
    hkRenderNotes();
    hkSetStatus("已恢复默认操作说明，被停用的操作也重新打开了");
    hkPersist("已恢复默认操作说明");
  });
}

/* ---------- 【v2.25.0】词汇等级：全选 / 清空 ---------- */
const lvAllBtn = $("#lv-all");
if (lvAllBtn) {
  lvAllBtn.addEventListener("click", () => {
    const all = (VOCAB && VOCAB.order) || [];
    if (!all.length) return;
    applyLevels(all.slice(), "已全选 " + all.length + " 个等级");
  });
}
const lvNoneBtn = $("#lv-none");
if (lvNoneBtn) {
  lvNoneBtn.addEventListener("click", () => {
    if (!currentLevelVals.length) return;
    applyLevels([], "已清空词汇等级（页面不再高亮等级词）");
  });
}

const ocrHotkeyEditBtn = $("#ocrHotkeyEdit");if (ocrHotkeyEditBtn) {
  ocrHotkeyEditBtn.addEventListener("click", () => {
    const nav = document.querySelector('.nav-item[data-pane="keys"]');
    if (nav) nav.click();
    const row = document.querySelector('.hk-row[data-action="ocrShot"]');
    if (row) {
      row.scrollIntoView({ block: "center", behavior: "smooth" });
      row.classList.add("hk-row-flash");
      setTimeout(() => row.classList.remove("hk-row-flash"), 1200);
    }
  });
}

/* 【v2.25.5】关于分区（联系作者 / 支持作者）：复制联系方式、二维码放大、一键填入测试账号、分区互跳 */
(function initAboutPanes() {
  const panes = ["#pane-contact", "#pane-support"].map((s) => $(s)).filter(Boolean);
  if (!panes.length) return;

  async function copyText(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (e) { /* 剪贴板被拒时走兜底 */ }
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.top = "-1000px";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch (e) { return false; }
  }

  panes.forEach((pane) => {
    pane.querySelectorAll("[data-copy]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const text = btn.dataset.copy || "";
        const ok = await copyText(text);
        setStatus(ok ? "已复制：" + text : "复制失败，请手动选中复制");
      });
    });
  });

  // 二维码放大预览：所有 .qr-thumb[data-qr] 共用一个遮罩，点谁放大谁
  const overlay = $("#qrOverlay");
  const overlayImg = overlay ? overlay.querySelector("img") : null;
  const overlayTip = overlay ? overlay.querySelector(".qr-overlay-tip") : null;
  function showQr(src, title, show) {
    if (!overlay) return;
    if (show && src && overlayImg) {
      overlayImg.src = src;
      if (title) {
        overlayImg.alt = title;
        if (overlayTip) overlayTip.textContent = title + " · 点击任意处关闭";
      }
    }
    overlay.classList.toggle("hidden", !show);
  }
  document.querySelectorAll(".qr-thumb[data-qr]").forEach((btn) => {
    btn.addEventListener("click", () => showQr(btn.dataset.qr, btn.dataset.qrTitle, true));
  });
  if (overlay) {
    overlay.addEventListener("click", () => showQr(null, null, false));
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") showQr(null, null, false);
    });
  }

  // 测试账号：点一下自动填进「账号」页并登录（登录由账号模块监听该事件）
  document.querySelectorAll("[data-fill-test]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.dispatchEvent(new CustomEvent("wh-fill-test-account"));
    });
  });

  // 分区互跳（如「支持作者」→「去联系作者」）
  document.querySelectorAll("[data-goto]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const nav = document.querySelector('.nav-item[data-pane="' + btn.dataset.goto + '"]');
      if (nav) nav.click();
    });
  });
})();

/* ---------- 侧边栏导航（Read Frog 风格分区切换） ---------- */
/* 【v2.34.0】分区切换与滚动位置交给 Panda 设计语言 M1c 的 pane-scroll.js（WHPaneScroll）。
   此前这里自己写了一份「切走记位置、切回恢复」的实现，wordlist.js / learn.js 各自又写了一遍，
   三份代码三个形状；而且它只解决了位置记忆，没有关掉滚动锚定（overflow-anchor），
   面板切换时浏览器仍会把旧位置"找回来"。现在只有 pane-scroll.js 一份实现：
   第一次进入从顶部开始、切回恢复原位、重复点不动、顺手关锚定。
   这里只保留「程序化跳转」的入口。 */
const paneScroll = (typeof WHPaneScroll !== "undefined")
  ? WHPaneScroll.bind({ nav: ".nav-item", pane: ".pane", dataKey: "pane" })
  : null;

/* 【v2.17.19】支持 URL hash 直达分区（popup 账号按钮跳转 options.html#account） */
(function () {
  const h = (location.hash || "").replace("#", "");
  if (!h) return;
  const btn = document.querySelector('.nav-item[data-pane="' + h + '"]');
  if (btn) btn.click();
  history.replaceState(null, "", location.pathname); // 清除 hash，避免刷新时重复定位
})();

/* 环境提示 */
if (!IS_EXT) {
  const w = $("#env-warn");
  if (w) w.classList.remove("hidden");
}

load();

/* ---------- 账号（Supabase Auth，v2.17.18） ---------- */
(function initAccount() {
  const loginSec = $("#account-login-sec");
  const infoSec = $("#account-info-sec");
  if (!loginSec || !infoSec || typeof WHAuth === "undefined") return;

  const emailInput = $("#acctEmail");
  const passInput = $("#acctPass");
  const msgEl = $("#acctMsg");
  const emailLabel = $("#acctEmailLabel");
  const planLabel = $("#acctPlanLabel");
  const planBadge = $("#acctPlanBadge");

  let busy = false;

  let sayTimer = null;
  function say(text, isErr) {
    if (!msgEl) return;
    msgEl.textContent = text || "";
    msgEl.classList.toggle("err", !!isErr);
    msgEl.classList.toggle("ok", !isErr && !!text);
    if (sayTimer) { clearTimeout(sayTimer); sayTimer = null; }
    if (text) {
      // 自动消失：成功/进行中 4 秒，错误 6 秒（给足阅读时间）
      sayTimer = setTimeout(() => {
        msgEl.textContent = "";
        msgEl.classList.remove("err", "ok");
        sayTimer = null;
      }, isErr ? 6000 : 4000);
    }
  }

  function fmtDate(iso) {
    if (!iso) return "永久";
    const raw = String(iso);
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
    try {
      const d = new Date(iso);
      return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
    } catch (e) { return raw; }
  }

  function isProMembership(m) {
    if (!m || !m.signed_in || !m.pro) return false;
    if (!m.expires_at) return true;
    const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
    return Number.isFinite(t) && t > Date.now();
  }

  function updateNavChip(m) {
    const chip = document.getElementById("nav-acct-chip");
    if (!chip) return;
    chip.classList.remove("on", "pro");
    if (!m || !m.signed_in) { chip.textContent = "未登录"; return; }
    if (isProMembership(m)) { chip.textContent = "PRO"; chip.classList.add("pro"); return; }
    chip.textContent = "已登录";
    chip.classList.add("on");
  }

  /** 【v2.17.26】只用本地数据拼出"已登录"状态（不联网）：离线/网络慢时先立即渲染，
   *  PRO 与到期时间取 background 上次成功校验的缓存（local.wh_membership） */
  async function localMembership() {
    const peek = WHAuth.peekSession ? await WHAuth.peekSession().catch(() => null) : null;
    if (!peek || !peek.signed_in) return null;
    let cached = null;
    try { cached = ((await chrome.storage.local.get("wh_membership")) || {}).wh_membership || null; } catch (e) { /* ignore */ }
    return {
      signed_in: true,
      offline: true,
      pro: isProMembership(cached),
      plan: (cached && cached.plan) || "free",
      expires_at: (cached && cached.expires_at) || 0,
      email: peek.email || (cached && cached.email) || "",
      reason: "离线/未校验：显示上次校验的会员状态"
    };
  }

  /** 渲染账号面板（refreshUI 的本地预览与联网结果共用） */
  function paintAccount(m) {
    const pro = isProMembership(m);
    updateNavChip(m);
    const offlineNote = $("#acctOfflineNote");
    if (offlineNote) {
      offlineNote.classList.toggle("hidden", !(m && m.offline));
      if (m && m.offline) {
        offlineNote.textContent = "⚠ 当前处于离线状态：登录状态与会员权益沿用上次校验结果（"
          + (pro ? "PRO" : "免费版") + "）。联网后会自动重新校验，无需重新登录。";
      }
    }
    if (m && m.signed_in) {
      loginSec.classList.add("hidden");
      infoSec.classList.remove("hidden");
      if (emailLabel) emailLabel.textContent = (m.email || "—") + (m.offline ? "（离线）" : "");
      if (planBadge) {
        planBadge.textContent = pro ? "PRO" : "免费版";
        planBadge.classList.toggle("pro", pro);
      }
      if (planLabel) {
        planLabel.textContent = pro
          ? "Pro 会员 · 有效期至 " + fmtDate(m.expires_at) + (m.offline ? "（离线，未联网校验）" : "")
          : (m.reason || "免费版，升级后解锁会员功能");
      }
      if (m.offline) say("离线中：已保留登录状态，联网后自动校验", false);
    } else if (m) {
      loginSec.classList.remove("hidden");
      infoSec.classList.add("hidden");
      if (m.reason && m.reason.indexOf("失效") >= 0) say(m.reason, true);
    }
  }

  async function refreshUI() {
    // ① 先用本地会话 + 上次校验缓存立即渲染（离线时不至于干等网络重试十几秒）
    try {
      const lm = await localMembership();
      if (lm) paintAccount(lm);
    } catch (e) { /* ignore */ }
    // ② 联网校验后用真实结果覆盖
    try {
      let m = await WHAuth.getMembership();
      const uncertain = m && /查询失败|拒绝访问|未创建|不存在|异常|网络错误/i.test(String(m.reason || ""));
      if (m && (m.offline || uncertain)) {
        const lm = await localMembership();
        if (lm) {
          m = Object.assign({}, m, lm, {
            offline: !!m.offline,
            reason: m.offline ? "离线：显示上次校验的会员状态" : "会员校验异常：显示上次校验的会员状态"
          });
        }
      }
      paintAccount(m);
      // 【v2.17.20】同步最新会员状态到 background 缓存（content/popup 立即生效）；
      // 离线结果不同步，避免把 PRO 缓存覆盖成免费版
      if (IS_EXT && m && !m.offline && !uncertain) {
        try { chrome.runtime.sendMessage({ type: "WH_MEMBERSHIP_SYNC", membership: m }, () => { void chrome.runtime.lastError; }); } catch (e) { /* ignore */ }
      }
      return m;
    } catch (e) {
      say("状态查询失败：" + (e.message || e), true);
      return null;
    }
  }

  function getCreds() {
    const email = String(emailInput.value || "").trim();
    const pass = String(passInput.value || "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say("请输入有效的邮箱地址", true); return null; }
    if (pass.length < 6) { say("密码至少 6 位", true); return null; }
    return { email, pass };
  }

  /* 【v2.17.26】记住邮箱：浏览器内置密码管理器不作用于 chrome-extension:// 页面，
     这里用插件自己的"记住邮箱"兜底（只存邮箱，绝不存密码） */
  const rememberBox = $("#acctRemember");
  const REMEMBER_KEY = "wh_remember_email";

  async function loadRememberedEmail() {
    if (!rememberBox) return;
    try {
      const o = await chrome.storage.local.get(REMEMBER_KEY);
      const v = o && o[REMEMBER_KEY];
      if (v && v.email) {
        rememberBox.checked = true;
        if (!emailInput.value) emailInput.value = v.email;
      } else {
        rememberBox.checked = false;
      }
    } catch (e) { /* ignore */ }
  }

  async function rememberEmail(email) {
    try {
      if (rememberBox && rememberBox.checked) await chrome.storage.local.set({ [REMEMBER_KEY]: { email } });
      else await chrome.storage.local.remove(REMEMBER_KEY);
    } catch (e) { /* ignore */ }
  }

  if (rememberBox) {
    rememberBox.addEventListener("change", () => {
      if (!rememberBox.checked) { try { chrome.storage.local.remove(REMEMBER_KEY); } catch (e) { /* ignore */ } }
      else if (String(emailInput.value || "").trim()) { try { chrome.storage.local.set({ [REMEMBER_KEY]: { email: String(emailInput.value).trim() } }); } catch (e) { /* ignore */ } }
    });
  }
  loadRememberedEmail();

  async function doLogin() {
    if (busy) return;
    const c = getCreds();
    if (!c) return;
    busy = true; say("登录中…");
    try {
      await WHAuth.signIn(c.email, c.pass);
      passInput.value = "";
      rememberEmail(c.email); // 【v2.17.26】按勾选记住邮箱，下次自动填充
      say("登录成功");
      await refreshUI();
    } catch (e) {
      say(e.message || "登录失败", true);
    } finally { busy = false; }
  }

  async function doSignup() {
    if (busy) return;
    const c = getCreds();
    if (!c) return;
    busy = true; say("注册中…");
    try {
      const r = await WHAuth.signUp(c.email, c.pass);
      if (r.needConfirm) {
        say("注册成功！请到邮箱查收验证邮件，点击链接后再登录");
      } else {
        passInput.value = "";
        say("注册成功，已自动登录");
        await refreshUI();
      }
    } catch (e) {
      say(e.message || "注册失败", true);
    } finally { busy = false; }
  }

  async function doLogout() {
    if (busy) return;
    busy = true;
    try {
      await WHAuth.signOut();
      say("已退出登录");
      emailInput.value = ""; passInput.value = "";
      await refreshUI();
    } catch (e) {
      say("退出失败：" + (e.message || e), true);
    } finally { busy = false; }
  }

  /* 【v2.17.21】忘记密码：验证码重置（邮件 6 位验证码 → 验证 → 设新密码，全程插件内完成） */
  const resetForm = $("#acctResetForm");
  const resetEmail = $("#resetEmail");
  const resetCode = $("#resetCode");
  const resetPass = $("#resetPass");

  function showResetForm(show) {
    if (!resetForm) return;
    resetForm.classList.toggle("hidden", !show);
    if (show) {
      resetEmail.value = String(emailInput.value || "").trim();
      resetCode.value = "";
      resetPass.value = "";
    }
  }

  function doForgot() {
    const email = String(emailInput.value || "").trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say("请先在上方输入你的注册邮箱，再点“忘记密码？”", true); return; }
    showResetForm(true);
    say("已展开重置表单，点“发送验证码”后查收邮件");
  }

  async function doResetSend() {
    if (busy) return;
    const email = String(resetEmail.value || "").trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say("请输入注册邮箱", true); return; }
    busy = true; say("验证码发送中…");
    try {
      await WHAuth.requestPasswordReset(email);
      say("验证码已发送到邮箱（收不到请检查垃圾箱），1 小时内有效");
    } catch (e) {
      say(e.message || "发送失败", true);
    } finally { busy = false; }
  }

  async function doResetSubmit() {
    if (busy) return;
    const email = String(resetEmail.value || "").trim();
    const code = String(resetCode.value || "").trim();
    const pass = String(resetPass.value || "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say("请输入注册邮箱", true); return; }
    if (!/^\d{6,8}$/.test(code)) { say("请输入邮件中的数字验证码（6-8 位）", true); return; }
    if (pass.length < 6) { say("新密码至少 6 位", true); return; }
    busy = true; say("验证中…");
    try {
      await WHAuth.verifyRecoveryCode(email, code);
      await WHAuth.setNewPassword(pass);
      showResetForm(false);
      say("密码已重置并自动登录");
      await refreshUI();
    } catch (e) {
      say(e.message || "重置失败", true);
    } finally { busy = false; }
  }

  async function doRedeem() {
    if (busy) return;
    const input = $("#acctRedeem");
    const code = String(input.value || "").trim();
    if (!code) { say("请输入兑换码", true); return; }
    busy = true; say("兑换中…");
    try {
      const r = await WHAuth.redeemCode(code);
      input.value = "";
      say("兑换成功！Pro 会员有效期至 " + fmtDate(r.expires_at));
      await refreshUI();
    } catch (e) {
      say(e.message || "兑换失败", true);
    } finally { busy = false; }
  }

  // 【v2.17.26】标准 <form> 语义：回车即提交（密码管理器也据此识别登录表单）
  const loginForm = $("#acctLoginForm");
  if (loginForm) loginForm.addEventListener("submit", (e) => { e.preventDefault(); doLogin(); });
  else $("#acctLogin").addEventListener("click", doLogin);
  $("#acctSignup").addEventListener("click", doSignup);
  $("#acctForgot").addEventListener("click", doForgot);
  if ($("#resetSend")) $("#resetSend").addEventListener("click", doResetSend);
  if (resetForm) resetForm.addEventListener("submit", (e) => { e.preventDefault(); doResetSubmit(); });
  else if ($("#resetSubmit")) $("#resetSubmit").addEventListener("click", doResetSubmit);
  if ($("#resetCancel")) $("#resetCancel").addEventListener("click", () => showResetForm(false));
  if (resetCode) resetCode.addEventListener("keydown", (e) => { if (e.key === "Enter") doResetSubmit(); });
  $("#acctLogout").addEventListener("click", doLogout);
  $("#acctRedeemBtn").addEventListener("click", doRedeem);
  $("#acctRedeem").addEventListener("keydown", (e) => { if (e.key === "Enter") doRedeem(); });
  $("#acctRefresh").addEventListener("click", async () => {
    say("刷新中…");
    const m = await refreshUI();
    if (m) say(m.signed_in ? "已刷新" : "", !m.signed_in);
  });
  passInput.addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });

  // 【v2.25.5】联系作者页的「填入并登录」：自动填测试账号 → 跳到账号页 → 直接登录
  document.addEventListener("wh-fill-test-account", async () => {
    emailInput.value = "test@example.com";
    passInput.value = "test1234";
    const navBtn = document.querySelector('.nav-item[data-pane="account"]');
    if (navBtn) navBtn.click();
    say("已填入测试账号，正在登录…");
    await doLogin();
  });

  refreshUI();
})();

/* ---------- 使用手册：目录跳转 + 当前小节高亮 ---------- */
/* 【v2.34.0】交给 Panda 设计语言 M1d 的 manual.js（WHManual）。它随 </body> 前引入即自动接管
   .man-toc / .man-sec / [data-scroll] / [data-goto]。

   为什么删掉这里原来的 IntersectionObserver 版本：观察器把「每一条 intersecting 的小节」
   都标一遍，两节同时命中时后写覆盖前写 —— 实测点第 1 节点亮了第 2 节（#man-pick）、
   点第 3 节亮第 4 节、点第 5 节亮第 6 节，整整偏一节。manual.js 改成确定性判定
   （取最后一个顶部越过判读线的小节），同一位置永远只有一个答案；滚到页面底部直接标最后一节，
   否则最后一节永远顶不到判读线、高亮永远停在倒数第二节。 */
