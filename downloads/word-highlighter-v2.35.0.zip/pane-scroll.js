/*! Panda 设计语言 · M1c 分区滚动控制器（pane-scroll.js）
 *
 *  为什么有这个文件：
 *  设置页 / 列表页的滚动容器都是**文档本身**——侧栏 sticky、主区随内容长高，整页共用同一个
 *  `scrollY`。于是浏览器只认识"一个滚动位置"，分区（设置页 .pane）与标签页（列表页 .s-tab-pane）
 *  之间没有各自的记忆。在长分区往下滑之后点别的分区，那个纵向位置会被原样套到新分区上：
 *  短分区直接被顶到它自己的最底部，长分区从中间开始——用户看到的就是
 *  「换个设置项，一打开就停在这一页的最底部」，而且时好时坏（取决于上一个分区滑了多深）。
 *
 *  实测（1200×820，先在「常规」分区滑到底再点别的分区）：
 *    点 contact → 302/302（正好底部）   keys → 796/796   manual → 5072/5072
 *  接上本控制器：
 *    点 contact → 0（分区标题在顶部）   keys → 0        manual → 0
 *
 *  契约（三条，别改）：
 *  1. 第一次进入的分区一律从顶部开始；
 *  2. 切走时记住旧分区的位置，切回来恢复（长列表 / 使用手册才用得下去）；
 *  3. 重复点击当前分区不动位置；同时关掉浏览器滚动锚定（overflow-anchor），
 *     否则它在面板切换、内容高度突变的同一帧把旧位置"找回来"。
 *
 *  用法（两种，二选一，**不要和页面自己的切换逻辑并存**）：
 *
 *    A. 只要把文件放进来，什么都不用写——它会自动接管：
 *         <script src="pane-scroll.js"></script>   <!-- 放在 </body> 前 -->
 *       认得两套约定：`[data-pane] → #pane-<值>`（设置页）与 `[data-tab] → #tab-<值>`（列表页标签）。
 *
 *    B. 显式接管（骨架/类名变体、需要程序化跳转时）：
 *         const api = WHPaneScroll.bind({ nav: ".nav-item", pane: ".pane" });
 *         api.activate("keys");            // 等价于点侧栏「快捷键」
 *         api.activate("keys", { scroll: 0 });  // 跳过去，并且停在指定位置
 *         api.y();                         // 当前滚动位置
 *
 *  和「就地跳转」搭配：设置页里从 A 分区跳到 B 分区再滚到某一行，写
 *    api.activate("keys"); 然后 target.scrollIntoView({ block: "center" })
 *  ——activate 先把位置落到 B 分区的记忆位置（第一次是顶部），再 smooth 滚到目标行，两者不打架。
 */
(function (global) {
  "use strict";

  /** 每个分组一份记忆：key = nav|pane 选择器，value = Map(paneId → scrollY) */
  const groups = new Map();
  /** 已经绑定过的元素，防止同一页引两次脚本导致双重切换 */
  const bound = new WeakSet();
  let anchorOff = false;

  const scroller = () => document.scrollingElement || document.documentElement;

  function pageScrollY() {
    const de = scroller();
    return Math.max(0, Math.round(global.scrollY || (de && de.scrollTop) || 0));
  }

  function scrollPageTo(y) {
    const top = Math.max(0, Math.round(y) || 0);
    global.scrollTo(0, top);
    // 兜底：个别 Chromium 版本在 display 切换的同一帧里会把 scrollTo 吞掉
    const de = scroller();
    if (de && top === 0 && (de.scrollTop || 0) !== 0) de.scrollTop = 0;
  }

  /** 关掉滚动锚定：内容高度突变时浏览器别再自己"找回"旧位置 */
  function disableAnchor() {
    if (anchorOff) return;
    anchorOff = true;
    const de = scroller();
    if (de) de.style.overflowAnchor = "none";
    if (document.body) document.body.style.overflowAnchor = "none";
  }

  function paneIdOf(item, o) {
    const raw = item.dataset ? item.dataset[o.dataKey] : "";
    if (!raw) return "";
    const prefix = o.prefix != null ? o.prefix : o.dataKey === "tab" ? "tab-" : "pane-";
    return prefix + raw;
  }

  /**
   * 接管一组「导航项 ↔ 分区」的切换与滚动。
   * @param {{nav?: string, pane?: string, dataKey?: string, prefix?: string, activeClass?: string}} [opts]
   */
  function bind(opts) {
    const o = {
      nav: ".nav-item",
      pane: ".pane",
      dataKey: "pane",
      activeClass: "active",
      prefix: null,
      ...(opts || {}),
    };
    const items = Array.from(document.querySelectorAll(o.nav + "[" + "data-" + o.dataKey + "]"));
    const panes = Array.from(document.querySelectorAll(o.pane));
    if (!items.length || !panes.length) return null;

    const key = o.nav + "|" + o.pane;
    const memo = groups.get(key) || new Map();
    groups.set(key, memo);
    disableAnchor();

    const activePaneId = () => {
      const p = document.querySelector(o.pane + "." + o.activeClass);
      return p ? p.id : "";
    };

    function show(id, targetItem, override) {
      const leaving = activePaneId();
      if (leaving && leaving !== id) memo.set(leaving, pageScrollY());
      items.forEach((b) => b.classList.toggle(o.activeClass, b === targetItem));
      panes.forEach((p) => p.classList.toggle(o.activeClass, p.id === id));
      scrollPageTo(override != null ? override : memo.has(id) ? memo.get(id) : 0);
    }

    for (const item of items) {
      if (bound.has(item)) continue;
      bound.add(item);
      item.addEventListener("click", () => {
        const id = paneIdOf(item, o);
        if (!id || !document.getElementById(id)) return; // 不是分区导航（可能是纯动作按钮）
        if (activePaneId() === id) return; // 重复点当前分区：位置不动
        show(id, item);
      });
    }

    const api = {
      /** 切到某个分区（等价于点对应的导航项） */
      activate(id, { scroll } = {}) {
        if (!id || !document.getElementById(id)) return false;
        const item = items.find((b) => paneIdOf(b, o) === id) || null;
        show(id, item, scroll);
        return true;
      },
      /** 记住当前分区的滚动位置（长任务前后调用，避免渲染把位置吃掉） */
      remember() {
        const id = activePaneId();
        if (id) memo.set(id, pageScrollY());
      },
      y: pageScrollY,
      scrollTo: scrollPageTo,
      /** 清空记忆：所有分区下次都从顶部开始 */
      reset() {
        memo.clear();
      },
      memo,
    };
    return api;
  }

  /** 按页面里已有的结构自动接管（认得设置页与列表页两套约定） */
  function auto() {
    const apis = [];
    if (document.querySelector(".nav-item[data-pane]") && document.querySelector(".pane")) {
      apis.push(bind({ nav: ".nav-item", pane: ".pane", dataKey: "pane" }));
    }
    if (document.querySelector(".s-tab[data-tab]") && document.querySelector(".s-tab-pane")) {
      apis.push(bind({ nav: ".s-tab", pane: ".s-tab-pane", dataKey: "tab", prefix: "tab-" }));
    }
    return apis.filter(Boolean);
  }

  global.WHPaneScroll = { bind, auto, y: pageScrollY, scrollTo: scrollPageTo };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", auto, { once: true });
  } else {
    auto();
  }
})(typeof window !== "undefined" ? window : globalThis);
