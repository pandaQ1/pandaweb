/**
 * account-pane.js —— 设置页「账号」分区的逻辑（Panda 设计语言 §7.1）
 *
 * 为什么不再有 account.html：设置页是这个扩展所有设置的唯一界面与统一入口。
 * 账号（登录 / 注册 / 找回 / 兑换 / 会员状态 / 退出）只是其中一个分区，
 * 分区内的多态切换用分段控件（.seg），不再另开一页。
 *
 * 依赖：auth_util.js（WHAuth）、account-pane.css（零件样式）、options.css（骨架）
 * id 契约见 options.html 的 #pane-account；改名要同步改这里和 about.js 的「填入并登录」约定。
 */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));
  const show = (el, on) => el && el.classList.toggle("hidden", !on);
  const REMEMBER_KEY = "bili_login_email";

  function say(el, text, kind) {
    if (!el) return;
    el.textContent = text || "";
    el.classList.remove("ok", "err");
    if (kind) el.classList.add(kind);
  }

  const fmtDate = (v) => {
    if (!v) return "";
    const t = typeof v === "number" ? v : Date.parse(v);
    if (!Number.isFinite(t)) return "";
    const d = new Date(t);
    const p = (n) => String(n).padStart(2, "0");
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
  };

  function isPro(m) {
    if (!m || !m.signed_in || !m.pro) return false;
    if (!m.expires_at) return true;
    const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
    return Number.isFinite(t) && t > Date.now();
  }

  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r || { ok: false });
        });
      } catch (e) {
        resolve({ ok: false, error: String((e && e.message) || e) });
      }
    });
  }

  /** service worker 缓存会员快照 60 秒：登录/退出/兑换后必须让它立刻重取 */
  async function syncBackground() {
    try { await send({ type: "PM_REFRESH_AUTH" }); } catch (e) { /* ignore */ }
  }

  let busy = false;
  function setBusy(on) {
    busy = on;
    $$("#pane-account button").forEach((b) => {
      if (b.dataset.authTab) return; // 分段控件始终可点
      b.disabled = on;
    });
  }

  /* ---------------- 渲染 ---------------- */
  async function render() {
    let sess = null;
    try { sess = await WHAuth.peekSession(); } catch (e) { sess = null; }
    const signed = !!(sess && sess.signed_in);

    show($("#signed"), signed);
    show($("#guest"), !signed);

    if (!signed) {
      $("#whoEmail").textContent = "未登录";
      $("#whoPlan").textContent = "登录并激活 PRO 后启用全部增强";
      paintPlan(false, null);
      await paintQuota(false);
      return;
    }

    $("#whoEmail").textContent = (sess.user && sess.user.email) || "（未知邮箱）";
    let m = null;
    try { m = await WHAuth.getMembership(); } catch (e) { m = null; }
    const pro = isPro(m);
    $("#whoPlan").textContent = pro
      ? (m && m.expires_at ? "PRO 会员 · 有效期至 " + fmtDate(m.expires_at) : "PRO 会员")
      : (m && m.offline ? "免费账号（离线，联网后自动校验）" : "免费账号 · 每天 3 个视频 · 最高 720P");
    paintPlan(pro, m);
    await paintQuota(pro);
  }

  function paintPlan(pro, m) {
    const badgeCls = "account-badge" + (pro ? " pro" : " free");
    const label = pro ? "PRO" : (m && m.signed_in ? "FREE" : "GUEST");
    [$("#whoBadge"), $("#planBadge")].forEach((el) => {
      if (!el) return;
      el.className = badgeCls;
      el.textContent = label;
    });
    if ($("#planExpiry")) {
      $("#planExpiry").textContent = pro && m && m.expires_at ? fmtDate(m.expires_at) : "—";
    }
    const chip = $("#navAcctChip");
    if (chip) {
      chip.className = "nav-chip" + (pro ? " pro" : m && m.signed_in ? " on" : "");
      chip.textContent = pro ? "PRO" : m && m.signed_in ? "已登录" : "未登录";
    }
  }

  /** 今日额度：以 service worker 的快照为准（与弹窗同一份口径） */
  async function paintQuota(pro) {
    const num = $("#quotaNum");
    const desc = $("#quotaDesc");
    const r = await send({ type: "PM_GET_STATE" });
    const q = (r && r.quota) || null;
    if (pro) {
      if (num) num.textContent = "不限";
      if (desc) desc.textContent = "PRO 会员：不限次数，全部清晰度、弹幕与选集批量都可用。";
      return;
    }
    if (q && typeof q.remaining === "number") {
      if (num) num.textContent = q.remaining + " / " + q.free;
      if (desc) desc.textContent = "免费账号每天 " + q.free + " 个视频、最高 720P；当地日期每天归零。";
      return;
    }
    if (num) num.textContent = "—";
    if (desc) desc.textContent = "免费账号每天 3 个视频，PRO 不限次数。";
  }

  /* ---------------- 分区内三段：登录 | 注册 | 找回密码 ---------------- */
  function activateAuthTab(tab) {
    $$("#authSeg [data-auth-tab]").forEach((b) => {
      const on = b.dataset.authTab === tab;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
    show($("#formLogin"), tab === "login");
    show($("#formSignup"), tab === "signup");
    show($("#formReset"), tab === "reset");
  }

  $$("#authSeg [data-auth-tab]").forEach((btn) => {
    btn.addEventListener("click", () => activateAuthTab(btn.dataset.authTab));
  });

  /* ---------------- 登录 / 注册 / 找回 ---------------- */
  $("#formLogin").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (busy) return;
    const msg = $("#msgLogin");
    setBusy(true);
    say(msg, "登录中…");
    try {
      await WHAuth.signIn($("#loginEmail").value.trim(), $("#loginPassword").value);
      const remember = $("#rememberEmail");
      try {
        if (remember && remember.checked) localStorage.setItem(REMEMBER_KEY, $("#loginEmail").value.trim());
        else localStorage.removeItem(REMEMBER_KEY);
      } catch (err) { /* 隐私模式忽略 */ }
      $("#loginPassword").value = "";
      say(msg, "");
      await syncBackground();
      await render();
      if ($("#signed").classList.contains("hidden")) say(msg, "登录失败：没拿到会话，请重试", "err");
    } catch (err) {
      say(msg, (err && err.message) || "登录失败", "err");
    } finally { setBusy(false); }
  });

  $("#formSignup").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (busy) return;
    const msg = $("#msgSignup");
    const p1 = $("#signupPassword").value;
    const p2 = $("#signupPassword2").value;
    if (p1 !== p2) { say(msg, "两次输入的密码不一致", "err"); return; }
    setBusy(true);
    say(msg, "注册中…");
    try {
      const r = await WHAuth.signUp($("#signupEmail").value.trim(), p1);
      if (r && r.needConfirm) {
        say(msg, "注册成功，请到邮箱确认后再登录", "ok");
        activateAuthTab("login");
      } else {
        say(msg, "注册成功，已登录", "ok");
        await syncBackground();
        await render();
      }
    } catch (err) {
      say(msg, (err && err.message) || "注册失败", "err");
    } finally { setBusy(false); }
  });

  $("#formReset").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (busy) return;
    const msg = $("#msgReset");
    setBusy(true);
    try {
      const step2 = $("#resetStep2");
      if (step2 && !step2.classList.contains("hidden")) {
        if ($("#resetPassword").value !== $("#resetPassword2").value) {
          say(msg, "两次输入的新密码不一致", "err");
          return;
        }
        say(msg, "重设中…");
        await WHAuth.verifyRecoveryCode($("#resetEmail").value.trim(), $("#resetCode").value.trim());
        await WHAuth.setNewPassword($("#resetPassword").value);
        say(msg, "密码已重设，请用新密码登录", "ok");
        show($("#resetStep2"), false);
        show($("#resetStep1"), true);
        activateAuthTab("login");
      } else {
        say(msg, "发送中…");
        await WHAuth.requestPasswordReset($("#resetEmail").value.trim());
        say(msg, "验证码已发送，请查收邮箱", "ok");
        show($("#resetStep1"), false);
        show($("#resetStep2"), true);
      }
    } catch (err) {
      say(msg, (err && err.message) || "操作失败", "err");
    } finally { setBusy(false); }
  });

  /* ---------------- 兑换 / 刷新 / 退出 ---------------- */
  $("#redeemForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (busy) return;
    const code = ($("#redeem").value || "").trim();
    const msg = $("#msgSigned").classList.contains("hidden") ? $("#msgLogin") : $("#msgSigned");
    if (!code) { say(msg, "请输入兑换码", "err"); return; }
    const sess = await WHAuth.peekSession().catch(() => null);
    if (!sess || !sess.signed_in) {
      say($("#msgLogin"), "兑换前需要先登录", "err");
      activateAuthTab("login");
      return;
    }
    setBusy(true);
    say($("#msgSigned"), "兑换中…");
    try {
      const r = await WHAuth.redeemCode(code);
      say($("#msgSigned"), "兑换成功！PRO 有效期至 " + fmtDate(r && r.expires_at), "ok");
      $("#redeem").value = "";
      await syncBackground();
      await render();
    } catch (err) {
      say($("#msgSigned"), (err && err.message) || "兑换失败", "err");
    } finally { setBusy(false); }
  });

  $("#btnRefresh").addEventListener("click", async () => {
    say($("#msgSigned"), "刷新中…");
    await syncBackground();
    await render();
    say($("#msgSigned"), "已刷新", "ok");
  });

  $("#btnSignOut").addEventListener("click", async () => {
    if (!confirm("退出登录后本地会话会被清除，PRO 权益需要重新登录才能恢复。确定退出？")) return;
    setBusy(true);
    try { await WHAuth.signOut(); } catch (e) { /* ignore */ }
    await syncBackground();
    setBusy(false);
    await render();
    activateAuthTab("login");
    say($("#msgLogin"), "已退出登录");
  });

  /* ---------------- 「填入并登录」：关于组的约定事件 ----------------
   * 联系作者 / 支持作者两页的按钮带 data-fill-test，about.js 会广播
   * `wh-fill-test-account`（detail 可带 email / password，没带就用下面的公用测试账号）。
   * 本分区接住它：切到账号分区 → 填表 → 直接提交，用户点一下就能进免费档。
   * 这个测试账号与其它 Panda 插件是同一套账号服务，密码公开，只用于体验会员功能。 */
  const TEST_EMAIL = "test@example.com";
  const TEST_PASS = "test1234";

  document.addEventListener("wh-fill-test-account", async (ev) => {
    if (ev) ev.preventDefault(); // 告诉 about.js：这个页面自己处理，别再填一遍
    const d = (ev && ev.detail) || {};
    const email = d.email || TEST_EMAIL;
    const password = d.password || TEST_PASS;

    const nav = document.querySelector('.nav-item[data-pane="account"]');
    if (nav) nav.click(); // 从「联系作者」跳回账号分区
    activateAuthTab("login");
    $("#loginEmail").value = email;
    $("#loginPassword").value = password;
    say($("#msgLogin"), "已填入测试账号 " + email + "，正在登录…");
    if ($("#formLogin").requestSubmit) $("#formLogin").requestSubmit();
    else $("#formLogin").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
  });

  /* ---------------- 记住邮箱 ---------------- */
  try {
    const saved = localStorage.getItem(REMEMBER_KEY);
    if (saved) {
      $("#loginEmail").value = saved;
      const box = $("#rememberEmail");
      if (box) box.checked = true;
    }
  } catch (e) { /* ignore */ }

  /* ---------------- 跨页同步 ---------------- */
  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && (changes.bili_auth || changes.bili_membership || changes.bili_limits)) {
        render().catch(() => {});
      }
    });
  }

  render().catch(() => {});
})();
