/*! Panda 设计语言 · M1e 关于组控制器（about.js）
 *
 *  为什么有这个文件：
 *  「联系作者 / 支持作者」这两页看着只是排了一堆联系方式和二维码，实际上**四类东西都要动**：
 *  复制联系方式、点二维码放大、一键填入测试账号、分区互跳。原版把这些写在设置页自己的
 *  options.js 里（十来万字节的文件里夹着 70 行），复刻 HTML 的人几乎不会把它一起搬走——
 *  于是新插件的关于页「看起来一模一样」，点下去什么都不发生：
 *    · 点「复制链接」没反馈      → 用户以为没复制成功（无声的复制等于坏掉）
 *    · 点二维码不放大            → 电脑上扫不了 132px 的小图
 *    · 点「填入并登录」没反应    → 免费体验路径直接断掉
 *    · 点「去联系作者」不切页    → 写在按钮上的承诺没人执行
 *  再加上图片没跟着落地（`images/wechat-qr.png` 之类的 PNG 不在项目里），
 *  页面上就只剩一个裂图图标——这就是"复刻了但没复现"最常见的四连。
 *  所以这里把四件事做成**独立行为底座**，和 pane-scroll.js / manual.js 一个用法：
 *  HTML 照抄 + 引一个脚本 + 放三张图，效果就与参考实现一致。
 *
 *  用法（放在 </body> 前；自动接管下列约定，不需要写任何页面逻辑）：
 *
 *    <script src="about.js"></script>
 *
 *    [data-copy="要复制的文本"]        点击复制（Clipboard API → execCommand 兜底），按钮态 + 读屏播报
 *    .qr-thumb[data-qr="图片路径"]     点击把这张图放大到全局 .qr-overlay；data-qr-title 作为说明
 *    [data-fill-test]                  填入测试账号并登录（data-test-email / data-test-pass 可覆盖默认值）
 *    [data-goto="paneId"]              跳到某个分区（等价于点侧栏那一项）
 *
 *  显式接管（类名变体或需要程序化调用）：
 *
 *    const api = WHAbout.bind();
 *    api.copy("pandaQ1");            // 复制并给出反馈
 *    api.openQr("images/wechat-qr.png", "作者个人微信");
 *    api.goTo("contact");            // 切到联系作者分区
 *
 *  契约：
 *  1. 复制先走 `navigator.clipboard`，被拒（`file://`、无权限、非安全上下文）再走隐藏 textarea +
 *     `execCommand("copy")` 兜底；两条都失败才报错，报错要说"手动选中复制"，不能静默；
 *  2. 放大层全页共用**一个** `.qr-overlay`（没有就自己建一个），点谁放大谁；打开时锁页面滚动，
 *     `Esc` 或点任意处关闭，关闭后焦点回到刚才那张缩略图——不还焦点，键盘用户会掉到页首；
 *  3. 「填入并登录」先广播 `wh-fill-test-account` 给页面自己的账号模块（panda_auth 的 account.js 就是这个约定），
 *     下一帧发现输入框还没被填上，就自己填 `#acctEmail` / `#acctPass` 并提交——
 *     没有账号模块的页面也能用，有账号模块的页面不会被登录两次；
 *  4. 缩略图加载失败（图片没跟着落地）时，在控制台**点名缺哪个文件**，并把缩略图改成"缺图"占位块，
 *     不留裂图图标；把图放进 `images/` 就自动恢复，不需要改 HTML。
 */
(function (global) {
  "use strict";

  const DEFAULT_TEST_EMAIL = "test@example.com";
  const DEFAULT_TEST_PASS = "test1234";
  /** 复制成功的按钮态停留时长（与 .contact-btn 的过渡时长对得上） */
  const FLASH_MS = 1400;

  const bound = new WeakSet();
  let live = null;
  let lastFocus = null;

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  /* ------------------------------------------------------------ 自带状态样式 */

  /* 三个状态类（.is-copied / .is-error / .is-missing）与读屏容器 .ui-sr 的本体样式由本文件带，
     不写进 options.css：options.css 是从源扩展逐字节同步来的成稿（见 DESIGN.md §十一），
     往里加规则下次同步就被抹掉；而状态样式没了，"复制成功""缺图"这些反馈就变成有 class 没画面。
     MV3 默认 CSP 只限 script-src（`script-src 'self'; object-src 'self'`），不限制 style-src，
     所以这里插一段 <style> 是安全的；被更严的宿主策略拦掉时会静默跳过，功能不受影响。 */
  const STYLE = [
    ".contact-btn.is-copied{border-color:var(--ui-known,#3e7a52);color:var(--ui-known,#3e7a52)}",
    ".contact-btn.is-error{border-color:var(--ui-danger,#dc2626);color:var(--ui-danger,#dc2626)}",
    ".qr-thumb.is-missing{position:relative;cursor:not-allowed;border-style:dashed;background:transparent}",
    ".qr-thumb.is-missing img{opacity:0}",
    ".qr-thumb.is-missing::after{content:attr(data-qr-missing);position:absolute;inset:0;display:flex;" +
      "align-items:center;justify-content:center;padding:10px;font-size:11.5px;line-height:1.45;" +
      "text-align:center;white-space:pre-wrap;word-break:break-all;color:var(--ui-muted,#71717a)}",
    ".ui-sr{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;" +
      "clip:rect(0 0 0 0);white-space:nowrap;border:0}",
  ].join("\n");

  function ensureStyles() {
    if (document.getElementById("wh-about-style")) return;
    try {
      const style = document.createElement("style");
      style.id = "wh-about-style";
      style.textContent = STYLE;
      (document.head || document.documentElement).appendChild(style);
    } catch (e) {
      /* 宿主 CSP 比 MV3 默认更严时放弃：交互照常，只是少了状态色 */
    }
  }

  /* ------------------------------------------------------------ 反馈 */

  /** 读屏播报：视觉隐藏但 aria-live 能读到（复制 / 登录这类"没有画面变化"的操作必须播报） */
  function announce(text) {
    if (!text) return;
    if (!live) {
      live = document.createElement("div");
      live.className = "ui-sr";
      live.setAttribute("role", "status");
      live.setAttribute("aria-live", "polite");
      document.body.appendChild(live);
    }
    // 同一句话连点两次也要重播：清空再写，浏览器才会认成新消息
    live.textContent = "";
    global.setTimeout(() => {
      live.textContent = text;
    }, 16);
  }

  /** 页面自己的状态条优先（设置页的 #save-status），没有就只播报 */
  function say(text, isOk) {
    const el = $("#save-status") || $("#acctMsg");
    if (el) {
      el.textContent = text || "";
      if (el.classList) {
        el.classList.toggle("ok", !!isOk);
        el.classList.toggle("error", isOk === false);
      }
      global.clearTimeout(say._t);
      say._t = global.setTimeout(() => {
        if (el.textContent === text) el.textContent = "";
      }, 2400);
    }
    announce(text);
  }

  /** 按钮态：文案临时换成「已复制」再还原，让"点到了"这件事有画面证据 */
  function flash(btn, label) {
    if (!btn) return;
    if (!btn.dataset.aboutLabel) btn.dataset.aboutLabel = btn.textContent;
    btn.textContent = label;
    btn.classList.add("is-copied");
    btn.classList.remove("is-error");
    global.clearTimeout(btn._aboutT);
    btn._aboutT = global.setTimeout(() => {
      btn.textContent = btn.dataset.aboutLabel;
      btn.classList.remove("is-copied");
    }, FLASH_MS);
  }

  /* ------------------------------------------------------------ 复制 */

  async function copyText(text) {
    const value = String(text == null ? "" : text);
    if (!value) return false;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(value);
        return true;
      }
    } catch (e) {
      /* 被拒（file:// / 无权限 / 非安全上下文）时走兜底，不要在这里 return false */
    }
    try {
      const ta = document.createElement("textarea");
      ta.value = value;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.top = "-1000px";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return !!ok;
    } catch (e) {
      return false;
    }
  }

  async function copyFrom(btn) {
    const text = btn.dataset.copy || "";
    const ok = await copyText(text);
    if (ok) {
      flash(btn, "已复制");
      say("已复制：" + text, true);
    } else {
      flash(btn, "复制失败");
      btn.classList.add("is-error");
      say("复制失败，请手动选中复制：" + text, false);
    }
    return ok;
  }

  /* ------------------------------------------------------------ 二维码放大 */

  function ensureOverlay() {
    let ov = $("#qrOverlay") || $(".qr-overlay");
    if (ov) return ov;
    ov = document.createElement("div");
    ov.id = "qrOverlay";
    ov.className = "qr-overlay hidden";
    ov.setAttribute("role", "dialog");
    ov.setAttribute("aria-modal", "true");
    ov.setAttribute("aria-label", "二维码放大预览");
    ov.innerHTML = '<img alt="二维码" /><div class="qr-overlay-tip"></div>';
    document.body.appendChild(ov);
    return ov;
  }

  function setScrollLock(on) {
    const html = document.documentElement;
    if (!html) return;
    if (on) {
      if (html.dataset.aboutScrollY == null) html.dataset.aboutScrollY = String(global.scrollY || 0);
      html.style.overflow = "hidden";
    } else {
      html.style.overflow = "";
      delete html.dataset.aboutScrollY;
    }
  }

  function openQr(src, title) {
    if (!src) return;
    const ov = ensureOverlay();
    const img = ov.querySelector("img");
    const tip = ov.querySelector(".qr-overlay-tip");
    if (img) {
      img.src = src;
      img.alt = title || "二维码";
    }
    if (tip) tip.textContent = (title ? title + " · " : "") + "点击任意处关闭";
    ov.classList.remove("hidden");
    setScrollLock(true);
    const focusable = ov;
    if (focusable && focusable.focus) {
      if (!focusable.hasAttribute("tabindex")) focusable.setAttribute("tabindex", "-1");
      focusable.focus({ preventScroll: true });
    }
  }

  function closeQr() {
    const ov = $("#qrOverlay") || $(".qr-overlay");
    if (!ov || ov.classList.contains("hidden")) return;
    ov.classList.add("hidden");
    setScrollLock(false);
    if (lastFocus && lastFocus.isConnected && lastFocus.focus) {
      lastFocus.focus({ preventScroll: true });
    }
    lastFocus = null;
  }

  /* ------------------------------------------------------------ 测试账号 */

  function fillTest(btn) {
    const email = (btn && btn.dataset && btn.dataset.testEmail) || DEFAULT_TEST_EMAIL;
    const pass = (btn && btn.dataset && btn.dataset.testPass) || DEFAULT_TEST_PASS;

    // ① 先交给页面自己的账号模块（约定事件名：wh-fill-test-account）
    const evt = new CustomEvent("wh-fill-test-account", {
      detail: { email: email, password: pass },
      bubbles: true,
      cancelable: true,
    });
    document.dispatchEvent(evt);
    if (evt.defaultPrevented) return; // 页面明确表示"我自己处理"

    const emailInput = $("#acctEmail");
    const passInput = $("#acctPass");
    if (!emailInput || !passInput) {
      // 没有账号表单（独立页 / 弹窗变体）：把账号念出来，别让按钮变成死键
      say("测试账号：" + email + " / " + pass, true);
      return;
    }

    // ② 页面模块可能在上一句里**同步**填好了；给它一帧，别把登录做成两次
    global.setTimeout(() => {
      if (emailInput.value === email && passInput.value === pass) return;
      emailInput.value = email;
      passInput.value = pass;
      goTo("account");
      say("已填入测试账号，正在登录…", true);
      const form = $("#acctLoginForm");
      if (form) {
        if (form.requestSubmit) form.requestSubmit();
        else form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
        return;
      }
      const loginBtn = $("#acctLogin");
      if (loginBtn) loginBtn.click();
      else emailInput.dispatchEvent(new Event("input", { bubbles: true }));
    }, 0);
  }

  /* ------------------------------------------------------------ 分区互跳 */

  function goTo(paneId) {
    if (!paneId) return;
    const nav = document.querySelector('.nav-item[data-pane="' + paneId + '"], [data-tab="' + paneId + '"]');
    if (nav) {
      nav.click();
      return;
    }
    // 没有侧栏（独立页 / 弹窗变体）：直接切 class 兜底
    const pane = document.getElementById("pane-" + paneId);
    if (pane) {
      $$(".pane").forEach((p) => p.classList.toggle("active", p === pane));
      $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.pane === paneId));
    }
  }

  /* ------------------------------------------------------------ 缺图守卫 */

  function guardImage(img) {
    const thumb = img.closest(".qr-thumb");
    const mark = () => {
      const src = img.getAttribute("src") || "";
      if (thumb) {
        thumb.classList.add("is-missing");
        thumb.setAttribute("data-qr-missing", "缺图\n" + src);
        thumb.setAttribute("aria-label", "二维码缺失：" + src);
      }
      // 控制台点名：页面上只看到一个占位块的话，人根本猜不到要补哪个文件
      console.warn(
        "[Panda 设计语言] 二维码缺失：" + src +
        "\n  把同名 PNG 放进项目的 images/ 目录即可（或 panda_design { action: \"scaffold\", modules: [\"about-images\"] } 一次拷齐）。",
      );
    };
    const unmark = () => {
      if (!thumb) return;
      thumb.classList.remove("is-missing");
      thumb.removeAttribute("data-qr-missing");
    };
    if (img.complete && img.naturalWidth === 0 && img.getAttribute("src")) mark();
    img.addEventListener("error", mark);
    img.addEventListener("load", unmark);
  }

  /* ------------------------------------------------------------ 绑定 */

  function onClick(event) {
    if (event.defaultPrevented || event.button > 0) return;
    const target = event.target;
    if (!target || !target.closest) return;

    const copyBtn = target.closest("[data-copy]");
    if (copyBtn) {
      event.preventDefault();
      copyFrom(copyBtn);
      return;
    }

    const thumb = target.closest(".qr-thumb[data-qr]");
    if (thumb) {
      event.preventDefault();
      if (thumb.classList.contains("is-missing")) {
        say("这张二维码还没放进项目，暂时放大不了", false);
        return;
      }
      lastFocus = thumb;
      openQr(thumb.dataset.qr, thumb.dataset.qrTitle);
      return;
    }

    const fillBtn = target.closest("[data-fill-test]");
    if (fillBtn) {
      event.preventDefault();
      fillTest(fillBtn);
      return;
    }

    const gotoBtn = target.closest("[data-goto]");
    if (gotoBtn) {
      event.preventDefault();
      goTo(gotoBtn.dataset.goto);
      return;
    }

    // 点遮罩任意处关闭
    if (target.closest(".qr-overlay")) {
      event.preventDefault();
      closeQr();
    }
  }

  function onKeydown(event) {
    if (event.key === "Escape" || event.key === "Esc") closeQr();
  }

  /** 绑定（重复调用安全：元素只绑一次，全局监听只加一次） */
  function bind(root) {
    const scope = root && root.querySelectorAll ? root : document;
    $$(".qr-thumb img", scope).forEach((img) => {
      if (bound.has(img)) return;
      bound.add(img);
      guardImage(img);
    });
    if (!bind._doc) {
      bind._doc = true;
      document.addEventListener("click", onClick);
      document.addEventListener("keydown", onKeydown);
    }
    return bind.api;
  }

  const api = { bind: bind, copy: copyText, copyFrom: copyFrom, openQr: openQr, closeQr: closeQr, goTo: goTo, fillTest: fillTest, announce: announce };
  bind.api = api;
  global.WHAbout = api;

  function boot() {
    if (!document.body) return;
    ensureStyles();
    bind(document);
    ensureOverlay();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})(typeof window !== "undefined" ? window : globalThis);
