/* ============================================================
   Panda 设计语言 —— M1b 主题控制器（日间 / 夜间 / 跟随系统）
   零依赖。职责四件：
     1. 把偏好（light | dark | auto）解析成实际主题（light | dark）
     2. 落到 html[data-wh-theme]（popup/options/page）+ body.dark（独立页兼容）
     3. 持久化（chrome.storage.sync 优先）、跨页同步、监听系统主题变化、广播 wh:themechange
     4. 把偏好镜像到 localStorage，供首屏引导 theme-boot.js 同步读取（见下）
   令牌见 ui-tokens.css；规格见 refs/themes.md。

   配套文件：theme-boot.js —— 必须在 <head> 里、所有样式表之前同步引入。
     它只做一件事：用上一帧的偏好先落 data-wh-theme + colorScheme + 内联底色，消掉夜间首屏白闪。
     分工：boot 管首帧（同步、无存储 IO）；本文件管之后的解析、持久化与同步。

   ⚠️ 首屏引导必须走 theme-boot.js 这个独立文件，**不要写 <head> 内联脚本**：
      MV3 的扩展页 CSP 禁内联脚本（发布前检查的 csp/inline 项会直接判失败）。

   用法：
     WHTheme.init({ storageKey: "wh_theme", fallback: "auto" });   // 页面底部
     WHTheme.set("dark");        // 用户点「夜间」→ 持久化 + 镜像 + 重绘
     WHTheme.set("auto");        // 跟随系统
     WHTheme.get();              // { pref: "auto", theme: "dark", ready: true }
     WHTheme.onChange((theme, pref) => { ... });
   ============================================================ */
(function (global) {
  "use strict";

  var VALID = { light: 1, dark: 1, auto: 1 };
  var pref = "light";
  var listeners = [];
  var mql = global.matchMedia ? global.matchMedia("(prefers-color-scheme: dark)") : null;
  var opts = { storageKey: "wh_theme", fallback: "auto" };
  var ready = false;

  /* 与 theme-boot.js 里的 COLORS 必须一致：首帧兜底底色 */
  var COLORS = { dark: "#0a0a0a", light: "#ffffff" };

  function root() { return document.documentElement; }

  function resolve(p) {
    if (p === "auto") return mql && mql.matches ? "dark" : "light";
    return p === "dark" ? "dark" : "light";
  }

  /* 镜像到 localStorage：theme-boot.js 在 <head> 里同步读这一份，
     chrome.storage 是异步的，赶不上首帧。两处必须同键同值。 */
  function mirror(p) {
    try { global.localStorage && localStorage.setItem(opts.storageKey, p); } catch (e) { /* 隐私模式忽略 */ }
  }

  function paint(p) {
    var theme = resolve(p);
    var r = root();
    var dark = theme === "dark";
    r.setAttribute("data-wh-theme", theme);
    r.setAttribute("data-wh-theme-pref", p); // 记录"偏好"，样式可区分 auto

    /* 内联底色与 colorScheme：内联样式会盖过样式表里的 html{background-color:var(--ui-bg)}，
       所以主题一变必须跟着改，否则切到夜间后画布边角仍是白的。 */
    r.style.backgroundColor = dark ? COLORS.dark : COLORS.light;
    r.style.colorScheme = theme;

    if (document.body) document.body.classList.toggle("dark", theme === "dark");
    for (var i = 0; i < listeners.length; i++) {
      try { listeners[i](theme, p); } catch (e) { /* 单个监听器出错不影响其他 */ }
    }
    try {
      document.dispatchEvent(new CustomEvent("wh:themechange", { detail: { theme: theme, pref: p } }));
    } catch (e) { /* 老浏览器忽略 */ }
    return theme;
  }

  /* ---------- 存储：扩展内用 chrome.storage.sync，网页里退回 localStorage ---------- */
  function read(done) {
    try {
      if (global.chrome && chrome.storage && chrome.storage.sync) {
        chrome.storage.sync.get({ [opts.storageKey]: opts.fallback }, function (o) {
          var v = o && o[opts.storageKey];
          done(VALID[v] ? v : opts.fallback);
        });
        return;
      }
    } catch (e) { /* 落到 localStorage */ }
    var v2 = null;
    try { v2 = global.localStorage && localStorage.getItem(opts.storageKey); } catch (e) { v2 = null; }
    done(VALID[v2] ? v2 : opts.fallback);
  }

  function write(p) {
    mirror(p); // 先镜像：即使 chrome.storage 报错，下一次首屏也不会读错
    try {
      if (global.chrome && chrome.storage && chrome.storage.sync) {
        var o = {}; o[opts.storageKey] = p;
        chrome.storage.sync.set(o);
        return;
      }
    } catch (e) { /* 已在上面镜像过 */ }
  }

  function init(options) {
    if (options && options.storageKey) opts.storageKey = options.storageKey;
    if (options && VALID[options.fallback]) opts.fallback = options.fallback;
    ready = true;
    // 系统主题变化：仅当偏好是 auto 时重绘
    if (mql && mql.addEventListener) {
      mql.addEventListener("change", function () { if (pref === "auto") paint("auto"); });
    } else if (mql && mql.addListener) {
      mql.addListener(function () { if (pref === "auto") paint("auto"); });
    }
    read(function (p) { pref = p; mirror(p); paint(p); });
    // 其他页面（设置页/弹窗）改动偏好时同步：storage.onChanged 更可靠，本地事件兜底
    try {
      if (global.chrome && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener(function (changes, area) {
          if (area !== "sync" || !changes[opts.storageKey]) return;
          var v = changes[opts.storageKey].newValue;
          if (VALID[v] && v !== pref) { pref = v; mirror(v); paint(v); }
        });
      }
    } catch (e) { /* ignore */ }
    return WHTheme;
  }

  function set(p) {
    var v = VALID[p] ? p : opts.fallback;
    pref = v;
    write(v);
    return paint(v);
  }

  function get() {
    return { pref: pref, theme: resolve(pref), ready: ready };
  }

  function onChange(fn) {
    if (typeof fn === "function") listeners.push(fn);
    return function () {
      var i = listeners.indexOf(fn);
      if (i >= 0) listeners.splice(i, 1);
    };
  }

  var WHTheme = { init: init, set: set, get: get, onChange: onChange, resolve: resolve };
  global.WHTheme = WHTheme;
})(typeof globalThis !== "undefined" ? globalThis : window);
