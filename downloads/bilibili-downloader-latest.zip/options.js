/**
 * options.js —— 设置页（216 侧栏 + 780 主区）
 *
 * 分工：
 *   · 分区切换与滚动位置：pane-scroll.js（WHPaneScroll），本文件不写 showPane()
 *   · 账号分区：account-pane.js；关于组交互：about.js；使用手册：manual.js
 *   · 本文件只管本插件自己的设置项
 *
 * 保存模型（与 Panda 设置页一致）：
 *   · 开关 / 分段 / 下拉 → 即时生效（写 chrome.storage.sync，各界面即时跟随）
 *   · 文本（目录、文件名模板）→ 显式保存（底部 .actions + 状态文字）
 */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));

  const QUALITY_LABEL = {
    16: "360P", 32: "480P", 64: "720P", 74: "720P60", 80: "1080P",
    112: "1080P+", 116: "1080P60", 120: "4K", 125: "HDR", 126: "杜比视界", 127: "8K"
  };

  let settings = Object.assign({}, PM_STORAGE.DEFAULTS);

  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r || { ok: false, error: "扩展未响应" });
        });
      } catch (e) {
        resolve({ ok: false, error: String((e && e.message) || e) });
      }
    });
  }

  function setStatus(text, kind) {
    const el = $("#filesStatus");
    if (!el) return;
    el.textContent = text || "";
    el.className = "status" + (kind === "err" ? " err" : "");
    el.style.color = kind === "err" ? "var(--ui-danger)" : "";
  }

  /* ---------------- 分区跳转 ---------------- */
  /** 点侧栏那一项（pane-scroll 接管显示与滚动，这里只负责触发） */
  function goPane(id) {
    const nav = document.querySelector('.nav-item[data-pane="' + id + '"]');
    if (nav) nav.click();
  }

  function openPage(url) {
    try { chrome.tabs.create({ url: url }); } catch (e) { location.href = url; }
  }

  function bindNavExtras() {
    const tasks = $("#navTasks");
    if (tasks) tasks.addEventListener("click", () => openPage("tasks.html"));
    const openTasks = $("#btnOpenTasks");
    if (openTasks) openTasks.addEventListener("click", () => openPage("tasks.html"));
    const upgrade = $("#btnUpgrade");
    if (upgrade) upgrade.addEventListener("click", () => goPane("account"));
  }

  /** 深链：options.html#pane-<id> 落地后激活该分区（popup / 提示条都指这里） */
  function applyHash() {
    const m = /^#pane-([\w-]+)$/.exec(location.hash || "");
    if (m) goPane(m[1]);
  }

  /* ---------------- 即时生效的控件 ---------------- */
  function paintControls() {
    if ($("#qualitySelect")) $("#qualitySelect").value = String(settings.quality || 80);
    if ($("#modeSelect")) $("#modeSelect").value = settings.mode || "auto";
    if ($("#parallelSelect")) $("#parallelSelect").value = String(settings.maxParallel || 2);
    if ($("#saveCover")) $("#saveCover").checked = !!settings.saveCover;
    if ($("#saveDanmaku")) $("#saveDanmaku").checked = !!settings.saveDanmaku;
    if ($("#mergeSingle")) $("#mergeSingle").checked = settings.merge !== false;
    if ($("#folderInput")) $("#folderInput").value = settings.folder || "";
    if ($("#filenameInput")) $("#filenameInput").value = settings.filename || "{title}-{quality}";
    paintPreview();
  }

  async function save(key, value) {
    settings[key] = value;
    await send({ type: "PM_SET_SETTING", key: key, value: value });
  }

  function bindInstant() {
    const on = (sel, ev, fn) => {
      const el = $(sel);
      if (el) el.addEventListener(ev, fn);
    };

    on("#qualitySelect", "change", (e) => {
      save("quality", Number(e.target.value));
      paintPreview();
    });
    on("#modeSelect", "change", (e) => save("mode", e.target.value));
    on("#parallelSelect", "change", (e) => save("maxParallel", Number(e.target.value)));
    on("#saveCover", "change", (e) => save("saveCover", e.target.checked));
    on("#saveDanmaku", "change", async (e) => {
      if (e.target.checked) {
        const st = await send({ type: "PM_GET_STATE" });
        const pro = !!(st && st.membership && st.membership.pro);
        if (!pro) {
          e.target.checked = false;
          setStatus("弹幕下载是 PRO 功能，激活后可用", "err");
          setTimeout(() => setStatus(""), 2600);
          return;
        }
      }
      save("saveDanmaku", e.target.checked);
    });
    on("#mergeSingle", "change", (e) => save("merge", e.target.checked));

    const seg = $("#themeSeg");
    if (seg) {
      seg.addEventListener("click", (ev) => {
        const b = ev.target.closest("[data-theme]");
        if (!b) return;
        try { WHTheme.set(b.dataset.theme); } catch (e) { /* ignore */ }
        paintTheme();
      });
    }
  }

  /* ---------------- 主题 ---------------- */
  function paintTheme() {
    let pref = "auto";
    try { pref = (WHTheme.get() || {}).pref || "auto"; } catch (e) { pref = "auto"; }
    $$("#themeSeg [data-theme]").forEach((b) => b.classList.toggle("active", b.dataset.theme === pref));
  }

  function initTheme() {
    try {
      // 规范键名 wh_theme：theme-boot.js 在 <head> 里同步读它的 localStorage 镜像，两处必须同键
      WHTheme.init({ storageKey: "wh_theme", fallback: "auto" });
      WHTheme.onChange(() => paintTheme());
    } catch (e) { /* ignore */ }
    paintTheme();
  }

  /* ---------------- 文件名预览 ---------------- */
  function sanitize(s, max) {
    return String(s || "").replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").trim().slice(0, max || 100);
  }

  /** 本地日期：toISOString() 是 UTC，东八区凌晨会显示成前一天 */
  function localDate() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
  }

  function buildPreview() {
    const tpl = ($("#filenameInput") && $("#filenameInput").value) || "{title}-{quality}";
    const map = {
      title: "哔哩哔哩 · 示例视频",
      part: "P1 开头",
      quality: QUALITY_LABEL[settings.quality] || String(settings.quality),
      bvid: "BV1xx411c7mD",
      up: "某个UP主",
      page: "1",
      date: localDate()
    };
    let name = tpl;
    Object.keys(map).forEach((k) => { name = name.split("{" + k + "}").join(map[k]); });
    name = sanitize(name, 110).replace(/[-_\s]+$/, "") || "video";
    const folder = String(($("#folderInput") && $("#folderInput").value) || "")
      .split("/").map((s) => sanitize(s, 40)).filter(Boolean).join("/");
    return (folder ? folder + "/" : "") + name;
  }

  function paintPreview() {
    const el = $("#namePreview");
    if (el) el.textContent = buildPreview();
  }

  /* ---------------- 显式保存 ---------------- */
  function bindFiles() {
    const folder = $("#folderInput");
    const file = $("#filenameInput");
    if (folder) folder.addEventListener("input", paintPreview);
    if (file) file.addEventListener("input", paintPreview);

    const btn = $("#btnSaveFiles");
    if (!btn) return;
    btn.addEventListener("click", async () => {
      const nextFolder = sanitize(folder ? folder.value : "", 80);
      const nextName = ((file ? file.value : "") || "").trim() || "{title}-{quality}";
      await send({ type: "PM_SET_SETTING", key: "folder", value: nextFolder });
      await send({ type: "PM_SET_SETTING", key: "filename", value: nextName });
      settings.folder = nextFolder;
      settings.filename = nextName;
      paintPreview();
      setStatus("已保存");
      setTimeout(() => setStatus(""), 2200);
    });
  }

  /* ---------------- 额度 ---------------- */
  async function refreshQuota() {
    const st = await send({ type: "PM_GET_STATE" });
    const m = (st && st.membership) || {};
    const q = (st && st.quota) || null;
    const title = $("#quotaTitle");
    const hint = $("#quotaHint");
    if (!title || !hint) return;
    if (m.pro || (q && q.pro)) {
      title.textContent = "PRO 会员 · 不限次数";
      hint.textContent = "全部清晰度 + 弹幕 + 选集批量下载。";
      return;
    }
    if (q && typeof q.remaining === "number") {
      title.textContent = "今日免费剩余 " + q.remaining + " / " + q.free;
      hint.textContent = m.signed_in
        ? "免费账号每天 3 个视频、最高 720P；激活 PRO 后不限次数。"
        : "未登录每日 3 个视频；登录后可同步会员与更稳定的解析。";
      return;
    }
    title.textContent = "额度读取失败";
    hint.textContent = "可以到「自检」分区跑一次诊断，看账号服务是否可达。";
  }

  /* ---------------- 自检 ---------------- */
  async function runSelfTest() {
    const list = $("#testList");
    if (!list) return;
    list.innerHTML = '<div class="t-row info spin">正在检查…</div>';
    const r = await send({ type: "PM_SELFTEST" });
    list.innerHTML = "";
    const checks = (r && r.checks) || [];
    if (!checks.length) {
      list.innerHTML = '<div class="t-row fail">自检失败：' + ((r && r.error) || "扩展未响应") + "</div>";
      return;
    }
    checks.forEach((c) => {
      const row = document.createElement("div");
      row.className = "t-row " + (c.ok ? "ok" : "fail");
      const mark = document.createElement("span");
      mark.className = "t-mark";
      mark.textContent = c.ok ? "✓" : "✕";
      const name = document.createElement("span");
      name.textContent = c.name;
      row.appendChild(mark);
      row.appendChild(name);
      if (c.detail) {
        const d = document.createElement("span");
        d.className = "t-detail";
        d.textContent = c.detail;
        row.appendChild(d);
      }
      list.appendChild(row);
    });
    const sum = document.createElement("div");
    sum.className = "t-row info";
    sum.textContent = "共 " + checks.length + " 项，通过 " + checks.filter((c) => c.ok).length + " 项";
    list.appendChild(sum);
  }

  /* ---------------- 启动 ---------------- */
  (async function boot() {
    try {
      const ver = chrome.runtime.getManifest().version;
      if ($("#appVer")) $("#appVer").textContent = "v" + ver;
      if ($("#verFoot")) $("#verFoot").textContent = ver;
    } catch (e) { /* ignore */ }

    initTheme();
    bindNavExtras();
    bindInstant();
    bindFiles();
    if ($("#btnSelfTest")) $("#btnSelfTest").addEventListener("click", runSelfTest);

    settings = await PM_STORAGE.getSettings();
    paintControls();
    await refreshQuota();
    applyHash();
    window.addEventListener("hashchange", applyHash);

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "sync") {
        let touched = false;
        Object.keys(changes).forEach((k) => {
          if (settings[k] !== undefined || k === "folder" || k === "filename") {
            settings[k] = changes[k].newValue;
            touched = true;
          }
        });
        if (touched) paintControls();
      }
      if (area === "local" && (changes.bili_membership || changes.bili_limits)) refreshQuota();
    });
  })();
})();
