/**
 * popup.js —— 300px 单列弹窗（1.2.0 起是唯一操作入口）
 *
 * 流程：读当前标签页 → 内容脚本解析视频/合集 → 选清晰度 →（多集时）勾选集数 → 下载
 * 页面里不再有任何浮层，所以这里必须把「选集 / 清晰度 / 下载 / 封面 / 弹幕」都装下。
 */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const state = {
    tab: null,
    settings: null,
    membership: null,
    quota: null,
    info: null,
    episodes: [],
    sel: {},          // { key: true }
    resolvedKey: "",  // 当前 playurl 对应的那一集
    playurl: null,
    qn: 80,
    busy: false
  };

  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r || { ok: false, error: "扩展未响应" });
        });
      } catch (e) {
        resolve({ ok: false, error: String((e && e.message) || e) });
      }
    });
  }

  function isBiliUrl(url) {
    return /^https:\/\/www\.bilibili\.com\/(video|list|bangumi\/play|medialist\/play)\//.test(String(url || ""));
  }

  function setHint(text, kind) {
    const el = $("#hint");
    el.textContent = text || "";
    el.className = "pp-hint" + (kind ? " " + kind : "");
  }

  /* ---------------- 主题 ---------------- */
  function initTheme() {
    const seg = $("#themeSeg");
    const paint = (pref) => {
      Array.from(seg.querySelectorAll("[data-theme]")).forEach((b) => {
        b.classList.toggle("active", b.dataset.theme === pref);
      });
    };
    try {
      WHTheme.init({ storageKey: "theme", fallback: "auto" });
      WHTheme.onChange((theme, pref) => {
        try { localStorage.setItem("bili_theme", pref); } catch (e) { /* ignore */ }
        paint(pref);
      });
      paint((WHTheme.get() || {}).pref || "auto");
    } catch (e) { /* ignore */ }
    seg.addEventListener("click", (ev) => {
      const b = ev.target.closest("[data-theme]");
      if (!b) return;
      WHTheme.set(b.dataset.theme);
      paint(b.dataset.theme);
    });
  }

  /* ---------------- 账号 / 配额 ---------------- */
  function paintAccount() {
    const m = state.membership || {};
    const chip = $("#planChip");
    if (m.pro) {
      chip.className = "p-chip pro";
      chip.textContent = "PRO";
    } else if (m.signed_in) {
      chip.className = "p-chip on";
      chip.textContent = "免费";
    } else {
      chip.className = "p-chip";
      chip.textContent = "未登录";
    }
    $("#acctText").textContent = m.signed_in ? (m.email || "已登录") : "未登录（免费可用 720P）";
    $("#acctAction").textContent = m.signed_in ? "管理" : "登录";
  }

  function paintQuota() {
    const q = state.quota;
    if (!q || state.busy) return;
    if (q.pro) {
      setHint("PRO 会员：不限次数，可选全部清晰度");
      return;
    }
    setHint("今日免费剩余 " + q.remaining + " / " + q.free + " 个 · 免费最高 720P",
      q.remaining <= 0 ? "warn" : "");
  }

  /* ---------------- 选集（分P / 合集 / 番剧集数统一成一张表） ---------------- */
  function episodeList() {
    const info = state.info;
    if (!info) return [];
    const season = info.season;
    if (season && season.episodes && season.episodes.length > 1) {
      return season.episodes.map((e, i) => ({
        key: e.bvid,
        bvid: e.bvid,
        cid: e.cid,
        page: i + 1,
        label: e.title || ("第" + (i + 1) + "集"),
        duration: e.duration || 0,
        current: e.bvid === info.bvid
      }));
    }
    const isBangumi = info.kind === "bangumi";
    return (info.pages || []).map((p) => ({
      key: info.bvid + ":" + p.page,
      bvid: info.bvid,
      cid: p.cid,
      page: p.page,
      label: (isBangumi ? "第" + p.page + "话 " : "P" + p.page + " ") + (p.part || ""),
      duration: p.duration || 0,
      current: p.page === info.currentPage
    }));
  }

  function selectedEpisodes() {
    return state.episodes.filter((e) => state.sel[e.key]);
  }

  /** 主选集：勾了多个时用第一个的清晰度列表做预览 */
  function primaryEpisode() {
    const sel = selectedEpisodes();
    return sel.length ? sel[0] : (state.episodes[0] || null);
  }

  function paintEpisodes() {
    const list = state.episodes;
    const row = $("#epsRow");
    const panel = $("#epsPanel");
    const countEl = $("#epsCount");
    const labelEl = $("#epsLabel");
    const box = $("#epsList");

    if (list.length < 2) {
      row.style.display = "none";
      panel.hidden = true;
      return;
    }
    row.style.display = "";

    box.innerHTML = "";
    list.forEach((e) => {
      const item = document.createElement("label");
      item.className = "pp-ep" + (e.current ? " cur" : "");
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = !!state.sel[e.key];
      cb.addEventListener("change", () => {
        state.sel[e.key] = cb.checked;
        paintEpsCount();
        onSelectionChanged(e.key);
      });
      item.appendChild(cb);
      item.appendChild(Object.assign(document.createElement("span"), {
        className: "pp-ep-name", textContent: e.label
      }));
      if (e.duration) {
        item.appendChild(Object.assign(document.createElement("span"), {
          className: "pp-ep-dur", textContent: BILI_DUR(e.duration)
        }));
      }
      box.appendChild(item);
    });

    const n = selectedEpisodes().length;
    if (labelEl) labelEl.textContent = n === list.length ? "全部（" + n + "）" : (n === 1 ? (selectedEpisodes()[0].label || "1 集") : "已选 " + n + " 集");
    if (countEl) countEl.textContent = "已选 " + n + " / " + list.length;
  }

  function BILI_DUR(sec) {
    const s = Math.max(0, Math.round(Number(sec) || 0));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const ss = s % 60;
    const mm = h ? String(m).padStart(2, "0") : String(m);
    return (h ? h + ":" : "") + mm + ":" + String(ss).padStart(2, "0");
  }

  function paintEpsCount() {
    const list = state.episodes;
    const n = selectedEpisodes().length;
    const labelEl = $("#epsLabel");
    const countEl = $("#epsCount");
    if (labelEl) {
      const sel = selectedEpisodes();
      labelEl.textContent = n === 0 ? "请选择"
        : n === list.length ? "全部（" + n + "）"
          : n === 1 ? sel[0].label
            : "已选 " + n + " 集";
    }
    if (countEl) countEl.textContent = "已选 " + n + " / " + list.length;
    const btn = $("#btnDownload");
    if (btn) btn.textContent = n > 1 ? "下载所选（" + n + "）" : "下载";
  }

  /** 勾选变化：主选集换了就重新解析清晰度（不同集的可选清晰度可能不同） */
  function onSelectionChanged(changedKey) {
    const p = primaryEpisode();
    if (!p) { state.playurl = null; state.resolvedKey = ""; return; }
    if (state.resolvedKey !== p.key) loadPlayurl(p);
    else if (changedKey) paintFormats();
  }

  /* ---------------- 视频信息 ---------------- */
  function paintVideo() {
    const info = state.info;
    if (!info) return;
    $("#vTitle").textContent = info.title || "未命名视频";
    const bits = [];
    if (info.up) bits.push(info.up);
    if (info.durationText) bits.push(info.durationText);
    if (info.pages && info.pages.length > 1) bits.push("共 " + info.pages.length + " P");
    if (info.season && info.season.episodes && info.season.episodes.length > 1) {
      bits.push("合集 · " + info.season.episodes.length + " 集");
    }
    $("#vMeta").textContent = bits.join(" · ");
    if (info.cover) {
      const img = $("#thumb");
      img.src = info.cover.replace(/^http:/, "https:");
      img.referrerPolicy = "no-referrer";
      $("#thumbWrap").style.display = "";
    } else {
      $("#thumbWrap").style.display = "none";
    }

    state.episodes = episodeList();
    // 默认只勾「当前这一集」：避免一进弹窗就误把整季加进队列
    state.sel = {};
    const cur = state.episodes.find((e) => e.current) || state.episodes[0];
    if (cur) state.sel[cur.key] = true;
    paintEpisodes();
    paintEpsCount();
  }

  function paintFormats() {
    const pu = state.playurl;
    const sel = $("#qualitySelect");
    sel.innerHTML = "";
    if (!pu || !pu.formats || !pu.formats.length) {
      sel.innerHTML = '<option value="">没有可用清晰度</option>';
      $("#btnDownload").disabled = true;
      return;
    }
    const pro = !!(state.membership && state.membership.pro);
    pu.formats.forEach((f) => {
      const o = document.createElement("option");
      o.value = String(f.qn);
      o.textContent = f.label + (f.pro && !pro ? " · PRO" : "");
      if (f.qn === state.qn) o.selected = true;
      sel.appendChild(o);
    });
    $("#btnDownload").disabled = false;
    paintEpsCount();

    const cur = pu.formats.filter((f) => f.qn === state.qn)[0];
    if (cur && cur.pro && !pro) {
      setHint("当前清晰度需 PRO，免费账号最高 720P", "warn");
    } else {
      paintQuota();
    }
  }

  /* ---------------- 加载 ---------------- */
  async function loadState() {
    const r = await send({ type: "PM_GET_STATE" });
    if (r && r.ok) {
      state.settings = r.settings;
      state.membership = r.membership;
      state.quota = r.quota;
      state.qn = (r.settings && Number(r.settings.quality)) || 80;
      if (!(r.membership && r.membership.pro) && state.qn > 64) state.qn = 64;
    }
    paintAccount();
  }

  async function loadTasks() {
    const r = await send({ type: "PM_TASKS" });
    const tasks = (r && r.tasks) || [];
    const active = tasks.filter((t) => t.status === "downloading").length;
    $("#taskCount").textContent = String(active);
  }

  async function loadPage() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    state.tab = (tabs && tabs[0]) || null;
    if (!state.tab || !isBiliUrl(state.tab.url)) {
      $("#mainBox").classList.add("hidden");
      $("#emptyBox").classList.remove("hidden");
      return;
    }
    $("#emptyBox").classList.add("hidden");
    $("#mainBox").classList.remove("hidden");
    setHint("正在解析视频…");

    const info = await send({ type: "PM_INFO", tabId: state.tab.id });
    if (!info || !info.ok) {
      $("#vTitle").textContent = "解析失败";
      $("#vMeta").textContent = (info && info.error) || "请刷新 B 站页面后重试";
      $("#btnDownload").disabled = true;
      setHint((info && info.error) || "请刷新 B 站页面后重试", "err");
      return;
    }
    state.info = info.data;
    paintVideo();
    const p = primaryEpisode();
    if (p) await loadPlayurl(p);
  }

  async function loadPlayurl(ep) {
    if (!state.info || !ep) return;
    setHint("正在解析清晰度…");
    $("#btnDownload").disabled = true;
    const r = await send({
      type: "PM_PLAYURL",
      tabId: state.tab.id,
      options: { qn: state.qn, media: "dash", page: ep.page, bvid: ep.bvid, cid: ep.cid }
    });
    $("#btnDownload").disabled = false;
    if (!r || !r.ok) {
      $("#qualitySelect").innerHTML = '<option value="">解析失败</option>';
      setHint((r && r.error) || "解析失败", "err");
      state.playurl = null;
      state.resolvedKey = "";
      return;
    }
    state.playurl = r.data;
    state.resolvedKey = ep.key;
    const has = (r.data.formats || []).some((f) => f.qn === state.qn);
    if (!has && r.data.formats && r.data.formats.length) state.qn = r.data.formats[0].qn;
    paintFormats();
  }

  /* ---------------- 下载 ---------------- */
  function qualityLabelNow() {
    const pu = state.playurl;
    const f = pu && pu.formats ? pu.formats.filter((x) => x.qn === pu.qn)[0] : null;
    return (f && f.label) || String((pu && pu.qn) || state.qn);
  }

  async function onDownload() {
    if (state.busy) return;
    const sel = selectedEpisodes();
    if (!sel.length) {
      setHint("先在「选集」里勾选要下载的集数", "warn");
      return;
    }
    if (sel.length > 1) return downloadBatch(sel);
    return downloadOne(sel[0]);
  }

  async function downloadBatch(sel) {
    const info = state.info;
    const btn = $("#btnDownload");
    state.busy = true;
    btn.disabled = true;
    setHint("正在批量解析 " + sel.length + " 集…");
    try {
      const r = await send({
        type: "PM_BATCH",
        payload: {
          tabId: state.tab.id,
          bvid: info.bvid,
          epId: info.epId,
          kind: info.kind,
          title: info.title,
          up: info.up,
          cover: info.cover,
          qn: state.qn,
          quality: qualityLabelNow(),
          pages: sel.map((e) => ({
            page: e.page,
            cid: e.cid,
            bvid: e.bvid,
            part: e.label,
            title: e.current ? "" : e.label // 合集里用这一集自己的标题命名
          }))
        }
      });
      if (r && r.ok) {
        setHint("已加入 " + r.started + " 集" + (r.failed ? "，失败 " + r.failed + " 个" : "") + "，可在「下载任务」看进度");
        loadTasks();
      } else if (r && r.reason === "pro") {
        setHint("选集批量下载是 PRO 功能：免费账号可一集一集下", "warn");
      } else {
        setHint((r && r.error) || "批量下载失败", "err");
      }
    } finally {
      state.busy = false;
      btn.disabled = false;
      paintEpsCount();
    }
  }

  async function downloadOne(ep) {
    // 勾选的可能不是当前页那一集：先按它的 bvid + cid 解析
    if (state.resolvedKey !== ep.key || !state.playurl) {
      await loadPlayurl(ep);
      if (!state.playurl) return;
    }
    const pu = state.playurl;
    const info = state.info;
    const btn = $("#btnDownload");
    state.busy = true;
    btn.disabled = true;
    btn.textContent = "准备中…";
    try {
      const isCurrent = ep.current;
      const payload = {
        tabId: state.tab.id,
        bvid: ep.bvid,
        epId: info.epId,
        kind: info.kind,
        cid: ep.cid,
        title: isCurrent ? info.title : ep.label,
        part: isCurrent ? info.currentPart : "",
        page: ep.page,
        up: info.up,
        cover: info.cover,
        qn: pu.qn,
        quality: qualityLabelNow(),
        media: "dash",
        playurl: { video: pu.video, audio: pu.audio }
      };
      const r = await send({ type: "PM_DOWNLOAD", payload });
      if (r && r.ok) {
        setHint(r.mergeNote
          ? r.mergeNote + "已改为两个文件，任务页可复制 ffmpeg 命令"
          : (r.merged
            ? "下载后自动合并成单个 MP4（不转码、画质无损）"
            : (r.fallback ? "CDN 拒绝直连，已改走兼容保存" : "已加入下载队列，可在「下载任务」查看进度")));
        if (state.quota && !state.quota.pro) {
          state.quota.used = (state.quota.used || 0) + 1;
          state.quota.remaining = Math.max(0, (state.quota.remaining || 0) - 1);
        }
        loadTasks();
      } else if (r && r.reason === "quota") {
        setHint("今日免费额度已用完，激活 PRO 可无限下载", "warn");
      } else if (r && r.reason === "quality") {
        setHint("该清晰度需 PRO：免费最高 720P", "warn");
      } else {
        setHint((r && r.error) || "下载失败", "err");
      }
    } finally {
      state.busy = false;
      btn.disabled = false;
      paintEpsCount();
    }
  }

  /* ---------------- 封面 / 弹幕 ---------------- */
  async function onCover() {
    if (!state.info) return;
    const r = await send({ type: "PM_DOWNLOAD_COVER", payload: { url: state.info.cover, title: state.info.title } });
    setHint(r && r.ok ? "封面已开始下载" : ((r && r.error) || "封面下载失败"), r && r.ok ? "" : "err");
  }

  async function onDanmaku() {
    if (!state.info) return;
    const ep = selectedEpisodes()[0] || state.episodes[0];
    const r = await send({
      type: "PM_DOWNLOAD_DANMAKU",
      payload: { cid: ep ? ep.cid : state.info.cid, title: state.info.title }
    });
    setHint(r && r.ok ? "弹幕已开始保存" : ((r && r.error) || "弹幕下载失败"), r && r.ok ? "" : "err");
  }

  /* ---------------- 事件 ---------------- */
  function bind() {
    $("#btnDownload").addEventListener("click", onDownload);
    $("#btnCover").addEventListener("click", onCover);
    $("#btnDanmaku").addEventListener("click", onDanmaku);

    $("#epsToggle").addEventListener("click", () => {
      const panel = $("#epsPanel");
      const open = panel.hidden;
      panel.hidden = !open;
      $("#epsToggle").setAttribute("aria-expanded", open ? "true" : "false");
      $("#epsRow").classList.toggle("open", open);
    });
    $("#epsPanel").addEventListener("click", (ev) => {
      const b = ev.target.closest("[data-ep-act]");
      if (!b) return;
      const act = b.dataset.epAct;
      state.episodes.forEach((e) => {
        if (act === "all") state.sel[e.key] = true;
        else if (act === "none") state.sel[e.key] = false;
      });
      paintEpisodes();
      paintEpsCount();
      onSelectionChanged("");
    });

    $("#qualitySelect").addEventListener("change", (e) => {
      state.qn = Number(e.target.value || state.qn);
      const p = primaryEpisode();
      // 只改下拉框不会改变已解析的流地址，必须按新 qn 重新解析
      if (p) loadPlayurl(p);
    });
    $("#btnTasks").addEventListener("click", () => send({ type: "PM_OPEN", page: "tasks" }));
    $("#btnOptions").addEventListener("click", () => send({ type: "PM_OPEN", page: "options" }));
    $("#btnAccount").addEventListener("click", () => send({ type: "PM_OPEN", page: "account" }));
    $("#acctRow").addEventListener("click", () => send({ type: "PM_OPEN", page: "account" }));
    $("#btnGoBili").addEventListener("click", () => {
      chrome.tabs.create({ url: "https://www.bilibili.com/" });
    });
  }

  try {
    $("#verText").textContent = "v" + chrome.runtime.getManifest().version;
  } catch (e) { /* ignore */ }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.bili_tasks || changes.bili_membership)) {
      if (changes.bili_membership) {
        state.membership = changes.bili_membership.newValue;
        paintAccount();
      }
      loadTasks();
    }
    if (area === "sync" && changes.quality) state.qn = Number(changes.quality.newValue) || state.qn;
  });

  initTheme();
  bind();
  (async () => {
    await loadState();
    await loadTasks();
    await loadPage();
  })();
})();
