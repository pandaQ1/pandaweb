/**
 * content.js —— B 站视频页的数据通道（不再有任何注入 UI）
 *
 * 为什么还需要内容脚本：
 *   playurl / view 等接口要带页面 Cookie 与同源环境，只有跑在页面里的脚本才拿得到；
 *   service worker 里 fetch 既没有站点 Cookie，也容易被风控。
 *
 * 职责只剩三件：
 *   1) 把视频信息、播放地址、清晰度列表交给 popup（BILI_INFO / BILI_PLAYURL）
 *   2) 页面跳转（B 站是 SPA）后作废缓存，避免拿到上一个视频的数据
 *   3) 需要时在页面右下角弹一条轻提示（BILI_TOAST）
 *
 * 1.2.0 起去掉了页面右下角浮按钮与注入面板：所有操作都收进工具栏弹窗，
 * 页面保持干净（只读页面数据，不改 B 站 DOM）。
 */
(function () {
  "use strict";
  if (window.__PM_BILI_CONTENT__) return;
  window.__PM_BILI_CONTENT__ = true;

  var state = {
    info: null,
    lastHref: location.href
  };

  function send(msg) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage(msg, function (resp) {
          void chrome.runtime.lastError;
          resolve(resp || { ok: false, error: "扩展未响应" });
        });
      } catch (e) {
        resolve({ ok: false, error: String((e && e.message) || e) });
      }
    });
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  /** 轻提示：只在需要告诉用户「去点工具栏图标」时用 */
  function toast(text, kind) {
    var old = document.getElementById("pm-bili-toast");
    if (old) old.remove();
    var t = el("div", "pm-toast" + (kind === "err" ? " remove" : ""), text);
    t.id = "pm-bili-toast";
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 1600);
  }

  /* ---------------- 消息通道（popup / background → 本页） ---------------- */
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || typeof msg.type !== "string") return;

    if (msg.type === "BILI_PING") {
      sendResponse({ ok: true, url: location.href, ready: !!state.info });
      return true;
    }

    if (msg.type === "BILI_INFO") {
      PM_BILI.getVideoInfo()
        .then(function (info) {
          state.info = info;
          sendResponse({ ok: true, data: info });
        })
        .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) || "解析失败" }); });
      return true;
    }

    if (msg.type === "BILI_PLAYURL") {
      var o = msg.options || {};
      var cached = state.info;
      var run = cached ? Promise.resolve(cached) : PM_BILI.getVideoInfo();
      var resolved = null;
      run.then(function (inf) {
        state.info = inf;
        var page = o.page ? (inf.pages || []).filter(function (p) { return p.page === o.page; })[0] : null;
        // 合集里每一集是独立视频：调用方直接给 bvid + cid，不再按分P页码查
        var bvid = o.bvid || inf.bvid;
        var cid = o.cid || (page ? page.cid : inf.cid);
        resolved = {
          cid: cid,
          page: page ? page.page : inf.currentPage,
          part: page ? page.part : inf.currentPart
        };
        return PM_BILI.getPlayurl({
          bvid: bvid,
          cid: cid,
          epId: page && page.epId ? page.epId : inf.epId,
          kind: inf.kind,
          qn: o.qn,
          media: o.media
        });
      }).then(function (data) {
        sendResponse({
          ok: true,
          data: data,
          cid: resolved ? resolved.cid : "",
          page: resolved ? resolved.page : 1,
          part: resolved ? resolved.part : ""
        });
      }).catch(function (e) {
        sendResponse({ ok: false, error: (e && e.message) || "解析失败" });
      });
      return true;
    }

    if (msg.type === "BILI_TOAST") {
      toast(msg.text || "", msg.kind);
      sendResponse({ ok: true });
      return true;
    }
    return;
  });

  /* ---------------- SPA 跳转：作废缓存 ---------------- */
  setInterval(function () {
    if (location.href === state.lastHref) return;
    state.lastHref = location.href;
    state.info = null; // 换视频了，下次重新解析
  }, 900);

  /* ---------------- 启动：预热一次（失败无妨，popup 打开时会重试） ---------------- */
  send({ type: "PM_GET_STATE" }).catch(function () { /* ignore */ });
})();
