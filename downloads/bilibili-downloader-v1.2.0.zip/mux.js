/**
 * mux.js —— 把 B 站 DASH 的两段 fMP4（视频 .m4s + 音频 .m4s）重封装成一个 MP4
 *
 * 为什么自己做：B 站高清只在 DASH 通道下发，音视频是分开的两条流；
 * 想要「一个文件」又不损失画质，必须做一次 remux——只搬样本、不重新编码，
 * 等价于 `ffmpeg -i v.mp4 -i a.m4a -c copy out.mp4`。
 *
 * 为什么不用 ffmpeg.wasm：core 30 MB+，MV3 打包与商店审核都不划算，
 * 4K 长视频在 wasm 里也吃内存。这里只处理 B 站实际用的两种编码：
 *   视频 avc1（H.264）/ 音频 mp4a（AAC）。
 *   其余（HEVC / AV1 / 杜比 EC-3 / Hi-Res FLAC）抛 unsupported，
 *   由上层回退成「两个文件 + ffmpeg 命令」，不会让用户两头空。
 *
 * 输入：两条完整 fMP4（ftyp + moov(1 trak) + 若干 moof/mdat）
 * 输出：ftyp + moov(2 traks) + mdat，普通非分片 MP4，可播放、可拖动
 *
 * 三个关键设计：
 *   1. 样本字节零拷贝：直接引用输入缓冲区的视图，只有 moov 是新造的；
 *   2. 连续样本合并成 run，一个 run = 一个 chunk（stsc 每条 run 一项），
 *      避免十万个样本各占一个 chunk 把 stco 撑到几 MB；
 *   3. 视频样本整体排在音频样本前（MP4 不要求交错，播放器都认，省一次重排）。
 *
 * 字段偏移一律照 ISO/IEC 14496-12 手算，并在文件末尾用自检函数校验长度，
 * 错一个字节就会出现「能下载但打不开」，所以宁可多写几行显式偏移。
 */
"use strict";

var PMMUX = (function () {
  /* 合并上限：超过就抛 unsupported，让上层退回分开下载。
   * 重封装是「输入 1× + 输出 Blob 1×」，再大容易把标签页内存打满。 */
  var MAX_BYTES = 900 * 1024 * 1024;

  var VIDEO_OK = /^(avc1|avc3)$/i;
  var AUDIO_OK = /^mp4a/i;

  function unsupported(msg) {
    var e = new Error(msg);
    e.unsupported = true;
    return e;
  }

  /* ============================ 读 ============================ */
  function bytesOf(x) {
    if (x instanceof Uint8Array) return x;
    if (x instanceof ArrayBuffer) return new Uint8Array(x);
    if (x && x.buffer instanceof ArrayBuffer) {
      return new Uint8Array(x.buffer, x.byteOffset || 0, x.byteLength);
    }
    throw new Error("mux: 输入不是字节数组");
  }

  function u32(b, o) { return ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0; }
  function i32(b, o) { return (b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]; }
  function u16(b, o) { return (b[o] << 8) | b[o + 1]; }
  function u64(b, o) { return u32(b, o) * 4294967296 + u32(b, o + 4); }
  function fourcc(b, o) { return String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]); }

  /** 列出一段字节里的同级 box */
  function boxes(b, start, end) {
    var out = [];
    var p = start;
    while (p + 8 <= end) {
      var size = u32(b, p);
      var type = fourcc(b, p + 4);
      var header = 8;
      if (size === 1) {
        if (p + 16 > end) break;
        size = u64(b, p + 8);
        header = 16;
      } else if (size === 0) {
        size = end - p;
      }
      if (size < header || p + size > end) break; // 截断：后面的都不可信
      out.push({ type: type, start: p, end: p + size, body: p + header, size: size });
      p += size;
    }
    return out;
  }

  function findBox(list, type) {
    for (var i = 0; i < list.length; i++) if (list[i].type === type) return list[i];
    return null;
  }

  function child(b, parent, type) {
    return findBox(boxes(b, parent.body, parent.end), type);
  }

  /* ============================ 解析 init ============================ */
  /**
   * 从 moov 里取出唯一一条轨道的信息。
   * tkhd 字段偏移（body 从 version/flags 起算）：
   *   v0: creat@4 mod@8 trackID@12 res@16 dur@20 res8@24 layer@32 alt@34 vol@36
   *       res@38 matrix@40 w@76 h@80
   *   v1: creat@4(8) mod@12(8) trackID@20 res@24 dur@28(8) res8@36
   *       layer@44 alt@46 vol@48 res@50 matrix@52 w@88 h@92
   */
  function parseInit(b, label) {
    var top = boxes(b, 0, b.length);
    var moov = findBox(top, "moov");
    if (!moov) throw unsupported(label + " 不是 fMP4（缺少 moov）");

    var traks = boxes(b, moov.body, moov.end).filter(function (x) { return x.type === "trak"; });
    if (!traks.length) throw unsupported(label + " 的 moov 里没有 trak");

    var info = null;
    for (var i = 0; i < traks.length && !info; i++) {
      var mdia = child(b, traks[i], "mdia");
      if (!mdia) continue;
      var mdhd = child(b, mdia, "mdhd");
      var hdlr = child(b, mdia, "hdlr");
      var minf = child(b, mdia, "minf");
      if (!mdhd || !hdlr || !minf) continue;

      var handler = fourcc(b, hdlr.body + 8); // fullbox(4) + pre_defined(4) → handler_type
      var ts, dur;
      if (b[mdhd.body] === 1) {
        ts = u32(b, mdhd.body + 20);
        dur = u64(b, mdhd.body + 24);
      } else {
        ts = u32(b, mdhd.body + 12);
        dur = u32(b, mdhd.body + 16);
      }

      var stbl = child(b, minf, "stbl");
      var stsd = stbl && child(b, stbl, "stsd");
      if (!stsd) continue;
      var entries = boxes(b, stsd.body + 8, stsd.end); // fullbox(4) + entry_count(4)
      if (!entries.length) continue;
      var entry = entries[0];

      var width = 0, height = 0, volume = 0;
      var tkhd = child(b, traks[i], "tkhd");
      if (tkhd && tkhd.body + 84 <= tkhd.end) {
        var isV1 = b[tkhd.body] === 1;
        var wOff = tkhd.body + (isV1 ? 88 : 76);
        var vOff = tkhd.body + (isV1 ? 48 : 36);
        width = u32(b, wOff) / 65536;
        height = u32(b, wOff + 4) / 65536;
        volume = u16(b, vOff) / 256;
      }

      info = {
        handler: handler,
        timescale: ts || 1000,
        declaredDuration: dur,
        entryType: entry.type,
        entryBytes: b.subarray(entry.start, entry.end), // 原样保留 avcC / esds
        width: Math.round(width),
        height: Math.round(height),
        volume: volume
      };
    }
    if (!info) throw unsupported(label + " 的 moov 结构不认识");
    return { track: info, top: top };
  }

  /* ============================ 解析样本 ============================ */
  /** 按 moof/traf/trun 展开样本表：字节区间、时长、合成偏移、是否关键帧 */
  function parseSamples(b, label) {
    var top = boxes(b, 0, b.length);
    var samples = [];
    var allSync = true;

    for (var i = 0; i < top.length; i++) {
      var moof = top[i];
      if (moof.type !== "moof") continue;
      var traf = child(b, moof, "traf");
      if (!traf) continue;
      var kids = boxes(b, traf.body, traf.end);
      var tfhd = findBox(kids, "tfhd");
      if (!tfhd) continue;

      var tfFlags = u32(b, tfhd.body) & 0xffffff;
      var p = tfhd.body + 8; // version/flags(4) + track_ID(4)
      var baseDataOffset = 0;
      var hasBase = false;
      var defDur = 0, defSize = 0, defFlags = 0;
      if (tfFlags & 0x01) { baseDataOffset = u64(b, p); p += 8; hasBase = true; }
      if (tfFlags & 0x02) p += 4;
      if (tfFlags & 0x08) { defDur = u32(b, p); p += 4; }
      if (tfFlags & 0x10) { defSize = u32(b, p); p += 4; }
      if (tfFlags & 0x20) { defFlags = u32(b, p); p += 4; }

      // 没有 base_data_offset 时，样本数据紧跟在这个 moof 之后；
      // 若紧跟的是 mdat，则要跳过它的 box 头（规范说「data follows the moof」，
      // 但实际文件里 moof 后面是 mdat 头 + 数据，少跳 8 字节就会整体错位）
      var cursor = hasBase ? baseDataOffset : moof.end;
      if (!hasBase && moof.end + 8 <= b.length && fourcc(b, moof.end + 4) === "mdat") {
        var hdr = u32(b, moof.end) === 1 ? 16 : 8;
        cursor = moof.end + hdr;
      }

      for (var j = 0; j < kids.length; j++) {
        if (kids[j].type !== "trun") continue;
        var trun = kids[j];
        var trunVer = b[trun.body];
        var f = u32(b, trun.body) & 0xffffff;
        var count = u32(b, trun.body + 4);
        var q = trun.body + 8;
        var dataOffset = 0;
        if (f & 0x01) { dataOffset = i32(b, q); q += 4; }
        var hasFirst = !!(f & 0x04);
        var firstFlags = hasFirst ? u32(b, q) : 0;
        if (hasFirst) q += 4;

        var pos = (f & 0x01) ? (moof.start + dataOffset) : cursor;

        for (var k = 0; k < count; k++) {
          var dur = defDur;
          var size = defSize;
          var flags = (hasFirst && k === 0) ? firstFlags : defFlags;
          var cts = 0;
          if (f & 0x100) { dur = u32(b, q); q += 4; }
          if (f & 0x200) { size = u32(b, q); q += 4; }
          if (f & 0x400) { flags = u32(b, q); q += 4; }
          if (f & 0x800) { cts = trunVer === 1 ? i32(b, q) : u32(b, q); q += 4; }

          if (!size) throw unsupported(label + " 里有大小为 0 的样本");
          if (pos < 0 || pos + size > b.length) {
            throw unsupported(label + " 的样本越界（文件可能被截断）");
          }
          samples.push({
            offset: pos,
            size: size,
            duration: dur || 0,
            cts: cts,
            sync: (flags & 0x00010000) === 0
          });
          if (flags & 0x00010000) allSync = false;
          pos += size;
        }
        cursor = pos;
      }
    }

    if (!samples.length) throw unsupported(label + " 里没有找到任何样本（可能是初始化段）");
    return { samples: samples, allSync: allSync };
  }

  /* ============================ 写 ============================ */
  function w32(out, o, v) {
    v = v >>> 0;
    out[o] = (v >>> 24) & 0xff;
    out[o + 1] = (v >>> 16) & 0xff;
    out[o + 2] = (v >>> 8) & 0xff;
    out[o + 3] = v & 0xff;
  }
  function w16(out, o, v) { out[o] = (v >>> 8) & 0xff; out[o + 1] = v & 0xff; }
  function wType(out, o, s) { for (var i = 0; i < 4; i++) out[o + i] = s.charCodeAt(i); }

  function concat(parts) {
    var total = 0, i;
    for (i = 0; i < parts.length; i++) total += parts[i].length;
    var out = new Uint8Array(total);
    var at = 0;
    for (i = 0; i < parts.length; i++) { out.set(parts[i], at); at += parts[i].length; }
    return out;
  }

  /** 普通 box：size + type + 内容 */
  function box(type, parts) {
    var body = parts && parts.length ? concat(parts) : new Uint8Array(0);
    var out = new Uint8Array(8 + body.length);
    w32(out, 0, out.length);
    wType(out, 4, type);
    out.set(body, 8);
    return out;
  }

  /** 把 version/flags 写进 4 字节头 */
  function vf(version, flags) {
    var h = new Uint8Array(4);
    h[0] = version & 0xff;
    h[1] = (flags >>> 16) & 0xff;
    h[2] = (flags >>> 8) & 0xff;
    h[3] = flags & 0xff;
    return h;
  }

  function u32s(values) {
    var out = new Uint8Array(values.length * 4);
    for (var i = 0; i < values.length; i++) w32(out, i * 4, values[i]);
    return out;
  }

  /** unity matrix（9 × int32） */
  function matrixBytes() {
    var m = new Uint8Array(36);
    var vals = [0x00010000, 0, 0, 0, 0x00010000, 0, 0, 0, 0x40000000];
    for (var i = 0; i < 9; i++) w32(m, i * 4, vals[i]);
    return m;
  }

  function buildFtyp() {
    var major = new Uint8Array(8);
    wType(major, 0, "isom");
    w32(major, 4, 0x200);
    var brands = new Uint8Array(12);
    wType(brands, 0, "isom");
    wType(brands, 4, "iso2");
    wType(brands, 8, "mp41");
    return box("ftyp", [major, brands]);
  }

  /** mvhd v0：vf + 96 字节固定内容（含 36 字节 matrix 与 24 字节 pre_defined） */
  function buildMvhd(durationMs, nextTrackId) {
    var b = new Uint8Array(96);
    // 相对内容起点（vf 之后）的偏移
    w32(b, 0, 0);            // creation_time
    w32(b, 4, 0);            // modification_time
    w32(b, 8, 1000);         // timescale
    w32(b, 12, durationMs);  // duration
    w32(b, 16, 0x00010000);  // rate 1.0
    w16(b, 20, 0x0100);      // volume 1.0
    b.set(matrixBytes(), 28);        // matrix @28..64
    w32(b, 88, nextTrackId);         // next_track_ID @88..92
    return box("mvhd", [vf(0, 0), b]);
  }

  /** tkhd v0：vf + 80 字节固定内容（含 matrix，末尾 width/height） */
  function buildTkhd(o) {
    var b = new Uint8Array(80);
    w32(b, 0, 0);                 // creation_time
    w32(b, 4, 0);                 // modification_time
    w32(b, 8, o.trackId);         // track_ID
    w32(b, 16, o.durationMs);     // duration（电影时间刻度）
    w16(b, 28, 0);                // layer
    w16(b, 30, 0);                // alternate_group
    w16(b, 32, o.isVideo ? 0 : Math.round((o.volume || 1) * 256)); // volume
    b.set(matrixBytes(), 36);     // matrix @36..72
    w32(b, 72, o.isVideo ? Math.round(o.width * 65536) : 0);  // width 16.16
    w32(b, 76, o.isVideo ? Math.round(o.height * 65536) : 0); // height 16.16
    return box("tkhd", [vf(0, 0x000003), b]); // enabled | in_movie
  }

  function buildMdhd(timescale, duration) {
    var b = new Uint8Array(20);
    w32(b, 0, 0);           // creation_time
    w32(b, 4, 0);           // modification_time
    w32(b, 8, timescale);
    w32(b, 12, duration);
    w16(b, 16, 0x55c4);     // language 'und'
    w16(b, 18, 0);          // pre_defined
    return box("mdhd", [vf(0, 0), b]);
  }

  function buildHdlr(isVideo) {
    var b = new Uint8Array(20);
    wType(b, 4, isVideo ? "vide" : "soun"); // pre_defined(4) 之后是 handler_type
    var name = isVideo ? "VideoHandler" : "SoundHandler";
    var nm = new Uint8Array(name.length + 1);
    for (var i = 0; i < name.length; i++) nm[i] = name.charCodeAt(i);
    return box("hdlr", [vf(0, 0), b, nm]);
  }

  function buildDinf() {
    var url = box("url ", [vf(0, 0x000001)]); // self-contained
    var dref = box("dref", [vf(0, 0), u32s([1]), url]);
    return box("dinf", [dref]);
  }

  /** 连续样本合并成 run（一个 run = 一个 chunk） */
  function runsOf(samples) {
    var runs = [];
    var cur = null;
    for (var i = 0; i < samples.length; i++) {
      var s = samples[i];
      if (cur && s.offset === cur.end) {
        cur.end = s.offset + s.size;
        cur.count++;
      } else {
        cur = { start: s.offset, end: s.offset + s.size, count: 1 };
        runs.push(cur);
      }
    }
    return runs;
  }

  function buildStbl(o) {
    var samples = o.samples;
    var runs = o.runs;
    var parts = [];

    // stsd：只放一份原始条目（avcC / esds 原样搬过来）
    parts.push(box("stsd", [vf(0, 0), u32s([1]), o.entryBytes]));

    // stts：连续相同时长合并
    var sttsRuns = [];
    for (var i = 0; i < samples.length; i++) {
      var d = samples[i].duration;
      var last = sttsRuns[sttsRuns.length - 1];
      if (last && last.d === d) last.n++;
      else sttsRuns.push({ n: 1, d: d });
    }
    var sttsBody = new Uint8Array(sttsRuns.length * 8);
    for (i = 0; i < sttsRuns.length; i++) {
      w32(sttsBody, i * 8, sttsRuns[i].n);
      w32(sttsBody, i * 8 + 4, sttsRuns[i].d);
    }
    parts.push(box("stts", [vf(0, 0), u32s([sttsRuns.length]), sttsBody]));

    // ctts：有非零合成偏移才写（B 帧必需）；出现负数就用 v1
    var needCtts = false;
    var minCts = 0;
    for (i = 0; i < samples.length; i++) {
      if (samples[i].cts !== 0) needCtts = true;
      if (samples[i].cts < minCts) minCts = samples[i].cts;
    }
    if (needCtts) {
      var cttsRuns = [];
      for (i = 0; i < samples.length; i++) {
        var c = samples[i].cts;
        var lc = cttsRuns[cttsRuns.length - 1];
        if (lc && lc.c === c) lc.n++;
        else cttsRuns.push({ n: 1, c: c });
      }
      var body = new Uint8Array(cttsRuns.length * 8);
      for (i = 0; i < cttsRuns.length; i++) {
        w32(body, i * 8, cttsRuns[i].n);
        w32(body, i * 8 + 4, cttsRuns[i].c);
      }
      parts.push(box("ctts", [vf(minCts < 0 ? 1 : 0, 0), u32s([cttsRuns.length]), body]));
    }

    // stss：有关键帧标记就写（全同步可省，播放器按全同步处理）
    if (o.allSync === false) {
      var sync = [];
      for (i = 0; i < samples.length; i++) if (samples[i].sync) sync.push(i + 1);
      if (sync.length && sync.length < samples.length) {
        parts.push(box("stss", [vf(0, 0), u32s([sync.length]), u32s(sync)]));
      }
    }

    // stsc：一个 run 一个 chunk
    var stscBody = new Uint8Array(runs.length * 12);
    for (i = 0; i < runs.length; i++) {
      w32(stscBody, i * 12, i + 1);        // first_chunk
      w32(stscBody, i * 12 + 4, runs[i].count); // samples_per_chunk
      w32(stscBody, i * 12 + 8, 1);        // sample_description_index
    }
    parts.push(box("stsc", [vf(0, 0), u32s([runs.length]), stscBody]));

    // stsz：sample_size = 0（逐样本给）
    var sizes = new Uint8Array(samples.length * 4);
    for (i = 0; i < samples.length; i++) w32(sizes, i * 4, samples[i].size);
    parts.push(box("stsz", [vf(0, 0), u32s([0, samples.length]), sizes]));

    // stco：每个 chunk 的绝对偏移（文件 < 4 GB 才走 32 位）
    parts.push(box("stco", [vf(0, 0), u32s([runs.length]), u32s(o.chunkOffsets)]));

    return box("stbl", parts);
  }

  function buildMinf(o) {
    var head = o.isVideo
      ? box("vmhd", [vf(0, 0x000001), new Uint8Array(8)]) // graphicsmode + opcolor
      : box("smhd", [vf(0, 0), new Uint8Array(4)]);       // balance + reserved
    return box("minf", [head, buildDinf(), buildStbl(o)]);
  }

  function buildTrak(o) {
    var mdia = box("mdia", [
      buildMdhd(o.timescale, o.trackDuration),
      buildHdlr(o.isVideo),
      buildMinf(o)
    ]);
    return box("trak", [buildTkhd(o), mdia]);
  }

  /* ============================ 对外 ============================ */
  /** 编解码是否落在首版支持范围内（H.264 + AAC） */
  function canRemux(videoCodecs, audioCodecs) {
    var v = String(videoCodecs || "").split(".")[0];
    var a = String(audioCodecs || "").split(".")[0];
    if (v && !VIDEO_OK.test(v)) return false;
    if (a && !AUDIO_OK.test(a)) return false;
    return true;
  }

  /**
   * @param {Uint8Array|ArrayBuffer} videoBytes 视频 .m4s 全文
   * @param {Uint8Array|ArrayBuffer} audioBytes 音频 .m4s 全文
   * @returns {{blob: Blob, bytes: number, durationMs: number, videoSamples: number, audioSamples: number}}
   */
  function remux(videoBytes, audioBytes) {
    var vB = bytesOf(videoBytes);
    var aB = bytesOf(audioBytes);
    var total = vB.length + aB.length;
    if (total > MAX_BYTES) {
      throw unsupported("文件过大（" + Math.round(total / 1048576) + " MB，上限 " +
        Math.round(MAX_BYTES / 1048576) + " MB），请改用分开下载");
    }

    var vInit = parseInit(vB, "视频流");
    var aInit = parseInit(aB, "音频流");
    if (!VIDEO_OK.test(vInit.track.entryType)) {
      throw unsupported("视频编码 " + vInit.track.entryType + " 暂不支持自动合并（仅 H.264）");
    }
    if (!AUDIO_OK.test(aInit.track.entryType)) {
      throw unsupported("音频编码 " + aInit.track.entryType + " 暂不支持自动合并（仅 AAC）");
    }

    var vS = parseSamples(vB, "视频流");
    var aS = parseSamples(aB, "音频流");
    var vRuns = runsOf(vS.samples);
    var aRuns = runsOf(aS.samples);

    var vDur = 0, aDur = 0, i;
    for (i = 0; i < vS.samples.length; i++) vDur += vS.samples[i].duration;
    for (i = 0; i < aS.samples.length; i++) aDur += aS.samples[i].duration;

    var vTs = vInit.track.timescale || 1000;
    var aTs = aInit.track.timescale || 1000;
    var vMs = Math.round(vDur / vTs * 1000);
    var aMs = Math.round(aDur / aTs * 1000);
    var movieMs = Math.max(vMs, aMs, 1);

    var ftyp = buildFtyp();

    function buildMoov(vOffsets, aOffsets) {
      var vTrak = buildTrak({
        trackId: 1, isVideo: true, timescale: vTs,
        trackDuration: vDur, durationMs: vMs,
        width: vInit.track.width, height: vInit.track.height, volume: 0,
        entryBytes: vInit.track.entryBytes, samples: vS.samples, runs: vRuns,
        allSync: vS.allSync, chunkOffsets: vOffsets
      });
      var aTrak = buildTrak({
        trackId: 2, isVideo: false, timescale: aTs,
        trackDuration: aDur, durationMs: aMs,
        width: 0, height: 0, volume: aInit.track.volume || 1,
        entryBytes: aInit.track.entryBytes, samples: aS.samples, runs: aRuns,
        allSync: aS.allSync, chunkOffsets: aOffsets
      });
      return box("moov", [buildMvhd(movieMs, 3), vTrak, aTrak]);
    }

    // 先用占位偏移量一次 moov 大小：uint32 定长，真实偏移不会改变尺寸
    var probe = buildMoov(new Array(vRuns.length).fill(0), new Array(aRuns.length).fill(0));
    var headerSize = ftyp.length + probe.length + 8; // + mdat 8 字节头

    var vOffsets = [], aOffsets = [];
    var cursor = headerSize;
    for (i = 0; i < vRuns.length; i++) { vOffsets.push(cursor); cursor += vRuns[i].end - vRuns[i].start; }
    for (i = 0; i < aRuns.length; i++) { aOffsets.push(cursor); cursor += aRuns[i].end - aRuns[i].start; }
    var payload = cursor - headerSize;

    var moov = buildMoov(vOffsets, aOffsets);
    if (moov.length !== probe.length) {
      throw new Error("mux: moov 尺寸不稳定（占位 " + probe.length + " / 实际 " + moov.length + "）");
    }

    var mdatHead = new Uint8Array(8);
    w32(mdatHead, 0, payload + 8); // < 4GB，32 位 size 够用
    wType(mdatHead, 4, "mdat");

    // 零拷贝：直接引用输入缓冲区的片段
    var parts = [ftyp, moov, mdatHead];
    for (i = 0; i < vRuns.length; i++) parts.push(vB.subarray(vRuns[i].start, vRuns[i].end));
    for (i = 0; i < aRuns.length; i++) parts.push(aB.subarray(aRuns[i].start, aRuns[i].end));

    return {
      blob: new Blob(parts, { type: "video/mp4" }),
      bytes: payload,
      durationMs: movieMs,
      videoSamples: vS.samples.length,
      audioSamples: aS.samples.length
    };
  }

  return {
    MAX_BYTES: MAX_BYTES,
    canRemux: canRemux,
    remux: remux,
    // 单测用（生产代码不调）
    _internal: {
      boxes: boxes, parseInit: parseInit, parseSamples: parseSamples, runsOf: runsOf,
      buildMoovParts: function (o) { return buildTrak(o); }
    }
  };
})();

if (typeof globalThis !== "undefined") globalThis.PMMUX = PMMUX;
