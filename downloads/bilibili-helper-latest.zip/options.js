/**
 * Panda 哔哩哔哩助手 · 设置页
 * 所有开关即时保存；账号状态来自 WHAuth；搜索历史只读 chrome.storage.local。
 */
(function () {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));

  let settings = PB.normalize(PB.DEFAULTS);
  let history = [];
  let entitlement = null;
  let entitled = false;
  let toastTimer = 0;
  let clearArmed = false;
  let clearTimer = 0;
  let accountBusy = false;
  let diagnosticsBusy = false;

  function formatSpeed(rate) {
    const value = Number(rate) || 1;
    let text = value.toFixed(2).replace(/0+$/, "");
    if (text.endsWith(".")) text += "0";
    return text + "x";
  }

  function formatDate(value) {
    if (!value) return "—";
    const time = typeof value === "number" ? value : Date.parse(value);
    if (!Number.isFinite(time)) return "—";
    const date = new Date(time);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }

  function showToast(text, kind) {
    const toast = $("#saveToast");
    if (!toast) return;
    clearTimeout(toastTimer);
    toast.textContent = text;
    toast.classList.toggle("is-error", kind === "error");
    toast.classList.add("is-show");
    toastTimer = setTimeout(() => toast.classList.remove("is-show"), 2200);
  }

  function activatePane(name, updateHash) {
    const target = document.getElementById("pane-" + name) ? name : "general";
    $$(".s-nav-item[data-pane]").forEach((button) => {
      const active = button.dataset.pane === target;
      button.classList.toggle("active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
    $$(".s-pane").forEach((pane) => pane.classList.toggle("active", pane.id === "pane-" + target));
    if (updateHash !== false) {
      try { window.history.replaceState(null, "", "#" + target); } catch (e) { /* ignore */ }
    }
  }

  function bindNav() {
    $$(".s-nav-item[data-pane]").forEach((button) => {
      button.addEventListener("click", () => activatePane(button.dataset.pane));
    });
    window.addEventListener("hashchange", () => {
      const name = location.hash.replace(/^#/, "");
      if (name) activatePane(name, false);
    });
  }

  function bindSwitches() {
    const map = {
      settingEnabled: "enabled",
      settingCleanHome: "cleanHome",
      settingHideLive: "hideLive",
      settingHideAds: "hideAds",
      settingRollHistory: "rollHistory",
      settingAntiCocoon: "antiCocoon",
      settingSpeedControl: "speedControl",
      settingRememberSpeed: "rememberSpeed",
      settingAutoWidescreen: "autoWidescreen",
      settingAutoSubtitle: "autoSubtitle",
      settingSearchClean: "searchClean",
      settingSearchHistory: "searchHistory"
    };
    Object.entries(map).forEach(([id, key]) => {
      const input = document.getElementById(id);
      if (!input) return;
      input.addEventListener("change", () => {
        save({ [key]: input.checked });
      });
    });
  }

  function bindChoices() {
    $$("[data-choice]").forEach((group) => {
      const key = group.dataset.choice;
      group.addEventListener("click", (event) => {
        const button = event.target.closest("[data-value]");
        if (!button || !group.contains(button)) return;
        let value = button.dataset.value;
        if (key === "searchHistoryLimit") value = Number(value);
        if (key === "autoplayMode") value = String(value);
        save({ [key]: value });
      });
    });
  }

  function bindTheme() {
    if (!window.WHTheme) return;
    $$("[data-theme-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        WHTheme.set(button.dataset.themeChoice);
        try { localStorage.setItem("pbl_theme_cache", button.dataset.themeChoice); } catch (e) { /* ignore */ }
        renderTheme();
      });
    });
  }

  function renderTheme() {
    if (!window.WHTheme) return;
    const pref = WHTheme.get().pref;
    $$("[data-theme-choice]").forEach((button) => {
      button.classList.toggle("active", button.dataset.themeChoice === pref);
    });
  }

  function render() {
    const checkboxes = {
      settingEnabled: settings.enabled,
      settingCleanHome: settings.cleanHome,
      settingHideLive: settings.hideLive,
      settingHideAds: settings.hideAds,
      settingRollHistory: settings.rollHistory,
      settingAntiCocoon: settings.antiCocoon,
      settingSpeedControl: settings.speedControl,
      settingRememberSpeed: settings.rememberSpeed,
      settingAutoWidescreen: settings.autoWidescreen,
      settingAutoSubtitle: settings.autoSubtitle,
      settingSearchClean: settings.searchClean,
      settingSearchHistory: settings.searchHistory
    };
    Object.entries(checkboxes).forEach(([id, value]) => {
      const input = document.getElementById(id);
      if (input) input.checked = !!value;
    });

    $$("[data-choice='autoplayMode'] [data-value]").forEach((button) => {
      button.classList.toggle("active", button.dataset.value === settings.autoplayMode);
    });
    $$("[data-choice='searchHistoryLimit'] [data-value]").forEach((button) => {
      button.classList.toggle("active", Number(button.dataset.value) === settings.searchHistoryLimit);
    });

    const speed = $("#rememberedSpeed");
    if (speed) speed.textContent = formatSpeed(settings.lastSpeed);

    const activeCount = [
      settings.cleanHome,
      settings.hideLive,
      settings.hideAds,
      settings.rollHistory,
      settings.antiCocoon
    ].filter(Boolean).length;
    const summary = $("#homeSummary");
    if (summary) {
      summary.textContent = settings.enabled
        ? `首页已启用 ${activeCount} / 5 项净化。隐藏内容由 CSS 直接移除占位，推荐网格会自动补位。`
        : "总开关已关闭，首页净化暂不生效。";
    }

    const count = $("#searchHistoryCount");
    if (count) count.textContent = String(history.length);
    renderHistory();
    renderTheme();
    updateAntiCocoonState();
  }

  function renderVersion() {
    let version = "1.1.3";
    try {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest) {
        version = chrome.runtime.getManifest().version;
      }
    } catch (e) { /* ignore */ }
    $$(".s-brand-ver").forEach((el) => { el.textContent = "v" + version; });
    const metaCaps = $$(".pbl-side-meta .ui-cap");
    if (metaCaps[1]) metaCaps[1].textContent = "V" + version;
    const about = $("#aboutVersion");
    if (about) about.textContent = "v" + version;
  }

  function applyEntitlement(next) {
    entitlement = next || null;
    entitled = PB.isProEntitlement(entitlement);
    const banner = $("#proGateBanner");
    if (banner) banner.classList.toggle("pbl-hidden", entitled);
    const app = $(".s-app");
    if (app) app.classList.toggle("is-gated", !entitled);
    $$(".s-pane:not(#pane-account)").forEach((pane) => {
      try { pane.inert = !entitled; } catch (e) { /* ignore */ }
    });
  }

  async function save(patch) {
    if (!entitled) {
      showToast("需要 Panda PRO 激活后才能修改", "error");
      return;
    }
    try {
      settings = await PB.saveSettings(patch);
      if (Object.prototype.hasOwnProperty.call(patch, "searchHistoryLimit")) {
        history = await PB.trimSearchHistory(settings.searchHistoryLimit);
      }
      render();
      showToast("已保存");
    } catch (error) {
      showToast("保存失败：" + (error.message || "请重试"), "error");
    }
  }

  /* ---------------- 搜索历史 ---------------- */

  async function loadHistory() {
    history = await PB.getSearchHistory();
    const count = $("#searchHistoryCount");
    if (count) count.textContent = String(history.length);
    renderHistory();
  }

  function renderHistory() {
    const box = $("#searchHistoryChips");
    if (!box) return;
    box.textContent = "";
    const shown = history.slice(0, 10);
    if (!shown.length) {
      const note = document.createElement("span");
      note.className = "pbl-inline-note";
      note.textContent = "还没有本地搜索记录。";
      box.appendChild(note);
      return;
    }
    shown.forEach((item) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "pbl-history-chip";
      chip.textContent = item.q;
      chip.title = "在 B 站搜索：" + item.q;
      chip.addEventListener("click", () => {
        const url = "https://search.bilibili.com/all?keyword=" + encodeURIComponent(item.q);
        if (typeof chrome !== "undefined" && chrome.tabs) chrome.tabs.create({ url });
        else window.open(url, "_blank", "noopener");
      });
      box.appendChild(chip);
    });
    if (history.length > shown.length) {
      const more = document.createElement("span");
      more.className = "pbl-inline-note";
      more.textContent = `还有 ${history.length - shown.length} 条，进入搜索框可查看全部`;
      box.appendChild(more);
    }
  }

  function bindProGate() {
    const button = $("#proGateBtn");
    if (!button) return;
    button.addEventListener("click", () => {
      if (typeof chrome !== "undefined" && chrome.tabs && chrome.runtime) {
        chrome.tabs.create({ url: chrome.runtime.getURL("account.html") });
      } else {
        location.href = "account.html";
      }
    });
  }

  function bindHistoryActions() {
    const clear = $("#clearSearchHistory");
    if (!clear) return;
    clear.addEventListener("click", async () => {
      if (!clearArmed) {
        clearArmed = true;
        clear.textContent = "确认清空？";
        clear.classList.add("danger");
        clearTimer = setTimeout(() => {
          clearArmed = false;
          clear.textContent = "清空历史";
          clear.classList.remove("danger");
        }, 2800);
        return;
      }
      clearArmed = false;
      clearTimeout(clearTimer);
      history = await PB.clearSearchHistory();
      clear.textContent = "清空历史";
      clear.classList.remove("danger");
      render();
      showToast("本地搜索历史已清空");
    });
  }

  /* ---------------- 账号 ---------------- */

  function timeout(promise, ms) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        resolve(null);
      }, ms);
      Promise.resolve(promise).then((value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      }).catch(() => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(null);
      });
    });
  }

  function setAccountBadge(text, kind) {
    const badge = $("#accountBadge");
    if (!badge) return;
    badge.textContent = text;
    badge.className = "pbl-account-badge" + (kind ? " " + kind : "");
    const side = $("#sideAccountChip");
    if (side) {
      side.textContent = text;
      side.className = "p-chip pbl-nav-chip" + (kind === "pro" ? " pro" : "");
    }
  }

  function renderGuest(message) {
    const email = $("#accountEmail");
    const plan = $("#accountPlan");
    const planValue = $("#accountPlanValue");
    const expiry = $("#accountExpiry");
    const open = $("#accountOpen");
    if (email) email.textContent = "未登录";
    if (plan) plan.textContent = "登录并激活 Panda PRO 后启用全部增强";
    if (planValue) planValue.textContent = "未登录";
    if (expiry) expiry.textContent = "—";
    if (open) open.textContent = "注册 / 找回密码";
    const quickLogin = $("#quickLoginWrap");
    if (quickLogin) quickLogin.classList.toggle("pbl-hidden", !window.WHAuth);
    const password = $("#quickLoginPassword");
    if (password) password.value = "";
    $("#accountSignOut").classList.add("pbl-hidden");
    $("#accountOffline").classList.add("pbl-hidden");
    setAccountBadge("GUEST");
    if (message) {
      showAccountMessage(message.text, message.kind);
    } else {
      showAccountMessage("");
    }
  }

  function showAccountMessage(text, kind) {
    const el = $("#accountMessage");
    if (!el) return;
    el.textContent = text || "";
    let className = "p-note pbl-note-block";
    if (text) {
      className += kind === "error" ? " p-note-err" : kind === "warn" ? " p-note-warn" : " p-note-ok";
    } else {
      className += " pbl-hidden";
    }
    el.className = className;
  }

  async function renderAccount() {
    if (!window.WHAuth) {
      renderGuest();
      return;
    }
    let session = null;
    try { session = await WHAuth.peekSession(); } catch (e) { session = null; }
    if (!session || !session.signed_in) {
      renderGuest();
      return;
    }

    const quickLogin = $("#quickLoginWrap");
    if (quickLogin) quickLogin.classList.add("pbl-hidden");
    const quickPassword = $("#quickLoginPassword");
    if (quickPassword) quickPassword.value = "";
    $("#accountEmail").textContent = session.email || "(未知邮箱)";
    $("#accountOpen").textContent = "账号与兑换";
    $("#accountSignOut").classList.remove("pbl-hidden");
    setAccountBadge(session.stale ? "离线" : "已登录");
    showAccountMessage("");

    const membership = await timeout(WHAuth.getMembership(), 5200);
    if (!membership) {
      $("#accountPlan").textContent = "已登录 · 会员状态暂时无法获取";
      $("#accountPlanValue").textContent = "已登录";
      setAccountBadge("已登录");
      return;
    }
    if (membership.signed_in === false) {
      renderGuest({ text: membership.reason || "会话已失效，请重新登录", kind: "error" });
      return;
    }
    const offline = !!membership.offline;
    $("#accountOffline").classList.toggle("pbl-hidden", !offline);
    $("#accountPlan").textContent = membership.pro
      ? "Panda PRO 会员"
      : "已登录 · 免费用户（需激活 PRO 解锁增强）";
    $("#accountPlanValue").textContent = membership.pro ? "PRO" : "免费";
    $("#accountExpiry").textContent = membership.expires_at ? formatDate(membership.expires_at) : (membership.pro ? "长期" : "—");
    setAccountBadge(membership.pro ? "PRO" : "FREE", membership.pro ? "pro" : "free");
    if (membership.reason && offline) {
      showAccountMessage(membership.reason, "warn");
    } else if (membership.reason && !membership.pro) {
      showAccountMessage(membership.reason, "error");
    }
  }

  function bindQuickLogin() {
    const form = $("#quickLoginForm");
    if (!form) return;
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!window.WHAuth) {
        showAccountMessage("账号模块未加载，请刷新设置页", "error");
        return;
      }
      const email = ($("#quickLoginEmail").value || "").trim();
      const password = $("#quickLoginPassword").value || "";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showAccountMessage("请输入有效的 Panda 邮箱", "error");
        $("#quickLoginEmail").focus();
        return;
      }
      if (password.length < 6) {
        showAccountMessage("密码至少 6 位", "error");
        $("#quickLoginPassword").focus();
        return;
      }
      const submit = $("#quickLoginSubmit");
      if (submit.disabled) return;
      const original = submit.textContent;
      submit.disabled = true;
      submit.textContent = "登录中…";
      showAccountMessage("");
      try {
        await WHAuth.signIn(email, password);
        $("#quickLoginPassword").value = "";
        await renderAccount();
        showToast("Panda 登录成功");
      } catch (error) {
        showAccountMessage(error.message || "Panda 登录失败，请重试", "error");
      } finally {
        submit.disabled = false;
        submit.textContent = original;
      }
    });
  }

  function bindAccountActions() {
    const open = $("#accountOpen");
    if (open) {
      open.addEventListener("click", () => {
        if (typeof chrome !== "undefined" && chrome.tabs && chrome.runtime) {
          chrome.tabs.create({ url: chrome.runtime.getURL("account.html") });
        } else {
          location.href = "account.html";
        }
      });
    }
    const redeem = $("#accountRedeem");
    if (redeem) redeem.addEventListener("click", () => open && open.click());

    const refresh = $("#accountRefresh");
    if (refresh) {
      refresh.addEventListener("click", async () => {
        if (accountBusy) return;
        accountBusy = true;
        refresh.disabled = true;
        refresh.textContent = "刷新中…";
        await renderAccount();
        refresh.disabled = false;
        refresh.textContent = "刷新状态";
        accountBusy = false;
        showToast("账号状态已刷新");
      });
    }

    const signOut = $("#accountSignOut");
    if (signOut) {
      signOut.addEventListener("click", async () => {
        if (!confirm("退出登录？本地浏览、倍速与搜索历史不会受到影响。")) return;
        signOut.disabled = true;
        try {
          await WHAuth.signOut();
          renderGuest();
          showToast("已退出登录");
        } catch (e) {
          showToast("退出失败：" + (e.message || "请重试"), "error");
        } finally {
          signOut.disabled = false;
        }
      });
    }
  }

  /* ---------------- 诊断 ---------------- */

  async function runtimeMessage(message) {
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) return null;
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (e) {
      return null;
    }
  }

  async function getActiveTab() {
    if (typeof chrome === "undefined" || !chrome.tabs || !chrome.tabs.query) return null;
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      return tabs && tabs[0];
    } catch (e) {
      return null;
    }
  }

  async function updateAntiCocoonState() {
    const el = $("#antiCocoonState");
    if (!el) return;
    const diagnostics = await runtimeMessage({ type: "PBL_GET_DIAGNOSTICS" });
    if (!diagnostics) {
      el.textContent = "规则状态需要在扩展环境中读取。";
      return;
    }
    if (!entitled) {
      el.textContent = "Panda PRO 未激活：动态规则与全部增强已暂停。";
      return;
    }
    if (!settings.enabled) {
      el.textContent = "总开关关闭：动态规则已暂停。";
      return;
    }
    if (!settings.antiCocoon) {
      el.textContent = "当前关闭：列表请求会按 B 站默认携带 Cookie。";
      return;
    }
    el.textContent = diagnostics.dynamicRuleCount >= diagnostics.expectedRuleCount
      ? `动态规则已就绪：${diagnostics.dynamicRuleCount} 条接口规则生效。`
      : `规则数量异常（${diagnostics.dynamicRuleCount} / ${diagnostics.expectedRuleCount}），可到「帮助与自检」查看。`;
  }

  function addDiagRow(label, state, detail) {
    const row = document.createElement("div");
    row.className = "pbl-diag-row " + (state || "");
    const dot = document.createElement("span");
    dot.className = "pbl-dot" + (state === "ok" ? " is-on" : state === "fail" ? " is-warn" : "");
    const text = document.createElement("span");
    text.className = "pbl-diag-text";
    text.textContent = label;
    const value = document.createElement("span");
    value.className = "pbl-diag-state";
    value.textContent = detail || "—";
    row.appendChild(dot);
    row.appendChild(text);
    row.appendChild(value);
    return row;
  }

  async function runDiagnostics() {
    if (diagnosticsBusy) return;
    diagnosticsBusy = true;
    const button = $("#runDiagnostics");
    const result = $("#diagResult");
    const time = $("#diagnosticsTime");
    button.disabled = true;
    button.textContent = "检测中…";
    result.textContent = "";
    if (time) time.textContent = "";
    const rows = [];

    const isExt = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id;
    rows.push(addDiagRow("扩展上下文", isExt ? "ok" : "fail", isExt ? "正常" : "不是扩展环境"));
    rows.push(addDiagRow("设置存储", settings ? "ok" : "fail", settings ? "已读取" : "读取失败"));
    rows.push(addDiagRow("Panda PRO", entitled ? "ok" : "fail", entitled ? "已激活" : "未激活 · 全部增强关闭"));
    rows.push(addDiagRow("拒绝信息茧房", entitled && settings.antiCocoon && settings.enabled ? "ok" : "", entitled && settings.antiCocoon && settings.enabled ? "已开启" : "未生效"));

    const diag = await runtimeMessage({ type: "PBL_GET_DIAGNOSTICS" });
    if (diag) {
      const expected = diag.pro ? (diag.expectedRuleCount || 8) : 0;
      const ok = !diag.pro || !settings.enabled || !settings.antiCocoon || diag.dynamicRuleCount >= expected;
      rows.push(addDiagRow("动态规则", ok ? "ok" : "fail", `${diag.dynamicRuleCount} / ${expected} 条`));
    } else {
      rows.push(addDiagRow("动态规则", "fail", "Service Worker 无响应"));
    }

    const tab = await getActiveTab();
    if (!tab) {
      rows.push(addDiagRow("当前标签页", "", "无法读取"));
    } else if (!PB.isBilibili(tab.url || "")) {
      rows.push(addDiagRow("B 站页面注入", "", "当前不是 B 站页面"));
    } else {
      try {
        const ping = await chrome.tabs.sendMessage(tab.id, { type: "PBL_PING" });
        if (ping && ping.ok) {
          const ads = Number(ping.stats && ping.stats.ads) || 0;
          const live = Number(ping.stats && ping.stats.live) || 0;
          rows.push(addDiagRow("B 站页面注入", "ok", `${ping.page} · 广告 ${ads} / 直播 ${live}`));
        } else {
          rows.push(addDiagRow("B 站页面注入", "fail", "内容脚本无响应，刷新页面后重试"));
        }
      } catch (e) {
        rows.push(addDiagRow("B 站页面注入", "fail", "内容脚本未注入，刷新页面后重试"));
      }
    }

    rows.forEach((row) => result.appendChild(row));
    if (time) time.textContent = "检测于 " + new Date().toLocaleTimeString("zh-CN", { hour12: false });
    button.disabled = false;
    button.textContent = "重新检测";
    diagnosticsBusy = false;
  }

  function bindDiagnostics() {
    const button = $("#runDiagnostics");
    if (button) button.addEventListener("click", runDiagnostics);
  }

  /* ---------------- 其他 ---------------- */

  function bindReset() {
    const reset = $("#resetSettings");
    if (!reset) return;
    reset.addEventListener("click", async () => {
      if (!confirm("恢复默认设置？所有功能开关和倍速会复位，但本地搜索历史不会被删除。")) return;
      await PB.saveSettings(PB.DEFAULTS);
      settings = await PB.getSettings();
      render();
      showToast("已恢复默认设置");
    });
  }

  function bindSpeed() {
    const reset = $("#resetSpeed");
    if (!reset) return;
    reset.addEventListener("click", () => save({ lastSpeed: 1 }));
  }

  async function init() {
    bindNav();
    bindSwitches();
    bindChoices();
    bindTheme();
    bindProGate();
    bindHistoryActions();
    bindQuickLogin();
    bindAccountActions();
    bindDiagnostics();
    bindReset();
    bindSpeed();

    if (window.WHTheme) {
      WHTheme.init({ storageKey: "pbl_theme", fallback: "auto" });
      WHTheme.onChange((theme, pref) => {
        try { localStorage.setItem("pbl_theme_cache", pref); } catch (e) { /* ignore */ }
        renderTheme();
      });
    }

    const hash = location.hash.replace(/^#/, "");
    activatePane(hash || "general", false);

    let cached = null;
    [settings, cached] = await Promise.all([PB.getSettings(), PB.getEntitlementCache()]);
    renderVersion();
    applyEntitlement(cached);
    await loadHistory();
    render();
    renderAccount();

    PB.onSettingsChanged((next) => {
      settings = next;
      render();
    });
    PB.onStorageChange((changes, areaName) => {
      if (areaName === "local" && changes[PB.SEARCH_HISTORY_KEY]) {
        loadHistory();
      }
      if (areaName === "local" && changes[PB.ENTITLEMENT_KEY]) {
        applyEntitlement(changes[PB.ENTITLEMENT_KEY].newValue);
      }
      if (areaName === "local" && changes[PB.AUTH_STORE_KEY]) {
        renderAccount();
        setTimeout(() => PB.requestEntitlement(true).then((ent) => {
          if (ent) applyEntitlement(ent);
        }).catch(() => {}), 300);
      }
    });
    PB.requestEntitlement(!cached).then((ent) => {
      if (ent) applyEntitlement(ent);
    }).catch(() => {});
  }

  init().catch((error) => {
    showToast("设置页初始化失败：" + (error.message || "请重开"), "error");
  });
})();
