/**
 * Panda 哔哩哔哩助手 · 账号页
 * 基于 WHAuth（Supabase Auth REST），零第三方依赖。
 */
(function () {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const show = (el, visible) => el && el.classList.toggle("pbl-hidden", !visible);
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  let busy = false;
  let currentTab = "login";

  function say(el, text, kind) {
    if (!el) return;
    el.textContent = text || "";
    el.className = "pbl-form-message" + (kind ? " " + kind : "");
  }

  function formatDate(value) {
    if (!value) return "—";
    const time = typeof value === "number" ? value : Date.parse(value);
    if (!Number.isFinite(time)) return "—";
    const date = new Date(time);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }

  function setBusy(on, label) {
    busy = on;
    document.querySelectorAll("form button").forEach((button) => {
      if (on) {
        if (!button.dataset.originalText) button.dataset.originalText = button.textContent;
        button.disabled = true;
      } else {
        button.disabled = false;
        if (button.dataset.originalText) {
          button.textContent = button.dataset.originalText;
          delete button.dataset.originalText;
        }
      }
    });
    const submit = document.querySelector("form:not(.pbl-hidden) button[type='submit']");
    if (submit && on && label) submit.textContent = label;
  }

  function setBadge(text, kind) {
    const badge = $("#whoBadge");
    if (!badge) return;
    badge.textContent = text;
    badge.className = "pbl-account-badge" + (kind ? " " + kind : "");
  }

  function selectTab(tab) {
    currentTab = tab;
    const tabs = document.querySelectorAll("#authTabs [data-tab]");
    tabs.forEach((button) => {
      const active = button.dataset.tab === tab;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
    });
    show($("#formLogin"), tab === "login");
    show($("#formSignup"), tab === "signup");
    show($("#formReset"), tab === "reset");
    if (tab === "reset") {
      show($("#resetStep1"), true);
      show($("#resetStep2"), false);
    }
    const email = $("#loginEmail");
    if (tab === "login" && email) setTimeout(() => email.focus({ preventScroll: true }), 30);
  }

  function renderTheme() {
    if (!window.WHTheme) return;
    const pref = WHTheme.get().pref;
    document.querySelectorAll("[data-theme-choice]").forEach((button) => {
      const active = button.dataset.themeChoice === pref;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });
  }

  function initTheme() {
    if (!window.WHTheme) return;
    WHTheme.init({ storageKey: "pbl_theme", fallback: "auto" });
    WHTheme.onChange((theme, pref) => {
      try { localStorage.setItem("pbl_theme_cache", pref); } catch (e) { /* ignore */ }
      renderTheme();
    });
    document.querySelectorAll("[data-theme-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        WHTheme.set(button.dataset.themeChoice);
        try { localStorage.setItem("pbl_theme_cache", button.dataset.themeChoice); } catch (e) { /* ignore */ }
        renderTheme();
      });
    });
    renderTheme();
  }

  function timeout(promise, ms) {
    return PB.withTimeout(promise, ms);
  }

  function showGuest(message, kind) {
    show($("#signed"), false);
    show($("#guest"), true);
    if (message) {
      const target = $("#msgLogin");
      selectTab("login");
      say(target, message, kind || "err");
    }
  }

  async function render() {
    if (!window.WHAuth) {
      showGuest("账号模块未加载，请刷新页面重试", "err");
      return;
    }

    let session = null;
    try { session = await WHAuth.peekSession(); } catch (e) { session = null; }
    if (!session || !session.signed_in) {
      show($("#signed"), false);
      show($("#guest"), true);
      show($("#offlineNote"), false);
      return;
    }

    show($("#guest"), false);
    show($("#signed"), true);
    $("#whoEmail").textContent = session.email || "(未知邮箱)";
    $("#whoPlan").textContent = "正在读取会员状态…";
    $("#whoPlanValue").textContent = "—";
    $("#whoExpiry").textContent = "—";
    setBadge(session.stale ? "离线" : "已登录");
    show($("#sessionNote"), false);
    show($("#offlineNote"), false);

    const membership = await timeout(WHAuth.getMembership(), 6500);
    if (!membership) {
      $("#whoPlan").textContent = "已登录 · 会员状态暂时无法获取";
      $("#whoPlanValue").textContent = "已登录";
      setBadge("已登录");
      return;
    }

    if (membership.signed_in === false) {
      showGuest(membership.reason || "会话已失效，请重新登录", "err");
      return;
    }

    const offline = !!membership.offline;
    show($("#offlineNote"), offline);
    if (offline) {
      $("#whoPlan").textContent = "已登录 · 离线，保留上次会员状态";
      $("#whoPlanValue").textContent = membership.pro ? "PRO（离线）" : "免费（离线）";
      setBadge(membership.pro ? "PRO" : "FREE", membership.pro ? "pro" : "free");
      show($("#sessionNote"), true);
      $("#sessionNote").textContent = membership.reason || "当前离线，联网后会自动校验会员状态。";
      $("#whoExpiry").textContent = membership.expires_at ? formatDate(membership.expires_at) : "—";
      return;
    }

    $("#whoPlan").textContent = membership.pro
      ? "Panda PRO 会员"
      : "已登录 · 免费用户（需激活 PRO 解锁增强）";
    $("#whoPlanValue").textContent = membership.pro ? "PRO" : "免费";
    $("#whoExpiry").textContent = membership.expires_at ? formatDate(membership.expires_at) : (membership.pro ? "长期" : "—");
    setBadge(membership.pro ? "PRO" : "FREE", membership.pro ? "pro" : "free");
    if (membership.reason && !membership.pro) {
      show($("#sessionNote"), true);
      $("#sessionNote").textContent = membership.reason;
    }
  }

  function validateEmail(input) {
    const value = (input.value || "").trim();
    if (!EMAIL_RE.test(value)) {
      say(findMessageFor(input), "请输入有效的邮箱地址", "err");
      input.focus();
      return null;
    }
    return value;
  }

  function findMessageFor(input) {
    const form = input.closest("form");
    if (!form) return null;
    return form.querySelector(".pbl-form-message");
  }

  function rememberEmail(email) {
    try {
      if ($("#rememberEmail") && $("#rememberEmail").checked) {
        localStorage.setItem(PB.REMEMBER_EMAIL_KEY, email);
      } else {
        localStorage.removeItem(PB.REMEMBER_EMAIL_KEY);
      }
    } catch (e) { /* ignore */ }
  }

  function prefillRememberedEmail() {
    try {
      const saved = localStorage.getItem(PB.REMEMBER_EMAIL_KEY);
      if (!saved) return;
      if ($("#loginEmail")) $("#loginEmail").value = saved;
      if ($("#rememberEmail")) $("#rememberEmail").checked = true;
    } catch (e) { /* ignore */ }
  }

  function bindTabs() {
    document.querySelectorAll("#authTabs [data-tab]").forEach((button) => {
      button.addEventListener("click", () => selectTab(button.dataset.tab));
    });
  }

  function bindForms() {
    $("#formLogin").addEventListener("submit", async (event) => {
      event.preventDefault();
      if (busy) return;
      const msg = $("#msgLogin");
      const email = validateEmail($("#loginEmail"));
      if (!email) return;
      const password = $("#loginPassword").value;
      if (password.length < 6) {
        say(msg, "密码至少 6 位", "err");
        return;
      }
      setBusy(true, "登录中…");
      say(msg, "正在登录…");
      try {
        await WHAuth.signIn(email, password);
        rememberEmail(email);
        say(msg, "");
        await render();
      } catch (error) {
        say(msg, error.message || "登录失败，请重试", "err");
      } finally {
        setBusy(false);
      }
    });

    $("#formSignup").addEventListener("submit", async (event) => {
      event.preventDefault();
      if (busy) return;
      const msg = $("#msgSignup");
      const email = validateEmail($("#signupEmail"));
      if (!email) return;
      const password = $("#signupPassword").value;
      if (password.length < 6) {
        say(msg, "密码至少 6 位", "err");
        return;
      }
      if (password !== $("#signupPassword2").value) {
        say(msg, "两次输入的密码不一致", "err");
        return;
      }
      setBusy(true, "注册中…");
      say(msg, "正在创建账号…");
      try {
        const result = await WHAuth.signUp(email, password);
        if (result && result.needConfirm) {
          say(msg, "注册成功，请到邮箱完成验证后再登录", "ok");
          $("#loginEmail").value = email;
          selectTab("login");
          say($("#msgLogin"), "注册成功，请到邮箱完成验证后再登录", "ok");
        } else {
          say(msg, "注册成功，已登录", "ok");
          await render();
        }
      } catch (error) {
        say(msg, error.message || "注册失败，请重试", "err");
      } finally {
        setBusy(false);
      }
    });

    $("#formReset").addEventListener("submit", async (event) => {
      event.preventDefault();
      if (busy) return;
      const msg = $("#msgReset");
      if ($("#resetStep2").classList.contains("pbl-hidden")) {
        const email = validateEmail($("#resetEmail"));
        if (!email) return;
        setBusy(true, "发送中…");
        say(msg, "正在发送验证码…");
        try {
          await WHAuth.requestPasswordReset(email);
          say(msg, "验证码已发送，请查收邮箱", "ok");
          show($("#resetStep1"), false);
          show($("#resetStep2"), true);
          $("#resetCode").focus();
        } catch (error) {
          say(msg, error.message || "发送失败，请重试", "err");
        } finally {
          setBusy(false);
        }
        return;
      }

      const code = ($("#resetCode").value || "").trim();
      const password = $("#resetPassword").value;
      if (!code) {
        say(msg, "请输入邮件里的验证码", "err");
        return;
      }
      if (password.length < 6) {
        say(msg, "新密码至少 6 位", "err");
        return;
      }
      if (password !== $("#resetPassword2").value) {
        say(msg, "两次输入的新密码不一致", "err");
        return;
      }
      setBusy(true, "重设中…");
      say(msg, "正在验证并重设密码…");
      try {
        await WHAuth.verifyRecoveryCode($("#resetEmail").value.trim(), code);
        await WHAuth.setNewPassword(password);
        await WHAuth.signOut();
        say(msg, "密码已重设，请用新密码登录", "ok");
        $("#loginEmail").value = $("#resetEmail").value.trim();
        selectTab("login");
        say($("#msgLogin"), "密码已重设，请用新密码登录", "ok");
      } catch (error) {
        say(msg, error.message || "重设失败，请重试", "err");
      } finally {
        setBusy(false);
      }
    });

    $("#redeemForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      if (busy) return;
      const code = ($("#redeemCode").value || "").trim();
      const msg = $("#msgSigned");
      if (!code) {
        say(msg, "请输入兑换码", "err");
        return;
      }
      setBusy(true, "兑换中…");
      say(msg, "正在兑换…");
      try {
        const result = await WHAuth.redeemCode(code);
        say(msg, "兑换成功" + (result && result.expires_at ? "，有效期至 " + formatDate(result.expires_at) : ""), "ok");
        $("#redeemCode").value = "";
        await render();
      } catch (error) {
        say(msg, error.message || "兑换失败，请重试", "err");
      } finally {
        setBusy(false);
      }
    });
  }

  function bindButtons() {
    $("#btnRefresh").addEventListener("click", async () => {
      if (busy) return;
      setBusy(true, "刷新中…");
      await render();
      setBusy(false);
    });

    $("#btnSignOut").addEventListener("click", async () => {
      if (busy) return;
      if (!confirm("退出登录？本地浏览、倍速与搜索历史不会受到影响。")) return;
      setBusy(true, "退出中…");
      try {
        await WHAuth.signOut();
        showGuest();
        say($("#msgLogin"), "已退出登录", "ok");
      } catch (error) {
        say($("#msgSigned"), error.message || "退出失败", "err");
      } finally {
        setBusy(false);
      }
    });

    $("#openOptions").addEventListener("click", () => {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
      } else {
        location.href = "options.html";
      }
    });
  }

  function init() {
    initTheme();
    bindTabs();
    bindForms();
    bindButtons();
    prefillRememberedEmail();
    selectTab("login");
    render().catch(() => {});

    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === "local" && changes[PB.AUTH_STORE_KEY]) {
          render().catch(() => {});
        }
      });
    }
  }

  init();
})();
