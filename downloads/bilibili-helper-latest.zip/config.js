/**
 * Panda 哔哩哔哩助手 · 共享配置与存储
 *
 * 只依赖 WebExtension API；在普通网页预览时退回 localStorage。
 * 设置存 chrome.storage.sync（可跨设备，体积很小），
 * 搜索历史存 chrome.storage.local（只留在当前浏览器，符合功能承诺）。
 */
(function (global) {
  "use strict";

  const SETTINGS_KEY = "pbl_settings";
  const SEARCH_HISTORY_KEY = "pbl_search_history";
  const THEME_KEY = "pbl_theme";
  const REMEMBER_EMAIL_KEY = "pbl_remember_email";
  const AUTH_STORE_KEY = "pbl_auth";
  const ENTITLEMENT_KEY = "pbl_entitlement";
  const MEMBERSHIP_CACHE_KEY = "pbl_membership_cache";

  const DEFAULTS = Object.freeze({
    enabled: true,
    cleanHome: true,
    hideLive: true,
    hideAds: true,
    rollHistory: true,
    antiCocoon: false,
    speedControl: true,
    rememberSpeed: false,
    lastSpeed: 1,
    autoWidescreen: false,
    autoplayMode: "follow",
    autoSubtitle: false,
    searchClean: true,
    searchHistory: false,
    searchHistoryLimit: 20
  });

  const AUTOPLAY_MODES = Object.freeze(["follow", "off", "collections"]);
  const HISTORY_LIMITS = Object.freeze([10, 20, 50, 100]);
  const MAX_HISTORY_STORE = 100;
  const SPEED_MIN = 0.1;
  const SPEED_MAX = 16;

  const hasChrome = typeof chrome !== "undefined" && !!(chrome.storage && chrome.storage.sync);

  const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

  function normalize(raw) {
    const src = raw && typeof raw === "object" ? raw : {};
    const speed = Number(src.lastSpeed);
    const limit = Number(src.searchHistoryLimit);
    const mode = AUTOPLAY_MODES.includes(src.autoplayMode) ? src.autoplayMode : DEFAULTS.autoplayMode;
    return {
      enabled: src.enabled !== false,
      cleanHome: src.cleanHome !== false,
      hideLive: src.hideLive !== false,
      hideAds: src.hideAds !== false,
      rollHistory: src.rollHistory !== false,
      antiCocoon: src.antiCocoon === true,
      speedControl: src.speedControl !== false,
      rememberSpeed: src.rememberSpeed === true,
      lastSpeed: Number.isFinite(speed) ? clamp(speed, SPEED_MIN, SPEED_MAX) : DEFAULTS.lastSpeed,
      autoWidescreen: src.autoWidescreen === true,
      autoplayMode: mode,
      autoSubtitle: src.autoSubtitle === true,
      searchClean: src.searchClean !== false,
      searchHistory: src.searchHistory === true,
      searchHistoryLimit: HISTORY_LIMITS.includes(limit) ? limit : DEFAULTS.searchHistoryLimit
    };
  }

  function areaGet(area, defaults) {
    return new Promise((resolve) => {
      try {
        area.get(defaults, (value) => resolve(value || {}));
      } catch (e) {
        resolve(defaults);
      }
    });
  }

  function areaSet(area, value) {
    return new Promise((resolve, reject) => {
      try {
        area.set(value, () => {
          const err = chrome.runtime && chrome.runtime.lastError;
          if (err) reject(new Error(err.message || "写入设置失败"));
          else resolve();
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  async function getSettings() {
    if (!hasChrome) {
      try {
        return normalize(JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}"));
      } catch (e) {
        return normalize({});
      }
    }
    const value = await areaGet(chrome.storage.sync, { [SETTINGS_KEY]: DEFAULTS });
    return normalize(value[SETTINGS_KEY]);
  }

  async function saveSettings(patch) {
    const current = await getSettings();
    const next = normalize(Object.assign({}, current, patch || {}));
    if (!hasChrome) {
      try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(next)); } catch (e) { /* ignore */ }
      return next;
    }
    await areaSet(chrome.storage.sync, { [SETTINGS_KEY]: next });
    return next;
  }

  function onSettingsChanged(fn) {
    if (typeof fn !== "function") return () => {};
    if (!hasChrome || !chrome.storage || !chrome.storage.onChanged) return () => {};
    const listener = (changes, areaName) => {
      if (areaName !== "sync" || !changes[SETTINGS_KEY]) return;
      fn(normalize(changes[SETTINGS_KEY].newValue));
    };
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }

  function onStorageChange(fn) {
    if (typeof fn !== "function") return () => {};
    if (!hasChrome || !chrome.storage || !chrome.storage.onChanged) return () => {};
    chrome.storage.onChanged.addListener(fn);
    return () => chrome.storage.onChanged.removeListener(fn);
  }

  async function getSearchHistory() {
    if (!hasChrome) {
      try { return JSON.parse(localStorage.getItem(SEARCH_HISTORY_KEY) || "[]"); } catch (e) { return []; }
    }
    const value = await areaGet(chrome.storage.local, { [SEARCH_HISTORY_KEY]: [] });
    const list = Array.isArray(value[SEARCH_HISTORY_KEY]) ? value[SEARCH_HISTORY_KEY] : [];
    return list.filter((item) => item && typeof item.q === "string" && item.q.trim()).slice(0, MAX_HISTORY_STORE);
  }

  async function saveSearchHistory(list) {
    const clean = (Array.isArray(list) ? list : [])
      .filter((item) => item && typeof item.q === "string" && item.q.trim())
      .slice(0, MAX_HISTORY_STORE);
    if (!hasChrome) {
      try { localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(clean)); } catch (e) { /* ignore */ }
      return clean;
    }
    await areaSet(chrome.storage.local, { [SEARCH_HISTORY_KEY]: clean });
    return clean;
  }

  async function addSearchTerm(keyword, limit) {
    const text = String(keyword || "").replace(/\s+/g, " ").trim().slice(0, 100);
    if (!text) return getSearchHistory();
    const list = await getSearchHistory();
    const next = [{ q: text, t: Date.now() }].concat(list.filter((item) => item.q !== text));
    const cap = HISTORY_LIMITS.includes(Number(limit)) ? Number(limit) : DEFAULTS.searchHistoryLimit;
    return saveSearchHistory(next.slice(0, cap));
  }

  async function trimSearchHistory(limit) {
    const cap = HISTORY_LIMITS.includes(Number(limit)) ? Number(limit) : DEFAULTS.searchHistoryLimit;
    const list = await getSearchHistory();
    return saveSearchHistory(list.slice(0, cap));
  }

  async function clearSearchHistory() {
    if (!hasChrome) {
      try { localStorage.removeItem(SEARCH_HISTORY_KEY); } catch (e) { /* ignore */ }
      return [];
    }
    try { await chrome.storage.local.remove(SEARCH_HISTORY_KEY); } catch (e) { /* ignore */ }
    return [];
  }

  function isBilibili(url) {
    try { return /(^|\.)bilibili\.com$/i.test(new URL(url).hostname); } catch (e) { return false; }
  }

  function pageType(url) {
    let u;
    try { u = new URL(url); } catch (e) { return "other"; }
    if (!isBilibili(u.href)) return "other";
    if (/^live\./i.test(u.hostname)) return "live";
    if (/^search\./i.test(u.hostname)) return "search";
    if (/^\/(video|list|bangumi\/play)\//.test(u.pathname)) return "video";
    if (/^\/search/.test(u.pathname)) return "search";
    if (/^\/popular/.test(u.pathname)) return "popular";
    if (u.pathname === "/" || u.pathname === "/index.html") return "home";
    return "other";
  }

  /* ---------- PRO 权益（所有功能的总门禁） ---------- */
  function isProEntitlement(entitlement) {
    if (!entitlement || !entitlement.signed_in || !entitlement.pro) return false;
    if (!entitlement.expires_at) return true;
    const time = typeof entitlement.expires_at === "number"
      ? entitlement.expires_at
      : Date.parse(entitlement.expires_at);
    return Number.isFinite(time) && time > Date.now();
  }

  function normalizeEntitlement(raw) {
    const src = raw && typeof raw === "object" ? raw : {};
    return {
      signed_in: !!src.signed_in,
      pro: !!src.pro,
      plan: src.plan || "free",
      expires_at: src.expires_at || 0,
      email: typeof src.email === "string" ? src.email : "",
      offline: !!src.offline,
      reason: src.reason || "",
      checked_at: Number(src.checked_at) || 0
    };
  }

  async function getEntitlementCache() {
    if (!hasChrome) {
      try {
        const raw = JSON.parse(localStorage.getItem(ENTITLEMENT_KEY) || "null");
        return raw ? normalizeEntitlement(raw) : null;
      } catch (e) {
        return null;
      }
    }
    const value = await areaGet(chrome.storage.local, {
      [ENTITLEMENT_KEY]: null,
      [MEMBERSHIP_CACHE_KEY]: null
    });
    if (value[ENTITLEMENT_KEY]) return normalizeEntitlement(value[ENTITLEMENT_KEY]);
    const cached = value[MEMBERSHIP_CACHE_KEY];
    if (cached && typeof cached === "object") {
      // auth_util 的会员缓存可作为首次启动时的权益种子。
      return normalizeEntitlement({
        signed_in: true,
        pro: !!cached.pro,
        plan: cached.plan || "free",
        expires_at: cached.expires_at || 0,
        email: cached.email || "",
        checked_at: cached.ts || 0
      });
    }
    return null;
  }

  async function saveEntitlement(entitlement) {
    const next = normalizeEntitlement(entitlement);
    if (!next.checked_at) next.checked_at = Date.now();
    if (!hasChrome) {
      try { localStorage.setItem(ENTITLEMENT_KEY, JSON.stringify(next)); } catch (e) { /* ignore */ }
      return next;
    }
    await areaSet(chrome.storage.local, { [ENTITLEMENT_KEY]: next });
    return next;
  }

  async function requestEntitlement(fresh) {
    if (!hasChrome || !chrome.runtime || !chrome.runtime.sendMessage) return null;
    try {
      return await chrome.runtime.sendMessage({ type: "PBL_GET_ENTITLEMENT", fresh: !!fresh });
    } catch (e) {
      return null;
    }
  }

  async function openAccount() {
    if (hasChrome && chrome.runtime) {
      if (chrome.tabs) {
        await chrome.tabs.create({ url: chrome.runtime.getURL("account.html") });
        return;
      }
      // 内容脚本没有 chrome.tabs，交给 Service Worker 打开扩展页。
      try {
        await chrome.runtime.sendMessage({ type: "PBL_OPEN_ACCOUNT" });
        return;
      } catch (e) { /* 回退到当前页跳转 */ }
    }
    location.href = "account.html";
  }

  const PB = {
    SETTINGS_KEY,
    SEARCH_HISTORY_KEY,
    THEME_KEY,
    REMEMBER_EMAIL_KEY,
    AUTH_STORE_KEY,
    ENTITLEMENT_KEY,
    MEMBERSHIP_CACHE_KEY,
    DEFAULTS,
    AUTOPLAY_MODES,
    HISTORY_LIMITS,
    MAX_HISTORY_STORE,
    SPEED_MIN,
    SPEED_MAX,
    normalize,
    getSettings,
    saveSettings,
    onSettingsChanged,
    onStorageChange,
    getSearchHistory,
    saveSearchHistory,
    addSearchTerm,
    trimSearchHistory,
    clearSearchHistory,
    isBilibili,
    pageType,
    isProEntitlement,
    getEntitlementCache,
    saveEntitlement,
    requestEntitlement,
    openAccount,
    hasChrome
  };

  global.PB = Object.assign(global.PB || {}, PB);
})(typeof globalThis !== "undefined" ? globalThis : this);
