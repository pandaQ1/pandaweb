/* 首屏防闪烁：在样式表之前同步写入主题属性。
   真实偏好由 theme.js 从 chrome.storage.sync 读取，这里只读 localStorage 镜像。 */
(function () {
  "use strict";
  try {
    var pref = localStorage.getItem("pbl_theme_cache") || "auto";
    var dark = pref === "dark" || (pref === "auto" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    var root = document.documentElement;
    root.setAttribute("data-wh-theme", dark ? "dark" : "light");
    root.setAttribute("data-wh-theme-pref", pref);
    root.style.colorScheme = dark ? "dark" : "light";
  } catch (e) {
    document.documentElement.setAttribute("data-wh-theme", "light");
  }
})();
