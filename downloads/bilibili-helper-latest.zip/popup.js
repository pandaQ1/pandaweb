/**
 * Panda 哔哩哔哩助手 · 工具栏弹窗
 * 300px 单列：总开关 → 当前页状态 → 快捷开关 → 提示 → 底部入口。
 */
(function () {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const formatter = new Intl.NumberFormat("zh-CN");

  let settings = PB.normalize(PB.DEFAULTS);
  let entitlement = null;
  let entitled = false;

  const QUICK_FEATURES = [
    "cleanHome",
    "hideLive",
    "hideAds",
    "rollHistory",
    "antiCocoon",
    "speedControl",
    "rememberSpeed",
    "autoWidescreen",
    "autoSubtitle",
    "searchClean"
  ];

  function autoplayLabel(mode) {
    if (mode === "off") return "关闭";
    if (mode === "collections") return "合集";
    return "跟随";
  }

  /* ---------- 清爽首页：点开选档（方案 C） ----------
     三档不再藏在「连点」里：点一下按钮原地展开三个档位，选完自动收起。
     折叠态按钮只显示当前档，右侧小三角是「可展开」的通用暗示；
     展开时 aria-expanded=true，面板用 role=group + aria-pressed 表述选中项。 */
  const CLEAN_LABEL = { off: "关", standard: "标准", strong: "2.0" };

  function cleanMode(s) {
    if (s && s.cleanHome2) return "strong";
    return s && s.cleanHome ? "standard" : "off";
  }

  function cleanPatch(mode) {
    return { cleanHome: mode !== "off", cleanHome2: mode === "strong" };
  }

  function setCleanPanel(open) {
    const trigger = $("#cleanTrigger");
    const panel = $("#cleanPanel");
    if (!panel) return;
    panel.hidden = !open;
    if (trigger) trigger.setAttribute("aria-expanded", open ? "true" : "false");
  }

  function closeCleanPanel() { setCleanPanel(false); }

  function toggleCleanPanel() {
    const panel = $("#cleanPanel");
    setCleanPanel(!!(panel && panel.hidden));
  }

  /** 折叠态按钮的文案 + 面板里三个档位的选中态（设置变了就要重画） */
  function renderClean() {
    const mode = cleanMode(settings);
    const on = mode !== "off";
    const trigger = $("#cleanTrigger");
    if (trigger) {
      trigger.disabled = !entitled;
      // aria-pressed 表示「功能是否开着」，供现有样式（点亮小圆点、蓝色数值）复用；
      // 展开与否由 aria-expanded 单独表达。
      trigger.setAttribute("aria-pressed", on ? "true" : "false");
      const val = trigger.querySelector(".pbl-q-val");
      if (val) val.textContent = CLEAN_LABEL[mode];
      const dot = trigger.querySelector(".pbl-dot");
      if (dot) dot.classList.toggle("is-on", on && !!settings.enabled && entitled);
      trigger.title = `清爽首页：当前「${CLEAN_LABEL[mode]}」· 点开可改档`;
    }
    $$("[data-clean-opt]").forEach((btn) => {
      const active = btn.dataset.cleanOpt === mode;
      btn.classList.toggle("active", active);
      btn.setAttribute("aria-pressed", active ? "true" : "false");
      btn.disabled = !entitled;
    });
  }

  function setStatus(text, kind) {
    const dot = $("#pageDot");
    if (dot) {
      dot.classList.toggle("is-on", kind === "on");
      dot.classList.toggle("is-warn", kind === "warn");
    }
    const label = $("#pageStatusText");
    if (label) label.textContent = text;
  }

  function applySettings(next) {
    settings = PB.normalize(next);
    const enabled = !!settings.enabled;
    const master = $("#masterSwitch");
    if (master) {
      master.checked = entitled && enabled;
      master.disabled = !entitled;
    }

    // 清爽首页算一项：标准与 2.0 都算开启（2.0 是标准版的超集）
    const enabledCount = QUICK_FEATURES.filter((key) => (
      key === "cleanHome" ? (settings.cleanHome || settings.cleanHome2) : !!settings[key]
    )).length;
    const desc = $("#masterDesc");
    if (desc) {
      desc.textContent = !entitled
        ? "Panda PRO 未激活"
        : enabled
          ? `已启用 ${enabledCount} / ${QUICK_FEATURES.length} 项增强`
          : "全部功能已暂停，设置与历史仍保留";
    }

    $$("[data-feature]").forEach((button) => {
      const key = button.dataset.feature;
      const on = !!settings[key];
      button.disabled = !entitled;
      button.setAttribute("aria-pressed", on ? "true" : "false");
      const value = button.querySelector(".pbl-q-val");
      if (value) {
        if (key === "rememberSpeed") value.textContent = on ? PB.formatSpeed(settings.lastSpeed) + "x" : "关";
        else if (key === "antiCocoon") value.textContent = on ? "无 Cookie" : "关";
        else value.textContent = on ? "开" : "关";
      }
      const dot = button.querySelector(".pbl-dot");
      if (dot) dot.classList.toggle("is-on", on && enabled && entitled);
    });

    // 清爽首页是三档的展开式控件，不走上面这套两档开关的渲染
    renderClean();

    const autoplay = $("#autoplayValue");
    if (autoplay) autoplay.textContent = autoplayLabel(settings.autoplayMode);

    const hint = $("#rollHint");
    if (hint) {
      hint.innerHTML = settings.rollHistory
        ? '<kbd>R</kbd> 换一批 · <kbd>Shift</kbd>+<kbd>R</kbd> 上一组<br><kbd>Alt</kbd>+<kbd>R</kbd> 下一组 · 输入文字时不会触发。'
        : "换一换历史已关闭，可在设置 → 首页净化中开启。";
    }

    const popup = $(".s-popup");
    if (popup) {
      popup.classList.toggle("is-paused", !enabled || !entitled);
      popup.classList.toggle("is-locked", !entitled);
    }
    updatePageStatus();
    updateHistoryHint();
  }

  function applyEntitlement(next) {
    entitlement = next || null;
    entitled = PB.isProEntitlement(entitlement);
    const gate = $("#proGate");
    if (gate) gate.classList.toggle("pbl-hidden", entitled);
    applySettings(settings);
  }

  async function save(patch) {
    if (!entitled) {
      // 总开关已经被用户点动过：未激活时必须按设置里的真实值回滚，否则 UI 会显示成已开启。
      applySettings(settings);
      openAccount();
      return;
    }
    try {
      settings = await PB.saveSettings(patch);
      applySettings(settings);
    } catch (error) {
      setStatus("保存失败：" + (error.message || "请重试"), "warn");
    }
  }

  async function updatePageStatus() {
    if (!entitled) {
      setStatus("Panda PRO 未激活，增强功能已锁定", "warn");
      return;
    }
    if (!PB.hasChrome || !chrome.tabs || !chrome.tabs.query) {
      setStatus("扩展预览模式：在 Edge 中加载后可用", "warn");
      return;
    }
    let tab = null;
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      tab = tabs && tabs[0];
    } catch (e) { /* ignore */ }
    if (!tab || !PB.isBilibili(tab.url || "")) {
      setStatus("当前不是 B 站页面", "warn");
      return;
    }
    if (!settings.enabled) {
      setStatus("本页已暂停，开启总开关后生效", "warn");
      return;
    }
    try {
      const result = await chrome.tabs.sendMessage(tab.id, { type: "PBL_PING" });
      if (!result || !result.ok) throw new Error("no result");
      const ads = Number(result.stats && result.stats.ads) || 0;
      const live = Number(result.stats && result.stats.live) || 0;
      if (ads || live) {
        setStatus(`本页已隐藏 ${ads} 个广告 · ${live} 个直播`, "on");
      } else {
        setStatus("本页已生效", "on");
      }
    } catch (error) {
      setStatus("刷新 B 站页面后生效", "warn");
    }
  }

  async function updateHistoryHint() {
    const hint = $("#historyHint");
    if (!hint) return;
    if (!settings.searchHistory) {
      hint.textContent = "本地搜索历史：已关闭（设置 → 搜索）";
      return;
    }
    try {
      const list = await PB.getSearchHistory();
      hint.textContent = `本地搜索历史：${formatter.format(list.length)} 条 · 只在当前浏览器`;
    } catch (e) {
      hint.textContent = "本地搜索历史读取失败";
    }
  }

  async function updateAccountChip() {
    const chip = $("#accountChip");
    if (!chip) return;
    if (!window.WHAuth) {
      chip.textContent = "账号";
      return;
    }
    try {
      const session = await WHAuth.peekSession();
      if (!session || !session.signed_in) {
        chip.textContent = "未登录";
        chip.classList.remove("is-pro");
        chip.title = "打开 Panda 账号页";
        return;
      }
      chip.title = session.email || "已登录";
      const membership = await PB.withTimeout(WHAuth.getMembership(), 3200);
      if (membership && membership.pro) {
        chip.textContent = "PRO";
        chip.classList.add("is-pro");
      } else {
        chip.textContent = "免费";
        chip.classList.remove("is-pro");
      }
    } catch (e) {
      chip.textContent = "账号";
    }
  }

  function openAccount() {
    if (PB.hasChrome && chrome.tabs && chrome.runtime) {
      chrome.tabs.create({ url: chrome.runtime.getURL("account.html") });
    } else {
      location.href = "account.html";
    }
  }

  function openOptions(hash) {
    const url = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL
      ? chrome.runtime.getURL("options.html" + (hash ? "#" + hash : ""))
      : "options.html" + (hash ? "#" + hash : "");
    if (PB.hasChrome && chrome.tabs) chrome.tabs.create({ url });
    else location.href = url;
  }

  function bind() {
    const master = $("#masterSwitch");
    if (master) master.addEventListener("change", () => save({ enabled: master.checked }));

    $$("[data-feature]").forEach((button) => {
      button.addEventListener("click", async () => {
        if (!entitled) {
          openAccount();
          return;
        }
        const key = button.dataset.feature;
        if (!Object.prototype.hasOwnProperty.call(settings, key)) return;
        button.disabled = true;
        await save({ [key]: !settings[key] });
        button.disabled = !entitled;
        button.classList.add("ui-pop");
        setTimeout(() => button.classList.remove("ui-pop"), 280);
      });
    });

    /* ---- 清爽首页：点开选档 ---- */
    const cleanTrigger = $("#cleanTrigger");
    const cleanPanel = $("#cleanPanel");
    if (cleanTrigger) {
      cleanTrigger.addEventListener("click", () => {
        if (!entitled) {
          openAccount();
          return;
        }
        toggleCleanPanel();
      });
    }
    $$("[data-clean-opt]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!entitled) {
          openAccount();
          return;
        }
        const mode = btn.dataset.cleanOpt;
        // 点的是当前档：只收起，不写存储
        if (cleanMode(settings) === mode) {
          closeCleanPanel();
          return;
        }
        btn.disabled = true;
        await save(cleanPatch(mode));
        btn.disabled = !entitled;
        closeCleanPanel();
        if (cleanTrigger) {
          cleanTrigger.classList.add("ui-pop");
          setTimeout(() => cleanTrigger.classList.remove("ui-pop"), 280);
        }
      });
    });
    // 点到面板外、或按 Esc 都收起（capture 里先判，避免和触发器自己的 click 打架）
    document.addEventListener("click", (event) => {
      if (!cleanPanel || cleanPanel.hidden) return;
      const target = event.target;
      if (cleanPanel.contains(target)) return;
      if (cleanTrigger && (cleanTrigger === target || cleanTrigger.contains(target))) return;
      closeCleanPanel();
    }, true);
    document.addEventListener("keydown", (event) => {
      if (event && event.key === "Escape") closeCleanPanel();
    }, true);

    $("#autoplayQuick").addEventListener("click", () => {
      if (!entitled) {
        openAccount();
        return;
      }
      openOptions("playback");
    });
    $("#openOptions").addEventListener("click", () => openOptions("general"));
    $("#openAccount").addEventListener("click", openAccount);
    $("#accountChip").addEventListener("click", openAccount);
    $("#proGateBtn").addEventListener("click", openAccount);

    if (PB.hasChrome && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === "sync" && changes[PB.SETTINGS_KEY]) {
          applySettings(changes[PB.SETTINGS_KEY].newValue);
        }
        if (areaName === "local" && changes[PB.ENTITLEMENT_KEY]) {
          applyEntitlement(changes[PB.ENTITLEMENT_KEY].newValue);
        }
        if (areaName === "local" && changes[PB.SEARCH_HISTORY_KEY]) {
          updateHistoryHint();
        }
        if (areaName === "local" && changes[PB.AUTH_STORE_KEY]) {
          setTimeout(() => PB.requestEntitlement(true).then((ent) => {
            if (ent) applyEntitlement(ent);
          }).catch(() => {}), 250);
        }
      });
    }
  }

  function renderVersion() {
    const el = $("#popupVersion");
    if (!el) return;
    try {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest) {
        el.textContent = "v" + chrome.runtime.getManifest().version;
      }
    } catch (e) { /* 预览模式保留静态文案 */ }
  }

  async function init() {
    renderVersion();
    if (window.WHTheme) {
      WHTheme.init({ storageKey: "pbl_theme", fallback: "auto" });
      WHTheme.onChange((theme, pref) => {
        try { localStorage.setItem("pbl_theme_cache", pref); } catch (e) { /* ignore */ }
      });
    }
    let cached = null;
    try {
      [settings, cached] = await Promise.all([PB.getSettings(), PB.getEntitlementCache()]);
    } catch (e) {
      settings = PB.normalize(PB.DEFAULTS);
    }
    bind();
    applyEntitlement(cached);
    updateHistoryHint();
    updateAccountChip();
    PB.requestEntitlement(!cached).then((ent) => {
      if (ent) applyEntitlement(ent);
    }).catch(() => {});
  }

  init().catch((error) => {
    setStatus("弹窗初始化失败：" + (error.message || "请重开"), "warn");
  });
})();
