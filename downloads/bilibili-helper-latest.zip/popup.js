/**
 * Panda 哔哩哔哩助手 · 工具栏弹窗
 * 300px 单列：总开关 → 当前页状态 → 快捷开关 → 提示 → 底部入口。
 */
(function () {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const formatter = new Intl.NumberFormat("zh-CN");

  let settings = PB.normalize(PB.DEFAULTS);
  let entitlement = null;
  let entitled = false;
  let toastTimer = 0;

  const QUICK_FEATURES = [
    "cleanHome",
    "hideLive",
    "hideAds",
    "rollHistory",
    "antiCocoon",
    "speedControl",
    "rememberSpeed",
    "autoWidescreen",
    "autoSubtitle",
    "searchClean"
  ];

  function formatSpeed(rate) {
    const value = Number(rate) || 1;
    let text = value.toFixed(2).replace(/0+$/, "");
    if (text.endsWith(".")) text += "0";
    return text + "x";
  }

  function autoplayLabel(mode) {
    if (mode === "off") return "关闭";
    if (mode === "collections") return "合集";
    return "跟随";
  }

  function setStatus(text, kind) {
    const dot = $("#pageDot");
    if (dot) {
      dot.classList.toggle("is-on", kind === "on");
      dot.classList.toggle("is-warn", kind === "warn");
    }
    const label = $("#pageStatusText");
    if (label) label.textContent = text;
  }

  function applySettings(next) {
    settings = PB.normalize(next);
    const enabled = !!settings.enabled;
    const master = $("#masterSwitch");
    if (master) {
      master.checked = entitled && enabled;
      master.disabled = !entitled;
    }

    const enabledCount = QUICK_FEATURES.filter((key) => !!settings[key]).length;
    const desc = $("#masterDesc");
    if (desc) {
      desc.textContent = !entitled
        ? "Panda PRO 未激活"
        : enabled
          ? `已启用 ${enabledCount} / ${QUICK_FEATURES.length} 项增强`
          : "全部功能已暂停，设置与历史仍保留";
    }

    $$("[data-feature]").forEach((button) => {
      const key = button.dataset.feature;
      const on = !!settings[key];
      button.disabled = !entitled;
      button.setAttribute("aria-pressed", on ? "true" : "false");
      const value = button.querySelector(".pbl-q-val");
      if (value) {
        if (key === "rememberSpeed") value.textContent = on ? formatSpeed(settings.lastSpeed) : "关";
        else if (key === "antiCocoon") value.textContent = on ? "无 Cookie" : "关";
        else value.textContent = on ? "开" : "关";
      }
      const dot = button.querySelector(".pbl-dot");
      if (dot) dot.classList.toggle("is-on", on && enabled && entitled);
    });

    const autoplay = $("#autoplayValue");
    if (autoplay) autoplay.textContent = autoplayLabel(settings.autoplayMode);

    const hint = $("#rollHint");
    if (hint) {
      hint.innerHTML = settings.rollHistory
        ? '<kbd>R</kbd> 换一批 · <kbd>Shift</kbd>+<kbd>R</kbd> 上一组<br><kbd>Alt</kbd>+<kbd>R</kbd> 下一组 · 输入文字时不会触发。'
        : "换一换历史已关闭，可在设置 → 首页净化中开启。";
    }

    const popup = $(".s-popup");
    if (popup) {
      popup.classList.toggle("is-paused", !enabled || !entitled);
      popup.classList.toggle("is-locked", !entitled);
    }
    updatePageStatus();
    updateHistoryHint();
  }

  function applyEntitlement(next) {
    entitlement = next || null;
    entitled = PB.isProEntitlement(entitlement);
    const gate = $("#proGate");
    if (gate) gate.classList.toggle("pbl-hidden", entitled);
    applySettings(settings);
  }

  async function save(patch) {
    if (!entitled) {
      openAccount();
      return;
    }
    try {
      settings = await PB.saveSettings(patch);
      applySettings(settings);
    } catch (error) {
      setStatus("保存失败：" + (error.message || "请重试"), "warn");
    }
  }

  async function updatePageStatus() {
    if (!entitled) {
      setStatus("Panda PRO 未激活，增强功能已锁定", "warn");
      return;
    }
    if (!PB.hasChrome || !chrome.tabs || !chrome.tabs.query) {
      setStatus("扩展预览模式：在 Edge 中加载后可用", "warn");
      return;
    }
    let tab = null;
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      tab = tabs && tabs[0];
    } catch (e) { /* ignore */ }
    if (!tab || !PB.isBilibili(tab.url || "")) {
      setStatus("当前不是 B 站页面", "warn");
      return;
    }
    if (!settings.enabled) {
      setStatus("本页已暂停，开启总开关后生效", "warn");
      return;
    }
    try {
      const result = await chrome.tabs.sendMessage(tab.id, { type: "PBL_PING" });
      if (!result || !result.ok) throw new Error("no result");
      const ads = Number(result.stats && result.stats.ads) || 0;
      const live = Number(result.stats && result.stats.live) || 0;
      if (ads || live) {
        setStatus(`本页已隐藏 ${ads} 个广告 · ${live} 个直播`, "on");
      } else {
        setStatus("本页已生效", "on");
      }
    } catch (error) {
      setStatus("刷新 B 站页面后生效", "warn");
    }
  }

  async function updateHistoryHint() {
    const hint = $("#historyHint");
    if (!hint) return;
    if (!settings.searchHistory) {
      hint.textContent = "本地搜索历史：已关闭（设置 → 搜索）";
      return;
    }
    try {
      const list = await PB.getSearchHistory();
      hint.textContent = `本地搜索历史：${formatter.format(list.length)} 条 · 只在当前浏览器`;
    } catch (e) {
      hint.textContent = "本地搜索历史读取失败";
    }
  }

  function timeout(promise, ms) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        resolve(null);
      }, ms);
      Promise.resolve(promise).then((value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      }).catch(() => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(null);
      });
    });
  }

  async function updateAccountChip() {
    const chip = $("#accountChip");
    if (!chip) return;
    if (!window.WHAuth) {
      chip.textContent = "账号";
      return;
    }
    try {
      const session = await WHAuth.peekSession();
      if (!session || !session.signed_in) {
        chip.textContent = "未登录";
        chip.classList.remove("is-pro");
        chip.title = "打开 Panda 账号页";
        return;
      }
      chip.title = session.email || "已登录";
      const membership = await timeout(WHAuth.getMembership(), 3200);
      if (membership && membership.pro) {
        chip.textContent = "PRO";
        chip.classList.add("is-pro");
      } else {
        chip.textContent = "免费";
        chip.classList.remove("is-pro");
      }
    } catch (e) {
      chip.textContent = "账号";
    }
  }

  function openAccount() {
    if (PB.hasChrome && chrome.tabs && chrome.runtime) {
      chrome.tabs.create({ url: chrome.runtime.getURL("account.html") });
    } else {
      location.href = "account.html";
    }
  }

  function openOptions(hash) {
    const url = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL
      ? chrome.runtime.getURL("options.html" + (hash ? "#" + hash : ""))
      : "options.html" + (hash ? "#" + hash : "");
    if (PB.hasChrome && chrome.tabs) chrome.tabs.create({ url });
    else location.href = url;
  }

  function bind() {
    const master = $("#masterSwitch");
    if (master) master.addEventListener("change", () => save({ enabled: master.checked }));

    $$("[data-feature]").forEach((button) => {
      button.addEventListener("click", async () => {
        if (!entitled) {
          openAccount();
          return;
        }
        const key = button.dataset.feature;
        if (!Object.prototype.hasOwnProperty.call(settings, key)) return;
        button.disabled = true;
        await save({ [key]: !settings[key] });
        button.disabled = !entitled;
        button.classList.add("ui-pop");
        setTimeout(() => button.classList.remove("ui-pop"), 280);
      });
    });

    $("#autoplayQuick").addEventListener("click", () => {
      if (!entitled) {
        openAccount();
        return;
      }
      openOptions("playback");
    });
    $("#openOptions").addEventListener("click", () => openOptions("general"));
    $("#openAccount").addEventListener("click", openAccount);
    $("#accountChip").addEventListener("click", openAccount);
    $("#proGateBtn").addEventListener("click", openAccount);

    if (PB.hasChrome && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === "sync" && changes[PB.SETTINGS_KEY]) {
          applySettings(changes[PB.SETTINGS_KEY].newValue);
        }
        if (areaName === "local" && changes[PB.ENTITLEMENT_KEY]) {
          applyEntitlement(changes[PB.ENTITLEMENT_KEY].newValue);
        }
        if (areaName === "local" && changes[PB.SEARCH_HISTORY_KEY]) {
          updateHistoryHint();
        }
        if (areaName === "local" && changes[PB.AUTH_STORE_KEY]) {
          setTimeout(() => PB.requestEntitlement(true).then((ent) => {
            if (ent) applyEntitlement(ent);
          }).catch(() => {}), 250);
        }
      });
    }
  }

  async function init() {
    if (window.WHTheme) {
      WHTheme.init({ storageKey: "pbl_theme", fallback: "auto" });
      WHTheme.onChange((theme, pref) => {
        try { localStorage.setItem("pbl_theme_cache", pref); } catch (e) { /* ignore */ }
      });
    }
    let cached = null;
    try {
      [settings, cached] = await Promise.all([PB.getSettings(), PB.getEntitlementCache()]);
    } catch (e) {
      settings = PB.normalize(PB.DEFAULTS);
    }
    bind();
    applyEntitlement(cached);
    updateHistoryHint();
    updateAccountChip();
    PB.requestEntitlement(!cached).then((ent) => {
      if (ent) applyEntitlement(ent);
    }).catch(() => {});
  }

  init().catch((error) => {
    setStatus("弹窗初始化失败：" + (error.message || "请重开"), "warn");
  });
})();
