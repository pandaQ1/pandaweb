/**
 * Panda 哔哩哔哩助手 · 内容脚本公共层
 *
 * 只做四件事：
 *  - 读写设置、把开关映射为 html 上的 pbl-* 类（CSS 只认这些类）
 *  - 监听 B 站 SPA 路由变化，通知各功能模块重新应用
 *  - 提供轻量的 Toast（带可选撤销动作）与元素等待工具
 *  - 接收 popup / 设置页的 PING，返回当前页状态与过滤计数
 */
(function () {
  "use strict";

  const PB = window.PB;
  if (!PB) return;

  const TYPING_SELECTOR = [
    "input",
    "textarea",
    "select",
    "[contenteditable='']",
    "[contenteditable='true']",
    "[role='textbox']",
    "[role='searchbox']"
  ].join(",");

  const state = {
    settings: PB.normalize(PB.DEFAULTS),
    effective: PB.normalize(PB.DEFAULTS),
    entitlement: null,
    entitled: false,
    page: PB.pageType(location.href),
    url: location.href,
    ready: false,
    stats: { ads: 0, live: 0, tags: 0, rollUndo: 0, rollRedo: 0 }
  };

  const settingsListeners = new Set();
  const routeListeners = new Set();
  let toastEl = null;
  let toastTimer = 0;
  let routeTimer = 0;
  let proGateEl = null;
  let entitlementRequest = 0;
  let resolveReady;
  const ready = new Promise((resolve) => { resolveReady = resolve; });

  const $ = (selector, root) => (root || document).querySelector(selector);
  const $$ = (selector, root) => Array.from((root || document).querySelectorAll(selector));

  function isTypingEvent(event) {
    const target = event && event.target;
    if (!(target instanceof Element)) return false;
    if (target.closest(TYPING_SELECTOR)) return true;
    const active = document.activeElement;
    return !!(active && active.closest && active.closest(TYPING_SELECTOR));
  }

  function isHome() {
    if (!/(^|\.)bilibili\.com$/i.test(location.hostname)) return false;
    return location.pathname === "/" || location.pathname === "/index.html";
  }

  function waitFor(selector, timeout, root) {
    const scope = root || document;
    const found = scope.querySelector ? scope.querySelector(selector) : null;
    if (found) return Promise.resolve(found);
    const ms = typeof timeout === "number" ? timeout : 8000;
    return new Promise((resolve) => {
      const started = Date.now();
      const timer = setInterval(() => {
        const node = scope.querySelector ? scope.querySelector(selector) : null;
        if (node) {
          clearInterval(timer);
          resolve(node);
        } else if (Date.now() - started > ms) {
          clearInterval(timer);
          resolve(null);
        }
      }, 120);
    });
  }

  function waitForBody(callback) {
    if (document.body) {
      callback();
      return;
    }
    const timer = setInterval(() => {
      if (document.body) {
        clearInterval(timer);
        callback();
      }
    }, 40);
  }

  function updatePageClasses(page) {
    const root = document.documentElement;
    root.classList.toggle("pbl-page-home", page === "home");
    root.classList.toggle("pbl-page-video", page === "video");
    root.classList.toggle("pbl-page-live", page === "live");
    root.classList.toggle("pbl-page-search", page === "search");
    root.classList.toggle("pbl-page-popular", page === "popular");
  }

  function applySettings(next, previous) {
    const s = PB.normalize(next);
    const prev = previous || state.effective;
    state.settings = s;
    // 非 PRO 时所有增强功能整体关闭，但保留用户设置，激活后原样恢复。
    const effective = state.entitled ? s : Object.assign({}, s, { enabled: false });
    state.effective = effective;

    const root = document.documentElement;
    const enabled = !!effective.enabled;
    root.classList.toggle("pbl-enabled", enabled);
    // 2.0 是标准版的超集：开了 2.0 也必须有标准版的类，否则 banner 不会被收起。
    root.classList.toggle("pbl-clean-home", enabled && (effective.cleanHome || effective.cleanHome2));
    root.classList.toggle("pbl-clean-home-2", enabled && effective.cleanHome2);
    root.classList.toggle("pbl-hide-live", enabled && effective.hideLive);
    root.classList.toggle("pbl-hide-ads", enabled && effective.hideAds);
    root.classList.toggle("pbl-search-clean", enabled && effective.searchClean);
    root.classList.toggle("pbl-roll-history", enabled && effective.rollHistory);
    root.classList.toggle("pbl-speed-control", enabled && effective.speedControl);
    root.classList.toggle("pbl-adjusted", enabled);
    updatePageClasses(state.page);

    settingsListeners.forEach((fn) => {
      try { fn(effective, prev); } catch (error) { console.warn("[Panda Bili] 设置应用失败", error); }
    });
  }

  function onSettings(fn) {
    if (typeof fn !== "function") return () => {};
    settingsListeners.add(fn);
    if (state.ready) {
      try { fn(state.effective, state.effective); } catch (e) { /* ignore */ }
    }
    return () => settingsListeners.delete(fn);
  }

  function onRoute(fn) {
    if (typeof fn !== "function") return () => {};
    routeListeners.add(fn);
    if (state.ready) {
      try { fn(state.page, state.url); } catch (e) { /* ignore */ }
    }
    return () => routeListeners.delete(fn);
  }

  function setStat(key, value) {
    if (typeof state.stats[key] !== "number") return;
    state.stats[key] = Math.max(0, Number(value) || 0);
  }

  function bumpStat(key, amount) {
    if (typeof state.stats[key] !== "number") return;
    state.stats[key] = Math.max(0, state.stats[key] + (Number(amount) || 1));
  }

  function ensureToast() {
    if (toastEl && toastEl.isConnected) return toastEl;
    toastEl = document.createElement("div");
    toastEl.id = "pbl-toast";
    toastEl.className = "pbl-toast";
    toastEl.setAttribute("role", "status");
    toastEl.setAttribute("aria-live", "polite");
    document.body.appendChild(toastEl);
    return toastEl;
  }

  /**
   * 页面内轻提示。
   * @param {string} message
   * @param {{duration?:number, action?:Function, actionLabel?:string}} options
   */
  function toast(message, options) {
    if (!document.body) return;
    const el = ensureToast();
    clearTimeout(toastTimer);
    el.textContent = "";
    const text = document.createElement("span");
    text.className = "pbl-toast-text";
    text.textContent = String(message || "");
    el.appendChild(text);

    if (options && typeof options.action === "function") {
      const action = document.createElement("button");
      action.type = "button";
      action.className = "pbl-toast-action";
      action.textContent = options.actionLabel || "撤销";
      action.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        hideToast();
        try { options.action(); } catch (error) { console.warn(error); }
      });
      el.appendChild(action);
    }

    el.classList.add("is-show");
    const duration = Number(options && options.duration) || (options && options.action ? 5200 : 2200);
    toastTimer = setTimeout(hideToast, duration);
  }

  function hideToast() {
    if (!toastEl) return;
    toastEl.classList.remove("is-show");
  }

  /* ---------------- PRO 总门禁 ---------------- */

  function ensureProGate() {
    if (!document.body) return;
    if (state.entitled) {
      if (proGateEl) proGateEl.remove();
      proGateEl = null;
      return;
    }
    if (proGateEl && proGateEl.isConnected) return;
    proGateEl = document.createElement("div");
    proGateEl.id = "pbl-pro-gate";
    proGateEl.setAttribute("role", "region");
    proGateEl.setAttribute("aria-label", "Panda PRO 未激活");
    proGateEl.innerHTML = [
      '<div class="pbl-pro-gate-copy">',
      '  <strong>Panda PRO 未激活</strong>',
      '  <span>全部增强功能已锁定</span>',
      "</div>",
      '<button type="button" class="pbl-pro-gate-btn">登录 / 激活</button>'
    ].join("");
    proGateEl.querySelector(".pbl-pro-gate-btn").addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      PB.openAccount();
    });
    document.body.appendChild(proGateEl);
  }

  function updateEntitlement(raw) {
    const next = raw && typeof raw === "object" ? raw : null;
    const wasEntitled = state.entitled;
    state.entitlement = next;
    state.entitled = PB.isProEntitlement(next);
    if (state.ready && wasEntitled !== state.entitled) {
      applySettings(state.settings, state.effective);
    }
    ensureProGate();
  }

  async function refreshEntitlement(fresh) {
    const seq = ++entitlementRequest;
    const result = await PB.requestEntitlement(fresh);
    if (seq !== entitlementRequest || !result) return;
    updateEntitlement(result);
  }

  function detectRoute() {
    if (location.href === state.url) return;
    state.url = location.href;
    const next = PB.pageType(location.href);
    const changed = next !== state.page;
    state.page = next;
    state.stats.ads = 0;
    state.stats.live = 0;
    state.stats.tags = 0;
    state.stats.rollUndo = 0;
    state.stats.rollRedo = 0;
    updatePageClasses(next);
    routeListeners.forEach((fn) => {
      try { fn(next, state.url, changed); } catch (error) { console.warn("[Panda Bili] 路由处理失败", error); }
    });
  }

  function startRouteWatcher() {
    if (routeTimer) return;
    const check = () => {
      // 后台标签页里 B 站也可能改 URL，但此时没必要做 DOM 相关处理；
      // 回到前台由 visibilitychange 补一次检测，不会漏路由。
      if (document.hidden) return;
      try { detectRoute(); } catch (e) { /* ignore */ }
    };
    window.addEventListener("popstate", check, true);
    window.addEventListener("hashchange", check, true);
    document.addEventListener("pjax:end", check, true);
    document.addEventListener("visibilitychange", check, true);
    routeTimer = setInterval(check, 700);
  }

  function installMessageHandler() {
    if (!PB.hasChrome || !chrome.runtime || !chrome.runtime.onMessage) return;
    try {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (!message || message.type !== "PBL_PING") return false;
        sendResponse({
          ok: true,
          page: state.page,
          url: location.href,
          pro: state.entitled,
          enabled: state.effective.enabled,
          stats: Object.assign({}, state.stats)
        });
        return false;
      });
    } catch (e) { /* 扩展更新后旧上下文失效 */ }
  }

  async function init() {
    state.page = PB.pageType(location.href);
    updatePageClasses(state.page);

    let settings;
    let cachedEntitlement;
    try {
      [settings, cachedEntitlement] = await Promise.all([
        PB.getSettings(),
        PB.getEntitlementCache()
      ]);
    } catch (error) {
      console.warn("[Panda Bili] 读取设置失败，使用默认值", error);
      settings = PB.DEFAULTS;
      cachedEntitlement = null;
    }
    state.entitlement = cachedEntitlement;
    state.entitled = PB.isProEntitlement(cachedEntitlement);
    applySettings(settings);

    state.ready = true;
    document.documentElement.dataset.pblReady = "1";
    PB.onSettingsChanged((next) => applySettings(next));
    PB.onStorageChange((changes, areaName) => {
      if (areaName !== "local") return;
      if (changes[PB.ENTITLEMENT_KEY]) {
        updateEntitlement(changes[PB.ENTITLEMENT_KEY].newValue);
      }
      if (changes[PB.AUTH_STORE_KEY]) {
        if (!changes[PB.AUTH_STORE_KEY].newValue) updateEntitlement(null);
        setTimeout(() => refreshEntitlement(true), 200);
      }
    });
    startRouteWatcher();
    installMessageHandler();
    resolveReady(state.effective);
    PB.waitForBody(ensureProGate);

    settingsListeners.forEach((fn) => {
      try { fn(state.effective, state.effective); } catch (e) { /* ignore */ }
    });
    routeListeners.forEach((fn) => {
      try { fn(state.page, state.url, true); } catch (e) { /* ignore */ }
    });

    // 有缓存时先按缓存放行/拦截，再在后台校准；无缓存时首次必须等服务端结果。
    refreshEntitlement(!cachedEntitlement).catch(() => {});
  }

  window.PB = Object.assign(PB, {
    state,
    ready,
    $,
    $$,
    waitFor,
    waitForBody,
    isTypingEvent,
    isHome,
    toast,
    hideToast,
    onSettings,
    onRoute,
    setStat,
    bumpStat,
    content: {
      state,
      ready,
      onSettings,
      onRoute,
      toast,
      waitFor,
      waitForBody,
      isTypingEvent,
      isHome,
      setStat,
      bumpStat
    }
  });

  init().catch((error) => {
    console.warn("[Panda Bili] 初始化失败", error);
    resolveReady(state.settings);
    state.ready = true;
  });
})();
