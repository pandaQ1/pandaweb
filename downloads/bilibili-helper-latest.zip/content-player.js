/**
 * Panda 哔哩哔哩助手 · 视频页增强
 *
 *  - 原生倍速菜单增强：直接扩展 B 站播放器的倍速菜单，保持原生外观与位置
 *  - 记住上次倍速：切换分 P / 合集 / 连播 / 新视频后自动恢复
 *  - 自动网页宽屏：点击 B 站播放器的「宽屏」按钮，不申请浏览器全屏
 *  - 连播策略：跟随 B 站 / 始终关闭 / 仅合集与播放列表
 *  - 自动字幕：有字幕时打开，分 P 切换后重新尝试
 */
(function () {
  "use strict";

  const PB = window.PB;
  if (!PB) return;

  const SPEED_STEP = 0.1;
  const SPEED_MIN = PB.SPEED_MIN;
  const SPEED_MAX = PB.SPEED_MAX;

  let current = PB.normalize(PB.DEFAULTS);
  let video = null;
  let boundVideos = new WeakSet();
  let nativeSpeedButton = null;
  let nativeSpeedMenu = null;
  let nativeSpeedObserver = null;
  let nativeSpeedButtonController = null;
  let nativeSpeedMenuController = null;
  let typedSpeed = "";
  let typedSpeedTimer = 0;
  let applyingRate = false;
  let speedIntentUntil = 0;
  let speedResetUntil = 0;
  let speedResetTimers = new Set();
  let resettingSpeed = false;
  let applyRateTimer = 0;
  let saveRateTimer = 0;
  let routeKey = "";
  let wideAppliedRoute = "";
  let wideTries = 0;
  let wideTimer = 0;
  let subtitleAttempted = new WeakSet();
  let subtitleTimer = 0;
  let subtitleScheduled = false;
  let autoplayGuardTimer = 0;
  let autoplayScheduled = false;
  let lastAutoplayClick = 0;
  let ensureTimer = 0;
  let observer = null;
  let syncRaf = 0;
  let lastSyncAt = 0;

  function isVideoPage() {
    return PB.pageType(location.href) === "video";
  }

  // 倍速文案与弹窗、设置页共用 config.js 的同一份实现，避免三处各写一遍产生偏差。
  function formatSpeed(rate) {
    return PB.formatSpeed(rate);
  }

  function clampSpeed(rate) {
    const n = Number(rate);
    if (!Number.isFinite(n)) return null;
    return Math.round(Math.min(SPEED_MAX, Math.max(SPEED_MIN, n)) * 100) / 100;
  }

  function isPressed(el) {
    if (!el) return false;
    return (
      el.classList.contains("bpx-state-active") ||
      el.classList.contains("bpx-player-ctrl-btn-active") ||
      el.classList.contains("active") ||
      el.getAttribute("aria-pressed") === "true" ||
      el.getAttribute("aria-checked") === "true"
    );
  }

  /* ---------------- 视频元素与倍速 ---------------- */

  function getVideoElement() {
    const all = Array.from(document.querySelectorAll("video")).filter(
      (item) => !item.closest(".bili-video-card, .bpx-player-row-dm-wrap")
    );
    if (!all.length) return null;

    // 分 P / 换视频 / 切清晰度时，B 站可能同时保留新旧 video。
    // 必须优先选择当前可见、面积最大的正在播放元素，避免把倍速应用到隐藏的旧元素。
    const ranked = all.map((item) => {
      const rect = item.getBoundingClientRect();
      let style = null;
      try { style = getComputedStyle(item); } catch (e) { /* ignore */ }
      const visible = !!style &&
        style.display !== "none" &&
        style.visibility !== "hidden" &&
        Number(style.opacity) > 0.01 &&
        rect.width >= 240 &&
        rect.height >= 120;
      return {
        el: item,
        visible,
        area: visible ? rect.width * rect.height : 0,
        playing: !item.paused && item.readyState >= 2
      };
    });

    const visible = ranked.filter((item) => item.visible).sort((a, b) => b.area - a.area);
    if (visible.length) return visible[0].el;
    const playing = ranked.filter((item) => item.playing).sort((a, b) => b.area - a.area);
    if (playing.length) return playing[0].el;
    return all[0] || null;
  }

  function applySpeedLabel() {
    if (!nativeSpeedButton || !nativeSpeedButton.isConnected) return;
    const result = nativeSpeedButton.querySelector(".bpx-player-ctrl-playbackrate-result");
    if (!result) return;
    const el = getVideoElement() || video;
    const rate = el ? el.playbackRate : current.lastSpeed;
    const isNormal = Math.abs((Number(rate) || 1) - 1) < 0.001;
    // 1.0x 仍显示「倍速」；选择其他倍速后显示实际值，例如 2.0x。
    const label = isNormal ? "倍速" : formatSpeed(rate) + "x";
    if (result.textContent !== label) result.textContent = label;
  }

  function updateSpeedUi() {
    if (!nativeSpeedMenu || !nativeSpeedMenu.isConnected) {
      applySpeedLabel();
      return;
    }
    const el = getVideoElement() || video;
    const rate = el ? el.playbackRate : current.lastSpeed;
    nativeSpeedMenu.querySelectorAll(".bpx-player-ctrl-playbackrate-menu-item").forEach((item) => {
      const value = Number(item.dataset.value);
      const active = Number.isFinite(value) && Math.abs(value - rate) < 0.001;
      item.classList.toggle("bpx-state-active", active);
      item.setAttribute("aria-selected", active ? "true" : "false");
    });
    applySpeedLabel();
  }

  function scheduleApplySpeed(delay) {
    clearTimeout(applyRateTimer);
    applyRateTimer = setTimeout(() => applyRememberedSpeed(false), typeof delay === "number" ? delay : 140);
  }

  function applyRememberedSpeed(force) {
    if (!current.enabled || !isVideoPage() || !current.rememberSpeed) return;
    const el = getVideoElement();
    if (!el) return;
    const target = clampSpeed(current.lastSpeed);
    if (target == null) return;
    if (force || Math.abs(el.playbackRate - target) > 0.001) {
      applyingRate = true;
      try {
        el.playbackRate = target;
      } catch (e) {
        applyingRate = false;
        return;
      }
      clearTimeout(applyRateTimer);
      applyRateTimer = setTimeout(() => { applyingRate = false; }, 120);
    }
    updateSpeedUi();
  }

  function clearSpeedResetTimers() {
    speedResetTimers.forEach((timer) => clearTimeout(timer));
    speedResetTimers.clear();
    speedResetUntil = 0;
  }

  function scheduleSpeedReset(delay) {
    const timer = setTimeout(() => {
      speedResetTimers.delete(timer);
      resetSpeedForNewVideo();
    }, delay);
    speedResetTimers.add(timer);
  }

  function resetSpeedForNewVideo() {
    if (!current.enabled || !isVideoPage() || current.rememberSpeed) return;
    const el = getVideoElement();
    if (!el) return;
    const oneX = document.querySelector(
      '.bpx-player-ctrl-playbackrate-menu [data-value="1"]'
    );
    if (oneX && !oneX.classList.contains("bpx-state-active")) {
      // 同时点一次原生 1.0x，让 B 站自己的倍速状态和按钮文字一起回到 1x。
      resettingSpeed = true;
      try { oneX.click(); } catch (e) { /* ignore */ }
      resettingSpeed = false;
    }
    if (Math.abs(el.playbackRate - 1) > 0.001) {
      applyingRate = true;
      try { el.playbackRate = 1; } catch (e) { applyingRate = false; }
      clearTimeout(applyRateTimer);
      applyRateTimer = setTimeout(() => { applyingRate = false; }, 120);
    }
    updateSpeedUi();
    applySpeedLabel();
  }

  function persistLastSpeed(rate) {
    if (!current.rememberSpeed) return;
    current.lastSpeed = rate;
    clearTimeout(saveRateTimer);
    saveRateTimer = setTimeout(() => {
      PB.saveSettings({ lastSpeed: rate }).catch(() => {});
    }, 280);
  }

  function setSpeed(rate, options) {
    const target = clampSpeed(rate);
    if (target == null) return false;
    clearSpeedResetTimers();
    const el = getVideoElement();
    if (!el) {
      PB.toast("当前页面没有可调节的播放器");
      return false;
    }
    applyingRate = true;
    try {
      el.playbackRate = target;
    } catch (e) {
      applyingRate = false;
      PB.toast("浏览器拒绝了这个倍速");
      return false;
    }
    clearTimeout(applyRateTimer);
    applyRateTimer = setTimeout(() => { applyingRate = false; }, 120);
    updateSpeedUi();
    persistLastSpeed(target);
    if (options && options.announce) PB.toast(`倍速 ${formatSpeed(target)}x`, { duration: 1400 });
    return true;
  }

  function nudgeSpeed(delta) {
    const el = getVideoElement() || video;
    const base = el ? el.playbackRate : current.lastSpeed;
    setSpeed((Number(base) || 1) + delta);
  }

  function bindVideo(el) {
    if (!el || boundVideos.has(el)) return;
    boundVideos.add(el);
    video = el;

    const onMeta = () => {
      video = el;
      scheduleApplySpeed(120);
      scheduleApplySpeed(700);
      scheduleWidescreen(0);
      scheduleAutoplay(120);
      scheduleSubtitle(900);
    };
    const onRate = () => {
      if (video === el) {
        const rate = clampSpeed(el.playbackRate);
        if (rate != null) {
          if (!applyingRate && Date.now() < speedIntentUntil) {
            // 用户从原生菜单选择了倍速：以新值为准。
            current.lastSpeed = rate;
            if (current.rememberSpeed) persistLastSpeed(rate);
          } else if (current.rememberSpeed && Math.abs(rate - current.lastSpeed) > 0.001) {
            // 切集/切清晰度时 B 站可能先把 rate 重置成 1；恢复用户记住的倍速。
            scheduleApplySpeed(180);
          }
        }
      }
      updateSpeedUi();
    };

    el.addEventListener("loadedmetadata", onMeta);
    el.addEventListener("canplay", onMeta);
    el.addEventListener("durationchange", onMeta);
    el.addEventListener("playing", () => {
      scheduleApplySpeed(80);
      // B 站切集/换清晰度后偶尔会在起播阶段把 playbackRate 重置为 1，补一次兜底。
      setTimeout(() => { if (video === el) applyRememberedSpeed(true); }, 700);
    });
    el.addEventListener("play", () => scheduleApplySpeed(100));
    el.addEventListener("ratechange", onRate);
    updateSpeedUi();
    scheduleApplySpeed(160);
    if (!current.rememberSpeed && Date.now() < speedResetUntil) {
      scheduleSpeedReset(160);
      scheduleSpeedReset(700);
    }
  }

  function ensureVideo() {
    if (!isVideoPage()) return;
    const el = getVideoElement();
    if (el && el !== video) bindVideo(el);
  }

  /* ---------------- 倍速控件 ---------------- */

  function makeExtraSpeedItem(rate) {
    const item = document.createElement("li");
    item.className = "bpx-player-ctrl-playbackrate-menu-item pbl-speed-extra";
    item.dataset.value = String(rate);
    item.dataset.pblExtra = String(rate);
    item.setAttribute("role", "menuitem");
    item.textContent = formatSpeed(rate) + "x";
    return item;
  }

  function closeNativeSpeedMenu() {
    if (nativeSpeedButton) nativeSpeedButton.classList.remove("bpx-state-show");
  }

  function injectNativeSpeedItems(menu) {
    if (!menu) return;
    const anchor2 = menu.querySelector('[data-value="2"]') || menu.querySelector(".bpx-player-ctrl-playbackrate-menu-item");
    [5, 4, 3].forEach((rate) => {
      // 如果未来 B 站自己也加入同倍率，避免重复；已有的原生项直接复用。
      if (menu.querySelector('[data-value="' + rate + '"]')) return;
      const item = makeExtraSpeedItem(rate);
      if (anchor2 && anchor2.parentNode === menu) menu.insertBefore(item, anchor2);
      else menu.appendChild(item);
    });
    if (!menu.querySelector('[data-value="0.25"]')) {
      const anchorHalf = menu.querySelector('[data-value="0.5"]');
      const item = makeExtraSpeedItem(0.25);
      if (anchorHalf) anchorHalf.insertAdjacentElement("afterend", item);
      else menu.appendChild(item);
    }
  }

  function teardownNativeSpeedUi() {
    clearTimeout(typedSpeedTimer);
    typedSpeed = "";
    if (nativeSpeedButtonController) {
      nativeSpeedButtonController.abort();
      nativeSpeedButtonController = null;
    }
    if (nativeSpeedMenuController) {
      nativeSpeedMenuController.abort();
      nativeSpeedMenuController = null;
    }
    if (nativeSpeedObserver) {
      nativeSpeedObserver.disconnect();
      nativeSpeedObserver = null;
    }
    if (nativeSpeedButton) {
      nativeSpeedButton.classList.remove("pbl-speed-replaced", "bpx-state-show");
      nativeSpeedButton.querySelectorAll("[data-pbl-extra]").forEach((item) => item.remove());
      const result = nativeSpeedButton.querySelector(".bpx-player-ctrl-playbackrate-result");
      if (result) {
        const rate = video ? video.playbackRate : current.lastSpeed;
        const isNormal = Math.abs((Number(rate) || 1) - 1) < 0.001;
        result.textContent = isNormal ? "倍速" : formatSpeed(rate) + "x";
      }
    }
    nativeSpeedButton = null;
    nativeSpeedMenu = null;
  }

  function bindNativeSpeedUi(button) {
    const controller = new AbortController();
    nativeSpeedButtonController = controller;
    button.classList.add("pbl-speed-replaced");

    button.addEventListener("wheel", (event) => {
      if (!current.speedControl) return;
      event.preventDefault();
      event.stopPropagation();
      nudgeSpeed(event.deltaY < 0 ? SPEED_STEP : -SPEED_STEP);
    }, { capture: true, passive: false, signal: controller.signal });

    button.addEventListener("dblclick", (event) => {
      if (!current.speedControl) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      setSpeed(1, { announce: true });
      closeNativeSpeedMenu();
    }, { capture: true, signal: controller.signal });

    button.addEventListener("click", (event) => {
      if (!current.speedControl) return;
      // 菜单项的点击交给菜单自己的 handler，不要把菜单项点击误当成按钮点击。
      if (event.target.closest(".bpx-player-ctrl-playbackrate-menu")) return;
      // 阻止 B 站原生按钮点击在菜单展开/收起时自动选择第一项（5x）。
      event.preventDefault();
      event.stopImmediatePropagation();
      if (button.classList.contains("bpx-state-show")) {
        closeNativeSpeedMenu();
      } else {
        button.classList.add("bpx-state-show");
        injectNativeSpeedItems(button.querySelector(".bpx-player-ctrl-playbackrate-menu"));
        updateSpeedUi();
      }
      applySpeedLabel();
    }, { capture: true, signal: controller.signal });

    // 点击播放器其他位置时关闭菜单；菜单项自身仍由菜单 handler 处理。
    document.addEventListener("pointerdown", (event) => {
      if (!nativeSpeedButton || !nativeSpeedButton.contains(event.target)) closeNativeSpeedMenu();
    }, { capture: true, signal: controller.signal });

    nativeSpeedObserver = new MutationObserver(() => {
      if (!nativeSpeedButton || !nativeSpeedButton.isConnected) return;
      const menu = nativeSpeedButton.querySelector(".bpx-player-ctrl-playbackrate-menu");
      if (!menu) return;
      injectNativeSpeedItems(menu);
      updateSpeedUi();
    });
    nativeSpeedObserver.observe(button, { childList: true, subtree: true });
  }

  function syncNativeSpeedUi() {
    if (!current.enabled || !current.speedControl || !isVideoPage()) {
      teardownNativeSpeedUi();
      return;
    }
    const button = document.querySelector(".bpx-player-ctrl-playbackrate");
    if (!button) {
      teardownNativeSpeedUi();
      return;
    }
    if (button !== nativeSpeedButton) {
      teardownNativeSpeedUi();
      nativeSpeedButton = button;
      bindNativeSpeedUi(button);
    }
    const menu = button.querySelector(".bpx-player-ctrl-playbackrate-menu");
    if (!menu) {
      nativeSpeedMenu = null;
      applySpeedLabel();
      return;
    }
    if (menu !== nativeSpeedMenu) {
      if (nativeSpeedMenuController) nativeSpeedMenuController.abort();
      nativeSpeedMenu = menu;
      nativeSpeedMenuController = new AbortController();
      menu.addEventListener("click", (event) => {
        const item = event.target.closest(".bpx-player-ctrl-playbackrate-menu-item");
        if (item) {
          speedIntentUntil = Date.now() + 300;
          if (!resettingSpeed) clearSpeedResetTimers();
        }
        const extra = event.target.closest("[data-pbl-extra]");
        if (!extra) {
          setTimeout(() => {
            updateSpeedUi();
            applySpeedLabel();
          }, 0);
          setTimeout(applySpeedLabel, 80);
          return;
        }
        event.preventDefault();
        event.stopImmediatePropagation();
        setSpeed(Number(extra.dataset.value));
        closeNativeSpeedMenu();
      }, { capture: true, signal: nativeSpeedMenuController.signal });
    }
    // tick 每 1.2s 跑一次；菜单没展开时不做注入，避免无意义的 DOM 写入。
    if (button.classList.contains("bpx-state-show")) injectNativeSpeedItems(menu);
    updateSpeedUi();
  }

  /* ---------------- 自动宽屏 ---------------- */

  function getWideButton() {
    return document.querySelector(".bpx-player-ctrl-wide");
  }

  function isWideScreen() {
    const container = document.querySelector(".bpx-player-container");
    const screen = container && container.getAttribute("data-screen");
    if (screen) return screen === "wide";
    const btn = getWideButton();
    return !!btn && isPressed(btn);
  }

  function scheduleWidescreen(delay) {
    clearTimeout(wideTimer);
    wideTimer = setTimeout(applyWidescreen, typeof delay === "number" ? delay : 500);
  }

  function applyWidescreen() {
    if (!current.enabled || !current.autoWidescreen || !isVideoPage()) return;
    if (document.fullscreenElement) return;
    const route = location.href;
    if (wideAppliedRoute === route) return;
    const container = document.querySelector(".bpx-player-container");
    const screen = container && container.getAttribute("data-screen");
    if (screen === "web" || screen === "full") {
      wideAppliedRoute = route;
      return;
    }
    const btn = getWideButton();
    if (!btn) return;
    if (isWideScreen()) {
      wideAppliedRoute = route;
      return;
    }
    if (wideTries >= 4) {
      wideAppliedRoute = route;
      return;
    }
    wideTries += 1;
    try {
      btn.click();
      wideAppliedRoute = route;
      // B 站偶尔在播放器初始化末尾把宽屏重置回普通模式；确认一次，必要时重试。
      setTimeout(() => {
        if (current.enabled && current.autoWidescreen && isVideoPage() && !isWideScreen() && wideTries < 4) {
          wideAppliedRoute = "";
          scheduleWidescreen(500);
        }
      }, 750);
    } catch (e) { /* 播放器还没准备好，下一轮再试 */ }
  }

  /* ---------------- 连播策略 ---------------- */

  function isCollectionContext() {
    if (/^\/list\//.test(location.pathname) || /^\/bangumi\/play\//.test(location.pathname)) return true;
    const url = new URL(location.href);
    const p = Number(url.searchParams.get("p"));
    if (Number.isFinite(p) && p > 1) return true;
    return !!document.querySelector(
      ".video-pod__list, .video-pod, .video-sections, .base-video-sections-v1, #multi_page, .multi-page, .cur-list, .playlist-container"
    );
  }

  function getAutoplayButton() {
    return (
      document.querySelector(".bpx-player-ctrl-btn.bpx-player-ctrl-autoplay") ||
      document.querySelector(".bpx-player-ctrl-autoplay") ||
      document.querySelector(".bpx-player-ctrl-btn[aria-label*='自动连播']")
    );
  }

  function desiredAutoplay() {
    if (current.autoplayMode === "off") return false;
    if (current.autoplayMode === "collections") return isCollectionContext();
    return null;
  }

  function applyAutoplay() {
    if (!current.enabled || !isVideoPage()) return;
    const want = desiredAutoplay();
    if (want == null) return;
    const btn = getAutoplayButton();
    if (!btn) return;
    const pressed = isPressed(btn);
    if (pressed === want) return;
    const now = Date.now();
    if (now - lastAutoplayClick < 700) return;
    lastAutoplayClick = now;
    try { btn.click(); } catch (e) { /* ignore */ }
  }

  function scheduleAutoplay(delay) {
    if (autoplayScheduled) return;
    autoplayScheduled = true;
    setTimeout(() => {
      autoplayScheduled = false;
      applyAutoplay();
    }, typeof delay === "number" ? delay : 300);
  }

  function startAutoplayGuard() {
    if (autoplayGuardTimer) return;
    autoplayGuardTimer = setInterval(() => {
      if (!current.enabled || !isVideoPage() || current.autoplayMode === "follow") return;
      applyAutoplay();
    }, 1800);
  }

  function stopAutoplayGuard() {
    if (!autoplayGuardTimer) return;
    clearInterval(autoplayGuardTimer);
    autoplayGuardTimer = 0;
  }

  /* ---------------- 自动字幕 ---------------- */

  function subtitleActive() {
    return !!document.querySelector(
      ".bpx-player-ctrl-subtitle-language-item.bpx-state-active, .bpx-player-ctrl-subtitle-language-item.bpx-player-ctrl-btn-active"
    );
  }

  function subtitleButton() {
    return document.querySelector(".bpx-player-ctrl-subtitle");
  }

  function scheduleSubtitle(delay) {
    if (subtitleScheduled) return;
    subtitleScheduled = true;
    clearTimeout(subtitleTimer);
    subtitleTimer = setTimeout(() => {
      subtitleScheduled = false;
      applySubtitle();
    }, typeof delay === "number" ? delay : 1200);
  }

  function applySubtitle() {
    if (!current.enabled || !current.autoSubtitle || !isVideoPage()) return;
    const el = getVideoElement();
    if (el && subtitleAttempted.has(el)) return;
    const btn = subtitleButton();
    if (!btn) return;
    if (subtitleActive()) {
      if (el) subtitleAttempted.add(el);
      return;
    }
    if (btn.getAttribute("aria-disabled") === "true" || btn.classList.contains("bpx-player-ctrl-btn-disabled")) {
      if (el) subtitleAttempted.add(el);
      return;
    }
    if (el) subtitleAttempted.add(el);

    try {
      btn.click();
    } catch (e) {
      return;
    }
    setTimeout(() => {
      if (!current.enabled || !current.autoSubtitle || !isVideoPage()) return;
      const active = document.querySelector(
        ".bpx-player-ctrl-subtitle-language-item.bpx-state-active, .bpx-player-ctrl-subtitle-language-item.bpx-player-ctrl-btn-active"
      );
      if (active) {
        try { btn.click(); } catch (e) { /* 收起菜单 */ }
        return;
      }
      const lang =
        document.querySelector(".bpx-player-ctrl-subtitle-language-item[data-lan='zh-CN']") ||
        document.querySelector(".bpx-player-ctrl-subtitle-language-item[data-lan='ai-zh']") ||
        document.querySelector(".bpx-player-ctrl-subtitle-language-item[data-lan]");
      if (lang) {
        try { lang.click(); } catch (e) { /* ignore */ }
      } else {
        // 没有字幕时把菜单收回去，避免挡住播放器。
        const menu = document.querySelector(".bpx-player-ctrl-subtitle-box");
        if (menu && menu.offsetParent !== null) {
          try { btn.click(); } catch (e) { /* ignore */ }
        }
      }
    }, 340);
  }

  /* ---------------- 页面生命周期 ---------------- */

  function resetForRoute() {
    closeNativeSpeedMenu();
    teardownNativeSpeedUi();
    typedSpeed = "";
    stopAutoplayGuard();
    clearTimeout(wideTimer);
    clearTimeout(subtitleTimer);
    clearTimeout(applyRateTimer);
    subtitleScheduled = false;
    video = null;
    wideAppliedRoute = "";
    wideTries = 0;
    subtitleAttempted = new WeakSet();
    lastAutoplayClick = 0;
    if (isVideoPage()) {
      ensureVideo();
      if (current.rememberSpeed) {
        speedResetUntil = 0;
        scheduleApplySpeed(450);
        scheduleApplySpeed(1400);
        // 播放器初始化结束后偶尔会把倍速重置回 1.0，再做一次兜底恢复。
        setTimeout(() => {
          if (current.enabled && current.rememberSpeed && isVideoPage()) applyRememberedSpeed(true);
        }, 2800);
      } else {
        // 未开启「记住倍速」：新视频必须从 1.0x 开始，不能沿用上一个视频的倍速。
        clearSpeedResetTimers();
        speedResetUntil = Date.now() + 3500;
        scheduleSpeedReset(450);
        scheduleSpeedReset(1400);
        scheduleSpeedReset(2800);
      }
      scheduleWidescreen(700);
      scheduleWidescreen(1800);
      scheduleAutoplay(600);
      scheduleSubtitle(1600);
      startAutoplayGuard();
    }
  }

  function handleRoute(page) {
    if (page !== "video") {
      resetForRoute();
      return;
    }
    const key = location.href;
    if (key === routeKey) return;
    routeKey = key;
    resetForRoute();
  }

  function apply(settings) {
    const previous = current;
    current = PB.normalize(settings);
    if (!current.enabled || !isVideoPage()) {
      teardownNativeSpeedUi();
      stopAutoplayGuard();
      return;
    }

    ensureVideo();
    syncNativeSpeedUi();

    if (current.rememberSpeed) {
      clearSpeedResetTimers();
      scheduleApplySpeed(120);
    }
    if (current.autoWidescreen) scheduleWidescreen(400);
    if (current.autoplayMode !== "follow") {
      scheduleAutoplay(300);
      startAutoplayGuard();
    } else {
      stopAutoplayGuard();
    }
    if (current.autoSubtitle) scheduleSubtitle(1000);

    if (previous.rememberSpeed !== current.rememberSpeed && current.rememberSpeed) {
      scheduleApplySpeed(80);
    }
    if (!current.rememberSpeed) {
      clearTimeout(saveRateTimer);
    }
  }

  function onKeydown(event) {
    if (!current.enabled || !current.speedControl || !isVideoPage()) return;
    if (event.isComposing || event.keyCode === 229) return;
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    if (PB.isTypingEvent(event)) return;

    // 原生菜单打开时，直接键入数字并回车即可跳到任意倍速（不增加任何可见输入框）。
    const menuOpen = !!(nativeSpeedButton && nativeSpeedButton.classList.contains("bpx-state-show"));
    if (menuOpen && (/^[0-9]$/.test(event.key) || event.key === "." || event.key === "Backspace" || event.key === "Enter" || event.key === "Escape")) {
      if (event.key === "Escape") {
        typedSpeed = "";
        return;
      }
      if (event.key === "Enter") {
        if (!typedSpeed) return;
        event.preventDefault();
        event.stopPropagation();
        const value = clampSpeed(parseFloat(typedSpeed));
        if (value != null) {
          setSpeed(value, { announce: true });
          closeNativeSpeedMenu();
        }
        typedSpeed = "";
        return;
      }
      if (event.key === "Backspace") {
        if (!typedSpeed) return;
        event.preventDefault();
        event.stopPropagation();
        typedSpeed = typedSpeed.slice(0, -1);
      } else {
        event.preventDefault();
        event.stopPropagation();
        // 只保留一个小数点：连按出 "1..5" 会被 parseFloat 静默截断成 1x。
        if (event.key !== "." || !typedSpeed.includes(".")) {
          typedSpeed = (typedSpeed + event.key).slice(0, 5);
        }
      }
      clearTimeout(typedSpeedTimer);
      typedSpeedTimer = setTimeout(() => { typedSpeed = ""; }, 2200);
      PB.toast(typedSpeed ? `输入倍速 ${typedSpeed}x · 回车确认` : "输入倍速…", { duration: 1100 });
      return;
    }

    if (event.key === "-" || event.key === "_") {
      if (!getVideoElement()) return;
      event.preventDefault();
      event.stopPropagation();
      nudgeSpeed(-SPEED_STEP);
    } else if (event.key === "+" || event.key === "=") {
      if (!getVideoElement()) return;
      event.preventDefault();
      event.stopPropagation();
      nudgeSpeed(SPEED_STEP);
    }
  }

  /**
   * 合并高频 DOM 变动：视频页的弹幕层、右栏推荐每秒会产生几十到上百次 mutation。
   * 原来的 observer 回调每次都直接跑 ensureVideo + syncNativeSpeedUi（多次 querySelector），
   * 现在合并到下一帧、并限制在约 5Hz——中间漏掉的状态由 tick（1.2s）兜底。
   */
  function scheduleSync() {
    if (syncRaf) return;
    const run = () => {
      syncRaf = 0;
      if (!isVideoPage() || !current.enabled) return;
      const now = Date.now();
      if (now - lastSyncAt < 180) return;
      lastSyncAt = now;
      ensureVideo();
      syncNativeSpeedUi();
    };
    syncRaf = typeof requestAnimationFrame === "function"
      ? requestAnimationFrame(run)
      : setTimeout(run, 200);
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver(scheduleSync);
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function tick() {
    if (!current.enabled || !isVideoPage()) return;
    ensureVideo();
    syncNativeSpeedUi();
    if (current.autoWidescreen && wideAppliedRoute !== location.href) scheduleWidescreen(500);
    if (current.autoSubtitle && video && !subtitleAttempted.has(video) && !subtitleScheduled) {
      scheduleSubtitle(500);
    }
  }

  PB.onSettings(apply);
  PB.onRoute(handleRoute);
  document.addEventListener("keydown", onKeydown, true);
  PB.waitForBody(() => {
    startObserver();
    ensureTimer = setInterval(tick, 1200);
  });
})();
