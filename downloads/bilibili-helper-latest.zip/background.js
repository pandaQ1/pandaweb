/**
 * Panda 哔哩哔哩助手 · Service Worker
 *
 * 职责：
 *  1. 首次安装时写入默认设置
 *  2. 按「拒绝信息茧房」开关维护动态 declarativeNetRequest 规则
 *     —— 只对推荐 / 相关视频 / 热门排行 / 视频搜索列表四类 GET 接口移除 Cookie
 *  3. 给设置页提供只读的诊断信息
 *
 * 播放、互动、账号请求完全不动，保证登录态与播放体验。
 */
"use strict";

importScripts("config.js", "auth_util.js");

const RULE_IDS = [9901, 9902, 9903, 9904, 9905, 9906, 9907, 9908];
let entitlementInFlight = null;
let entitlementRefreshTimer = 0;

/** 这些接口只负责「列表内容」，去掉 Cookie 即可避免个性化推荐。 */
const COOKIE_FREE_ENDPOINTS = [
  "/x/web-interface/wbi/index/top/feed/rcmd",
  "/x/web-interface/index/top/feed/rcmd",
  "/x/web-interface/archive/related",
  "/x/web-interface/ranking/v2",
  "/x/web-interface/search/type",
  "/x/web-interface/wbi/search/type",
  "/x/web-interface/search/all",
  "/x/web-interface/wbi/search/all"
];

function buildRules() {
  return COOKIE_FREE_ENDPOINTS.map((path, index) => ({
    id: RULE_IDS[index],
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "cookie", operation: "remove" }
      ]
    },
    condition: {
      requestDomains: ["api.bilibili.com"],
      urlFilter: path,
      isUrlFilterCaseSensitive: false
      // 不限定 resourceTypes：B 站偶尔从 Worker 发列表请求，限定 xmlhttprequest 会漏掉。
      // 域名 + 精确路径已足够窄，播放/账号接口不在其中。
    }
  }));
}

async function updateCookieRules() {
  if (!chrome.declarativeNetRequest) return { enabled: false, count: 0 };
  const settings = await PB.getSettings();
  const entitlement = await PB.getEntitlementCache();
  const shouldEnable = settings.enabled && settings.antiCocoon && PB.isProEntitlement(entitlement);
  try {
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = existing
      .map((rule) => rule.id)
      .filter((id) => RULE_IDS.includes(id));
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds,
      addRules: shouldEnable ? buildRules() : []
    });
    return { enabled: shouldEnable, count: shouldEnable ? COOKIE_FREE_ENDPOINTS.length : 0 };
  } catch (error) {
    console.warn("[Panda Bili] 动态规则更新失败：", error);
    return { enabled: false, count: 0, error: String(error && error.message || error) };
  }
}

async function ensureDefaults() {
  const settings = await PB.getSettings();
  await PB.saveSettings(settings);
}

/** 默认值迁移：v3 起记住倍速、自动字幕也默认关闭。 */
async function migrateDefaultStates() {
  try {
    const stored = await chrome.storage.local.get("pbl_defaults_rev");
    const rev = Number(stored.pbl_defaults_rev) || 0;
    if (rev >= 3) return;
    const patch = {};
    if (rev < 2) {
      patch.autoWidescreen = false;
      patch.antiCocoon = false;
      patch.searchHistory = false;
    }
    if (rev < 3) {
      patch.rememberSpeed = false;
      patch.autoSubtitle = false;
    }
    await PB.saveSettings(patch);
    await chrome.storage.local.set({ pbl_defaults_rev: 3 });
  } catch (error) {
    console.warn("[Panda Bili] 默认值迁移失败：", error);
  }
}

/** 以账号服务端为准刷新 PRO 权益，成功后同步给所有内容脚本与动态规则。 */
async function refreshEntitlement() {
  if (entitlementInFlight) return entitlementInFlight;
  entitlementInFlight = (async () => {
    let membership;
    try {
      membership = await WHAuth.getMembership();
    } catch (error) {
      membership = {
        signed_in: false,
        pro: false,
        plan: "free",
        reason: String(error && error.message || error)
      };
    }
    const entitlement = await PB.saveEntitlement({
      signed_in: !!membership.signed_in,
      pro: !!membership.pro,
      plan: membership.plan || "free",
      expires_at: membership.expires_at || 0,
      email: membership.email || "",
      offline: !!membership.offline,
      reason: membership.reason || "",
      checked_at: Date.now()
    });
    await updateCookieRules();
    return entitlement;
  })().finally(() => {
    entitlementInFlight = null;
  });
  return entitlementInFlight;
}

function scheduleEntitlementRefresh(delay) {
  clearTimeout(entitlementRefreshTimer);
  entitlementRefreshTimer = setTimeout(() => {
    refreshEntitlement().catch(() => {});
  }, typeof delay === "number" ? delay : 500);
}

async function getEntitlement(fresh) {
  const cached = await PB.getEntitlementCache();
  if (!fresh && cached) {
    if (PB.isProEntitlement(cached)) {
      if (Date.now() - (cached.checked_at || 0) > 5 * 60 * 1000) {
        scheduleEntitlementRefresh(1000);
      }
      return cached;
    }
    if (Date.now() - (cached.checked_at || 0) < 60 * 1000) return cached;
  }
  if (fresh || !cached) return refreshEntitlement();
  scheduleEntitlementRefresh(800);
  return cached;
}

chrome.runtime.onInstalled.addListener(() => {
  ensureDefaults().then(() => migrateDefaultStates()).catch(() => {});
  refreshEntitlement().catch(() => {});
  updateCookieRules().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  migrateDefaultStates().catch(() => {});
  refreshEntitlement().catch(() => {});
  updateCookieRules().catch(() => {});
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "sync" && changes[PB.SETTINGS_KEY]) {
    updateCookieRules().catch(() => {});
    return;
  }
  if (areaName === "local" && changes[PB.AUTH_STORE_KEY]) {
    scheduleEntitlementRefresh(300);
  }
  if (areaName === "local" && changes[PB.MEMBERSHIP_CACHE_KEY] && !entitlementInFlight) {
    // 账号页刚兑换/刷新会员后会写这个缓存；避免与后台自己的 refresh 形成回环。
    scheduleEntitlementRefresh(500);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return false;

  if (message.type === "PBL_GET_ENTITLEMENT") {
    (async () => {
      try {
        const entitlement = await getEntitlement(!!message.fresh);
        sendResponse(entitlement);
      } catch (error) {
        sendResponse({
          signed_in: false,
          pro: false,
          plan: "free",
          reason: "权益校验失败：" + (error && error.message || error)
        });
      }
    })();
    return true;
  }

  if (message.type === "PBL_REFRESH_ENTITLEMENT") {
    (async () => {
      try {
        sendResponse(await refreshEntitlement());
      } catch (error) {
        sendResponse({ signed_in: false, pro: false, plan: "free", reason: String(error && error.message || error) });
      }
    })();
    return true;
  }

  if (message.type === "PBL_OPEN_ACCOUNT") {
    try {
      chrome.tabs.create({ url: chrome.runtime.getURL("account.html") });
      sendResponse({ ok: true });
    } catch (error) {
      sendResponse({ ok: false, reason: String(error && error.message || error) });
    }
    return false;
  }

  if (message.type === "PBL_GET_DIAGNOSTICS") {
    (async () => {
      const settings = await PB.getSettings();
      const entitlement = await PB.getEntitlementCache();
      const pro = PB.isProEntitlement(entitlement);
      let rules = [];
      try {
        if (chrome.declarativeNetRequest) {
          rules = await chrome.declarativeNetRequest.getDynamicRules();
        }
      } catch (e) { /* ignore */ }
      sendResponse({
        ok: true,
        version: chrome.runtime.getManifest().version,
        pro,
        signedIn: !!(entitlement && entitlement.signed_in),
        antiCocoon: pro && settings.enabled && settings.antiCocoon,
        dynamicRuleCount: rules.filter((rule) => RULE_IDS.includes(rule.id)).length,
        expectedRuleCount: COOKIE_FREE_ENDPOINTS.length
      });
    })();
    return true;
  }

  return false;
});

// Service Worker 冷启动时也校准一次，避免浏览器异常退出后规则状态漂移。
migrateDefaultStates().catch(() => {});
updateCookieRules().catch(() => {});
refreshEntitlement().catch(() => {});
