/* ============================================================
   Panda 设计语言 —— M1b 主题控制器（日间 / 夜间 / 跟随系统）
   零依赖、可直接内联或外链。职责只有三件：
     1. 把偏好（light | dark | auto）解析成实际主题（light | dark）
     2. 落到 html[data-wh-theme]（popup/options/page）与 body.dark（独立页兼容）
     3. 持久化 + 监听系统主题变化 + 广播 wh:themechange
   令牌见 ui-tokens.css；规格见 references/themes.md。

   用法（页面底部或 DOMContentLoaded 后）：
     WHTheme.init({ storageKey: "wh_theme", fallback: "light" });
     WHTheme.set("dark");           // 用户点「夜间」
     WHTheme.set("auto");           // 跟随系统
     WHTheme.get();                 // { pref: "auto", theme: "dark" }
     WHTheme.onChange((theme, pref) => { ... });

   首屏防闪烁（推荐）：在 <head> 里、CSS 之前同步执行
     <script>
       (function(){try{var p=localStorage.getItem("wh_theme")||"light";
         var d=p==="dark"||(p==="auto"&&matchMedia("(prefers-color-scheme: dark)").matches);
         document.documentElement.setAttribute("data-wh-theme", d?"dark":"light");
         document.documentElement.setAttribute("data-wh-theme-pref", p);
         document.documentElement.style.colorScheme = d?"dark":"light";
       }catch(e){}})();
     </script>
   ============================================================ */
(function (global) {
  "use strict";

  var VALID = { light: 1, dark: 1, auto: 1 };
  var pref = "light";
  var listeners = [];
  var mql = global.matchMedia ? global.matchMedia("(prefers-color-scheme: dark)") : null;
  var opts = { storageKey: "wh_theme", fallback: "light" };
  var ready = false;

  function root() { return document.documentElement; }

  function resolve(p) {
    if (p === "auto") return mql && mql.matches ? "dark" : "light";
    return p === "dark" ? "dark" : "light";
  }

  function paint(p) {
    var theme = resolve(p);
    var r = root();
    r.setAttribute("data-wh-theme", theme);
    r.setAttribute("data-wh-theme-pref", p); // 记录"偏好"，样式可区分 auto
    r.style.colorScheme = theme;             // 原生滚动条 / 表单控件跟随
    if (document.body) document.body.classList.toggle("dark", theme === "dark");
    for (var i = 0; i < listeners.length; i++) {
      try { listeners[i](theme, p); } catch (e) { /* 单个监听器出错不影响其他 */ }
    }
    try {
      document.dispatchEvent(new CustomEvent("wh:themechange", { detail: { theme: theme, pref: p } }));
    } catch (e) { /* 老浏览器忽略 */ }
    return theme;
  }

  /* ---------- 存储：扩展内用 chrome.storage.sync，网页里退回 localStorage ---------- */
  function read(done) {
    try {
      if (global.chrome && chrome.storage && chrome.storage.sync) {
        chrome.storage.sync.get({ [opts.storageKey]: opts.fallback }, function (o) {
          var v = o && o[opts.storageKey];
          done(VALID[v] ? v : opts.fallback);
        });
        return;
      }
    } catch (e) { /* 落到 localStorage */ }
    var v2 = null;
    try { v2 = global.localStorage && localStorage.getItem(opts.storageKey); } catch (e) { v2 = null; }
    done(VALID[v2] ? v2 : opts.fallback);
  }

  function write(p) {
    try {
      if (global.chrome && chrome.storage && chrome.storage.sync) {
        var o = {}; o[opts.storageKey] = p;
        // 必须带回调并读一次 lastError：写入失败（配额超限、扩展被禁用）时
        // 不读 lastError 会在扩展页留下 "Unchecked runtime.lastError" 噪音。
        // 读到了就退回 localStorage，保住首屏防闪烁用的镜像。
        chrome.storage.sync.set(o, function () {
          if (chrome.runtime && chrome.runtime.lastError) {
            try { localStorage.setItem(opts.storageKey, p); } catch (e2) { /* 隐私模式 */ }
          }
        });
        return;
      }
    } catch (e) { /* 落到 localStorage */ }
    try { global.localStorage && localStorage.setItem(opts.storageKey, p); } catch (e) { /* 隐私模式 */ }
  }

  function init(options) {
    if (options && options.storageKey) opts.storageKey = options.storageKey;
    if (options && VALID[options.fallback]) opts.fallback = options.fallback;
    ready = true;
    // 系统主题变化：仅当偏好是 auto 时重绘
    if (mql && mql.addEventListener) {
      mql.addEventListener("change", function () { if (pref === "auto") paint("auto"); });
    } else if (mql && mql.addListener) {
      mql.addListener(function () { if (pref === "auto") paint("auto"); });
    }
    read(function (p) { pref = p; paint(p); });
    // 其他页面（设置页/弹窗）改动偏好时同步：storage.onChanged 更可靠，本地事件兜底
    try {
      if (global.chrome && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener(function (changes, area) {
          if (area !== "sync" || !changes[opts.storageKey]) return;
          var v = changes[opts.storageKey].newValue;
          if (VALID[v] && v !== pref) { pref = v; paint(v); }
        });
      }
    } catch (e) { /* ignore */ }
    return WHTheme;
  }

  function set(p) {
    var v = VALID[p] ? p : opts.fallback;
    pref = v;
    write(v);
    return paint(v);
  }

  function get() {
    return { pref: pref, theme: resolve(pref), ready: ready };
  }

  function onChange(fn) {
    if (typeof fn === "function") listeners.push(fn);
    return function () {
      var i = listeners.indexOf(fn);
      if (i >= 0) listeners.splice(i, 1);
    };
  }

  var WHTheme = { init: init, set: set, get: get, onChange: onChange, resolve: resolve };
  global.WHTheme = WHTheme;
})(typeof globalThis !== "undefined" ? globalThis : window);
