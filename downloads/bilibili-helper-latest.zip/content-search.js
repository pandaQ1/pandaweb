/**
 * Panda 哔哩哔哩助手 · 搜索净化与本地历史
 *
 *  - 隐藏 B 站热搜 / 搜索发现 / 灰热词，不动搜索联想
 *  - 在搜索框聚焦且为空时显示扩展自己的历史（默认 20 条，可选 10/50/100）
 *  - 历史只写入 chrome.storage.local，可在浮层里两步清空
 */
(function () {
  "use strict";

  const PB = window.PB;
  if (!PB) return;

  const SEARCH_INPUT_SELECTOR = [
    "input.nav-search-input",
    ".nav-search input",
    ".bili-header input[type='text']",
    ".bili-header input[type='search']",
    "input[placeholder*='搜索']",
    "input[placeholder*='搜']"
  ].join(",");

  const HOT_TITLES = new Set([
    "热搜",
    "搜索发现",
    "B站热搜",
    "bilibili热搜",
    "大家还在搜",
    "热门搜索",
    "热门话题",
    "热搜榜",
    "搜索趋势"
  ]);

  let current = PB.normalize(PB.DEFAULTS);
  let history = [];
  let panel = null;
  let activeInput = null;
  let clearArmed = false;
  let clearTimer = 0;
  let inputTimer = 0;
  let hotObserver = null;
  let hotTimer = 0;
  let panelHideTimer = 0;

  function isSearchInput(el) {
    return !!(el && el.matches && el.matches(SEARCH_INPUT_SELECTOR) && !el.closest("#pbl-search-history"));
  }

  function getActiveInput() {
    if (activeInput && activeInput.isConnected && isSearchInput(activeInput)) return activeInput;
    return null;
  }

  function currentKeywordFromUrl() {
    if (PB.pageType(location.href) !== "search") return "";
    try {
      const url = new URL(location.href);
      return (url.searchParams.get("keyword") || url.searchParams.get("q") || "").trim();
    } catch (e) {
      return "";
    }
  }

  function ensurePanel() {
    if (panel && panel.isConnected) return panel;
    panel = document.createElement("div");
    panel.id = "pbl-search-history";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "本地搜索历史");
    document.body.appendChild(panel);
    panel.addEventListener("click", (event) => event.stopPropagation());
    panel.addEventListener("mousedown", (event) => event.stopPropagation());
    return panel;
  }

  function positionPanel() {
    if (!panel || !panel.classList.contains("is-show")) return;
    const input = getActiveInput();
    if (!input) return;
    const rect = input.getBoundingClientRect();
    const width = Math.max(320, Math.min(rect.width || 360, 460, window.innerWidth - 24));
    const height = panel.offsetHeight || 180;
    let left = Math.max(12, Math.min(rect.left, window.innerWidth - width - 12));
    let top = rect.bottom + 8;
    if (top + height > window.innerHeight - 12) {
      top = Math.max(12, rect.top - height - 8);
    }
    panel.style.width = Math.round(width) + "px";
    panel.style.left = Math.round(left) + "px";
    panel.style.top = Math.round(top) + "px";
  }

  function renderPanel() {
    if (!panel) return;
    panel.textContent = "";
    const head = document.createElement("div");
    head.className = "pbl-sh-head";
    const title = document.createElement("span");
    title.className = "pbl-sh-title";
    title.textContent = "搜索历史 · 本地";
    const clear = document.createElement("button");
    clear.type = "button";
    clear.className = "pbl-sh-clear";
    clear.textContent = clearArmed ? "确认清空？" : "清空";
    if (clearArmed) clear.classList.add("is-confirm");
    clear.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (!clearArmed) {
        clearArmed = true;
        clearTimeout(clearTimer);
        clearTimer = setTimeout(() => {
          clearArmed = false;
          renderPanel();
        }, 2600);
        renderPanel();
        return;
      }
      clearArmed = false;
      clearTimeout(clearTimer);
      await PB.clearSearchHistory();
      history = [];
      renderPanel();
      positionPanel();
      PB.toast("本地搜索历史已清空");
    });
    head.appendChild(title);
    head.appendChild(clear);
    panel.appendChild(head);

    const list = document.createElement("div");
    list.className = "pbl-sh-list";
    const shown = history.slice(0, current.searchHistoryLimit);
    if (!shown.length) {
      const empty = document.createElement("div");
      empty.className = "pbl-sh-empty";
      empty.textContent = "还没有本地记录。搜索一次后会自动记住。";
      panel.appendChild(list);
      panel.appendChild(empty);
    } else {
      shown.forEach((item) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "pbl-sh-chip";
        chip.textContent = item.q;
        chip.title = item.q;
        chip.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          runSearch(item.q);
        });
        list.appendChild(chip);
      });
      panel.appendChild(list);
    }

    const foot = document.createElement("div");
    foot.className = "pbl-sh-foot";
    foot.textContent = `共 ${shown.length} / ${current.searchHistoryLimit} 条 · 仅保存在当前浏览器 · 输入文字仍显示 B 站联想`;
    panel.appendChild(foot);
  }

  async function reloadHistory() {
    history = await PB.getSearchHistory();
    if (panel && panel.classList.contains("is-show")) {
      renderPanel();
      positionPanel();
    }
  }

  async function recordSearch(keyword) {
    if (!current.enabled || !current.searchHistory) return;
    const q = String(keyword || "").replace(/\s+/g, " ").trim().slice(0, 100);
    if (!q) return;
    await PB.addSearchTerm(q, current.searchHistoryLimit);
    await reloadHistory();
  }

  async function showPanel(input) {
    if (!current.enabled || !current.searchHistory || !input) return;
    if ((input.value || "").trim()) return;
    activeInput = input;
    ensurePanel();
    await reloadHistory();
    renderPanel();
    panel.classList.add("is-show");
    requestAnimationFrame(positionPanel);
    setTimeout(positionPanel, 60);
  }

  function hidePanel() {
    clearTimeout(panelHideTimer);
    if (panel) panel.classList.remove("is-show");
    clearArmed = false;
  }

  function runSearch(keyword) {
    const q = String(keyword || "").trim();
    if (!q) return;
    if (activeInput) {
      activeInput.value = q;
      activeInput.dispatchEvent(new Event("input", { bubbles: true }));
    }
    hidePanel();
    recordSearch(q).catch(() => {});
    const target = "https://search.bilibili.com/all?keyword=" + encodeURIComponent(q);
    try { location.assign(target); } catch (e) { location.href = target; }
  }

  function findInputNear(node) {
    let parent = node;
    for (let i = 0; i < 5 && parent; i += 1) {
      const input = parent.querySelector && parent.querySelector(SEARCH_INPUT_SELECTOR);
      if (input) return input;
      parent = parent.parentElement;
    }
    return null;
  }

  function handleFocusIn(event) {
    const target = event.target;
    if (!isSearchInput(target)) return;
    activeInput = target;
    if (!(target.value || "").trim()) {
      clearTimeout(inputTimer);
      inputTimer = setTimeout(() => showPanel(target), 80);
    }
  }

  function handleInput(event) {
    const target = event.target;
    if (!isSearchInput(target)) return;
    activeInput = target;
    if (!current.enabled || !current.searchHistory) {
      hidePanel();
      return;
    }
    if ((target.value || "").trim()) {
      hidePanel();
      return;
    }
    clearTimeout(inputTimer);
    inputTimer = setTimeout(() => showPanel(target), 80);
  }

  function handleKeydown(event) {
    if (event.key === "Escape" && panel && panel.classList.contains("is-show")) {
      hidePanel();
      return;
    }
    const target = event.target;
    if (!isSearchInput(target)) return;
    if (event.key === "Enter" && !event.isComposing) {
      recordSearch(target.value).catch(() => {});
      hidePanel();
    }
  }

  function handleSubmit(event) {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    const input = form.querySelector(SEARCH_INPUT_SELECTOR);
    if (!input) return;
    recordSearch(input.value).catch(() => {});
    hidePanel();
  }

  function handleClick(event) {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    if (panel && panel.contains(target)) return;

    const button = target.closest(
      ".nav-search-btn, .search-btn, .bili-header .search-button, .search-button, button[aria-label*='搜索']"
    );
    if (button) {
      const input = findInputNear(button);
      if (input) recordSearch(input.value).catch(() => {});
    }

    if (isSearchInput(target)) return;
    if (!panel || !panel.classList.contains("is-show")) return;
    if (target.closest("#pbl-search-history")) return;
    hidePanel();
  }

  function handleFocusOut(event) {
    if (!panel || !panel.classList.contains("is-show")) return;
    if (!isSearchInput(event.target)) return;
    clearTimeout(panelHideTimer);
    panelHideTimer = setTimeout(() => {
      const active = document.activeElement;
      if (active && panel && panel.contains(active)) return;
      hidePanel();
    }, 160);
  }

  /* ---------------- 热搜净化 ---------------- */

  function markHotBox(heading) {
    let node = heading;
    for (let i = 0; i < 6 && node && node !== document.body; i += 1) {
      const className = typeof node.className === "string" ? node.className : "";
      const moduleName = node.getAttribute && node.getAttribute("data-module");
      if (/hot|trend/i.test(className) || /hotSearch|trend/i.test(moduleName || "")) {
        node.setAttribute("data-pbl-hot", "1");
        return true;
      }
      node = node.parentElement;
    }
    const side = heading.closest(".search-page aside, .search-page__right, .search-page-right, .search-panel__hot");
    if (side) {
      const box = heading.parentElement;
      if (box && box !== document.body && (box.textContent || "").length < 700) {
        box.setAttribute("data-pbl-hot", "1");
        return true;
      }
    }
    return false;
  }

  function cleanHotModules() {
    if (!current.enabled || !current.searchClean) {
      PB.$$("[data-pbl-hot]").forEach((el) => el.removeAttribute("data-pbl-hot"));
      return;
    }
    const roots = PB.$$(".search-page, .search-page-container, .search-container, .search-panel, .nav-search-content, .bili-header .search-panel");
    if (!roots.length) return;
    roots.forEach((root) => {
      const headings = root.querySelectorAll("h1, h2, h3, h4, .header, .title, .search-panel__title");
      headings.forEach((heading) => {
        if (heading.closest(".history, .search-history, .suggest, .search-suggest, #pbl-search-history")) return;
        const text = (heading.textContent || "").replace(/\s+/g, "").trim();
        if (!HOT_TITLES.has(text)) return;
        markHotBox(heading);
      });
    });
  }

  function scheduleCleanHot(delay) {
    clearTimeout(hotTimer);
    hotTimer = setTimeout(cleanHotModules, typeof delay === "number" ? delay : 180);
  }

  function startHotObserver() {
    if (hotObserver || !document.body) return;
    hotObserver = new MutationObserver(() => {
      if (!current.enabled || !current.searchClean) return;
      if (!document.querySelector(".search-page, .search-panel, .nav-search-content")) return;
      scheduleCleanHot(350);
    });
    hotObserver.observe(document.body, { childList: true, subtree: true });
  }

  function stopHotObserver() {
    if (!hotObserver) return;
    hotObserver.disconnect();
    hotObserver = null;
  }

  /* ---------------- 设置 / 路由 ---------------- */

  function apply(settings) {
    const previous = current;
    current = PB.normalize(settings);
    if (!current.enabled) {
      hidePanel();
      PB.$$("[data-pbl-hot]").forEach((el) => el.removeAttribute("data-pbl-hot"));
      stopHotObserver();
      return;
    }

    if (!current.searchHistory) hidePanel();
    PB.waitForBody(() => {
      if (current.searchClean) {
        startHotObserver();
        scheduleCleanHot(30);
      } else {
        PB.$$("[data-pbl-hot]").forEach((el) => el.removeAttribute("data-pbl-hot"));
        stopHotObserver();
      }
      if (current.searchHistory) applyHistoryLimit(previous);
    });
    if (current.searchHistory) reloadHistory().catch(() => {});
  }

  function applyHistoryLimit(previous) {
    if (!previous || previous.searchHistoryLimit === current.searchHistoryLimit) return;
    PB.trimSearchHistory(current.searchHistoryLimit).then(() => reloadHistory()).catch(() => {});
  }

  function handleRoute(page) {
    hidePanel();
    if (page === "search") {
      const keyword = currentKeywordFromUrl();
      if (keyword && current.searchHistory) recordSearch(keyword).catch(() => {});
      setTimeout(() => scheduleCleanHot(0), 250);
      setTimeout(() => scheduleCleanHot(0), 1200);
    } else {
      scheduleCleanHot(100);
    }
  }

  PB.onSettings(apply);
  PB.onRoute(handleRoute);
  PB.onStorageChange((changes, areaName) => {
    if (areaName !== "local" || !changes[PB.SEARCH_HISTORY_KEY]) return;
    reloadHistory().catch(() => {});
  });
  document.addEventListener("focusin", handleFocusIn, true);
  document.addEventListener("focusout", handleFocusOut, true);
  document.addEventListener("input", handleInput, true);
  document.addEventListener("keydown", handleKeydown, true);
  document.addEventListener("submit", handleSubmit, true);
  document.addEventListener("click", handleClick, true);
  window.addEventListener("resize", positionPanel, { passive: true });
  window.addEventListener("scroll", positionPanel, { passive: true });
})();
