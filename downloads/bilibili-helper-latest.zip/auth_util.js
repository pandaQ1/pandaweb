/**
 * 生词高亮 & 翻译助手 —— Supabase Auth 鉴权模块（无第三方依赖，纯 REST）
 *
 * 设计要点（与 Panda 视频控制插件共用同一套账号体系）：
 *  - 不打包 supabase-js：MV3 禁止远程代码，纯 fetch 调 Supabase Auth/REST 接口更轻，
 *    且 service worker（background.js 经 importScripts 引入本文件）可直接复用。
 *  - 会话存 chrome.storage.local（token 是敏感凭证，禁止放 sync 跨设备漫游）。
 *  - access_token 过期前 60 秒自动用 refresh_token 换新；只有服务端明确拒绝才清会话，
 *    断网 / 网络抖动时保留登录态（stale），避免离线一次就被登出。
 *  - 会员状态查 memberships 表（RLS：用户只能读自己那行，服务端强制）。
 *
 * 供 background service worker（importScripts）与设置页（<script>）共用。
 */
"use strict";

/* ============ 配置（Supabase 项目凭据，公开的 publishable/anon key） ============ */
/* 国内直连 supabase.co 常被间歇性阻断：优先走自有域名 panda2026.cn 上的
 * Cloudflare Worker 反代，代理不可用时自动回退官方直连。 */
const WH_SUPABASE_URLS = [
  "https://sb.panda2026.cn", // Cloudflare Worker 反代（主）
  "https://jahkktkmupynxckkvwhn.supabase.co" // 官方直连（备）
];
const WH_SUPABASE_URL = WH_SUPABASE_URLS[0];
const WH_SUPABASE_ANON = "sb_publishable_d2qrLjSKPbyLg4_lzz0Vvw_6iWiWTZV";
const WH_AUTH_STORE_KEY = "pbl_auth"; // chrome.storage.local 键名
/** 反代 / 网关的瞬时错误（Cloudflare 52x 也算）：换下一个接入点，而不是当成业务失败。 */
const WH_TRANSIENT_STATUS = new Set([502, 503, 504, 520, 521, 522, 523, 524]);

const WHAuth = (() => {
  const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);
  const hasLocal = typeof chrome !== "undefined" && !!(chrome.storage && chrome.storage.local);

  /** 会话代际：每次登录/退出/刷新成功都会递增。
   *  用于防止“旧请求的刷新结果”覆盖新登录的会话（refresh_token 轮换竞态）。 */
  let sessionGen = 0;
  /** 同一代际只允许一个 refresh 请求在途，避免 refresh_token 轮换时并发互相作废。 */
  let refreshInFlight = null;

  /* ---------- 存储抽象：扩展用 chrome.storage.local，网页预览降级 localStorage ---------- */
  async function loadSession() {
    if (hasLocal) {
      try {
        const o = await chrome.storage.local.get(WH_AUTH_STORE_KEY);
        return (o && o[WH_AUTH_STORE_KEY]) || null;
      } catch (e) {
        return null;
      }
    }
    try { return JSON.parse(localStorage.getItem(WH_AUTH_STORE_KEY)) || null; } catch (e) { return null; }
  }
  async function saveSession(s) {
    sessionGen++;
    if (hasLocal) {
      try { await chrome.storage.local.set({ [WH_AUTH_STORE_KEY]: s }); } catch (e) { /* ignore */ }
      return;
    }
    try { localStorage.setItem(WH_AUTH_STORE_KEY, JSON.stringify(s)); } catch (e) { /* ignore */ }
  }
  async function clearSession() {
    sessionGen++;
    if (hasLocal) {
      try { await chrome.storage.local.remove(WH_AUTH_STORE_KEY); } catch (e) { /* ignore */ }
      return;
    }
    try { localStorage.removeItem(WH_AUTH_STORE_KEY); } catch (e) { /* ignore */ }
  }

  /* ---------- 网络层：超时 + 多接入点 + 有限重试 ---------- */
  /** 网络类错误标记：断网 / 被阻断 ≠ 会话失效。 */
  function netError(msg, cause) {
    const e = new Error(msg);
    e.isNetworkError = true;
    if (cause) e.cause = cause;
    return e;
  }
  /** 判断错误是否为网络类（fetch 抛错 / 无法连接 / 超时 / 被阻断） */
  function isNetworkFailure(e) {
    if (!e) return false;
    if (e.isNetworkError) return true;
    if (e.name === "AbortError" || e.name === "TimeoutError") return true;
    return /无法连接|Failed to fetch|NetworkError|ERR_|net::|timeout|timed out|abort|ECONN|ENOTFOUND|EAI_AGAIN/i
      .test(String((e && e.message) || e));
  }

  /** 给一次 fetch 加超时；同时兼容调用方自带的 signal。 */
  function fetchWithTimeout(target, opts, timeoutMs) {
    if (!timeoutMs || typeof AbortController === "undefined") return fetch(target, opts);
    const ctrl = new AbortController();
    const timer = setTimeout(() => {
      try { ctrl.abort(); } catch (e) { /* ignore */ }
    }, timeoutMs);
    const src = opts && opts.signal;
    let onAbort = null;
    if (src) {
      if (src.aborted) {
        try { ctrl.abort(); } catch (e) { /* ignore */ }
      } else {
        onAbort = () => { try { ctrl.abort(); } catch (e) { /* ignore */ } };
        src.addEventListener("abort", onAbort);
      }
    }
    const merged = Object.assign({}, opts, { signal: ctrl.signal });
    const cleanup = () => {
      clearTimeout(timer);
      if (src && onAbort) src.removeEventListener("abort", onAbort);
    };
    return fetch(target, merged).finally(cleanup);
  }

  /**
   * 依次尝试每个接入点，每个点内部再重试 maxTries 次。
   * @param {number} tries  每个接入点额外重试次数（0 = 只请求一次）
   * @param {number} timeoutMs 单次请求超时
   * @param {number} deadlineMs 整体截止时间，避免网络极差时无限等待
   */
  async function fetchRetry(url, opts, tries, timeoutMs, deadlineMs) {
    let lastErr;
    const knownOffline = typeof navigator !== "undefined" && navigator.onLine === false;
    const maxTries = knownOffline ? 0 : (tries || 0);
    const started = Date.now();
    const deadline = deadlineMs || 20000;

    outer:
    for (let bi = 0; bi < WH_SUPABASE_URLS.length; bi++) {
      const base = WH_SUPABASE_URLS[bi];
      const target = base === WH_SUPABASE_URL ? url : url.replace(WH_SUPABASE_URL, base);
      for (let i = 0; i <= maxTries; i++) {
        const remaining = deadline - (Date.now() - started);
        if (remaining <= 0) break outer;
        try {
          const r = await fetchWithTimeout(target, opts, Math.min(timeoutMs || 10000, remaining));
          // 反代宕机时常见 502/503/504：换下一个接入点，而不是把错误当成业务失败
          if (r && WH_TRANSIENT_STATUS.has(r.status) && bi < WH_SUPABASE_URLS.length - 1) {
            lastErr = new Error("HTTP " + r.status + " (" + base + ")");
            continue outer;
          }
          return r;
        } catch (e) {
          lastErr = e;
          if (i < maxTries) await new Promise((r) => setTimeout(r, 400 * (i + 1)));
        }
      }
    }
    throw netError("无法连接账号服务：当前网络可能阻断了 Supabase，请开启代理或更换网络后重试", lastErr);
  }

  function errorMessage(data, status) {
    return (data && (data.msg || data.error_description || data.error || data.message)) || ("HTTP " + status);
  }

  function zhAuthError(msg) {
    if (/invalid_credentials/i.test(msg) || /invalid login credentials/i.test(msg)) return "邮箱或密码错误";
    if (/email.*not.*confirmed|email_not_confirmed/i.test(msg)) return "邮箱尚未验证，请查收验证邮件";
    if (/already.*registered|user_already_exists/i.test(msg)) return "该邮箱已注册，请直接登录";
    if (/password/i.test(msg) && /at least|weak|length/i.test(msg)) return "密码强度不足（至少 6 位）";
    if (/rate limit|too many|over_email_send_rate_limit/i.test(msg)) return "操作过于频繁，请稍后再试";
    if (/otp|invalid token|token.*expired|invalid.*token/i.test(msg)) return "验证码无效或已过期";
    if (/signup.*disabled|signups not allowed/i.test(msg)) return "当前暂未开放注册，请稍后再试";
    return msg;
  }

  async function callAuth(path, body) {
    const r = await fetchRetry(
      WH_SUPABASE_URL + "/auth/v1/" + path,
      {
        method: "POST",
        headers: { apikey: WH_SUPABASE_ANON, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      },
      1,
      10000,
      22000
    );
    let data = null;
    try { data = await r.json(); } catch (e) { /* 非 JSON 响应 */ }
    if (!r.ok || !data) {
      const raw = errorMessage(data, r.status);
      const err = new Error(zhAuthError(raw));
      err.code = (data && (data.error_code || data.code)) || "";
      err.status = r.status;
      throw err;
    }
    return data;
  }

  function normalizeSession(data) {
    return {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Date.now() + (data.expires_in || 3600) * 1000,
      user: data.user ? { id: data.user.id, email: data.user.email } : null
    };
  }

  async function signUp(email, password) {
    const data = await callAuth("signup", { email: String(email || "").trim(), password: String(password || "") });
    // 开启邮箱验证时：注册成功但不会下发会话
    if (data.access_token) { await saveSession(normalizeSession(data)); return { needConfirm: false }; }
    if (data.session && data.session.access_token) {
      await saveSession(normalizeSession(data.session));
      return { needConfirm: false };
    }
    return { needConfirm: true };
  }

  async function signIn(email, password) {
    const data = await callAuth("token?grant_type=password", {
      email: String(email || "").trim(),
      password: String(password || "")
    });
    if (!data.access_token) throw new Error("登录失败：服务端未返回会话");
    await saveSession(normalizeSession(data));
    return { email: data.user ? data.user.email : "" };
  }

  async function signOut() {
    const s = await loadSession();
    if (s && s.refresh_token) {
      // 吊销服务端 refresh token（access token 用途单一，可不管）
      try {
        await fetchWithTimeout(WH_SUPABASE_URL + "/auth/v1/logout", {
          method: "POST",
          headers: {
            apikey: WH_SUPABASE_ANON,
            "Content-Type": "application/json",
            Authorization: "Bearer " + s.access_token
          },
          body: JSON.stringify({ refresh_token: s.refresh_token })
        }, 8000);
      } catch (e) { /* 网络失败也要清本地 */ }
    }
    await clearSession();
  }

  /** 忘记密码：发送重置邮件 → 邮件内容为验证码（Supabase 模板需使用 {{ .Token }}）
   *  → verifyRecoveryCode 验证并建立会话 → setNewPassword 设置新密码。
   *  出于安全考虑，无论邮箱是否注册都按成功返回（防止账号枚举）。 */
  async function requestPasswordReset(email) {
    const r = await fetchRetry(WH_SUPABASE_URL + "/auth/v1/recover", {
      method: "POST",
      headers: { apikey: WH_SUPABASE_ANON, "Content-Type": "application/json" },
      body: JSON.stringify({ email: String(email || "").trim() })
    }, 1, 10000, 22000);
    if (!r.ok) {
      let data = null;
      try { data = await r.json(); } catch (e) { /* ignore */ }
      const msg = errorMessage(data, r.status);
      throw new Error(/rate limit|too many/i.test(msg) ? "发送过于频繁，请稍后再试" : zhAuthError(msg));
    }
    return { sent: true };
  }

  /** 用邮件中的验证码完成验证，成功后自动建立会话（相当于登录）。 */
  async function verifyRecoveryCode(email, token) {
    const data = await callAuth("verify", {
      type: "recovery",
      email: String(email || "").trim(),
      token: String(token || "").trim()
    });
    if (!data.access_token) throw new Error("验证码无效或已过期");
    await saveSession(normalizeSession(data));
    return { email: data.user ? data.user.email : "" };
  }

  /** 已登录状态下设置新密码（忘记密码重置用）。 */
  async function setNewPassword(password) {
    const s = await getSession();
    if (!s) throw new Error("会话已失效，请重新操作");
    const r = await fetchRetry(WH_SUPABASE_URL + "/auth/v1/user", {
      method: "PUT",
      headers: {
        apikey: WH_SUPABASE_ANON,
        "Content-Type": "application/json",
        Authorization: "Bearer " + s.access_token
      },
      body: JSON.stringify({ password: String(password || "") })
    }, 1, 10000, 22000);
    if (!r.ok) {
      let data = null;
      try { data = await r.json(); } catch (e) { /* ignore */ }
      const msg = errorMessage(data, r.status);
      if (r.status === 401) {
        await clearSession();
        throw new Error("登录已过期，请重新登录后再重置密码");
      }
      throw new Error(/password/i.test(msg) && /at least|weak/i.test(msg) ? "密码强度不足（至少 6 位）" : msg);
    }
    return { ok: true };
  }

  async function refreshSession(refreshToken, expectedGen) {
    const data = await callAuth("token?grant_type=refresh_token", { refresh_token: refreshToken });
    const s = normalizeSession(data);
    // 刷新期间已经发生登录/退出/另一次刷新：丢弃本次结果，避免旧 token 覆盖新会话
    if (expectedGen !== undefined && expectedGen !== sessionGen) {
      const err = new Error("会话已在其他操作中更新");
      err.sessionChanged = true;
      throw err;
    }
    await saveSession(s);
    return s;
  }

  function refreshSessionLocked(refreshToken, expectedGen) {
    if (refreshInFlight && refreshInFlight.gen === expectedGen) return refreshInFlight.promise;
    const p = refreshSession(refreshToken, expectedGen);
    refreshInFlight = { gen: expectedGen, promise: p };
    p.finally(() => {
      if (refreshInFlight && refreshInFlight.promise === p) refreshInFlight = null;
    }).catch(() => {});
    return p;
  }

  /** 获取有效会话（临期自动刷新）。
   *  刷新失败时区分原因：网络类失败保留本地会话并标记 stale；服务端明确拒绝才清会话。 */
  async function getSession(depth = 0) {
    const s = await loadSession();
    if (!s || !s.access_token) return null;
    if (Date.now() < (s.expires_at || 0) - 60_000) return s;
    const gen = sessionGen;
    try {
      return await refreshSessionLocked(s.refresh_token, gen);
    } catch (e) {
      if (e && e.sessionChanged) {
        // 另一个请求已经完成刷新/登录：读取最新会话，避免把新会话清掉
        return depth < 2 ? getSession(depth + 1) : null;
      }
      if (isNetworkFailure(e)) return Object.assign({}, s, { stale: true });
      await clearSession();
      return null;
    }
  }

  /** 只读本地会话（不联网）：离线时立即判定“已登录”并显示邮箱。 */
  async function peekSession() {
    const s = await loadSession();
    if (!s || !s.access_token) return null;
    return {
      signed_in: true,
      email: (s.user && s.user.email) || "",
      expires_at: s.expires_at || 0,
      stale: Date.now() >= (s.expires_at || 0) - 60_000
    };
  }

  /* ---------- 会员状态（memberships 表 + RLS） ---------- */
  const WH_MEMBERSHIP_STORE_KEY = "pbl_membership_cache";

  /** 离线时保留上次成功校验的会员状态，避免网络一次抖动就掉 PRO。 */
  async function readMembershipCache(email) {
    let cache = null;
    try {
      if (hasLocal) {
        const o = await new Promise((resolve) => {
          chrome.storage.local.get(WH_MEMBERSHIP_STORE_KEY, (value) => resolve(value || {}));
        });
        cache = o[WH_MEMBERSHIP_STORE_KEY];
      } else {
        cache = JSON.parse(localStorage.getItem(WH_MEMBERSHIP_STORE_KEY) || "null");
      }
    } catch (e) {
      cache = null;
    }
    if (!cache || cache.email !== email) return null;
    if (cache.expires_at) {
      const exp = typeof cache.expires_at === "number" ? cache.expires_at : Date.parse(cache.expires_at);
      if (Number.isFinite(exp) && exp < Date.now()) return null;
    }
    return {
      signed_in: true,
      pro: !!cache.pro,
      plan: cache.plan || "free",
      expires_at: cache.expires_at || 0,
      email
    };
  }

  async function writeMembershipCache(email, membership) {
    const cache = {
      email,
      pro: !!membership.pro,
      plan: membership.plan || "free",
      expires_at: membership.expires_at || 0,
      ts: Date.now()
    };
    try {
      if (hasLocal) {
        await new Promise((resolve) => chrome.storage.local.set({ [WH_MEMBERSHIP_STORE_KEY]: cache }, resolve));
      } else {
        localStorage.setItem(WH_MEMBERSHIP_STORE_KEY, JSON.stringify(cache));
      }
    } catch (e) { /* ignore */ }
  }

  async function rememberMembership(email, membership) {
    if (membership && membership.signed_in && !membership.offline) {
      try { await writeMembershipCache(email, membership); } catch (e) { /* ignore */ }
    }
    return membership;
  }

  async function fetchMemberships(accessToken) {
    return fetchRetry(WH_SUPABASE_URL + "/rest/v1/memberships?select=plan,expires_at", {
      headers: { apikey: WH_SUPABASE_ANON, Authorization: "Bearer " + accessToken }
    }, 1, 10000, 22000);
  }

  /** 返回 { signed_in, pro, plan, expires_at, email, reason, offline? } */
  async function getMembership() {
    const s = await getSession();
    if (!s) return { signed_in: false, pro: false, plan: "free", reason: "未登录" };
    const email = (s.user && s.user.email) || "";
    try {
      let r = await fetchMemberships(s.access_token);
      if (r.status === 401 || r.status === 403) {
        // 临期 / 时钟偏差导致的偶发 401：先刷新 token 重试一次，仍失败才判定会话无效
        const gen = sessionGen;
        try {
          await refreshSessionLocked(s.refresh_token, gen);
        } catch (e) {
          if (e && e.sessionChanged) {
            // 其他请求已经更新了会话：继续用最新会话查询（authEpoch 会在后台兜底）
          } else if (isNetworkFailure(e)) {
            const cached = await readMembershipCache(email);
            if (cached) {
              return Object.assign(cached, {
                offline: true,
                reason: "网络错误：离线，保留上次会员状态（联网后自动校验）"
              });
            }
            return {
              signed_in: true, pro: false, plan: "free", offline: true, email,
              reason: "网络错误：离线，保留上次登录状态（联网后自动校验）"
            };
          } else {
            await clearSession();
            return { signed_in: false, pro: false, plan: "free", reason: "会话已失效，请重新登录" };
          }
        }
        const s2 = await getSession();
        if (s2) r = await fetchMemberships(s2.access_token);
        if (r && (r.status === 401 || r.status === 403)) {
          const body = await r.text().catch(() => "");
          console.warn("[WHAuth] memberships 拒绝访问:", r.status, body.slice(0, 300));
          return {
            signed_in: true, pro: false, plan: "free", email,
            reason: "会员接口拒绝访问(" + r.status + ")，请检查 memberships 表的 RLS 策略"
          };
        }
      }
      if (!r.ok) {
        const body = await r.text().catch(() => "");
        console.warn("[WHAuth] memberships 查询失败:", r.status, body.slice(0, 300));
        const short = body.replace(/\s+/g, " ").slice(0, 140);
        const tip = /PGRST205|Could not find the table/i.test(body) ? "memberships 表未创建（请先执行建表 SQL）"
          : r.status === 404 ? "memberships 表不存在（请先执行建表 SQL）"
          : "会员信息查询失败(HTTP " + r.status + "): " + short;
        return { signed_in: true, pro: false, plan: "free", email, reason: tip };
      }
      const rows = await r.json();
      const list = Array.isArray(rows) ? rows : [];
      // 同一账号理论上只有一行；若历史数据出现多行，优先取 pro
      const m = list.find((row) => row && row.plan === "pro") || list[0];
      if (!m) return rememberMembership(email, { signed_in: true, pro: false, plan: "free", email });
      if (m.plan !== "pro") {
        return rememberMembership(email, { signed_in: true, pro: false, plan: m.plan || "free", email });
      }
      const exp = m.expires_at
        ? (typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at))
        : 0;
      if (m.expires_at && !Number.isFinite(exp)) {
        return { signed_in: true, pro: false, plan: m.plan, expires_at: m.expires_at, email, reason: "会员有效期数据异常，请联系客服" };
      }
      if (m.expires_at && Number.isFinite(exp) && exp < Date.now()) {
        return rememberMembership(email, {
          signed_in: true, pro: false, plan: m.plan, expires_at: m.expires_at, email, reason: "会员已过期"
        });
      }
      return rememberMembership(email, {
        signed_in: true, pro: true, plan: m.plan, expires_at: m.expires_at || 0, email
      });
    } catch (e) {
      console.warn("[WHAuth] memberships 网络错误:", e);
      const offline = isNetworkFailure(e);
      if (offline) {
        const cached = await readMembershipCache(email);
        if (cached) {
          return Object.assign(cached, {
            offline: true,
            reason: "网络错误：离线，保留上次会员状态（联网后自动校验）"
          });
        }
      }
      return {
        signed_in: true, pro: false, plan: "free", email, offline,
        reason: (offline ? "网络错误：" : "查询失败：") + (e.message || e)
      };
    }
  }

  /** 便捷方法：带 Bearer token 的 fetch（会员专属后端接口用）。 */
  async function authedFetch(url, opts) {
    const s = await getSession();
    if (!s) {
      const err = new Error("此功能需要登录");
      err.needLogin = true;
      throw err;
    }
    const o = Object.assign({ headers: {} }, opts || {});
    o.headers = Object.assign({}, o.headers, { Authorization: "Bearer " + s.access_token });
    const r = await fetch(url, o);
    if (r.status === 401) {
      await clearSession();
      const err = new Error("登录已过期，请重新登录");
      err.needLogin = true;
      throw err;
    }
    return r;
  }

  /** 兑换码激活会员（服务端 security definer 函数原子处理，防并发重复使用）。
   *  成功返回 { ok:true, plan, expires_at }。 */
  async function redeemCode(code) {
    const s = await getSession();
    if (!s) throw new Error("请先登录后再兑换");
    const r = await fetchRetry(WH_SUPABASE_URL + "/rest/v1/rpc/redeem_code", {
      method: "POST",
      headers: {
        apikey: WH_SUPABASE_ANON,
        "Content-Type": "application/json",
        Authorization: "Bearer " + s.access_token
      },
      body: JSON.stringify({ p_code: String(code || "").trim() })
    }, 1, 10000, 22000);
    let data = null;
    try { data = await r.json(); } catch (e) { /* 非 JSON */ }
    const d = Array.isArray(data) ? data[0] : data;
    const ok = d === true || (d && d.ok === true);
    if (!r.ok || !ok) {
      const err = d && d.error;
      const msg = typeof err === "string" ? err : (err && err.message) || "";
      throw new Error(
        msg === "invalid_or_used" ? "兑换码无效或已被使用"
          : msg === "not_signed_in" ? "请先登录后再兑换"
            : msg || ("兑换失败(HTTP " + r.status + ")，请稍后重试")
      );
    }
    return d === true ? { ok: true } : d;
  }

  return {
    signUp, signIn, signOut,
    requestPasswordReset, verifyRecoveryCode, setNewPassword,
    getSession, peekSession, getMembership, authedFetch, redeemCode,
    isNetworkFailure, IS_EXT
  };
})();

/* 兼容 service worker（importScripts 无 window）与普通页面 */
if (typeof globalThis !== "undefined") globalThis.WHAuth = WHAuth;
if (typeof window !== "undefined") window.WHAuth = WHAuth;
