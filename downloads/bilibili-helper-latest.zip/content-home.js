/**
 * Panda 哔哩哔哩助手 · 首页与推荐流
 *
 *  - 标记并隐藏广告卡、直播卡（CSS 负责 display:none）
 *  - 换一换：保存推荐 DOM 快照，支持 R 换一批 / Shift+R 上一组 / Alt+R 下一组
 *  - 上一组 / 下一组按钮紧贴原生「换一换」，下一组就是撤销返回前的那批推荐
 *
 * 只在首页 / 视频页 / 搜索页 / 热门页工作；直播间只走 CSS 收起榜单侧栏。
 */
(function () {
  "use strict";

  const PB = window.PB;
  if (!PB) return;

  const CARD_SELECTOR = [
    ".bili-video-card",
    ".feed-card",
    ".bili-feed-card",
    ".bili-live-card",
    ".floor-single-card",
    ".video-page-card-small",
    ".video-card",
    ".card-box",
    ".video-page-special-card-small",
    ".video-card-ad-small",
    ".pop-live-small-mode",
    "#slide_ad",
    ".video-list > div"
  ].join(",");

  const AD_MARKERS = [
    ".bili-video-card__info--ad",
    ".bili-video-card__info--creative-ad",
    "[class*='video-card__info--ad']",
    "[class*='info--creative-ad']",
    "[class*='creative-ad']",
    "[data-module='ad']",
    "a[href*='cm.bilibili.com']",
    "a[href*='ad.bilibili.com']"
  ].join(",");

  const REFRESH_SELECTORS = [
    ".feed-roll-btn",
    ".flexible-roll-btn",
    ".roll-btn",
    ".primary-btn.roll",
    ".recommended-container_floor-aside .roll-btn",
    ".bili-feed4 .flexible-roll-btn"
  ];

  let current = PB.normalize(PB.DEFAULTS);
  let observer = null;
  let scanTimer = 0;
  let active = false;
  let history = [];
  let future = [];
  let pendingSnapshot = null;
  // innerHTML 还原后的现场：{ container, liveChildren, restoredNodes }
  let restoredFeed = null;
  let rollGroup = null;
  let backBtn = null;
  let forwardBtn = null;
  let rollPositionTimer = 0;
  let rollListenersBound = false;
  let internalRefresh = false;
  let lastRoute = "";
  let homeScanTimer = 0;

  /** 卡片类型缓存：B 站首页的 DOM 每秒会变动多次，每轮扫描都重新判定
   *  「是否广告」要遍历每张卡里最多 32 个叶子节点，是首页最主要的主线程开销。
   *  卡片的类型和开关无关，判定一次即可复用。 */
  const cardKinds = new WeakMap();
  /** 负结果（普通视频卡）只缓存这么久：骨架屏先渲染、内容后填充时不能把卡片判死。 */
  const CARD_KIND_TTL = 8000;

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
    return el.getClientRects().length > 0;
  }

  function isLiveCard(card) {
    if (card.matches(".bili-live-card, .pop-live-small-mode")) return true;
    return !!card.querySelector(
      "a[href*='live.bilibili.com'], a[href^='//live.bilibili.com'], a[href^='https://live.bilibili.com']"
    );
  }

  function isAdCard(card) {
    if (card.matches("#slide_ad, .video-card-ad-small, .video-page-special-card-small, .adcard")) return true;
    if (card.querySelector(AD_MARKERS)) return true;

    // 广告卡常常只渲染一个「广告」角标，做一次小范围文本兜底。
    const nodes = card.querySelectorAll("span, div, i, em");
    const limit = Math.min(nodes.length, 32);
    for (let i = 0; i < limit; i += 1) {
      const node = nodes[i];
      if (node.children.length) continue;
      const text = (node.textContent || "").trim();
      if (/^(广告|推广|赞助|AD)$/i.test(text)) return true;
    }
    return false;
  }

  function clearMarks() {
    PB.$$("[data-pbl-hide]").forEach((el) => el.removeAttribute("data-pbl-hide"));
    PB.setStat("ads", 0);
    PB.setStat("live", 0);
    PB.setStat("tags", 0);
  }

  function classifyCard(card) {
    const cached = cardKinds.get(card);
    if (cached) {
      // 正结果（广告/直播）不会变回普通卡片，可以永久复用；负结果留一个重判窗口。
      if (cached.kind || Date.now() - cached.at < CARD_KIND_TTL) return cached.kind;
    }
    const kind = isLiveCard(card) ? "live" : isAdCard(card) ? "ad" : "";
    cardKinds.set(card, { kind, at: Date.now() });
    return kind;
  }

  function scanCards() {
    if (!active || document.hidden) return;
    const page = PB.pageType(location.href);
    if (page !== "home" && page !== "video" && page !== "search" && page !== "popular") return;
    const cards = Array.from(document.querySelectorAll(CARD_SELECTOR));
    let ads = 0;
    let live = 0;
    let tags = 0;

    cards.forEach((card) => {
      if (card.closest("#pbl-toast, #pbl-roll-history, #pbl-search-history")) return;
      // 只处理最外层候选，避免同一张卡被内层元素重复标记。
      if (card.parentElement && card.parentElement.closest(CARD_SELECTOR)) return;
      const kind = classifyCard(card);
      let mark = "";
      if (kind === "live") mark = current.hideLive ? "live" : "";
      else if (kind === "ad") mark = current.hideAds ? "ad" : "";
      if (mark) {
        card.setAttribute("data-pbl-hide", mark);
        tags += 1;
        if (mark === "ad") ads += 1;
        else live += 1;
      } else if (card.hasAttribute("data-pbl-hide")) {
        card.removeAttribute("data-pbl-hide");
      }
    });

    // 统计在遍历里顺手累加：原来每轮扫描要再全文档查询 3 次。
    PB.setStat("ads", ads);
    PB.setStat("live", live);
    PB.setStat("tags", tags);
  }

  function scheduleScan(delay) {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scanCards, typeof delay === "number" ? delay : 100);
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver(() => scheduleScan(120));
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function stopObserver() {
    if (!observer) return;
    observer.disconnect();
    observer = null;
  }

  function getFeedContainer() {
    return (
      document.querySelector(".recommended-container_floor-aside .container") ||
      document.querySelector(".feed2 .container") ||
      document.querySelector(".recommend-container .container") ||
      document.querySelector(".bili-feed4 .container")
    );
  }

  /** 推荐流的廉价指纹：子节点数 + 前 6 张卡的跳转地址。
   *  只用来回答「这批推荐和上一批是不是同一批」，比序列化整个容器便宜两个数量级。 */
  function feedSignature(container) {
    if (!container) return "";
    const kids = container.children;
    const parts = [String(kids.length)];
    const limit = Math.min(kids.length, 6);
    for (let i = 0; i < limit; i += 1) {
      const node = kids[i];
      const link = node.querySelector ? node.querySelector("a[href]") : null;
      parts.push(link ? link.getAttribute("href") || "" : (node.textContent || "").slice(0, 24));
    }
    return parts.join("|");
  }

  function snapshotFeed() {
    const container = getFeedContainer();
    if (!container) return null;
    return {
      html: container.innerHTML,
      sig: feedSignature(container),
      scrollY: window.scrollY || document.documentElement.scrollTop || 0,
      time: Date.now()
    };
  }

  function findRefreshButton() {
    for (const selector of REFRESH_SELECTORS) {
      const node = PB.$$(selector).find(isVisible);
      if (node) return node;
    }
    const candidates = Array.from(document.querySelectorAll("button, [role='button'], .feed-roll-btn, .flexible-roll-btn, .roll-btn"));
    for (const node of candidates) {
      if (node.closest("#pbl-toast, #pbl-roll-history, #pbl-search-history")) continue;
      if (!isVisible(node)) continue;
      const text = (node.textContent || "").replace(/\s+/g, "").trim();
      if (text === "换一换" || text === "换一批" || text === "刷新推荐") return node;
    }
    return null;
  }

  function ensureRollControls() {
    if (!document.body) return null;
    if (rollGroup && rollGroup.isConnected) return rollGroup;
    rollGroup = document.createElement("div");
    rollGroup.id = "pbl-roll-history";
    rollGroup.className = "pbl-roll-history";
    rollGroup.setAttribute("role", "group");
    rollGroup.setAttribute("aria-label", "推荐历史");
    rollGroup.innerHTML = [
      '<button type="button" class="pbl-roll-history-btn" id="pbl-roll-back" title="返回上一组推荐（Shift + R）" aria-label="返回上一组推荐">',
      '  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">',
      '    <path d="M9 14 4 9l5-5"/><path d="M4 9h9a7 7 0 1 1 0 14h-1"/>',
      "  </svg>",
      "</button>",
      '<button type="button" class="pbl-roll-history-btn" id="pbl-roll-forward" title="前往下一组推荐（Alt + R）" aria-label="前往下一组推荐">',
      '  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">',
      '    <path d="m15 14 5-5-5-5"/><path d="M20 9h-9a7 7 0 1 0 0 14h1"/>',
      "  </svg>",
      "</button>"
    ].join("");
    backBtn = rollGroup.querySelector("#pbl-roll-back");
    forwardBtn = rollGroup.querySelector("#pbl-roll-forward");
    backBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      undo();
    });
    forwardBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      redo();
    });
    document.body.appendChild(rollGroup);
    startRollPositionLoop();
    return rollGroup;
  }

  function positionRollControls() {
    if (!rollGroup || !rollGroup.isConnected) return;
    if (!current.enabled || !current.rollHistory || !PB.isHome()) {
      rollGroup.classList.remove("is-show");
      // 离开首页后不再需要 1.2s 一次的定位轮询；回到首页由 updateHistoryButtons 重启。
      stopRollPositionLoop();
      return;
    }
    const native = document.querySelector(".feed-roll-btn") || document.querySelector(".flexible-roll-btn");
    if (!native || !isVisible(native)) {
      rollGroup.classList.remove("is-show");
      return;
    }
    const rect = native.getBoundingClientRect();
    if (rect.width < 8 || rect.bottom < 0 || rect.top > window.innerHeight - 24) {
      rollGroup.classList.remove("is-show");
      return;
    }
    // fixed 定位的包含块宽度不含滚动条；用 clientWidth 才能和 B 站原生按钮对齐。
    const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
    rollGroup.style.right = Math.max(8, Math.round(viewportWidth - rect.right)) + "px";
    rollGroup.style.top = Math.round(rect.bottom + 6) + "px";
    rollGroup.style.width = Math.max(34, Math.round(rect.width)) + "px";
    rollGroup.classList.add("is-show");
  }

  function startRollPositionLoop() {
    // 监听只挂一次：轮询会被停掉再重启，监听重复挂会导致定位逻辑成倍执行。
    if (!rollListenersBound) {
      rollListenersBound = true;
      window.addEventListener("scroll", positionRollControls, { passive: true });
      window.addEventListener("resize", positionRollControls, { passive: true });
    }
    if (rollPositionTimer) return;
    rollPositionTimer = setInterval(positionRollControls, 1200);
  }

  function stopRollPositionLoop() {
    if (!rollPositionTimer) return;
    clearInterval(rollPositionTimer);
    rollPositionTimer = 0;
  }

  function updateHistoryButtons() {
    if (!current.enabled || !current.rollHistory || !PB.isHome()) {
      if (rollGroup) rollGroup.classList.remove("is-show");
      stopRollPositionLoop();
      return;
    }
    ensureRollControls();
    startRollPositionLoop();
    if (backBtn) {
      backBtn.disabled = history.length === 0;
      backBtn.setAttribute("aria-disabled", history.length ? "false" : "true");
    }
    if (forwardBtn) {
      forwardBtn.disabled = future.length === 0;
      forwardBtn.setAttribute("aria-disabled", future.length ? "false" : "true");
    }
    positionRollControls();
  }

  /**
   * 还原推荐流用的是 innerHTML，得到的是一批克隆节点：B 站绑在这些节点上的
   * 事件（尤其是容器里的原生「换一换」按钮）全都没了，Vue 的 vnode 也还指着
   * 已被摘掉的旧节点。所以还原时留住活节点，下次刷新前先接回去。
   */
  function sameNodes(container, nodes) {
    if (!container || !nodes || container.childNodes.length !== nodes.length) return false;
    for (let i = 0; i < nodes.length; i += 1) {
      if (container.childNodes[i] !== nodes[i]) return false;
    }
    return true;
  }

  function reviveFeed() {
    if (!restoredFeed) return false;
    const container = restoredFeed.container;
    const liveChildren = restoredFeed.liveChildren;
    const restoredNodes = restoredFeed.restoredNodes;
    // 还原之后容器被 B 站追加/改动过，就不要再动它，避免把新节点摘掉。
    if (!container || !container.isConnected || !sameNodes(container, restoredNodes)) {
      restoredFeed = null;
      return false;
    }
    restoredFeed = null;
    try {
      container.replaceChildren.apply(container, liveChildren);
    } catch (error) {
      while (container.firstChild) container.removeChild(container.firstChild);
      liveChildren.forEach((node) => container.appendChild(node));
    }
    return true;
  }

  function restoreSnapshot(snapshot) {
    const container = getFeedContainer();
    if (!container || !snapshot) return false;
    // 原生「换一换」按钮就在这个容器里：innerHTML 会把它换成没有事件绑定的克隆，
    // 之后点它再也不会有反应，所以先把活节点留下来，下次刷新前接回去。
    const liveChildren = restoredFeed && restoredFeed.container === container
      ? restoredFeed.liveChildren
      : Array.from(container.childNodes);
    container.innerHTML = snapshot.html;
    restoredFeed = { container, liveChildren, restoredNodes: Array.from(container.childNodes) };
    scheduleScan(0);
    try {
      window.scrollTo({ top: snapshot.scrollY || 0, behavior: "auto" });
    } catch (e) {
      window.scrollTo(0, snapshot.scrollY || 0);
    }
    return true;
  }

  function rememberFuture(snapshot) {
    if (!snapshot || !snapshot.html) return;
    future.push(snapshot);
    if (future.length > 6) future.shift();
  }

  function rememberHistory(snapshot) {
    if (!snapshot || !snapshot.html) return;
    history.push(snapshot);
    if (history.length > 6) history.shift();
  }

  function undo() {
    if (!history.length) {
      PB.toast("已经是第一组推荐了");
      return;
    }
    const currentSnapshot = snapshotFeed();
    const earlier = history[history.length - 1];
    if (!restoreSnapshot(earlier)) return;
    history.pop();
    rememberFuture(currentSnapshot);
    PB.bumpStat("rollUndo");
    PB.toast("已回到上一组推荐", { action: redo, actionLabel: "下一组" });
    updateHistoryButtons();
  }

  function redo() {
    if (!future.length) {
      PB.toast("已经是最后一组推荐了");
      return;
    }
    const currentSnapshot = snapshotFeed();
    const later = future[future.length - 1];
    if (!restoreSnapshot(later)) return;
    future.pop();
    rememberHistory(currentSnapshot);
    PB.bumpStat("rollRedo");
    PB.toast("已前往下一组推荐", { action: undo, actionLabel: "上一组" });
    updateHistoryButtons();
  }

  function watchFeedChange(before, onChanged) {
    const started = Date.now();
    // 只有 DOM 真的变化过才去算指纹。
    // 原实现每 180ms 序列化整个推荐流做比较（4.2 秒约 23 次 innerHTML），
    // 是首页最重的一笔主线程开销；现在改用 feedSignature 这种 O(卡片数) 的轻量指纹。
    const target = getFeedContainer();
    const beforeSig = (before && before.sig) || "";
    let mutated = false;
    const mo = target && target.nodeType === 1 ? new MutationObserver(() => { mutated = true; }) : null;
    if (mo) mo.observe(target, { childList: true, subtree: true });
    const stopWatch = () => { if (mo) mo.disconnect(); };
    const timer = setInterval(() => {
      const container = getFeedContainer();
      // 容器整个被替换（B 站重渲染）时 observer 收不到通知，用身份比较兜底。
      const touched = !!container && (container !== target || mutated);
      const changed = touched && feedSignature(container) !== beforeSig;
      if (changed || Date.now() - started > 4200) {
        clearInterval(timer);
        stopWatch();
        onChanged(changed);
      }
    }, 180);
    return timer;
  }

  function pushSnapshot(snapshot) {
    if (!snapshot || !snapshot.html) return;
    if (history.length && history[history.length - 1].html === snapshot.html) {
      updateHistoryButtons();
      return;
    }
    rememberHistory(snapshot);
    // 新的一批推荐会产生新分支，之前的“下一组”失效。
    future = [];
    updateHistoryButtons();
  }

  function performRefresh(source) {
    if (!PB.isHome()) {
      PB.toast("换一换只在首页生效");
      return;
    }
    const container = getFeedContainer();
    if (!container) {
      PB.toast("推荐流还没加载好，稍后再试");
      return;
    }
    const before = snapshotFeed();
    if (!findRefreshButton()) {
      // 没按钮就什么都不动，免得白白把还原态提前接回去
      PB.toast("没有找到 B 站的「换一换」按钮");
      return;
    }
    // 把 B 站的活节点接回去后再重新取按钮：还原出来的是克隆版，点了没反应
    if (restoredFeed) reviveFeed();
    const button = findRefreshButton();
    if (!button) return;

    // 先挂观察者再点击：万一 B 站是同步渲染，观察者也已经在场
    watchFeedChange(before, (changed) => {
      if (!changed) {
        if (source === "keyboard") PB.toast("这次没有换到新内容，请稍后再试");
        return;
      }
      pushSnapshot(before);
      PB.toast("已换一批推荐", { action: undo, actionLabel: "撤销" });
    });

    internalRefresh = true;
    try {
      button.click();
    } finally {
      internalRefresh = false;
    }
  }

  function onNativeRefreshClick(event) {
    if (!active || !current.rollHistory || !PB.isHome() || internalRefresh) return;
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const direct = target.closest(REFRESH_SELECTORS.join(","));
    const generic = target.closest("button, [role='button'], .feed-roll-btn, .flexible-roll-btn, .roll-btn");
    const button = direct || generic;
    if (!button || !isVisible(button)) return;
    if (button.closest("#pbl-toast, #pbl-roll-history, #pbl-search-history")) return;
    if (!direct) {
      const text = (button.textContent || "").replace(/\s+/g, "").trim();
      if (!/换一换|换一批|刷新推荐/.test(text)) return;
    }

    const before = snapshotFeed();
    if (!before) return;
    pendingSnapshot = before;
    // 还原过推荐流时，点击落在克隆出来的按钮上，它已经没有事件绑定了：
    // 先把活节点接回去，再把这次点击转发给真正的原生按钮。
    // 转发放到下一个宏任务，确保下面的 watchFeedChange 已经挂上 observer。
    let forwardButton = null;
    if (restoredFeed) {
      reviveFeed();
      const liveButton = findRefreshButton();
      if (liveButton && liveButton !== button) forwardButton = liveButton;
    }
    if (forwardButton) {
      event.preventDefault();
      event.stopPropagation();
      setTimeout(() => {
        // 这次是程序化点击：让 capture 监听跳过自己，避免再挂一个 watcher
        internalRefresh = true;
        try { forwardButton.click(); } catch (error) { /* ignore */ } finally { internalRefresh = false; }
      }, 0);
    }
    watchFeedChange(before, (changed) => {
      if (changed && pendingSnapshot) {
        pushSnapshot(pendingSnapshot);
        PB.toast("已换一批推荐", { action: undo, actionLabel: "撤销" });
      }
      pendingSnapshot = null;
    });
  }

  function onKeydown(event) {
    if (!active || !current.rollHistory || !PB.isHome()) return;
    if (event.isComposing || event.keyCode === 229) return;
    if (event.ctrlKey || event.metaKey) return;
    if (PB.isTypingEvent(event)) return;
    const key = String(event.key || "").toLowerCase();
    if (key !== "r") return;

    if (event.altKey) {
      if (event.shiftKey) return;
      event.preventDefault();
      event.stopPropagation();
      if (!event.repeat) redo();
      return;
    }
    if (event.shiftKey) {
      event.preventDefault();
      event.stopPropagation();
      if (!event.repeat) undo();
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    if (event.repeat) return;
    performRefresh("keyboard");
  }

  function handleRoute(page) {
    const routeKey = page + "|" + location.pathname;
    if (routeKey === lastRoute) {
      if (page === "home") scheduleScan(200);
      return;
    }
    lastRoute = routeKey;
    history = [];
    future = [];
    pendingSnapshot = null;
    restoredFeed = null;
    updateHistoryButtons();
    if (page === "home" && active) {
      clearTimeout(homeScanTimer);
      homeScanTimer = setTimeout(() => scheduleScan(0), 260);
    }
  }

  function apply(settings) {
    current = PB.normalize(settings);
    // active 表示扩展在首页启用，而不是“广告/直播过滤至少开一个”。
    // 否则用户只留“换一换历史”时，R 会被误判为不可用。
    active = !!current.enabled;
    if (!current.enabled) {
      clearMarks();
      stopObserver();
      updateHistoryButtons();
      return;
    }
    PB.waitForBody(() => {
      if (current.hideAds || current.hideLive) startObserver();
      else stopObserver();
      scheduleScan(40);
      updateHistoryButtons();
    });
    updateHistoryButtons();
  }

  PB.onSettings(apply);
  PB.onRoute(handleRoute);
  document.addEventListener("keydown", onKeydown, true);
  document.addEventListener("click", onNativeRefreshClick, true);
  // scanCards 在后台标签页会直接跳过；回到前台补扫一次，
  // 否则"本页已隐藏 N 个广告"这类统计会停在被跳过的那一刻。
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) scheduleScan(0);
  }, true);
})();

