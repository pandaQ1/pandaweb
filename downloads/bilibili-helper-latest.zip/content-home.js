/**
 * Panda 哔哩哔哩助手 · 首页与推荐流
 *
 *  - 标记并隐藏广告卡、直播卡（CSS 负责 display:none）
 *  - 换一换：保存推荐 DOM 快照，支持 R 换一批 / Shift+R 上一组 / Alt+R 下一组
 *  - 上一组 / 下一组按钮紧贴原生「换一换」，下一组就是撤销返回前的那批推荐
 *
 * 只在首页 / 视频页 / 搜索页 / 热门页工作；直播间只走 CSS 收起榜单侧栏。
 */
(function () {
  "use strict";

  const PB = window.PB;
  if (!PB) return;

  const CARD_SELECTOR = [
    ".bili-video-card",
    ".feed-card",
    ".bili-feed-card",
    ".bili-live-card",
    ".floor-single-card",
    ".video-page-card-small",
    ".video-card",
    ".card-box",
    ".video-page-special-card-small",
    ".video-card-ad-small",
    ".pop-live-small-mode",
    "#slide_ad",
    ".video-list > div"
  ].join(",");

  const AD_MARKERS = [
    ".bili-video-card__info--ad",
    ".bili-video-card__info--creative-ad",
    "[class*='video-card__info--ad']",
    "[class*='info--creative-ad']",
    "[class*='creative-ad']",
    "[data-module='ad']",
    "a[href*='cm.bilibili.com']",
    "a[href*='ad.bilibili.com']"
  ].join(",");

  const REFRESH_SELECTORS = [
    ".feed-roll-btn",
    ".flexible-roll-btn",
    ".roll-btn",
    ".primary-btn.roll",
    ".recommended-container_floor-aside .roll-btn",
    ".bili-feed4 .flexible-roll-btn"
  ];

  let current = PB.normalize(PB.DEFAULTS);
  let observer = null;
  let scanTimer = 0;
  let active = false;
  let history = [];
  let future = [];
  let pendingSnapshot = null;
  let rollGroup = null;
  let backBtn = null;
  let forwardBtn = null;
  let rollPositionTimer = 0;
  let internalRefresh = false;
  let lastRoute = "";
  let homeScanTimer = 0;

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
    return el.getClientRects().length > 0;
  }

  function isLiveCard(card) {
    if (card.matches(".bili-live-card, .pop-live-small-mode")) return true;
    return !!card.querySelector(
      "a[href*='live.bilibili.com'], a[href^='//live.bilibili.com'], a[href^='https://live.bilibili.com']"
    );
  }

  function isAdCard(card) {
    if (card.matches("#slide_ad, .video-card-ad-small, .video-page-special-card-small, .adcard")) return true;
    if (card.querySelector(AD_MARKERS)) return true;

    // 广告卡常常只渲染一个「广告」角标，做一次小范围文本兜底。
    const nodes = card.querySelectorAll("span, div, i, em");
    const limit = Math.min(nodes.length, 32);
    for (let i = 0; i < limit; i += 1) {
      const node = nodes[i];
      if (node.children.length) continue;
      const text = (node.textContent || "").trim();
      if (/^(广告|推广|赞助|AD)$/i.test(text)) return true;
    }
    return false;
  }

  function clearMarks() {
    PB.$$("[data-pbl-hide]").forEach((el) => el.removeAttribute("data-pbl-hide"));
    PB.setStat("ads", 0);
    PB.setStat("live", 0);
    PB.setStat("tags", 0);
  }

  function scanCards() {
    if (!active) return;
    const page = PB.pageType(location.href);
    if (page !== "home" && page !== "video" && page !== "search" && page !== "popular") return;
    const cards = Array.from(document.querySelectorAll(CARD_SELECTOR));

    cards.forEach((card) => {
      if (card.closest("#pbl-toast, #pbl-roll-history, #pbl-search-history")) return;
      // 只处理最外层候选，避免同一张卡被内层元素重复标记。
      if (card.parentElement && card.parentElement.closest(CARD_SELECTOR)) return;
      let mark = "";
      if (current.hideLive && isLiveCard(card)) mark = "live";
      else if (current.hideAds && isAdCard(card)) mark = "ad";
      if (mark) card.setAttribute("data-pbl-hide", mark);
      else if (card.hasAttribute("data-pbl-hide")) card.removeAttribute("data-pbl-hide");
    });

    PB.setStat("ads", PB.$$("[data-pbl-hide='ad']").length);
    PB.setStat("live", PB.$$("[data-pbl-hide='live']").length);
    PB.setStat("tags", PB.$$("[data-pbl-hide]").length);
  }

  function scheduleScan(delay) {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scanCards, typeof delay === "number" ? delay : 100);
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver(() => scheduleScan(120));
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function stopObserver() {
    if (!observer) return;
    observer.disconnect();
    observer = null;
  }

  function getFeedContainer() {
    return (
      document.querySelector(".recommended-container_floor-aside .container") ||
      document.querySelector(".feed2 .container") ||
      document.querySelector(".recommend-container .container") ||
      document.querySelector(".bili-feed4 .container")
    );
  }

  function snapshotFeed() {
    const container = getFeedContainer();
    if (!container) return null;
    return {
      html: container.innerHTML,
      scrollY: window.scrollY || document.documentElement.scrollTop || 0,
      time: Date.now()
    };
  }

  function findRefreshButton() {
    for (const selector of REFRESH_SELECTORS) {
      const node = PB.$$(selector).find(isVisible);
      if (node) return node;
    }
    const candidates = Array.from(document.querySelectorAll("button, [role='button'], .feed-roll-btn, .flexible-roll-btn, .roll-btn"));
    for (const node of candidates) {
      if (node.closest("#pbl-toast, #pbl-roll-history, #pbl-search-history")) continue;
      if (!isVisible(node)) continue;
      const text = (node.textContent || "").replace(/\s+/g, "").trim();
      if (text === "换一换" || text === "换一批" || text === "刷新推荐") return node;
    }
    return null;
  }

  function ensureRollControls() {
    if (!document.body) return null;
    if (rollGroup && rollGroup.isConnected) return rollGroup;
    rollGroup = document.createElement("div");
    rollGroup.id = "pbl-roll-history";
    rollGroup.className = "pbl-roll-history";
    rollGroup.setAttribute("role", "group");
    rollGroup.setAttribute("aria-label", "推荐历史");
    rollGroup.innerHTML = [
      '<button type="button" class="pbl-roll-history-btn" id="pbl-roll-back" title="返回上一组推荐（Shift + R）" aria-label="返回上一组推荐">',
      '  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">',
      '    <path d="M9 14 4 9l5-5"/><path d="M4 9h9a7 7 0 1 1 0 14h-1"/>',
      "  </svg>",
      "</button>",
      '<button type="button" class="pbl-roll-history-btn" id="pbl-roll-forward" title="前往下一组推荐（Alt + R）" aria-label="前往下一组推荐">',
      '  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">',
      '    <path d="m15 14 5-5-5-5"/><path d="M20 9h-9a7 7 0 1 0 0 14h1"/>',
      "  </svg>",
      "</button>"
    ].join("");
    backBtn = rollGroup.querySelector("#pbl-roll-back");
    forwardBtn = rollGroup.querySelector("#pbl-roll-forward");
    backBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      undo();
    });
    forwardBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      redo();
    });
    document.body.appendChild(rollGroup);
    startRollPositionLoop();
    return rollGroup;
  }

  function positionRollControls() {
    if (!rollGroup || !rollGroup.isConnected) return;
    if (!current.enabled || !current.rollHistory || !PB.isHome()) {
      rollGroup.classList.remove("is-show");
      return;
    }
    const native = document.querySelector(".feed-roll-btn") || document.querySelector(".flexible-roll-btn");
    if (!native || !isVisible(native)) {
      rollGroup.classList.remove("is-show");
      return;
    }
    const rect = native.getBoundingClientRect();
    if (rect.width < 8 || rect.bottom < 0 || rect.top > window.innerHeight - 24) {
      rollGroup.classList.remove("is-show");
      return;
    }
    // fixed 定位的包含块宽度不含滚动条；用 clientWidth 才能和 B 站原生按钮对齐。
    const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
    rollGroup.style.right = Math.max(8, Math.round(viewportWidth - rect.right)) + "px";
    rollGroup.style.top = Math.round(rect.bottom + 6) + "px";
    rollGroup.style.width = Math.max(34, Math.round(rect.width)) + "px";
    rollGroup.classList.add("is-show");
  }

  function startRollPositionLoop() {
    if (rollPositionTimer) return;
    rollPositionTimer = setInterval(positionRollControls, 1200);
    window.addEventListener("scroll", positionRollControls, { passive: true });
    window.addEventListener("resize", positionRollControls, { passive: true });
  }

  function updateHistoryButtons() {
    if (!current.enabled || !current.rollHistory || !PB.isHome()) {
      if (rollGroup) rollGroup.classList.remove("is-show");
      return;
    }
    ensureRollControls();
    if (backBtn) {
      backBtn.disabled = history.length === 0;
      backBtn.setAttribute("aria-disabled", history.length ? "false" : "true");
    }
    if (forwardBtn) {
      forwardBtn.disabled = future.length === 0;
      forwardBtn.setAttribute("aria-disabled", future.length ? "false" : "true");
    }
    positionRollControls();
  }

  function restoreSnapshot(snapshot) {
    const container = getFeedContainer();
    if (!container || !snapshot) return false;
    container.innerHTML = snapshot.html;
    scheduleScan(0);
    try {
      window.scrollTo({ top: snapshot.scrollY || 0, behavior: "auto" });
    } catch (e) {
      window.scrollTo(0, snapshot.scrollY || 0);
    }
    return true;
  }

  function rememberFuture(snapshot) {
    if (!snapshot || !snapshot.html) return;
    future.push(snapshot);
    if (future.length > 6) future.shift();
  }

  function rememberHistory(snapshot) {
    if (!snapshot || !snapshot.html) return;
    history.push(snapshot);
    if (history.length > 6) history.shift();
  }

  function undo() {
    if (!history.length) {
      PB.toast("已经是第一组推荐了");
      return;
    }
    const currentSnapshot = snapshotFeed();
    const earlier = history[history.length - 1];
    if (!restoreSnapshot(earlier)) return;
    history.pop();
    rememberFuture(currentSnapshot);
    PB.bumpStat("rollUndo");
    PB.toast("已回到上一组推荐", { action: redo, actionLabel: "下一组" });
    updateHistoryButtons();
  }

  function redo() {
    if (!future.length) {
      PB.toast("已经是最后一组推荐了");
      return;
    }
    const currentSnapshot = snapshotFeed();
    const later = future[future.length - 1];
    if (!restoreSnapshot(later)) return;
    future.pop();
    rememberHistory(currentSnapshot);
    PB.bumpStat("rollRedo");
    PB.toast("已前往下一组推荐", { action: undo, actionLabel: "上一组" });
    updateHistoryButtons();
  }

  function watchFeedChange(beforeHTML, onChanged) {
    const started = Date.now();
    const timer = setInterval(() => {
      const container = getFeedContainer();
      const changed = !!container && container.innerHTML !== beforeHTML;
      if (changed || Date.now() - started > 4200) {
        clearInterval(timer);
        onChanged(changed);
      }
    }, 180);
    return timer;
  }

  function pushSnapshot(snapshot) {
    if (!snapshot || !snapshot.html) return;
    if (history.length && history[history.length - 1].html === snapshot.html) {
      updateHistoryButtons();
      return;
    }
    rememberHistory(snapshot);
    // 新的一批推荐会产生新分支，之前的“下一组”失效。
    future = [];
    updateHistoryButtons();
  }

  function performRefresh(source) {
    if (!PB.isHome()) {
      PB.toast("换一换只在首页生效");
      return;
    }
    const container = getFeedContainer();
    if (!container) {
      PB.toast("推荐流还没加载好，稍后再试");
      return;
    }
    const before = snapshotFeed();
    const button = findRefreshButton();
    if (!button) {
      PB.toast("没有找到 B 站的「换一换」按钮");
      return;
    }

    internalRefresh = true;
    try {
      button.click();
    } finally {
      internalRefresh = false;
    }

    watchFeedChange(before.html, (changed) => {
      if (!changed) {
        if (source === "keyboard") PB.toast("这次没有换到新内容，请稍后再试");
        return;
      }
      pushSnapshot(before);
      PB.toast("已换一批推荐", { action: undo, actionLabel: "撤销" });
    });
  }

  function onNativeRefreshClick(event) {
    if (!active || !current.rollHistory || !PB.isHome() || internalRefresh) return;
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const direct = target.closest(REFRESH_SELECTORS.join(","));
    const generic = target.closest("button, [role='button'], .feed-roll-btn, .flexible-roll-btn, .roll-btn");
    const button = direct || generic;
    if (!button || !isVisible(button)) return;
    if (button.closest("#pbl-toast, #pbl-roll-history, #pbl-search-history")) return;
    if (!direct) {
      const text = (button.textContent || "").replace(/\s+/g, "").trim();
      if (!/换一换|换一批|刷新推荐/.test(text)) return;
    }

    const before = snapshotFeed();
    if (!before) return;
    pendingSnapshot = before;
    watchFeedChange(before.html, (changed) => {
      if (changed && pendingSnapshot) {
        pushSnapshot(pendingSnapshot);
        PB.toast("已换一批推荐", { action: undo, actionLabel: "撤销" });
      }
      pendingSnapshot = null;
    });
  }

  function onKeydown(event) {
    if (!active || !current.rollHistory || !PB.isHome()) return;
    if (event.isComposing || event.keyCode === 229) return;
    if (event.ctrlKey || event.metaKey) return;
    if (PB.isTypingEvent(event)) return;
    const key = String(event.key || "").toLowerCase();
    if (key !== "r") return;

    if (event.altKey) {
      if (event.shiftKey) return;
      event.preventDefault();
      event.stopPropagation();
      if (!event.repeat) redo();
      return;
    }
    if (event.shiftKey) {
      event.preventDefault();
      event.stopPropagation();
      if (!event.repeat) undo();
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    if (event.repeat) return;
    performRefresh("keyboard");
  }

  function handleRoute(page) {
    const routeKey = page + "|" + location.pathname;
    if (routeKey === lastRoute) {
      if (page === "home") scheduleScan(200);
      return;
    }
    lastRoute = routeKey;
    history = [];
    future = [];
    pendingSnapshot = null;
    updateHistoryButtons();
    if (page === "home" && active) {
      clearTimeout(homeScanTimer);
      homeScanTimer = setTimeout(() => scheduleScan(0), 260);
    }
  }

  function apply(settings) {
    current = PB.normalize(settings);
    // active 表示扩展在首页启用，而不是“广告/直播过滤至少开一个”。
    // 否则用户只留“换一换历史”时，R 会被误判为不可用。
    active = !!current.enabled;
    if (!current.enabled) {
      clearMarks();
      stopObserver();
      updateHistoryButtons();
      return;
    }
    PB.waitForBody(() => {
      if (current.hideAds || current.hideLive) startObserver();
      else stopObserver();
      scheduleScan(40);
      updateHistoryButtons();
    });
    updateHistoryButtons();
  }

  PB.onSettings(apply);
  PB.onRoute(handleRoute);
  document.addEventListener("keydown", onKeydown, true);
  document.addEventListener("click", onNativeRefreshClick, true);
})();

