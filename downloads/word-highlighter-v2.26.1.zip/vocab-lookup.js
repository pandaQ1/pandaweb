/* 生词高亮 & 翻译助手 —— 词形还原查词兜底 v1.0.0
 *
 * 内置词库（vocab-data.js）只收原形（约 1.1 万词，小学→SAT 八套词表）。
 * 网页上收藏的往往是变形词（rallying / posted / diaries），各处用
 * VOCAB.meta[word] 精确匹配就会落空 —— 生词本列表、导出 CSV/TXT/Anki、
 * 详情页、背单词页的释义与音标于是出现大片空白。
 *
 * 本模块：先精确匹配；失败再按常见屈折后缀反推原形重查，命中即复用原形词条。
 * 原则：只读词库、不改任何数据；也不改变网页高亮范围（高亮仍按原表判定）。
 */
(function () {
  "use strict";

  const VOCAB = (typeof window !== "undefined" && window.__WH_VOCAB__) || null;
  const META = (VOCAB && VOCAB.meta) || {};
  const cache = new Map();
  const CACHE_MAX = 3000;

  /* 双写辅音结尾（running → run / planned → plan） */
  const DOUBLE_CONSONANT = /([bcdfgklmnprstvz])\1$/;

  /** 按可能性从高到低生成原形候选；顺序即优先级 */
  function lemmaCandidates(word) {
    const w = String(word || "");
    const out = [];
    const push = (x) => {
      if (x && x.length >= 2 && x !== w && out.indexOf(x) < 0) out.push(x);
    };

    /* 复数 / 第三人称单数 */
    if (/ies$/.test(w)) push(w.slice(0, -3) + "y");                 // diaries → diary
    if (/(?:ches|shes|sses|xes|zes)$/.test(w)) push(w.slice(0, -2)); // watches → watch
    if (/es$/.test(w)) { push(w.slice(0, -2)); push(w.slice(0, -1)); }
    if (/s$/.test(w) && !/(?:ss|us|is)$/.test(w)) push(w.slice(0, -1)); // terms → term

    /* 过去式 / 过去分词 */
    if (/ied$/.test(w)) push(w.slice(0, -3) + "y");                  // studied → study
    if (/ed$/.test(w)) {
      const stem = w.slice(0, -2);
      push(stem);                                                    // posted → post
      push(stem + "e");                                              // expired → expire
      if (DOUBLE_CONSONANT.test(stem)) push(stem.slice(0, -1));      // planned → plan
      if (/i$/.test(stem)) push(stem.slice(0, -1) + "y");
    }

    /* 现在分词 */
    if (/ing$/.test(w)) {
      const stem = w.slice(0, -3);
      push(stem);                                                    // littering → litter
      push(stem + "e");                                              // alluring → allure
      if (DOUBLE_CONSONANT.test(stem)) push(stem.slice(0, -1));      // running → run
      if (/y$/.test(stem)) push(stem.slice(0, -1) + "ie");           // dying → die
    }

    /* 副词 */
    if (/ally$/.test(w)) push(w.slice(0, -4) + "al");                // accidentally → accidental
    if (/ily$/.test(w)) push(w.slice(0, -3) + "y");                  // happily → happy
    if (/ly$/.test(w)) push(w.slice(0, -2));

    /* 比较级 / 最高级 */
    if (/ier$/.test(w)) push(w.slice(0, -3) + "y");
    if (/iest$/.test(w)) push(w.slice(0, -4) + "y");
    if (/er$/.test(w)) push(w.slice(0, -2));
    if (/est$/.test(w)) push(w.slice(0, -3));

    return out;
  }

  /** 统一成小写、去掉首尾标点（保留连字符与撇号） */
  function normalize(word) {
    if (word == null) return "";
    return String(word)
      .trim()
      .toLowerCase()
      .replace(/^[^a-z]+/, "")
      .replace(/[^a-z'\-]+$/, "");
  }

  /** lookup(word) → { meta, lemma, exact } | null；exact=false 表示走的是原形兜底 */
  function lookup(word) {
    const key = normalize(word);
    if (!key) return null;
    if (cache.has(key)) return cache.get(key);

    let res = null;
    if (META[key]) {
      res = { meta: META[key], lemma: key, exact: true };
    } else {
      const cands = lemmaCandidates(key);
      for (let i = 0; i < cands.length; i++) {
        if (META[cands[i]]) {
          res = { meta: META[cands[i]], lemma: cands[i], exact: false };
          break;
        }
      }
    }
    if (cache.size >= CACHE_MAX) cache.clear();
    cache.set(key, res);
    return res;
  }

  /** get(word) → 词库词条 [释义数组, 音标] | null；可原地替换各处的 wordMetaOf */
  function get(word) {
    const r = lookup(word);
    return r ? r.meta : null;
  }

  /** 释义文本：多义用「；」连接，与导出的 CSV/Anki 口径保持一致 */
  function defOf(word) {
    const m = get(word);
    return m && m[0] ? [].concat(m[0]).join("；") : "";
  }

  /** 音标 */
  function phoneticOf(word) {
    const m = get(word);
    return (m && m[1]) || "";
  }

  if (typeof window !== "undefined") {
    window.WH_LOOKUP = { get, lookup, defOf, phoneticOf, lemmaCandidates, normalize };
  }
})();
