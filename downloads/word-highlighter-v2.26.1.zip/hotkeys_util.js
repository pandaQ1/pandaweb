/* Panda 生词高亮 & 翻译助手 —— 快捷键中心共享模块（v2.24.0）
 *
 * 为什么单独一个文件：
 *   设置页（options.html）要「录制 + 展示 + 冲突检测」，内容脚本（content.js）要「匹配按键」，
 *   两边如果各写一套解析，很容易出现「设置里录成了 Ctrl+K，页面上却按不出」这种分叉。
 *   所以规范化格式、匹配规则、动作清单只在这里定义一次，两边共用。
 *
 * 规范格式（存进 chrome.storage.sync.hotkeys.bindings）：
 *   "A" / "Alt+X" / "Ctrl+Shift+K" / "Meta+Slash"
 *   修饰键顺序固定为 Ctrl → Alt → Shift → Meta，键名走「物理键位」（KeyboardEvent.code）
 *   好处：Shift+斜杠 这类组合不受键盘布局与大小写影响，录制与匹配永远一致。
 */
(function (global) {
  "use strict";

  /** 每个动作最多几个按键 */
  const MAX_PER_ACTION = 4;

  /** 动作清单（顺序即「快捷键中心」的显示顺序；defaults 为空数组=默认不占用任何键） */
  const ACTIONS = [
    {
      id: "openCard",
      group: "取词与卡片",
      label: "取词卡片",
      desc: "在鼠标停留的单词上打开 / 关闭详细释义卡片（与右键同功能）",
      defaults: ["A"]
    },
    {
      id: "ocrShot",
      group: "取词与卡片",
      label: "截图翻译",
      desc: "光标变十字，按住左键拉框，松开即识别并翻译",
      defaults: ["Alt+X"]
    },
    {
      id: "toggleHighlight",
      group: "页面与工具",
      label: "开关生词高亮",
      desc: "临时打开 / 关闭当前页的生词高亮（与设置页总开关联动）",
      defaults: []
    },
    {
      id: "toggleTranslate",
      group: "页面与工具",
      label: "开关网页翻译",
      desc: "打开 / 关闭整页翻译（与弹窗里的「翻译：开/关」联动）",
      defaults: []
    },
    {
      id: "rescan",
      group: "页面与工具",
      label: "重新扫描本页",
      desc: "重新扫一遍当前页面，刷新高亮与译文（内容更新后取词不对时用）",
      defaults: []
    },
    {
      id: "openWordlist",
      group: "页面与工具",
      label: "打开生词本",
      desc: "新标签页打开生词本",
      defaults: []
    },
    {
      id: "pdfOpen",
      group: "页面与工具",
      label: "PDF 取词",
      desc: "用 Panda 阅读器打开 PDF：页面里内嵌 PDF 就取它的地址，普通网页则打开阅读器让你粘链接/拖文件",
      defaults: []
    },
    {
      id: "openSettings",
      group: "页面与工具",
      label: "打开设置",
      desc: "新标签页打开插件设置页",
      defaults: []
    }
  ];

  const MOD_ALIASES = {
    ctrl: "ctrl", control: "ctrl", cmd: "meta", command: "meta", meta: "meta", win: "meta",
    alt: "alt", option: "alt", opt: "alt", shift: "shift"
  };

  /** 键名规范表：各种写法 → code 风格键名 */
  const KEY_ALIASES = {
    esc: "Escape", escape: "Escape",
    enter: "Enter", return: "Enter",
    space: "Space", spacebar: "Space", " ": "Space",
    tab: "Tab", backspace: "Backspace", bksp: "Backspace",
    del: "Delete", delete: "Delete", ins: "Insert", insert: "Insert",
    home: "Home", end: "End",
    pageup: "PageUp", pgup: "PageUp", pagedown: "PageDown", pgdn: "PageDown",
    up: "ArrowUp", down: "ArrowDown", left: "ArrowLeft", right: "ArrowRight",
    arrowup: "ArrowUp", arrowdown: "ArrowDown", arrowleft: "ArrowLeft", arrowright: "ArrowRight",
    comma: "Comma", period: "Period", dot: "Period", slash: "Slash", semicolon: "Semicolon",
    quote: "Quote", apostrophe: "Quote", bracketleft: "BracketLeft", bracketright: "BracketRight",
    backslash: "Backslash", minus: "Minus", equal: "Equal", equals: "Equal",
    backquote: "Backquote", backtick: "Backquote", tilde: "Backquote", grave: "Backquote",
    capslock: "CapsLock"
  };

  /** 标点符号字符 → code 风格键名（e.key 兜底时用，含 Shift 后的字符） */
  const PUNCT_BY_CHAR = {
    ",": "Comma", ".": "Period", "/": "Slash", ";": "Semicolon", "'": "Quote",
    "[": "BracketLeft", "]": "BracketRight", "\\": "Backslash", "-": "Minus", "=": "Equal", "`": "Backquote",
    "<": "Comma", ">": "Period", "?": "Slash", ":": "Semicolon", "\"": "Quote",
    "{": "BracketLeft", "}": "BracketRight", "|": "Backslash", "_": "Minus", "+": "Equal", "~": "Backquote",
    "!": "1", "@": "2", "#": "3", "$": "4", "%": "5", "^": "6", "&": "7", "*": "8", "(": "9", ")": "0"
  };

  const PUNCT_BY_CODE = {
    Comma: "Comma", Period: "Period", Slash: "Slash", Semicolon: "Semicolon", Quote: "Quote",
    BracketLeft: "BracketLeft", BracketRight: "BracketRight", Backslash: "Backslash",
    Minus: "Minus", Equal: "Equal", Backquote: "Backquote"
  };

  const NAMED_BY_CODE = {
    Space: "Space", Enter: "Enter", NumpadEnter: "Enter", Escape: "Escape", Tab: "Tab",
    Backspace: "Backspace", Delete: "Delete", Insert: "Insert", Home: "Home", End: "End",
    PageUp: "PageUp", PageDown: "PageDown", ArrowUp: "ArrowUp", ArrowDown: "ArrowDown",
    ArrowLeft: "ArrowLeft", ArrowRight: "ArrowRight", CapsLock: "CapsLock"
  };

  /** 显示用的短标签 */
  const KEY_LABELS = {
    ArrowUp: "↑", ArrowDown: "↓", ArrowLeft: "←", ArrowRight: "→",
    Escape: "Esc", Space: "Space", Backspace: "⌫", Delete: "Del", Insert: "Ins",
    PageUp: "PgUp", PageDown: "PgDn", Comma: ",", Period: ".", Slash: "/", Semicolon: ";",
    Quote: "'", BracketLeft: "[", BracketRight: "]", Backslash: "\\", Minus: "-",
    Equal: "=", Backquote: "`", Ctrl: "Ctrl", Alt: "Alt", Shift: "Shift", Meta: "Meta"
  };

  /* ============================================================
   * 一、事件 → 规范组合
   * ============================================================ */

  /** KeyboardEvent → code 风格键名（优先 e.code：物理键位，Shift 不影响） */
  function keyFromEvent(e) {
    if (!e) return "";
    const code = String(e.code || "");
    let m = /^Key([A-Z])$/.exec(code);
    if (m) return m[1];
    m = /^Digit([0-9])$/.exec(code);
    if (m) return m[1];
    m = /^Numpad([0-9])$/.exec(code);
    if (m) return "Numpad" + m[1];
    m = /^(F\d{1,2})$/.exec(code);
    if (m) return m[1];
    if (NAMED_BY_CODE[code]) return NAMED_BY_CODE[code];
    if (PUNCT_BY_CODE[code]) return PUNCT_BY_CODE[code];
    // 老浏览器 / 特殊设备没有 code 时退回 e.key
    return keyFromChar(e.key);
  }

  /** e.key → code 风格键名 */
  function keyFromChar(ch) {
    if (!ch) return "";
    const lower = String(ch).toLowerCase();
    if (KEY_ALIASES[lower]) return KEY_ALIASES[lower];
    if (/^[a-z]$/.test(lower)) return lower.toUpperCase();
    if (/^[0-9]$/.test(ch)) return ch;
    if (/^f\d{1,2}$/.test(lower)) return lower.toUpperCase();
    if (PUNCT_BY_CHAR[ch]) return PUNCT_BY_CHAR[ch];
    return "";
  }

  /** 是否为纯修饰键按下（录制时要忽略，等真正的键） */
  function isModifierOnly(e) {
    const k = String((e && e.key) || "");
    return ["Control", "Alt", "Shift", "Meta", "AltGraph", "CapsLock", "Dead", "Unidentified", "Process", "Compose"].includes(k);
  }

  /** KeyboardEvent → 规范组合字符串（不合法的键返回 ""） */
  function comboFromEvent(e) {
    const key = keyFromEvent(e);
    if (!key) return "";
    if (key === "CapsLock") return "";
    const mods = [];
    if (e.ctrlKey) mods.push("Ctrl");
    if (e.altKey) mods.push("Alt");
    if (e.shiftKey) mods.push("Shift");
    if (e.metaKey) mods.push("Meta");
    return mods.length ? mods.join("+") + "+" + key : key;
  }

  /* ============================================================
   * 二、规范组合 ↔ 文本 ↔ 匹配
   * ============================================================ */

  /** 任意写法 → 规范组合（"alt + x" → "Alt+X"；不认识返回 ""） */
  function normalizeComboText(text) {
    if (!text || typeof text !== "string") return "";
    const parts = text.split("+").map((s) => s.trim()).filter(Boolean);
    if (!parts.length) return "";
    const mods = { ctrl: false, alt: false, shift: false, meta: false };
    let key = "";
    for (const p of parts) {
      const m = MOD_ALIASES[p.toLowerCase()];
      if (m && !key) { mods[m] = true; continue; }
      if (key) return ""; // 出现两个非修饰键 → 不合法
      key = p;
    }
    if (!key) return "";
    const k = keyFromChar(key) || keyFromChar(key.toLowerCase());
    if (!k || k === "CapsLock") return "";
    if (k === "Escape") return ""; // Esc 留给「关闭卡片 / 取消录制」
    const order = [];
    if (mods.ctrl) order.push("Ctrl");
    if (mods.alt) order.push("Alt");
    if (mods.shift) order.push("Shift");
    if (mods.meta) order.push("Meta");
    return order.length ? order.join("+") + "+" + k : k;
  }

  function parseCombo(combo) {
    const out = { ctrl: false, alt: false, shift: false, meta: false, key: "", ok: false };
    if (!combo || typeof combo !== "string") return out;
    const parts = combo.split("+").map((s) => s.trim()).filter(Boolean);
    if (!parts.length) return out;
    for (const p of parts) {
      const m = MOD_ALIASES[p.toLowerCase()];
      if (m && !out.key) { out[m] = true; continue; }
      if (out.key) return out;
      out.key = p;
    }
    out.ok = !!out.key;
    return out;
  }

  /** 组合是否带修饰键（纯字母/数字单键为 false） */
  function hasModifier(combo) {
    const p = parseCombo(combo);
    return !!(p.ctrl || p.alt || p.shift || p.meta);
  }

  /** 事件是否命中该组合 */
  function eventMatches(e, combo) {
    const p = parseCombo(combo);
    if (!p.ok || !e) return false;
    if (!!e.ctrlKey !== p.ctrl) return false;
    if (!!e.altKey !== p.alt) return false;
    if (!!e.shiftKey !== p.shift) return false;
    if (!!e.metaKey !== p.meta) return false;
    return keyFromEvent(e) === p.key;
  }

  /** 事件命中哪个动作（没有返回 ""） */
  function actionFromEvent(e, bindings) {
    if (!e || e.repeat) return "";
    for (const a of ACTIONS) {
      const list = (bindings && bindings[a.id]) || [];
      for (const combo of list) {
        if (eventMatches(e, combo)) return a.id;
      }
    }
    return "";
  }

  /** 展示文本："Ctrl+Shift+K" → "Ctrl + Shift + K" */
  function formatCombo(combo) {
    const p = parseCombo(combo);
    if (!p.ok) return String(combo || "");
    const out = [];
    if (p.ctrl) out.push("Ctrl");
    if (p.alt) out.push("Alt");
    if (p.shift) out.push("Shift");
    if (p.meta) out.push("Meta");
    out.push(KEY_LABELS[p.key] || p.key);
    return out.join(" + ");
  }

  /* ============================================================
   * 三、绑定集合（默认值 / 规范化 / 冲突）
   * ============================================================ */

  function defaultBindings() {
    const out = {};
    for (const a of ACTIONS) out[a.id] = a.defaults.slice();
    return out;
  }

  function uniq(list) {
    const seen = new Set();
    const out = [];
    for (const x of list) {
      if (!x || seen.has(x)) continue;
      seen.add(x);
      out.push(x);
    }
    return out;
  }

  /**
   * 读存档 → 规范绑定表。
   * @param {object|null} raw      storage 里的 hotkeys.bindings
   * @param {string}      legacyOcr 老版本的单字段 ocrHotkey（没有 hotkeys 存档时沿用它）
   */
  function normalizeBindings(raw, legacyOcr) {
    const out = {};
    for (const a of ACTIONS) {
      let list;
      const v = raw ? raw[a.id] : undefined;
      if (Array.isArray(v)) list = v;
      else if (typeof v === "string") list = [v];
      else list = a.defaults.slice();
      out[a.id] = uniq(list.map(normalizeComboText).filter(Boolean)).slice(0, MAX_PER_ACTION);
    }
    if (legacyOcr) {
      const hasOwn = raw && (Array.isArray(raw.ocrShot) || typeof raw.ocrShot === "string");
      if (!hasOwn) {
        const c = normalizeComboText(legacyOcr);
        if (c) out.ocrShot = [c];
      }
    }
    return out;
  }

  /** 该组合是否已被别的动作占用（返回占用者 id，没有返回 ""） */
  function findConflict(bindings, combo, exceptActionId) {
    const p = parseCombo(combo);
    if (!p.ok) return "";
    for (const a of ACTIONS) {
      if (a.id === exceptActionId) continue;
      const list = (bindings && bindings[a.id]) || [];
      for (const c of list) {
        if (parseCombo(c).ok && c === combo) return a.id;
      }
    }
    return "";
  }

  /** 浏览器 / 系统抢占的组合：网页根本收不到，录了也白录 */
  const RESERVED = new Set([
    "Ctrl+T", "Ctrl+W", "Ctrl+N", "Ctrl+R", "Ctrl+P", "Ctrl+S", "Ctrl+F", "Ctrl+H", "Ctrl+J",
    "Ctrl+D", "Ctrl+L", "Ctrl+O", "Ctrl+U", "Ctrl+G", "Ctrl+Shift+T", "Ctrl+Shift+N", "Ctrl+Shift+W",
    "Ctrl+Shift+P", "Ctrl+Shift+B", "Ctrl+Shift+I", "Ctrl+Shift+J", "Ctrl+Shift+C", "Ctrl+Shift+O",
    "Ctrl+Shift+Q", "Ctrl+Shift+Delete", "Ctrl+Tab", "Ctrl+Shift+Tab", "Ctrl+PageUp", "Ctrl+PageDown",
    "Ctrl+1", "Ctrl+2", "Ctrl+3", "Ctrl+4", "Ctrl+5", "Ctrl+6", "Ctrl+7", "Ctrl+8", "Ctrl+9",
    "Alt+Left", "Alt+Right", "Alt+Home", "Alt+D", "Alt+F", "Alt+E", "Alt+F4", "Alt+Tab",
    "F5", "F11", "F12", "Meta+T", "Meta+N", "Meta+W", "Meta+Q", "Shift+Tab"
  ]);

  function riskyReason(combo) {
    const c = normalizeComboText(combo) || combo;
    if (RESERVED.has(c)) return "「" + formatCombo(c) + "」是浏览器/系统占用的组合，网页收不到，建议换一个";
    return "";
  }

  const API = {
    MAX_PER_ACTION,
    ACTIONS,
    comboFromEvent,
    normalizeComboText,
    parseCombo,
    formatCombo,
    eventMatches,
    actionFromEvent,
    hasModifier,
    isModifierOnly,
    defaultBindings,
    normalizeBindings,
    findConflict,
    riskyReason,
    keyFromEvent,
    keyFromChar
  };

  global.WH_HOTKEYS = API;
  if (typeof module !== "undefined" && module.exports) module.exports = API;
})(typeof window !== "undefined" ? window : globalThis);
