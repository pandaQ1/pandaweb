/* 生词高亮 & 翻译助手 —— 单词详情共享模块 v2.14.0
 * 提供结构化单词详情查询与渲染，供 learn.html / wordlist.html 复用。
 * 数据来源：后台 AI（若配置）→ 词典链（有道/Free Dictionary）→ 本地词库兜底。
 */
(function () {
  "use strict";

  const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);
  const VOCAB = (typeof window.__WH_VOCAB__ !== "undefined") ? window.__WH_VOCAB__ : null;

  async function fetchWordDetail(word) {
    if (!word) return localDetail(word);
    if (!IS_EXT) return localDetail(word);

    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve(localDetail(word)), 15000);
      try {
        chrome.runtime.sendMessage({ type: "WH_WORD_DETAIL", word }, (resp) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) {
            resolve(localDetail(word));
            return;
          }
          if (resp && resp.ok) resolve(enrichWithLocal(resp, word));
          else resolve(localDetail(word));
        });
      } catch (e) {
        clearTimeout(timer);
        resolve(localDetail(word));
      }
    });
  }

  /** 词库查词：精确匹配 → 词形还原兜底（vocab-lookup.js）；都没有返回 null */
  function wordMetaOf(word) {
    if (window.WH_LOOKUP) return window.WH_LOOKUP.get(word);
    return (VOCAB && VOCAB.meta && VOCAB.meta[word]) || null;
  }

  function localDetail(word) {
    return enrichAll({
      ok: true,
      source: "local",
      word,
      phonetic: "",
      translations: [],
      examples: [],
      collocations: [],
      rootDeriv: "",
      synonyms: []
    }, word);
  }

  function enrichWithLocal(resp, word) {
    return enrichAll(resp, word);
  }

  function enrichAll(data, word) {
    const m = wordMetaOf(word);
    if (m && m[0] && (!data.translations || !data.translations.length)) {
      data.translations = m[0];
    }
    if (m && m[1] && !data.phonetic) data.phonetic = m[1];

    // 统一 rootDeriv 为对象
    let rootText = "";
    let derivativeArr = [];
    if (typeof data.rootDeriv === "string") {
      rootText = data.rootDeriv;
    } else if (data.rootDeriv && typeof data.rootDeriv === "object") {
      rootText = data.rootDeriv.root || "";
      derivativeArr = Array.isArray(data.rootDeriv.derivatives) ? data.rootDeriv.derivatives : [];
    }
    if (!rootText) rootText = explainRootAffix(word);
    if (!derivativeArr.length) derivativeArr = localDerivatives(word);
    data.rootDeriv = { root: rootText, derivatives: derivativeArr.slice(0, 12) };

    // 本地兜底：例句、词组搭配、近义词
    if (!data.examples || !data.examples.length) data.examples = makeFallbackExamples(word);
    if (!data.collocations || !data.collocations.length) data.collocations = makeFallbackCollocations(word);
    if (!data.synonyms || !data.synonyms.length) data.synonyms = makeFallbackSynonyms(word);

    return data;
  }

  // ---------- 本地词形还原与词根词缀分析 ----------
  const AFFIX_PREFIX = {
    un: "不，非", re: "再，又", in: "不，向内", im: "不", il: "不", ir: "不",
    dis: "否定，相反", en: "使…", em: "使…", pre: "前，预先", pro: "向前，支持",
    over: "过度，在…之上", under: "不足，在…之下", mis: "错误", sub: "下，次",
    de: "去除，向下", trans: "横过，转移", anti: "反对", auto: "自己", super: "超级"
  };
  const AFFIX_SUFFIX = {
    ing: "现在分词/动名词后缀", ed: "过去式/过去分词后缀", er: "做…的人/物；比较级",
    est: "最…", ly: "…地", tion: "名词后缀（行为/结果）", sion: "名词后缀",
    ness: "名词后缀（性质/状态）", ment: "名词后缀", ful: "充满…的", less: "没有…的",
    able: "可…的", ible: "可…的", al: "…的/名词后缀", ous: "…的", ive: "有…性质的",
    ize: "使…化", ise: "使…化", y: "…的/名词后缀", s: "复数/第三人称后缀",
    es: "复数/第三人称后缀"
  };
  const SUFFIX_RULES = [
    { suf: "ies", rep: "y" }, { suf: "ied", rep: "y" },
    { suf: "ying", rep: "ie" }, { suf: "ing", rep: "" }, { suf: "ing", rep: "e" },
    { suf: "ed", rep: "" }, { suf: "ed", rep: "e" },
    { suf: "er", rep: "" }, { suf: "est", rep: "" },
    { suf: "ly", rep: "" },
    { suf: "tion", rep: "te" }, { suf: "sion", rep: "se" },
    { suf: "ness", rep: "" }, { suf: "ment", rep: "" },
    { suf: "ful", rep: "" }, { suf: "less", rep: "" },
    { suf: "able", rep: "" }, { suf: "ible", rep: "" },
    { suf: "al", rep: "" }, { suf: "ous", rep: "" },
    { suf: "ive", rep: "" }, { suf: "ize", rep: "" }, { suf: "ise", rep: "" },
    { suf: "es", rep: "" }, { suf: "s", rep: "" }
  ];
  const PREFIX_LIST = Object.keys(AFFIX_PREFIX).sort((a, b) => b.length - a.length);
  const SUFFIX_LIST = Object.keys(AFFIX_SUFFIX).sort((a, b) => b.length - a.length);

  function lemmaCandidates(word) {
    const w = word.toLowerCase();
    const set = new Set([w]);
    for (const p of PREFIX_LIST) {
      if (w.startsWith(p) && w.length > p.length + 2) set.add(w.slice(p.length));
    }
    for (const { suf, rep } of SUFFIX_RULES) {
      if (w.endsWith(suf) && w.length > suf.length + 2) {
        set.add(w.slice(0, -suf.length) + rep);
      }
    }
    const arr = [...set].filter((x) => x !== w && wordMetaOf(x));
    arr.sort((a, b) => a.length - b.length || a.localeCompare(b));
    return arr;
  }

  function explainRootAffix(word) {
    const w = word.toLowerCase();
    let base = w, prefix = "", suffix = "";
    for (const p of PREFIX_LIST) {
      if (w.startsWith(p) && w.length > p.length + 2) { prefix = p; base = w.slice(p.length); break; }
    }
    for (const s of SUFFIX_LIST) {
      if (base.endsWith(s) && base.length > s.length + 1) { suffix = s; base = base.slice(0, -s.length); break; }
    }
    if (!prefix && !suffix) return "";
    const baseMeta = wordMetaOf(base);
    const baseTrans = baseMeta && baseMeta[0] && baseMeta[0][0]
      ? baseMeta[0][0].split(/[；;,]/)[0].replace(/^[a-z]+\.\s*/i, "").trim()
      : "";
    const parts = [];
    if (prefix) parts.push(prefix + "-（" + AFFIX_PREFIX[prefix] + "）");
    parts.push(base + (baseTrans ? "（" + baseTrans + "）" : ""));
    if (suffix) parts.push("-" + suffix + "（" + AFFIX_SUFFIX[suffix] + "）");
    return parts.join(" + ");
  }

  function localDerivatives(word) {
    const candidates = lemmaCandidates(word);
    const base = candidates[0] || word;
    const set = new Set();
    if (VOCAB && VOCAB.meta) {
      const baseLower = base.toLowerCase();
      const currentLower = word.toLowerCase();
      for (const w of Object.keys(VOCAB.meta)) {
        const wl = w.toLowerCase();
        if (wl !== currentLower && wl.includes(baseLower)) set.add(w);
      }
    }
    return [...set].sort((a, b) => a.length - b.length || a.localeCompare(b)).slice(0, 12);
  }

  function detectPos(word) {
    const trans = (wordMetaOf(word) && wordMetaOf(word)[0]) || [];
    const text = trans.join(" ");
    const pos = [];
    if (/\bn\./i.test(text)) pos.push("n");
    if (/\bv\./i.test(text)) pos.push("v");
    if (/\badj\./i.test(text)) pos.push("adj");
    if (/\badv\./i.test(text)) pos.push("adv");
    return pos;
  }

  function makeFallbackExamples(word) {
    const base = lemmaCandidates(word)[0] || word;
    const pos = detectPos(word);
    const ex = [];
    if (pos.includes("v")) {
      if (base !== word && word.toLowerCase() === base.toLowerCase() + "ing") {
        ex.push(word.charAt(0).toUpperCase() + word.slice(1) + " is good exercise.");
        ex.push("They are " + word + " together.");
      } else {
        ex.push("I often " + base + " in my free time.");
        ex.push("They " + base + " together every day.");
      }
    }
    if (pos.includes("n") && (base === word || !word.toLowerCase().endsWith("ing"))) {
      ex.push("This is a meaningful " + word + ".");
    }
    if (pos.includes("adj")) {
      ex.push("It is a " + word + " day.");
      ex.push("She looks very " + word + ".");
    }
    if (pos.includes("adv")) {
      ex.push("He did it very " + word + ".");
    }
    if (!ex.length) ex.push("Please make a sentence with \"" + word + "\".");
    return ex.slice(0, 3);
  }

  const COLLO_MAP = [
    { keys: ["玩", "游戏", "比赛"], cols: ["play games", "play with friends", "play outside", "play a match"] },
    { keys: ["演奏", "钢琴", "音乐"], cols: ["play the piano", "play the violin", "play music"] },
    { keys: ["扮演", "角色", "演出"], cols: ["play a role", "play the lead", "act in a play"] },
    { keys: ["学习"], cols: ["study hard", "study for exams", "learn by heart"] },
    { keys: ["工作"], cols: ["go to work", "work hard", "at work"] },
    { keys: ["跑", "跑步"], cols: ["go running", "run fast", "run away"] },
    { keys: ["吃"], cols: ["have a meal", "eat out", "eat up"] },
    { keys: ["走"], cols: ["go for a walk", "walk away", "walk the dog"] },
    { keys: ["说", "说话"], cols: ["speak English", "talk to sb", "say hello"] },
    { keys: ["看"], cols: ["watch TV", "see a film", "look at"] },
    { keys: ["写"], cols: ["write down", "write a letter"] }
  ];

  function makeFallbackCollocations(word) {
    const meta = wordMetaOf(word);
    const transText = (meta && meta[0] ? meta[0].join("；") : "") + " " + word;
    const cols = [];
    for (const item of COLLO_MAP) {
      for (const k of item.keys) {
        if (transText.includes(k)) { cols.push(...item.cols); break; }
      }
    }
    if (!cols.length) {
      const base = lemmaCandidates(word)[0] || word;
      const pos = detectPos(word);
      if (pos.includes("v")) { cols.push("like to " + base, "enjoy " + word); }
      else if (pos.includes("n")) { cols.push("a " + word, "the " + word); }
      else { cols.push("very " + word, "so " + word); }
    }
    return [...new Set(cols)].slice(0, 6);
  }

  function makeFallbackSynonyms(word) {
    const meta = wordMetaOf(word);
    const trans = meta && meta[0] ? meta[0][0] : "";
    if (!trans) return [];
    const segs = trans.split(/[；;,]/).map((s) => s.trim()).filter(Boolean);
    const keywords = [];
    for (const seg of segs.slice(0, 2)) {
      const m = seg.match(/[\u4e00-\u9fa5]+/g);
      if (m) keywords.push(...m);
    }
    if (!keywords.length) return [];
    const set = new Set();
    const wl = word.toLowerCase();
    if (VOCAB && VOCAB.meta) {
      for (const [w, m] of Object.entries(VOCAB.meta)) {
        if (w.toLowerCase() === wl) continue;
        const t = (m && m[0] && m[0][0]) || "";
        for (const k of keywords) {
          if (t.includes(k)) { set.add(w); break; }
        }
      }
    }
    return [...set].sort((a, b) => a.length - b.length || a.localeCompare(b)).slice(0, 8);
  }

  function renderDetail(container, data) {
    container.classList.remove("hidden");
    container.innerHTML = "";

    const wrap = document.createElement("div");
    wrap.className = "wl-detail-inner";
    wrap.addEventListener("click", onDetailClick);

    // 详细释义
    const transSec = sectionEl("详细释义");
    const transList = document.createElement("ul");
    transList.className = "wl-list";
    const trans = (data.translations || []).filter(Boolean);
    if (trans.length) {
      for (const t of trans) {
        const li = document.createElement("li");
        li.textContent = t;
        transList.appendChild(li);
      }
    } else {
      transList.innerHTML = '<li class="wl-detail-empty">暂无释义</li>';
    }
    transSec.appendChild(transList);
    wrap.appendChild(transSec);

    // 例句
    const exSec = sectionEl("例句");
    const exWrap = document.createElement("div");
    const examples = (data.examples || []).filter((e) => e && (e.en || typeof e === "string"));
    if (examples.length) {
      for (const ex of examples.slice(0, 5)) {
        const en = typeof ex === "string" ? ex : ex.en;
        const zh = typeof ex === "string" ? "" : (ex.zh || "");
        const row = document.createElement("div");
        row.className = "wl-ex";
        const enDiv = document.createElement("div");
        enDiv.className = "wl-ex-en";
        appendWordText(enDiv, en);
        row.appendChild(enDiv);
        if (zh) {
          const zhDiv = document.createElement("div");
          zhDiv.className = "wl-ex-zh";
          zhDiv.textContent = zh;
          row.appendChild(zhDiv);
        }
        exWrap.appendChild(row);
      }
    } else {
      exWrap.innerHTML = '<div class="wl-detail-empty">暂无例句</div>';
    }
    exSec.appendChild(exWrap);
    wrap.appendChild(exSec);

    // 词组搭配
    wrap.appendChild(tagSection("词组搭配", data.collocations || []));

    // 统一 rootDeriv 为对象
    const root = (typeof data.rootDeriv === "string")
      ? { root: data.rootDeriv, derivatives: [] }
      : (data.rootDeriv || { root: "", derivatives: [] });

    // 词根词缀
    const rootSec = sectionEl("词根词缀");
    if (root.root) {
      const p = document.createElement("p");
      p.className = "wl-root";
      p.textContent = root.root;
      rootSec.appendChild(p);
    } else {
      rootSec.innerHTML += '<div class="wl-detail-empty">暂无词根词缀信息</div>';
    }
    wrap.appendChild(rootSec);

    // 派生词
    const derivSec = sectionEl("派生词");
    const derivatives = (root.derivatives || []).filter(Boolean);
    if (derivatives.length) {
      const tagWrap = document.createElement("div");
      tagWrap.className = "wl-tags";
      for (const d of derivatives.slice(0, 12)) {
        const span = document.createElement("span");
        span.className = "wl-tag";
        appendWordText(span, d);
        tagWrap.appendChild(span);
      }
      derivSec.appendChild(tagWrap);
    } else {
      derivSec.innerHTML += '<div class="wl-detail-empty">暂无派生词</div>';
    }
    wrap.appendChild(derivSec);

    // 近义词
    wrap.appendChild(tagSection("近义词", data.synonyms || []));

    container.appendChild(wrap);
  }

  function renderLoading(container) {
    container.classList.remove("hidden");
    container.innerHTML = '<div class="wl-detail-inner"><div class="wl-detail-empty">加载详情中…</div></div>';
  }

  function sectionEl(title) {
    const sec = document.createElement("div");
    sec.className = "wl-sec";
    const h = document.createElement("div");
    h.className = "wl-sec-title";
    h.textContent = title;
    sec.appendChild(h);
    return sec;
  }

  function tagSection(title, items) {
    const sec = sectionEl(title);
    const wrap = document.createElement("div");
    wrap.className = "wl-tags";
    const arr = (items || []).filter(Boolean).slice(0, 12);
    if (arr.length) {
      for (const it of arr) {
        const tag = document.createElement("span");
        tag.className = "wl-tag";
        appendWordText(tag, it);
        wrap.appendChild(tag);
      }
    } else {
      wrap.innerHTML = '<div class="wl-detail-empty">暂无</div>';
    }
    sec.appendChild(wrap);
    return sec;
  }

  function appendWordText(container, text) {
    const re = /[A-Za-z][A-Za-z'’-]*/g;
    let last = 0;
    let m;
    while ((m = re.exec(text)) !== null) {
      if (m.index > last) container.appendChild(document.createTextNode(text.slice(last, m.index)));
      const span = document.createElement("span");
      span.className = "wl-word";
      span.dataset.word = m[0].toLowerCase().replace(/^[’'’-]+|[’'’-]+$/g, "");
      span.dataset.ctx = text;
      span.textContent = m[0];
      container.appendChild(span);
      last = m.index + m[0].length;
    }
    if (last < text.length) container.appendChild(document.createTextNode(text.slice(last)));
  }

  function onDetailClick(e) {
    const target = e.target.closest(".wl-word");
    if (!target) return;
    e.stopPropagation();
    const rect = target.getBoundingClientRect();
    if (typeof window.WH_SHOW_CARD === "function") {
      window.WH_SHOW_CARD(target.dataset.word, rect.left, rect.bottom, target.dataset.ctx || "");
    } else {
      showFloatCard(target.dataset.word, target);
    }
  }

  let activeFloat = null;

  function closeFloatCard() {
    if (activeFloat) {
      activeFloat.remove();
      activeFloat = null;
    }
    document.removeEventListener("click", onDocClick);
  }

  function onDocClick(e) {
    if (activeFloat && !activeFloat.contains(e.target)) closeFloatCard();
  }

  function showFloatCard(word, anchor) {
    closeFloatCard();
    const card = document.createElement("div");
    card.className = "wl-float";
    card.innerHTML = '<div class="wl-float-head">'
      + '<span class="wl-float-word"></span>'
      + '<span class="wl-float-ph"></span>'
      + '<button class="wl-float-act is-speak" title="朗读"><svg class="wl-ico" aria-hidden="true"><use href="#i-speaker"></use></svg></button>'
      + '<button class="wl-float-act is-close" title="关闭"><svg class="wl-ico" aria-hidden="true"><use href="#i-close"></use></svg></button>'
      + '</div>'
      + '<div class="wl-float-body"><span class="wl-detail-empty">加载中…</span></div>';
    card.querySelector(".wl-float-word").textContent = word;
    card.querySelector(".wl-float-act.is-speak").addEventListener("click", (e) => { e.stopPropagation(); speakFloat(word); });
    card.querySelector(".wl-float-act.is-close").addEventListener("click", (e) => { e.stopPropagation(); closeFloatCard(); });
    document.body.appendChild(card);
    activeFloat = card;
    positionFloatCard(card, anchor);
    // 延迟注册 document 关闭监听：开卡的这一次 click 事件还会继续冒泡到 document，
    // 若同步注册会被立即触发，导致卡片刚打开就被关闭（表现为"点击没反应"）
    setTimeout(() => {
      if (activeFloat === card) document.addEventListener("click", onDocClick);
    }, 0);
    fetchWordDetail(word).then((data) => renderFloatCard(card, data, anchor));
  }

  function speakFloat(word) {
    try {
      if (window.WH_TTS && window.WH_TTS.speakText) {
        window.WH_TTS.speakText(word);
        return;
      }
    } catch (e) { /* ignore */ }
    try {
      if (!("speechSynthesis" in window)) return;
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(word);
      u.lang = "en-US";
      speechSynthesis.speak(u);
    } catch (e) { /* ignore */ }
  }

  function renderFloatCard(card, data, anchor) {
    const body = card.querySelector(".wl-float-body");
    body.innerHTML = "";
    const ph = card.querySelector(".wl-float-ph");
    ph.textContent = data.phonetic || "";
    const trans = (data.translations || []).filter(Boolean).slice(0, 4);
    if (trans.length) {
      for (const t of trans) {
        const div = document.createElement("div");
        div.className = "wl-float-tr";
        div.textContent = t;
        body.appendChild(div);
      }
    } else {
      body.innerHTML = '<span class="wl-detail-empty">暂无释义</span>';
    }
    positionFloatCard(card, anchor);
  }

  function positionFloatCard(card, anchor) {
    const rect = anchor.getBoundingClientRect();
    const cardRect = card.getBoundingClientRect();
    const margin = 8;
    let top = rect.bottom + margin + window.scrollY;
    let left = rect.left + window.scrollX;
    const maxLeft = window.innerWidth - cardRect.width - margin;
    if (left > maxLeft) left = maxLeft;
    if (left < margin) left = margin;
    const maxTop = window.innerHeight + window.scrollY - cardRect.height - margin;
    if (top > maxTop) top = rect.top + window.scrollY - cardRect.height - margin;
    if (top < margin) top = margin;
    card.style.position = "absolute";
    card.style.top = top + "px";
    card.style.left = left + "px";
  }

  window.WH_DETAIL = { fetch: fetchWordDetail, render: renderDetail, loading: renderLoading };
  window.WH_DETAIL_FLOAT = { show: showFloatCard, hide: closeFloatCard };
})();
