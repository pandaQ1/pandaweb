/* Panda 生词高亮 & 翻译助手 —— 离屏 OCR 容器（v2.20.0）
 *
 *  职责（全部在本地完成，不联网）：
 *   1) WH_OFF_CROP：把整屏截图按选区裁出来，并放大 2 倍（小字号识别率提升明显）
 *   2) WH_OFF_OCR ：用 Tesseract（wasm）识别文字，worker/core/语言包全部来自扩展包内 vendor/
 *
 *  为什么放在离屏页面而不是 service worker：
 *   - tesseract.js 依赖 Worker + canvas + DOM，SW 里没有稳定可用的这些能力；
 *   - 离屏页面是普通扩展页面，CSP 允许 wasm（见 manifest 的 'wasm-unsafe-eval'）。
 */

const OCR = {
  worker: null,
  langs: "",
  creating: null,          // 正在创建 worker 的 Promise（并发保护）
  chain: Promise.resolve() // 串行队列：同一时刻只跑一次识别，避免多 worker 抢内存
};

function tessPaths() {
  return {
    workerPath: chrome.runtime.getURL("vendor/tesseract/worker.min.js"),
    corePath: chrome.runtime.getURL("vendor/tesseract/core"),
    langPath: chrome.runtime.getURL("vendor/tesseract/lang")
  };
}

/** 取得（或复用）指定语言的 worker。
 *  【v2.20.6】加并发保护：预热（WH_OFF_WARM）与正式识别（WH_OFF_OCR）可能同时到达，
 *  旧实现两者都会看到 OCR.worker 为空 → 各建一个 worker，泄漏一个（内存翻倍、语言包重复加载）。 */
async function getWorker(langs) {
  const want = langs || "eng";
  if (OCR.worker && OCR.langs === want) return OCR.worker;
  if (!OCR.creating) {
    OCR.creating = createWorker(want).finally(() => { OCR.creating = null; });
  }
  await OCR.creating;
  if (OCR.worker && OCR.langs === want) return OCR.worker;
  return getWorker(want); // 语言不同：串行重建（每次都会先 terminate 旧的）
}

async function createWorker(langs) {
  if (OCR.worker) {
    try { await OCR.worker.terminate(); } catch (e) { /* ignore */ }
    OCR.worker = null;
    OCR.langs = "";
  }
  const paths = tessPaths();
  const worker = await Tesseract.createWorker(langs, 1, {
    workerPath: paths.workerPath,
    corePath: paths.corePath,
    langPath: paths.langPath,
    workerBlobURL: false,   // 扩展内直接用 chrome-extension:// 的 worker 脚本，不能用 blob
    legacyCore: false,      // 只用 LSTM 核心（vendor 里就是 simd-lstm 版本）
    legacyLang: false,
    // 【v2.25.4】语言包改成不压缩的 *.traineddata：Edge/Chrome 商店把「包里还有压缩文件」
    // （原来的 *.traineddata.gz）判为非法程序包，直接拒绝上传。
    // 未压缩的 traineddata 在外层 zip 里同样会被 deflate，包体积几乎不变。
    gzip: false,
    errorHandler: (e) => console.error("[wh-ocr] worker error", e)
  });
  // PSM 6 = 单一均匀文本块（截图场景最稳）；保留词间空格便于按行还原
  await worker.setParameters({ tessedit_pageseg_mode: "6", preserve_interword_spaces: "1" });
  OCR.worker = worker;
  OCR.langs = langs;
  return worker;
}

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("图片解码失败"));
    img.src = url;
  });
}

/** 按视口 CSS 坐标裁剪并放大，返回 PNG data URL。
 *  【v2.20.4】pad：向外扩几个 CSS 像素再做识别——用户框选时很容易少框进
 *  每行的首/末字母（实测 "Practice" 会识别成 "ractlce"），留点余量更稳。 */
async function cropImage(imageUrl, rect, dpr, scale, pad) {
  const img = await loadImage(imageUrl);
  const ratio = Number(dpr) > 0 ? Number(dpr) : 1;
  const padCss = Number(pad) > 0 ? Number(pad) : 0;
  const iw = img.naturalWidth || img.width || 0;
  const ih = img.naturalHeight || img.height || 0;
  let sx = Math.round((rect.x - padCss) * ratio);
  let sy = Math.round((rect.y - padCss) * ratio);
  let ex = Math.round((rect.x + rect.w + padCss) * ratio);
  let ey = Math.round((rect.y + rect.h + padCss) * ratio);
  sx = Math.max(0, sx);
  sy = Math.max(0, sy);
  if (iw) ex = Math.min(iw, ex);
  if (ih) ey = Math.min(ih, ey);
  const sw = Math.max(1, ex - sx);
  const sh = Math.max(1, ey - sy);
  const up = Math.min(4, Math.max(1, Number(scale) || 1));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(sw * up));
  canvas.height = Math.max(1, Math.round(sh * up));
  const ctx = canvas.getContext("2d");
  // 先铺白底：截图若有透明像素/深色背景，白底能显著提高识别率
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/png");
}

/** 识别（串行执行） */
function recognize(imageUrl, langs) {
  const job = OCR.chain.then(async () => {
    const worker = await getWorker(langs || "eng");
    const { data } = await worker.recognize(imageUrl);
    return {
      text: String((data && data.text) || ""),
      confidence: Number((data && data.confidence) || 0)
    };
  });
  // 队列失败也要放行后续任务
  OCR.chain = job.then(() => {}, () => {});
  return job;
}

/** 反色（深色背景白字 → 白底黑字）：视频字幕、深色海报、暗色 UI 里 Tesseract 几乎读不出来 */
async function invertImage(url) {
  const img = await loadImage(url);
  const c = document.createElement("canvas");
  c.width = img.naturalWidth || img.width;
  c.height = img.naturalHeight || img.height;
  const ctx = c.getContext("2d");
  ctx.drawImage(img, 0, 0);
  try {
    const d = ctx.getImageData(0, 0, c.width, c.height);
    const p = d.data;
    for (let i = 0; i < p.length; i += 4) {
      p[i] = 255 - p[i];
      p[i + 1] = 255 - p[i + 1];
      p[i + 2] = 255 - p[i + 2];
    }
    ctx.putImageData(d, 0, 0);
  } catch (e) { /* 跨域等异常就返回原图 */ }
  return c.toDataURL("image/png");
}

const letterCount = (t) => (String(t).match(/[A-Za-z\u4e00-\u9fa5]/g) || []).length;

/** 识别一次，结果太差就反色再认一次，取更好的那个 */
async function recognizeSmart(imageUrl, langs) {
  let best = await recognize(imageUrl, langs);
  if (letterCount(best.text) >= 4 && best.confidence >= 55) return best;
  try {
    const alt = await recognize(await invertImage(imageUrl), langs);
    const better = (letterCount(alt.text) > letterCount(best.text))
      || (letterCount(alt.text) === letterCount(best.text) && alt.confidence > best.confidence);
    if (better) best = alt;
  } catch (e) { /* 反色失败就用原结果 */ }
  return best;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.__offscreen) return false; // 只处理发给离屏容器的消息
  const run = async () => {
    if (msg.type === "WH_OFF_CROP") {
      const dataUrl = await cropImage(msg.imageUrl, msg.rect, msg.dpr, msg.scale, msg.pad);
      return { ok: true, dataUrl };
    }
    if (msg.type === "WH_OFF_OCR") {
      const r = await recognizeSmart(msg.imageUrl, msg.langs);
      return { ok: true, text: r.text, confidence: r.confidence };
    }
    // 【v2.20.4】预热：只把 worker 建起来（最慢的是加载语言包），不做识别
    if (msg.type === "WH_OFF_WARM") {
      await getWorker(msg.langs || "eng");
      return { ok: true };
    }
    return { ok: false, error: "未知的离屏操作：" + String(msg.type) };
  };
  run().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
  return true; // 异步响应
});
