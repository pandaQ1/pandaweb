/* 生词高亮 & 翻译助手 —— 网页内嵌 PDF 入口浮标 v1.0.0（v2.22.0 起）
 *
 * 场景：网页里用 <iframe src="xxx.pdf"> / <embed> / <object> 嵌入 PDF（在线预览常见）。
 *   页面本身是网页，浮标能显示；但 PDF 仍在浏览器内置阅读器里渲染，取不了词。
 * 做法：检测到足够大的内嵌 PDF 时，右下角浮一个「用 Panda 打开」按钮，
 *   点击 → background 打开 pdf-reader.html?src=该 PDF 地址 → 由插件自己渲染，取词/高亮全可用。
 * 约束：只读 DOM、不改页面；没有内嵌 PDF 的页面什么都不做（不注入任何节点）。
 */
(function () {
  "use strict";
  if (window.__WH_PDF_HINT__) return;
  window.__WH_PDF_HINT__ = true;

  const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);
  if (!IS_EXT) return;
  if (document.contentType && document.contentType !== "text/html" && document.contentType !== "application/xhtml+xml") return;

  const SELECTOR = 'embed[type="application/pdf"], embed[src*=".pdf"], iframe[src*=".pdf"], object[data*=".pdf"], object[type="application/pdf"]';
  const MIN_SIZE = 240;

  let host = null;      // <div> 宿主（含 shadow root）
  let currentUrl = "";  // 当前浮标指向的 PDF
  let scanTimer = 0;

  function absolutePdfUrl(el) {
    const raw = el.getAttribute("src") || el.getAttribute("data") || "";
    if (!raw) return "";
    let url = "";
    try { url = new URL(raw, location.href).href; } catch (e) { return ""; }
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (!/\.pdf(\?|#|$)/i.test(url) && type !== "application/pdf") return "";
    return url;
  }

  function findEmbeddedPdf() {
    let els;
    try { els = document.querySelectorAll(SELECTOR); } catch (e) { return ""; }
    for (const el of els) {
      const url = absolutePdfUrl(el);
      if (!url) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width < MIN_SIZE || rect.height < MIN_SIZE) continue;
      return url;
    }
    return "";
  }

  function buildHost() {
    if (host) return host;
    host = document.createElement("div");
    host.id = "wh-pdf-hint-host";
    // 【v2.25.9】改到左下角常驻：右下角经常压着站点的客服/返回顶部按钮，左下角更空
    host.style.cssText = "all:initial;position:fixed;left:18px;bottom:18px;z-index:2147483000;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        :host { all: initial; }
        .btn {
          display: inline-flex; align-items: center; gap: 7px;
          padding: 9px 14px; border-radius: 999px; border: 1px solid rgba(24,24,27,.12);
          background: #18181b; color: #fafafa; cursor: pointer;
          font: 600 13px/1 -apple-system, "Segoe UI", "Microsoft YaHei", system-ui, sans-serif;
          box-shadow: 0 6px 20px rgba(0,0,0,.22);
          transition: transform .16s cubic-bezier(.22,1,.36,1), box-shadow .16s;
        }
        .btn:hover { transform: translateY(-1px); box-shadow: 0 10px 26px rgba(0,0,0,.28); }
        .btn:active { transform: scale(.97); }
        .dot { width: 7px; height: 7px; border-radius: 50%; background: #eab308; }
        svg { width: 15px; height: 15px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
      </style>
      <button class="btn" type="button" title="这个 PDF 由浏览器内置阅读器渲染，无法取词；用 Panda 阅读器打开即可悬停/右键查词、高亮生词">
        <span class="dot"></span>
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
        <span>用 Panda 打开此 PDF</span>
      </button>`;
    root.querySelector(".btn").addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!currentUrl) return;
      try {
        chrome.runtime.sendMessage({ type: "WH_OPEN_PDF_READER", url: currentUrl }, () => {
          void chrome.runtime.lastError; // 后台未响应时不抛错
        });
      } catch (err) { /* ignore */ }
    });
    (document.body || document.documentElement).appendChild(host);
    return host;
  }

  function hide() {
    if (host && host.parentNode) host.parentNode.removeChild(host);
    currentUrl = "";
  }

  function scan() {
    const url = findEmbeddedPdf();
    if (!url) { hide(); return; }
    if (url === currentUrl) return;
    currentUrl = url;
    buildHost();
  }

  function scheduleScan() {
    if (scanTimer) return;
    scanTimer = setTimeout(() => { scanTimer = 0; scan(); }, 400);
  }

  try {
    const mo = new MutationObserver(scheduleScan);
    const start = () => {
      scan();
      try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch (e) { /* ignore */ }
      // 兜底补扫：有的站点用定时器/异步渲染插入 iframe，MutationObserver 也未必触发齐全。
      // 只在页面刚加载的 2 分钟内低频补扫 30 次就停，避免长期占用 CPU。
      let left = 30;
      const timer = setInterval(() => {
        if (--left <= 0) clearInterval(timer);
        scan();
      }, 4000);
      window.addEventListener("resize", scheduleScan, { passive: true });
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
  } catch (e) { /* ignore */ }

  window.__WH_PDF_HINT_SCAN__ = scan;
  // 【v2.25.9】给「快捷键中心 → PDF 取词」取当前页内嵌 PDF 的地址（同一隔离世界，直接共享）
  window.__WH_PDF_HINT_GET__ = () => currentUrl || findEmbeddedPdf() || "";
})();
