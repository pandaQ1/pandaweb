/* Panda 生词高亮：在线 pdf.js viewer 的原生 Range 高亮。
 * 不向文字层插入元素，不读取 PDF 坐标，也不按字体框计算位置。
 * PDF.js 每次缩放/翻页重建 textLayer 后，重新对存活的文本节点建 Range。
 */
(() => {
  "use strict";
  const registry = { enabled: false, words: new Set(), wordbook: new Set(), ranges: [] };
  const HL_NAME = "wh-pdf-vocab";
  const WB_NAME = "wh-pdf-wordbook";
  const WORD_RE = /[A-Za-z][A-Za-z'’\-]*[A-Za-z]|[A-Za-z]/g;

  function addRanges(layer, words, predicate) {
    const walker = document.createTreeWalker(layer, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      WORD_RE.lastIndex = 0;
      let match;
      while ((match = WORD_RE.exec(node.nodeValue || ""))) {
        const word = match[0].toLowerCase();
        if (word.length < 2 || !predicate(word)) continue;
        const range = document.createRange();
        range.setStart(node, match.index);
        range.setEnd(node, match.index + match[0].length);
        words.push({ word, range });
      }
    }
  }

  /* content.js 也会在很多页面注入 .wh-highlight 标签式高亮。若 pdf.js 的文字层里被插进了这种
   * 标签，会和本脚本的 Range 高亮叠成两层（深浅不一）。这里在 Range 高亮生效时把文字层内的
   * 标签高亮透明掉，保证「一个词只有一个色块」。 */
  const NEUTRALIZE_ID = "wh-pdf-range-neutralize";
  function neutralizeTagHighlights(on) {
    const old = document.getElementById(NEUTRALIZE_ID);
    if (!on) { if (old) old.remove(); return; }
    if (old) return;
    const style = document.createElement("style");
    style.id = NEUTRALIZE_ID;
    style.textContent = ".textLayer .wh-highlight,.textLayer .wh-marked{background:transparent!important;box-shadow:none!important;}";
    (document.head || document.documentElement).appendChild(style);
  }

  function rebuild() {
    registry.ranges = [];
    if (!registry.enabled || typeof globalThis.Highlight !== "function" || !globalThis.CSS?.highlights) {
      // 关闭高亮 / 环境不支持 → 连已注册的 Range 一起清掉，不能只停在这里（否则关掉开关后色块还在）
      neutralizeTagHighlights(false);
      clear();
      return;
    }
    neutralizeTagHighlights(true);
    const vocab = [], wordbook = [];
    document.querySelectorAll(".textLayer").forEach((layer) => {
      addRanges(layer, vocab, (w) => registry.wordbook.has(w) || registry.words.has(w));
    });
    // 生词本优先于等级色：同一个 Range 只能放入其中一个 Highlight。
    const wb = vocab.filter((x) => registry.wordbook.has(x.word));
    const normal = vocab.filter((x) => !registry.wordbook.has(x.word));
    registry.ranges = vocab;
    CSS.highlights.set(HL_NAME, new Highlight(...normal.map((x) => x.range)));
    CSS.highlights.set(WB_NAME, new Highlight(...wb.map((x) => x.range)));
    window.__WH_PDF_RANGE_HL__ = { words: vocab.length, layers: document.querySelectorAll(".textLayer").length };
  }

  function clear() {
    if (globalThis.CSS?.highlights) {
      CSS.highlights.delete(HL_NAME);
      CSS.highlights.delete(WB_NAME);
    }
    registry.ranges = [];
    window.__WH_PDF_RANGE_HL__ = { words: 0, layers: 0 };
  }

  async function loadConfig() {
    if (typeof chrome === "undefined" || !chrome.storage) return;
    const sync = await chrome.storage.sync.get({ enabled: true, levels: [], level: "none", userWords: [], knownWords: [] });
    const local = await chrome.storage.local.get({ wh_wordbook: [] });
    const vocab = window.__WH_VOCAB__;
    const order = vocab?.order || [];
    const levels = Array.isArray(sync.levels) && sync.levels.length ? sync.levels : (order.includes(sync.level) ? [sync.level] : []);
    const known = new Set([...(sync.userWords || []), ...(sync.knownWords || [])].map((w) => String(w).toLowerCase()));
    registry.words.clear();
    for (const level of levels) {
      for (const word of vocab?.lists?.[level] || []) {
        if (!known.has(String(word).toLowerCase())) registry.words.add(String(word).toLowerCase());
      }
    }
    registry.wordbook = new Set((local.wh_wordbook || []).map((x) => x.word?.toLowerCase()).filter(Boolean));
    registry.enabled = !!sync.enabled;
    rebuild();
  }

  let scheduled = 0;
  function schedule() {
    clearTimeout(scheduled);
    scheduled = setTimeout(rebuild, 40);
  }

  // PDF.js 的公开事件：文本层完成后才对真实 DOM 建 Range。
  document.addEventListener("textlayerrendered", schedule, true);
  const observer = new MutationObserver((records) => {
    if (records.some((r) => r.type === "characterData" || r.addedNodes.length)) schedule();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  // viewer 的 textlayerrendered 并非所有版本都冒泡；已有文字层必须立即扫描。
  schedule();
  chrome.storage?.onChanged?.addListener(() => { loadConfig().catch(clear); });
  window.__WH_PDF_RANGE_REBUILD__ = rebuild;
  window.__WH_PDF_RANGE_RELOAD__ = () => loadConfig().catch(clear);
  loadConfig().catch(clear);
})();
