/* 生词高亮 & 翻译助手 —— 首屏主题引导（Panda M1b，必须同步引入且先于样式表）
 *
 * 为什么必须是独立的 <script> 而不是 <head> 内联脚本：
 * MV3 的扩展页 CSP 禁止内联脚本（preflight 的 csp/inline 会直接判失败），
 * 但主题属性又必须在 CSS 生效前写入，否则夜间用户会先看到一帧白屏。
 *
 * 数据来源：applyTheme() / applyPageTheme() 每次解析完主题都会把偏好镜像到
 * localStorage.wh_theme，这里同步读取镜像（chrome.storage 是异步的，赶不上首帧）。
 * 偏好三态：light | dark | auto（auto 由 prefers-color-scheme 解析成 light/dark）。
 *
 * 【v2.25.8】补三件事，彻底消掉「打开 popup / 设置页先闪一下白」：
 *   1) root.style.colorScheme —— UA 画布、滚动条、表单控件一开始就按正确明暗绘制；
 *   2) root.style.backgroundColor —— 首帧自带底色，不必等 ui-tokens.css 解析完；
 *   3) data-wh-theme-boot 标记 —— 让 CSS 能区分「已引导」与「未引导」。
 *   （闪白的另一半原因在 CSS：body 上的 background 过渡会把这次纠正画成渐变，已在样式里去掉。）
 */
(function () {
  "use strict";
  var KEY = "wh_theme";
  var pref = "auto";
  try {
    pref = window.localStorage.getItem(KEY) || "auto";
  } catch (e) {
    pref = "auto"; // 无痕/禁用 storage：退到系统偏好
  }
  if (pref !== "light" && pref !== "dark") pref = "auto";

  var systemDark = !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  var dark = pref === "dark" || (pref === "auto" && systemDark);

  var root = document.documentElement;
  var COLORS = { dark: "#0a0a0a", light: "#ffffff" };
  var paint = function (d) {
    // 内联底色是首帧兜底（样式表还没解析时不至于露出 UA 白底）
    root.style.backgroundColor = d ? COLORS.dark : COLORS.light;
    root.style.colorScheme = d ? "dark" : "light";
  };

  root.setAttribute("data-wh-theme", dark ? "dark" : "light");
  root.setAttribute("data-wh-theme-pref", pref);
  root.setAttribute("data-wh-theme-boot", "1");
  paint(dark);

  // 页面内切主题（设置页的日/夜/自动开关、popup 的主题按钮）只改 data-wh-theme，
  // 内联底色是「样式」，会盖过样式表里的 html{background-color:var(--ui-bg)} ——
  // 所以这里跟着属性一起改，否则切到深色后画布边角仍是白的。
  try {
    new MutationObserver(function () {
      paint(root.getAttribute("data-wh-theme") === "dark");
    }).observe(root, { attributes: true, attributeFilter: ["data-wh-theme"] });
  } catch (e) { /* 老浏览器没有 MutationObserver 就只保留首帧兜底 */ }

  // 系统主题在页面打开期间变化（auto 模式下）→ 跟着切，避免用户改系统设置后要重开
  try {
    if (pref === "auto" && window.matchMedia) {
      var mq = window.matchMedia("(prefers-color-scheme: dark)");
      var onChange = function (ev) {
        var d = !!ev.matches;
        root.setAttribute("data-wh-theme", d ? "dark" : "light");
        paint(d); // observer 也会做，这里顺手保证
      };
      if (mq.addEventListener) mq.addEventListener("change", onChange);
      else if (mq.addListener) mq.addListener(onChange);
    }
  } catch (e) { /* ignore */ }
})();
