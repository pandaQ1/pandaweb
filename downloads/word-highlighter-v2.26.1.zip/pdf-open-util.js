/* Panda 生词高亮 —— PDF 地址识别小工具（v2.25.1，零依赖）
 *
 * 为什么单独一个文件：
 *   「粘进来的地址到底是不是 PDF」这件事要能被单独测试（tests/check-pdf-open.mjs），
 *   否则只能靠真开浏览器去点，回归很慢。
 *
 * 提供两件事：
 *   1) looksLikePdf(bytes)          —— 嗅探 PDF 头（%PDF-），允许文件头前有少量垃圾字节
 *   2) findPdfUrlInHtml(html, url)  —— 从「网页外壳」（pdf.js viewer / 站点自建阅读器）里挖真正的 PDF 地址
 */
(function (global) {
  "use strict";

  /** 标准阅读器参数：值不一定是 .pdf 结尾（下载接口常见 /download?id=3），所以「宽松」接收 */
  const LOOSE_PARAMS = ["file", "url", "src"];
  /** 其它可疑参数：只有值里带 .pdf 才收，避免误把 /path=/home 当成 PDF */
  const STRICT_PARAMS = ["pdf", "doc", "path", "view", "download", "name"];

  /** 字节流是不是 PDF：pdf.js 认的是文件内容，不是扩展名 */
  function looksLikePdf(buf) {
    if (!buf || typeof buf.length !== "number" || buf.length < 8) return false;
    const head = buf.subarray ? buf.subarray(0, Math.min(buf.length, 1024)) : buf.slice(0, 1024);
    for (let i = 0; i + 4 < head.length; i++) {
      if (head[i] === 0x25 && head[i + 1] === 0x50 && head[i + 2] === 0x44 && head[i + 3] === 0x46 && head[i + 4] === 0x2d) {
        return true; // "%PDF-"
      }
    }
    return false;
  }

  /** 从网页外壳里找出真正的 PDF 地址（按可信度排序，去重、绝对化、排除自身） */
  function findPdfUrlInHtml(html, baseUrl) {
    const found = [];
    /**
     * @param {string} raw    候选地址（可能是相对路径 / 百分号编码）
     * @param {boolean} loose true = 来自 file=/url=/src= 参数，路径不一定以 .pdf 结尾（很多站点的下载接口不带扩展名）
     */
    const add = (raw, loose) => {
      if (!raw) return;
      let s = String(raw).trim().replace(/^["'（(<]+|["'）)>]+$/g, "");
      if (!s || /^(data|javascript|about|blob|chrome-extension):/i.test(s)) return;
      try {
        const u = new URL(s, baseUrl);
        if (!/^https?:$/i.test(u.protocol)) return;
        if (u.href === baseUrl) return;
        // 不带 .pdf 的候选只在「明确来自 file= 参数」时才收，
        // 否则像 viewer.html?file=../a.pdf 这种引号里出现的片段会被误当成 PDF 地址
        if (!loose && !/\.pdf$/i.test(u.pathname)) return;
        if (!found.includes(u.href)) found.push(u.href);
      } catch (e) { /* 不是合法地址就跳过 */ }
    };
    const text = String(html || "");

    // 1) 外壳地址自带的参数：?file= / ?url= / ?src=（pdf.js viewer 等），以及 hash 形式 #file=
    try {
      const u = new URL(baseUrl);
      for (const k of LOOSE_PARAMS) add(u.searchParams.get(k), true);
      for (const k of STRICT_PARAMS) {
        const v = u.searchParams.get(k);
        if (v && /\.pdf(\?|#|$)/i.test(v)) add(v, false);
      }
      const hash = (u.hash || "").replace(/^#/, "");
      if (hash) {
        const hp = new URLSearchParams(hash);
        for (const k of LOOSE_PARAMS) add(hp.get(k), true);
        for (const k of STRICT_PARAMS) {
          const v = hp.get(k);
          if (v && /\.pdf(\?|#|$)/i.test(v)) add(v, false);
        }
      }
    } catch (e) { /* ignore */ }

    // 2) HTML 里的 <embed src> / <iframe src> / <object data>
    const tagRe = /<(?:embed|iframe|object|frame)\b[^>]*?\b(?:src|data)\s*=\s*["']([^"']+)["']/gi;
    let m;
    while ((m = tagRe.exec(text))) add(m[1], false);

    // 3) 任意引号里以 .pdf 结尾的地址
    const pdfRe = /["'`]([^"'`<>\s]{2,}?\.pdf(?:\?[^"'`]*)?)["'`]/gi;
    while ((m = pdfRe.exec(text))) add(m[1], false);

    // 4) 内联脚本里的 file=/url= 参数（可能带百分号编码）
    const paramRe = /[?&](?:file|url|src)=([^"'\s&<>]+)/gi;
    while ((m = paramRe.exec(text))) {
      let v = m[1];
      try { v = decodeURIComponent(v); } catch (e) { /* 保持原样 */ }
      add(v, true);
    }
    return found;
  }

  /** 页面引用了哪些脚本（同源、去重、限量）：外壳的真 PDF 地址常常藏在被引用的 js 里 */
  function collectScriptSrcs(html, baseUrl, opts) {
    const limit = (opts && opts.limit) || 3;
    const base = new URL(baseUrl);
    const out = [];
    const re = /<script\b[^>]*?\bsrc\s*=\s*["']([^"']+)["']/gi;
    let m;
    while ((m = re.exec(String(html || "")))) {
      let u;
      try { u = new URL(m[1], base); } catch (e) { continue; }
      if (u.origin !== base.origin) continue; // 只读同源脚本，不拿用户地址去打第三方
      if (u.href === base.href) continue;
      if (!out.includes(u.href)) out.push(u.href);
      if (out.length >= limit) break;
    }
    return out;
  }

  /** 在一段脚本文本里找 PDF 地址（相对路径按「脚本自身地址」解析）
   *  排序：默认值类键（defaultUrl 等）→ 同源相对路径 → 同源绝对 → 其它域名
   *  为什么要排序：真实 pdf.js 的 viewer.mjs 里除了默认文件，还有 build/document.pdf 之类的无关字符串，
   *  取第一条就猜错，所以先认「默认值」，再按「离脚本越近越可信」排。 */
  function findPdfInTextRanked(text, scriptUrl) {
    const items = [];
    const add = (raw, score) => {
      if (!raw) return;
      let s = String(raw).trim().replace(/^["'`（(<]+|["'`）)>]+$/g, "");
      if (!s || /^(data|javascript|about|blob|chrome-extension):/i.test(s)) return;
      // 「viewer.html?file=x.pdf」这类是外壳地址片段，不是真的 PDF 路径 → 交给参数扫描处理
      const q = s.indexOf("?");
      const pdfAt = s.toLowerCase().indexOf(".pdf");
      if (q >= 0 && pdfAt >= 0 && q < pdfAt) return;
      try {
        const u = new URL(s, scriptUrl);
        if (!/^https?:$/i.test(u.protocol)) return;
        if (u.href === scriptUrl) return;
        let rank = score;
        if (rank == null) {
          const sameOrigin = u.origin === new URL(scriptUrl).origin;
          const relative = !/^([a-z]+:)?\/\//i.test(s);
          rank = sameOrigin ? (relative ? 1 : 2) : 3;
        }
        const i = items.findIndex((x) => x.url === u.href);
        if (i >= 0) { if (rank < items[i].score) items[i].score = rank; return; }
        items.push({ url: u.href, score: rank });
      } catch (e) { /* 跳过 */ }
    };
    const src = String(text || "");
    let m;
    // 0) 明确的「默认地址」键（defaultUrl: { value: "x.pdf" } / DEFAULT_URL = "x.pdf" 两种写法都认）
    const defRe = /(?:defaultUrl|default_url|DEFAULT_URL|defaultPdf|default_pdf|defaultFile|default_file|initialUrl|pdfUrl|pdf_url)\b[\s\S]{0,200}?["'`]([^"'`\s]{1,400}?\.pdf(?:\?[^"'`]*)?)["'`]/gi;
    while ((m = defRe.exec(src))) add(m[1], 0);
    // 1) 引号 / 反引号里的 .pdf
    const pdfRe = /["'`]([^"'`<>\s]{2,}?\.pdf(?:\?[^"'`]*)?)["'`]/gi;
    while ((m = pdfRe.exec(src))) add(m[1], null);
    // 2) 脚本里拼的参数：?file=xxx.pdf
    const paramRe = /[?&](?:file|url|src)=([^"'\s&<>]+)/gi;
    while ((m = paramRe.exec(src))) {
      let v = m[1];
      try { v = decodeURIComponent(v); } catch (e) { /* 原样 */ }
      if (/\.pdf(\?|#|$)/i.test(v)) add(v, null);
    }
    items.sort((a, b) => a.score - b.score);
    return items;
  }

  /** 同上，但只要地址（单测/简单场景用） */
  function findPdfInText(text, scriptUrl) {
    return findPdfInTextRanked(text, scriptUrl).map((x) => x.url);
  }

  /** 路径相似度：候选地址与页面地址共同前缀段越多、层级越接近，越可能是同一个 PDF */
  function pathSimilarity(candidateUrl, pageUrl) {
    try {
      const a = new URL(candidateUrl).pathname.split("/").filter(Boolean);
      const b = new URL(pageUrl).pathname.split("/").filter(Boolean);
      let common = 0;
      while (common < a.length && common < b.length && a[common] === b[common]) common++;
      return common - Math.abs(a.length - b.length) * 0.5;
    } catch (e) {
      return -99;
    }
  }

  /** 合并多个脚本的扫描结果：先去重（取最小 score），再按 score → 路径相似度排序 */
  function mergeScriptCandidates(lists, pageUrl) {
    const map = new Map();
    for (const list of lists || []) {
      for (const it of list || []) {
        const prev = map.get(it.url);
        if (!prev || it.score < prev.score) map.set(it.url, it);
      }
    }
    const arr = Array.from(map.values());
    arr.sort((a, b) => (a.score - b.score) || (pathSimilarity(b.url, pageUrl) - pathSimilarity(a.url, pageUrl)));
    return arr.map((x) => x.url);
  }

  /** 内容类型 + 前几个字节 → 人话描述（错误提示用） */
  function describeContent(contentType, htmlLike) {
    const ct = String(contentType || "").toLowerCase();
    if (ct.includes("html") || htmlLike) return "网页（HTML）";
    return "非 PDF 内容（" + (ct || "未知类型") + "）";
  }

  const API = {
    looksLikePdf, findPdfUrlInHtml, collectScriptSrcs,
    findPdfInText, findPdfInTextRanked, mergeScriptCandidates, describeContent
  };
  global.WH_PDF_OPEN = API;
  if (typeof module !== "undefined" && module.exports) module.exports = API;
})(typeof window !== "undefined" ? window : globalThis);
