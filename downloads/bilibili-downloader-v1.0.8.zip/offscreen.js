/**
 * offscreen.js —— 兼容下载通道（扩展上下文取流）
 *
 * 为什么需要它：
 *   B 站 CDN 校验 Referer，而 chrome.downloads 直接下 URL 时不带 Referer（403 SERVER_FORBIDDEN）；
 *   declarativeNetRequest 拦不到下载器的请求；内容脚本的 fetch 又受 CORS 限制
 *   （CDN 返回 403 且无 CORS 头时，页面里只能看到 "Failed to fetch"）。
 *   所以把「取流」搬到扩展自己的 offscreen 文档：host_permissions 免 CORS，
 *   DNR 规则对扩展上下文请求同样生效（自动补上 Referer），再把 Blob URL 交给下载器，
 *   这样文件名/子目录/进度都还是正常下载。
 *
 * 取流策略参考开源项目 Yuelioi/bdl（crates/bdl-core/src/fetcher.rs）：
 *   分段（Range）下载 → 每段独立重试 → 用 Content-Length / Content-Range 校验总长度。
 *   区别只在于浏览器里没有文件句柄，分段结果先拼成 Blob 再交给下载器；
 *   好处是一段网络抖动不会让整个 1 GB 重新开始，坏段只重取那一段。
 *
 * 生命周期：SW 用 chrome.offscreen.createDocument 创建；取流结束后把 Blob URL 交回 SW，
 *   由 SW 调 chrome.downloads 落盘（offscreen 文档只能访问 chrome.runtime，没有 downloads）。
 *   Blob 随文档存在，SW 在任务全部结束后关闭文档，内存随之释放。
 */
"use strict";

const MAX_BYTES = 1.5 * 1024 * 1024 * 1024; // 1.5 GB 以上不再缓冲到内存
const CHUNK_BYTES = 8 * 1024 * 1024;        // 分段大小：太小请求多，太大重试代价高
const RETRIES = 3;                          // 每段重试次数（bdl 默认 max_retries = 3）
const PROGRESS_MS = 400;                    // 进度上报节流

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.target !== "offscreen" || msg.type !== "SAVE_BLOB") return;
  // 只接受扩展自身的页面 / service worker 调用。网页里的内容脚本同样能把消息
  // 广播到本文档，不能让它们借扩展的主机权限去取任意地址（来自标签页的 sender 一定带 tab）。
  if (sender && sender.tab) {
    sendResponse({ ok: false, error: "SAVE_BLOB 只接受扩展内部调用" });
    return true;
  }
  handle(msg.payload || {})
    .then(function (r) { sendResponse(r); })
    .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) || String(e) }); });
  return true;
});

function sleep(ms) {
  return new Promise(function (r) { setTimeout(r, ms); });
}

function fmtSize(n) {
  const v = Number(n) || 0;
  if (v >= 1024 * 1024 * 1024) return (v / 1024 / 1024 / 1024).toFixed(2) + " GB";
  if (v >= 1024 * 1024) return (v / 1024 / 1024).toFixed(1) + " MB";
  if (v >= 1024) return Math.round(v / 1024) + " KB";
  return v + " B";
}

/** 把 HTTP 状态翻成用户能看懂、并且能指导下一步的说法 */
function httpError(status) {
  if (status === 403) return "资源被拒绝（HTTP 403）：链接可能已过期，请重新解析";
  if (status === 404) return "资源不存在（HTTP 404）：链接可能已过期，请重新解析";
  if (status === 412) return "被 B 站风控拦截（HTTP 412）：稍后重试，或减少同时下载数";
  if (status === 429) return "请求过于频繁（HTTP 429）：稍等一会儿再试";
  if (status === 416) return "分段越界（HTTP 416），请重新解析";
  if (status >= 500) return "CDN 暂时不可用（HTTP " + status + "），稍后重试";
  return "资源请求失败 HTTP " + status;
}

/**
 * 探测 CDN 是否支持 Range，以及文件总长度。
 * Range 是 CORS 安全列表成员，扩展上下文又有 host_permissions，不会被预检挡住。
 */
async function probe(url) {
  const r = await fetch(url, {
    headers: { Range: "bytes=0-0" },
    credentials: "include",
    cache: "no-store"
  });
  const cr = r.headers.get("content-range") || "";
  const m = /\/(\d+)\s*$/.exec(cr);
  const size = m ? Number(m[1]) : Number(r.headers.get("content-length") || 0);
  const ranges = r.status === 206 && !!m && size > 0;
  try { if (r.body && r.body.cancel) await r.body.cancel(); } catch (e) { /* ignore */ }
  if (!r.ok && r.status !== 206) throw new Error(httpError(r.status));
  return { ranges: ranges, size: size };
}

/** 取一段；每段独立重试，并校验长度，长度不符就当作坏段重取（bdl 的 fetcher 也是这么做的） */
async function fetchRange(url, start, end, index) {
  const want = end - start + 1;
  let lastErr = null;
  for (let attempt = 0; attempt < RETRIES; attempt++) {
    if (attempt) await sleep(400 * Math.pow(2, attempt - 1));
    try {
      const r = await fetch(url, {
        headers: { Range: "bytes=" + start + "-" + end },
        credentials: "include",
        cache: "no-store"
      });
      if (!r.ok && r.status !== 206) throw new Error(httpError(r.status));
      const buf = await r.arrayBuffer();
      if (buf.byteLength !== want) {
        throw new Error("分段 " + index + " 长度不符（" + buf.byteLength + " / " + want + "）");
      }
      return buf;
    } catch (e) {
      lastErr = e;
    }
  }
  throw new Error("分段 " + index + " 下载失败：" + ((lastErr && lastErr.message) || "未知错误"));
}

/** 取整个文件：能分段就分段取，取完校验总长度 */
async function fetchStream(url, onProgress) {
  const info = await probe(url);
  if (info.size > MAX_BYTES) {
    throw new Error("文件 " + fmtSize(info.size) + " 超过 1.5 GB，请改用「仅直连」或降低清晰度");
  }
  if (onProgress) onProgress(0, info.size);

  if (info.ranges && info.size > CHUNK_BYTES) {
    const total = info.size;
    const parts = [];
    let received = 0;
    let index = 0;
    for (let start = 0; start < total; start += CHUNK_BYTES) {
      index++;
      const end = Math.min(start + CHUNK_BYTES, total) - 1;
      const buf = await fetchRange(url, start, end, index);
      parts.push(buf);
      received += buf.byteLength;
      if (onProgress) onProgress(received, total);
    }
    const blob = new Blob(parts);
    if (blob.size !== total) {
      throw new Error("文件不完整：应有 " + total + " 字节（" + fmtSize(total) + "），实际 " + blob.size + " 字节");
    }
    return { blob: blob, total: total };
  }

  // CDN 不支持 Range（或文件很小）：整体取，但仍然重试 + 校验长度
  let lastErr = null;
  for (let attempt = 0; attempt < RETRIES; attempt++) {
    if (attempt) await sleep(400 * Math.pow(2, attempt - 1));
    try {
      const r = await fetch(url, { credentials: "include", cache: "no-store" });
      if (!r.ok) throw new Error(httpError(r.status));
      const blob = await r.blob();
      if (!blob.size) throw new Error("取到的内容为空，链接可能已过期，请重新解析");
      if (info.size && blob.size !== info.size) {
        throw new Error("文件不完整：应有 " + info.size + " 字节（" + fmtSize(info.size) + "），实际 " + blob.size + " 字节");
      }
      if (onProgress) onProgress(blob.size, info.size || blob.size);
      return { blob: blob, total: info.size || blob.size };
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("取流失败");
}

/** 清洗成安全相对路径：按 / 分段处理，保留子目录（下载器支持 "文件夹/文件.mp4"） */
function safePath(p) {
  const raw = String(p || "bili-download").replace(/\\/g, "/");
  const parts = raw.split("/").filter(function (s) { return s && s !== "." && s !== ".."; });
  const out = parts.map(function (seg) {
    const s = seg
      .replace(/[:*?"<>|]/g, "_")
      .replace(/[\u0000-\u001f]/g, "")
      .replace(/^\.+/, "")
      .replace(/[. ]+$/, "")
      .slice(0, 120);
    return s || "bili-download";
  });
  return out.join("/") || "bili-download";
}

async function handle(p) {
  const url = String(p.url || "");
  if (!url) throw new Error("缺少资源地址");

  const filename = safePath(p.filename);

  // SW 用这个文件名把进度写回任务卡
  let lastSent = 0;
  const onProgress = function (received, total) {
    const t = Date.now();
    if (received && total && received < total && t - lastSent < PROGRESS_MS) return;
    lastSent = t;
    try {
      chrome.runtime.sendMessage({
        type: "PM_SAVE_PROGRESS",
        payload: { filename: filename, received: received || 0, total: total || 0 }
      }).catch(function () { /* SW 可能正在重启，进度丢了不影响下载 */ });
    } catch (e) { /* ignore */ }
  };

  const got = await fetchStream(url, onProgress);
  const type = p.mime || got.blob.type || "application/octet-stream";
  const blob = new Blob([got.blob], { type: type });

  // 注意：offscreen 文档只能访问 chrome.runtime，没有 chrome.downloads。
  // 所以这里只把字节变成「可下载的临时地址」，真正的 downloads.download 由 service worker 发起。
  // Blob URL 的生命周期跟随本文档：文档开着就一直有效（SW 复制到磁盘是本地操作，很快），
  // 文档关闭时内存自动释放。
  const objUrl = makeObjectUrl(blob);
  if (objUrl) return { ok: true, blobUrl: objUrl, bytes: got.total || blob.size };

  // 没有 createObjectURL 的极端环境：小文件退回 data URL
  const dataUrl = await toDataUrl(blob, type);
  return { ok: true, dataUrl: dataUrl, bytes: got.total || blob.size };
}

function makeObjectUrl(blob) {
  try {
    if (typeof URL === "undefined" || typeof URL.createObjectURL !== "function") return "";
    return URL.createObjectURL(blob);
  } catch (e) {
    return "";
  }
}

/** 兜底：把 Blob 编成 data URL（只允许小文件，避免把几十 MB 的字符串塞进消息通道） */
async function toDataUrl(blob, type) {
  if (blob.size > 48 * 1024 * 1024) {
    throw new Error("当前环境不支持 createObjectURL，且文件超过 48 MB，无法转交下载器");
  }
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = "";
  const CH = 0x8000;
  for (let i = 0; i < buf.length; i += CH) {
    bin += String.fromCharCode.apply(null, buf.subarray(i, i + CH));
  }
  return "data:" + (type || "application/octet-stream") + ";base64," + btoa(bin);
}
