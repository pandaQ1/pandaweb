/**
 * bili.js —— B 站接口层（运行在内容脚本里，复用当前页面登录态）
 *
 * 为什么放在内容脚本：
 *   playurl / view 等接口要求携带用户 Cookie（SESSDATA）与 B 站页面来源。
 *   内容脚本运行在 bilibili.com 页面里，fetch 同源/同站请求自动带上 Cookie，
 *   并且扩展声明了 host_permissions，跨源请求不受 CORS 限制；
 *   service worker 里 fetch 拿不到站点 Cookie，只能解析到 480P，所以统一走这里。
 *
 * 对外暴露 PM_BILI：
 *   parseTarget()                        → { kind, bvid, p, epId, ssId }
 *   getVideoInfo()                       → 归一化的视频信息（含分P列表）
 *   getPlayurl({ bvid, cid, epId, qn })  → 归一化清晰度/流地址
 *   getDanmakuXml(cid)                   → 弹幕 XML 文本
 *   qualityLabel(qn) / qualityCatalogue()
 *   FREE_MAX_QN / PRO_ONLY_HINT
 */
"use strict";

var PM_BILI = (function () {
  var API = "https://api.bilibili.com";
  var FREE_MAX_QN = 64; // 免费用户上限：720P

  var QN_TEXT = {
    6: "240P", 16: "360P", 32: "480P", 64: "720P", 74: "720P60",
    80: "1080P", 112: "1080P+", 116: "1080P60", 120: "4K", 125: "HDR", 126: "杜比视界", 127: "8K"
  };

  function qualityLabel(qn) {
    return QN_TEXT[qn] || ("QN " + qn);
  }

  /* ============================ MD5（WBI 签名用） ============================ */
  /** RFC1321 的 K 表是常量，模块加载时算一次；以前每次 md5() 都重算 64 次 sin。 */
  var MD5_K = (function () {
    var k = [];
    for (var i = 0; i < 64; i++) k.push(Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296));
    return k;
  })();

  /** 标准 RFC1321 实现，输入字符串按 UTF-8 编码。 */
  function md5(input) {
    var K = MD5_K;
    var S = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
      5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
      4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
      6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    var i;

    function rotl(x, c) { return (x << c) | (x >>> (32 - c)); }

    /* UTF-8 编码 */
    var bytes = [];
    for (i = 0; i < input.length; i++) {
      var c = input.charCodeAt(i);
      if (c < 0x80) bytes.push(c);
      else if (c < 0x800) bytes.push(0xc0 | (c >> 6), 0x80 | (c & 63));
      else if (c < 0xd800 || c >= 0xe000) {
        bytes.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
      } else {
        i++;
        var c2 = input.charCodeAt(i);
        var cp = 0x10000 + (((c & 0x3ff) << 10) | (c2 & 0x3ff));
        bytes.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 63), 0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63));
      }
    }

    var bitLen = bytes.length * 8;
    bytes.push(0x80);
    while (bytes.length % 64 !== 56) bytes.push(0);
    var lo = bitLen >>> 0;
    var hi = Math.floor(bitLen / 4294967296);
    for (i = 0; i < 4; i++) bytes.push((lo >>> (8 * i)) & 0xff);
    for (i = 0; i < 4; i++) bytes.push((hi >>> (8 * i)) & 0xff);

    var a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
    for (var off = 0; off < bytes.length; off += 64) {
      var M = [];
      for (i = 0; i < 16; i++) {
        M[i] = bytes[off + i * 4] | (bytes[off + i * 4 + 1] << 8) |
          (bytes[off + i * 4 + 2] << 16) | (bytes[off + i * 4 + 3] << 24);
      }
      var A = a0, B = b0, C = c0, D = d0;
      for (i = 0; i < 64; i++) {
        var F, g;
        if (i < 16) { F = (B & C) | (~B & D); g = i; }
        else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
        else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; }
        else { F = C ^ (B | ~D); g = (7 * i) % 16; }
        var tmp = D;
        D = C;
        C = B;
        var sum = (A + F + K[i] + M[g]) | 0;
        B = (B + rotl(sum, S[i])) | 0;
        A = tmp;
      }
      a0 = (a0 + A) | 0;
      b0 = (b0 + B) | 0;
      c0 = (c0 + C) | 0;
      d0 = (d0 + D) | 0;
    }
    function hex(x) {
      var s = "";
      for (var j = 0; j < 4; j++) s += ("0" + (((x >>> (j * 8)) & 0xff).toString(16))).slice(-2);
      return s;
    }
    return hex(a0) + hex(b0) + hex(c0) + hex(d0);
  }

  /* ============================ WBI 签名 ============================ */
  var MIXIN_TAB = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52];

  var wbiKeys = null; // { imgKey, subKey, at }

  function mixinKey(orig) {
    var arr = [];
    for (var i = 0; i < MIXIN_TAB.length; i++) arr.push(orig[MIXIN_TAB[i]]);
    return arr.join("").slice(0, 32);
  }

  async function getWbiKeys() {
    if (wbiKeys && Date.now() - wbiKeys.at < 6 * 3600 * 1000) return wbiKeys;
    var r = await fetch(API + "/x/web-interface/nav", { credentials: "include" });
    var j = await r.json();
    var img = j && j.data && j.data.wbi_img;
    if (!img || !img.img_url || !img.sub_url) throw new Error("WBI 密钥获取失败，请刷新页面后重试");
    var k = {
      imgKey: img.img_url.split("/").pop().split(".")[0],
      subKey: img.sub_url.split("/").pop().split(".")[0],
      at: Date.now()
    };
    wbiKeys = k;
    return k;
  }

  /** 生成带 w_rid / wts 的查询串 */
  async function wbiQuery(params) {
    var k = await getWbiKeys();
    var mix = mixinKey(k.imgKey + k.subKey);
    var p = Object.assign({}, params, { wts: Math.round(Date.now() / 1000) });
    var parts = Object.keys(p).sort().map(function (key) {
      // B 站要求过滤值里的 ! ' ( ) * 字符
      var v = String(p[key]).replace(/[!'()*]/g, "");
      return encodeURIComponent(key) + "=" + encodeURIComponent(v);
    });
    var query = parts.join("&");
    return query + "&w_rid=" + md5(query + mix);
  }

  /* ============================ 基础请求 ============================ */
  async function apiGet(url) {
    var r = await fetch(url, { credentials: "include" });
    if (!r.ok) throw new Error("B 站接口返回 HTTP " + r.status);
    var j = await r.json();
    if (!j) throw new Error("B 站接口无响应，请稍后重试");
    var code = j.code;
    if (code === 0 || code === undefined || code === null) return j;
    if (code === -101) throw new Error("B 站账号未登录，只能获取较低清晰度");
    if (code === -352) throw new Error("B 站风控校验失败，请刷新页面或稍后再试");
    if (code === -404) throw new Error("视频不存在或已失效");
    if (code === -403) throw new Error("没有权限获取该视频（可能是充电专属或付费内容）");
    if (code === -10403) throw new Error("该清晰度需要 B 站大会员");
    throw new Error(j.message || j.msg || ("B 站接口返回 code " + code));
  }

  /* ============================ 页面目标解析 ============================ */
  function parseTarget() {
    var raw = location.href;
    var u;
    try { u = new URL(raw); } catch (e) { u = null; }
    var out = { kind: "video", bvid: "", p: 1, epId: "", ssId: "" };
    if (!u) return out;

    var bv = u.pathname.match(/\/video\/(BV[0-9A-Za-z]+)/);
    if (bv) out.bvid = bv[1];
    if (!out.bvid) {
      var q = u.searchParams.get("bvid") || "";
      if (/^BV[0-9A-Za-z]+$/.test(q)) out.bvid = q;
    }
    if (!out.bvid) {
      // 兜底：从 og:url / canonical 里找 BV 号
      var meta = document.querySelector('meta[property="og:url"]');
      var canon = document.querySelector('link[rel="canonical"]');
      var ref = (meta && meta.content) || (canon && canon.href) || "";
      var m2 = String(ref).match(/(BV[0-9A-Za-z]+)/);
      if (m2) out.bvid = m2[1];
    }
    out.p = Math.max(1, Number(u.searchParams.get("p") || 1) || 1);

    var ep = u.pathname.match(/\/bangumi\/play\/(ep\d+)/);
    var epQ = u.searchParams.get("ep_id") || "";
    var ss = u.pathname.match(/\/bangumi\/play\/ss(\d+)/);
    var ssQ = u.searchParams.get("season_id") || "";
    if (ep) { out.kind = "bangumi"; out.epId = ep[1]; }
    else if (/^ep\d+$/.test(epQ)) { out.kind = "bangumi"; out.epId = epQ; }
    else if (ss) { out.kind = "bangumi"; out.ssId = ss[1]; }
    else if (/^\d+$/.test(ssQ)) { out.kind = "bangumi"; out.ssId = ssQ; }
    return out;
  }

  /* ============================ 视频信息 ============================ */
  function fmtDuration(sec) {
    var s = Math.max(0, Math.round(Number(sec) || 0));
    var h = Math.floor(s / 3600);
    var m = Math.floor((s % 3600) / 60);
    var ss = s % 60;
    var mm = h ? String(m).padStart(2, "0") : String(m);
    return (h ? h + ":" : "") + mm + ":" + String(ss).padStart(2, "0");
  }

  async function getVideoInfo() {
    var t = parseTarget();
    if (t.kind === "bangumi") return getBangumiInfo(t);
    if (!t.bvid) throw new Error("未识别到视频号，请打开具体的视频播放页");
    var j = await apiGet(API + "/x/web-interface/view?bvid=" + encodeURIComponent(t.bvid));
    var d = j.data || {};
    var pages = (d.pages || []).map(function (p) {
      return { cid: p.cid, page: p.page, part: p.part || "P" + p.page, duration: p.duration };
    });
    var idx = Math.min(Math.max(0, t.p - 1), Math.max(0, pages.length - 1));
    var cur = pages[idx] || { cid: d.cid, page: 1, part: d.title, duration: d.duration };
    return {
      kind: "video",
      bvid: d.bvid || t.bvid,
      aid: d.aid,
      cid: cur.cid,
      title: d.title || document.title,
      up: (d.owner && d.owner.name) || "",
      cover: d.pic || "",
      duration: d.duration || cur.duration || 0,
      durationText: fmtDuration(d.duration || cur.duration || 0),
      pages: pages,
      currentPage: cur.page,
      currentPart: cur.part,
      url: location.href
    };
  }

  async function getBangumiInfo(t) {
    var epId = t.epId;
    var j = await apiGet(API + "/pgc/view/web/season?" + (epId
      ? "ep_id=" + encodeURIComponent(epId.replace(/\D/g, ""))
      : "season_id=" + encodeURIComponent(t.ssId)));
    var d = j.result || {};
    var eps = (d.episodes || []).map(function (e) {
      return {
        cid: e.cid,
        page: e.ep || e.id,
        part: e.share_copy || e.title || ("EP" + (e.ep || "")),
        duration: e.duration ? Math.round(e.duration / 1000) : 0,
        epId: e.id,
        badge: e.badge || ""
      };
    });
    if (!eps.length) throw new Error("未取到番剧剧集信息");
    var cur = eps[0];
    if (epId) {
      var target = eps.find(function (e) { return "ep" + e.epId === epId || String(e.epId) === epId.replace(/\D/g, ""); });
      if (target) cur = target;
    }
    return {
      kind: "bangumi",
      bvid: "",
      epId: cur.epId,
      cid: cur.cid,
      title: (d.title || "") + (cur.part ? " · " + cur.part : ""),
      up: (d.up_info && d.up_info.uname) || "",
      cover: d.cover || "",
      duration: cur.duration,
      durationText: fmtDuration(cur.duration),
      pages: eps.map(function (e) { return { cid: e.cid, page: e.page, part: e.part, duration: e.duration, epId: e.epId }; }),
      currentPage: cur.page,
      currentPart: cur.part,
      url: location.href
    };
  }

  /* ============================ 播放地址 ============================ */

  /** 统一升到 https：http 资源在 https 页面/扩展里会被当作不安全下载拦掉 */
  function httpsUrl(u) {
    var s = String(u || "");
    return s.replace(/^http:\/\//i, "https://");
  }

  function pickVideoStream(dash, qn) {
    var list = ((dash && dash.video) || []).filter(function (v) { return Number(v.id) <= qn; });
    if (!list.length) return null;
    var bestId = Math.max.apply(null, list.map(function (v) { return Number(v.id); }));
    var same = list.filter(function (v) { return Number(v.id) === bestId; });
    var avc = same.filter(function (v) { return /^avc1/i.test(v.codecs || ""); });
    var pool = avc.length ? avc : same;
    pool.sort(function (a, b) { return (b.bandwidth || 0) - (a.bandwidth || 0); });
    var v = pool[0];
    return {
      url: httpsUrl(v.baseUrl || v.base_url || ""),
      backups: (v.backupUrl || v.backup_url || []).map(httpsUrl),
      qn: Number(v.id),
      codecs: v.codecs || "",
      width: v.width || 0,
      height: v.height || 0,
      bandwidth: v.bandwidth || 0,
      mime: v.mimeType || ""
    };
  }

  /** 音轨：优先普通音轨里码率最高的 AAC（兼容性最好，ffmpeg/播放器都认）；
   *  只有普通音轨缺失时才退到杜比 / 无损 FLAC —— bdl 默认偏好无损，但它自带 ffmpeg 混流，
   *  这里输出的是分离文件，AAC 才不会让用户卡在混流这一步。 */
  function audioOf(a, label) {
    return {
      url: httpsUrl(a.baseUrl || a.base_url || ""),
      backups: (a.backupUrl || a.backup_url || []).map(httpsUrl),
      id: a.id,
      codecs: a.codecs || "",
      bandwidth: a.bandwidth || 0,
      label: label || ""
    };
  }

  function pickAudioStream(dash) {
    if (!dash) return null;
    var list = (dash.audio || []).slice();
    if (list.length) {
      list.sort(function (a, b) { return (b.bandwidth || 0) - (a.bandwidth || 0); });
      var best = list[0];
      var label = best.id === 30280 ? "192K" : best.id === 30232 ? "132K" : best.id === 30216 ? "64K" : "";
      return audioOf(best, label);
    }
    var dolby = ((dash.dolby && dash.dolby.audio) || [])[0];
    if (dolby && (dolby.baseUrl || dolby.base_url)) return audioOf(dolby, "杜比全景声");
    var flac = dash.flac && dash.flac.audio;
    if (flac && (flac.baseUrl || flac.base_url)) return audioOf(flac, "Hi-Res 无损");
    return null;
  }

  function formatsFromPlayurl(d) {
    var seen = {};
    var out = [];
    var push = function (qn, label) {
      if (!qn || seen[qn]) return;
      seen[qn] = 1;
      out.push({ qn: Number(qn), label: label || qualityLabel(qn), pro: Number(qn) > FREE_MAX_QN });
    };
    ((d && d.support_formats) || []).forEach(function (f) {
      var label = (f.new_description || f.display_desc || qualityLabel(f.quality)).trim();
      // superscript 常常和 description 重复（"1080P 60帧" + "60帧"）：只补没出现过的
      if (f.superscript && label.indexOf(f.superscript) < 0) label += " " + f.superscript;
      label = label.replace(/(\S+)(\s+\1)+/g, "$1"); // 再去一次重复词
      push(f.quality, label);
    });
    if (!out.length) {
      ((d && d.accept_quality) || []).forEach(function (q) { push(q); });
    }
    out.sort(function (a, b) { return b.qn - a.qn; });
    return out;
  }

  /**
   * 获取播放地址。
   * media = "dash"（音视频分离，全清晰度）| "mp4"（单文件，清晰度较低）
   */
  async function getPlayurl(opts) {
    var o = opts || {};
    var qn = Number(o.qn || 80);
    var media = o.media === "mp4" ? "mp4" : "dash";
    var fnval = media === "mp4" ? 1 : 4048;
    var extra = media === "mp4" ? "&fourk=0" : "&fourk=1&high_quality=1";
    var isPgc = !!(o.epId || o.kind === "bangumi");
    var base = isPgc ? "https://api.bilibili.com/pgc/player/wbi/playurl" : API + "/x/player/wbi/playurl";
    var params = isPgc
      ? { ep_id: String(o.epId || "").replace(/\D/g, ""), qn: qn, fnval: fnval, fnver: 0 }
      : { bvid: o.bvid, cid: o.cid, qn: qn, fnval: fnval, fnver: 0 };
    if (!isPgc && !params.bvid) throw new Error("缺少视频号");

    var query = await wbiQuery(params);
    var j = await apiGet(base + "?" + query + extra);
    var d = isPgc ? (j.result || {}) : (j.data || {});
    if (!d || (!d.dash && !d.durl)) {
      // WBI 版本偶发失败：退回不带签名的旧接口再试一次（老接口仍可用）
      var legacyBase = isPgc
        ? "https://api.bilibili.com/pgc/player/web/playurl"
        : API + "/x/player/playurl";
      var legacyParams = Object.keys(params).map(function (k) {
        return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]);
      }).join("&");
      var j2 = await apiGet(legacyBase + "?" + legacyParams + extra);
      d = isPgc ? (j2.result || {}) : (j2.data || {});
    }
    if (!d) throw new Error("未能获取播放地址，请确认已登录 B 站并刷新页面");

    var result = {
      qn: qn,
      media: media,
      formats: formatsFromPlayurl(d),
      video: null,
      audio: null,
      single: null,
      acceptQuality: d.accept_quality || []
    };

    if (media === "mp4") {
      var durl = d.durl || [];
      if (durl.length) {
        result.single = {
          url: httpsUrl(durl[0].url),
          backups: (durl[0].backup_url || durl[0].backupUrl || []).map(httpsUrl),
          size: durl[0].size || 0
        };
      }
      result.formats = [{ qn: Number(d.quality || qn), label: qualityLabel(d.quality || qn) + " · 单文件", pro: false }];
    } else {
      result.video = pickVideoStream(d.dash, qn);
      result.audio = pickAudioStream(d.dash);
      if (!result.video) throw new Error("该视频没有可用的视频流（可能受版权或清晰度限制）");
    }
    return result;
  }

  /* ============================ 弹幕 ============================ */
  async function getDanmakuXml(cid) {
    if (!cid) throw new Error("缺少 cid");
    var r = await fetch("https://comment.bilibili.com/" + cid + ".xml", { credentials: "include" });
    if (!r.ok) throw new Error("弹幕接口返回 HTTP " + r.status);
    var text = await r.text();
    if (!text || text.indexOf("<i>") < 0) throw new Error("没有取到弹幕内容");
    return text;
  }

  return {
    FREE_MAX_QN: FREE_MAX_QN,
    qualityLabel: qualityLabel,
    parseTarget: parseTarget,
    getVideoInfo: getVideoInfo,
    getPlayurl: getPlayurl,
    getDanmakuXml: getDanmakuXml,
    fmtDuration: fmtDuration,
    md5: md5
  };
})();

if (typeof globalThis !== "undefined") globalThis.PM_BILI = PM_BILI;
