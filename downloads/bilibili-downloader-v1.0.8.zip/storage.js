/**
 * storage.js —— 统一存储封装（Panda 下载器）
 *
 * 键名前缀 bili_，默认值全部集中在 PM_DEFAULTS：
 *   · 设置走 chrome.storage.sync（跨设备同步，不含任何凭证）
 *   · 任务历史 / 会员快照 / 额度计数走 chrome.storage.local（本地、可丢弃）
 *
 * service worker（importScripts）与各页面（<script>）共用同一份实现，
 * 因此同时挂到 globalThis 与 window（两者在扩展页面里是同一个对象）。
 */
"use strict";

var PM_DEFAULTS = {
  /* 下载 */
  quality: 80,                 // 默认清晰度 qn：64=720P 80=1080P 112=1080P+ 120=4K
  mode: "auto",                // auto=先直连，被拒自动转兼容保存；direct=仅直连；page=仅兼容保存（扩展内取流）
  media: "dash",               // dash=音视频分离；mp4=单文件（清晰度较低）
  saveCover: false,            // 下载完成后顺带保存封面
  saveDanmaku: false,          // 下载完成后顺带保存弹幕 XML（PRO）
  /* 文件 */
  folder: "B站下载",            // 保存子目录（相对浏览器下载目录）
  filename: "{title}-{quality}", // 文件名模板
  /* 页面 */
  floatBtn: true,              // 视频页右下角浮按钮
  maxParallel: 2,              // 批量下载并发
  /* 主题（与 theme.js 共用同一个键） */
  theme: "auto"                // light | dark | auto
};

var PM_STORAGE = (function () {
  var hasSync = typeof chrome !== "undefined" && !!(chrome.storage && chrome.storage.sync);
  var hasLocal = typeof chrome !== "undefined" && !!(chrome.storage && chrome.storage.local);
  var mem = Object.assign({}, PM_DEFAULTS); // 无扩展环境（预览）时的内存兜底

  function pick(raw) {
    var out = Object.assign({}, PM_DEFAULTS);
    if (raw && typeof raw === "object") {
      Object.keys(PM_DEFAULTS).forEach(function (k) {
        if (raw[k] !== undefined && raw[k] !== null) out[k] = raw[k];
      });
    }
    return out;
  }

  /** 读取全部设置（已合并默认值） */
  async function getSettings() {
    if (!hasSync) return Object.assign({}, mem);
    try {
      var all = await chrome.storage.sync.get(PM_DEFAULTS);
      return pick(all);
    } catch (e) {
      return Object.assign({}, mem);
    }
  }

  /** 读写单个设置项；写入后广播（页面无需刷新） */
  async function setSetting(key, value) {
    mem[key] = value;
    if (!hasSync) return;
    try {
      var patch = {};
      patch[key] = value;
      await chrome.storage.sync.set(patch);
    } catch (e) { /* 配额/隐私模式：忽略 */ }
  }

  async function setSettings(patch) {
    Object.assign(mem, patch || {});
    if (!hasSync) return;
    try { await chrome.storage.sync.set(patch || {}); } catch (e) { /* ignore */ }
  }

  /* ---------- 本地（历史 / 快照） ---------- */
  async function getLocal(key, dflt) {
    if (!hasLocal) return dflt;
    try {
      var o = await chrome.storage.local.get(key);
      return o && o[key] !== undefined ? o[key] : dflt;
    } catch (e) {
      return dflt;
    }
  }

  async function setLocal(key, value) {
    if (!hasLocal) return;
    try {
      var patch = {};
      patch[key] = value;
      await chrome.storage.local.set(patch);
    } catch (e) { /* ignore */ }
  }

  /* ---------- 任务历史 ---------- */
  var TASK_KEY = "bili_tasks";
  var TASK_LIMIT = 80;

  async function getTasks() {
    var list = await getLocal(TASK_KEY, []);
    return Array.isArray(list) ? list : [];
  }

  async function saveTasks(list) {
    var arr = (list || []).slice(0, TASK_LIMIT);
    await setLocal(TASK_KEY, arr);
    return arr;
  }

  /* 任务写入串行化。
   * 存储里只有一份「全量任务列表」，每次改动都是「读全量 → 改一条 → 写全量」。
   * 两个下载进度事件几乎同时到达时，两次读改写会交错：后写的那次拿着旧快照，
   * 把前一次刚写进去的进度/状态覆盖回去（丢更新）。所有写操作排进同一条链，
   * 让读改写变成原子操作，顺带减少 storage.local 的并发写入。 */
  var taskChain = Promise.resolve();

  function queueTaskWrite(fn) {
    var run = taskChain.then(fn);
    // 单次失败不能卡死整条链
    taskChain = run.then(function () { }, function () { });
    return run;
  }

  /** 新增或更新一条任务（按 id 合并） */
  function upsertTask(task) {
    if (!task || !task.id) return Promise.resolve(null);
    return queueTaskWrite(async function () {
      var list = await getTasks();
      var i = -1;
      for (var k = 0; k < list.length; k++) {
        if (list[k] && list[k].id === task.id) { i = k; break; }
      }
      // upd：最近一次写入时间。收敛僵尸任务时用它判断「还活着」，
      // 用创建时间 at 会把长时间下载误判成中断。
      if (i >= 0) list[i] = Object.assign({}, list[i], task, { upd: Date.now() });
      else list.unshift(Object.assign({}, task, { upd: Date.now() }));
      await saveTasks(list);
      return list;
    });
  }

  /**
   * 原子读改写：mutator(list) 在锁内拿到最新列表、**原地修改**，
   * 返回 false 表示这次不改（不写回，省一次 storage 写入）。
   * 进度事件、僵尸任务收敛都用它——只包住写入是不够的，
   * 「读快照 → 在快照上改 → 写回」跨了 await 就会被并发事件覆盖。
   */
  function updateTasks(mutator) {
    return queueTaskWrite(async function () {
      var list = await getTasks();
      var keep = await mutator(list);
      if (keep !== false) await saveTasks(list);
      return list;
    });
  }

  function removeTask(id) {
    return queueTaskWrite(async function () {
      var list = await getTasks();
      await saveTasks(list.filter(function (t) { return t && t.id !== id; }));
    });
  }

  function clearTasks() {
    return queueTaskWrite(function () {
      return saveTasks([]);
    });
  }

  return {
    DEFAULTS: PM_DEFAULTS,
    getSettings: getSettings,
    setSetting: setSetting,
    setSettings: setSettings,
    getLocal: getLocal,
    setLocal: setLocal,
    getTasks: getTasks,
    saveTasks: saveTasks,
    upsertTask: upsertTask,
    updateTasks: updateTasks,
    removeTask: removeTask,
    clearTasks: clearTasks
  };
})();

if (typeof globalThis !== "undefined") globalThis.PM_STORAGE = PM_STORAGE;
if (typeof window !== "undefined") window.PM_STORAGE = PM_STORAGE;
