/**
 * account.js —— 账号页（Panda 登录系统）
 * 依赖：auth_util.js（WHAuth）+ limits.js（WH_LIMITS）+ options.css 骨架
 */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));
  const show = (el, on) => el && el.classList.toggle("hidden", !on);

  function say(el, text, kind) {
    if (!el) return;
    el.textContent = text || "";
    el.classList.remove("err", "ok");
    if (kind) el.classList.add(kind);
  }

  const fmtDate = (v) => {
    if (!v) return "";
    const t = typeof v === "number" ? v : Date.parse(v);
    if (!Number.isFinite(t)) return "";
    const d = new Date(t);
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  };

  function isPro(m) {
    if (!m || !m.signed_in || !m.pro) return false;
    if (!m.expires_at) return true;
    const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
    return Number.isFinite(t) && t > Date.now();
  }

  let busy = false;
  const setBusy = (on) => {
    busy = on;
    $$("button").forEach((b) => { if (b.dataset.tab || b.dataset.pane) return; b.disabled = on; });
  };

  /** 让 service worker 立刻重取会员快照：它缓存 60 秒，
   *  登录/退出/兑换后不刷新的话，弹窗与页面浮层会在 1 分钟内还显示旧档位。 */
  async function syncBackground() {
    try { await chrome.runtime.sendMessage({ type: "PM_REFRESH_AUTH" }); } catch (e) { /* ignore */ }
  }

  /* ---------------- 额度（与 background 同一 key / 同一份配置） ---------------- */
  try {
    WH_LIMITS.init({
      key: "bili_limits",
      accountUrl: "account.html",
      showModal: false,
      features: {
        download: { free: 3, unit: "个视频/天", label: "视频下载" },
        batch: { free: 0, unit: "次/天", label: "P 全集批量下载" },
        danmaku: { free: 0, unit: "个/天", label: "弹幕下载" }
      }
    });
  } catch (e) { /* ignore */ }

  async function renderQuota(pro) {
    const box = $("#quotaList");
    if (!box) return;
    let st = null;
    try { st = await WH_LIMITS.stats(); } catch (e) { st = null; }
    box.innerHTML = "";
    if (!st || !st.features) {
      box.appendChild(row("额度读取失败，请刷新页面", "", false));
      return;
    }
    Object.keys(st.features).forEach((k) => {
      const f = st.features[k];
      const val = pro ? "不限" : (f.free < 0 ? "不限" : f.used + " / " + f.free);
      box.appendChild(row(f.label, val, pro || f.free < 0 || f.allowed));
    });
  }

  function row(name, num, ok) {
    const d = document.createElement("div");
    d.className = "quota-row";
    const n = document.createElement("span");
    n.className = "q-name";
    n.textContent = name || "";
    const v = document.createElement("span");
    v.className = "q-num";
    v.textContent = num || "";
    if (!ok && num) v.style.color = "var(--ui-danger)";
    d.appendChild(n);
    v && d.appendChild(v);
    return d;
  }

  /* ---------------- 导航 ---------------- */
  function showPane(name) {
    $$(".pane").forEach((p) => p.classList.toggle("active", p.id === "pane-" + name));
    $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.pane === name));
    if (name === "plan") render();
  }
  $$(".nav-item").forEach((b) => {
    if (!b.dataset.pane) return;
    b.addEventListener("click", () => showPane(b.dataset.pane));
  });
  $("#btnBackOptions").addEventListener("click", () => {
    location.href = "options.html";
  });

  /* ---------------- 渲染 ---------------- */
  async function render() {
    const sess = await WHAuth.peekSession().catch(() => null);
    const signed = !!(sess && sess.signed_in);
    show($("#signed"), signed);
    show($("#guest"), !signed);

    const chip = $("#navAcctChip");
    if (chip) chip.textContent = signed ? "已登录" : "未登录";

    if (!signed) {
      $("#planBadge").className = "acct-badge free";
      $("#planBadge").textContent = "FREE";
      $("#planExpiry").textContent = "—";
      await renderQuota(false);
      return;
    }

    const email = (sess.user && sess.user.email) || "(未知邮箱)";
    if ($("#whoEmail")) $("#whoEmail").textContent = email;

    let m = null;
    try { m = await WHAuth.getMembership(); } catch (e) { m = null; }
    const pro = isPro(m);
    if ($("#whoPlan")) {
      $("#whoPlan").textContent = pro
        ? (m && m.expires_at ? "PRO 会员 · 有效期至 " + fmtDate(m.expires_at) : "PRO 会员")
        : (m && m.offline ? "免费用户（离线，联网后自动校验）" : "免费用户（每天 3 个视频 · 最高 720P）");
    }
    [$("#whoBadge"), $("#planBadge")].forEach((el) => {
      if (!el) return;
      el.className = "acct-badge" + (pro ? "" : " free");
      el.textContent = pro ? "PRO" : "FREE";
    });
    $("#planExpiry").textContent = pro && m && m.expires_at ? fmtDate(m.expires_at) : "—";
    if (chip) chip.className = "nav-chip" + (pro ? " pro" : " on");
    if (chip) chip.textContent = pro ? "PRO" : "已登录";
    await renderQuota(pro);
  }

  /* ---------------- 标签页 ---------------- */
  $$(".tabs button").forEach((btn) => {
    btn.addEventListener("click", () => {
      $$(".tabs button").forEach((b) => b.classList.toggle("on", b === btn));
      const tab = btn.dataset.tab;
      show($("#formLogin"), tab === "login");
      show($("#formSignup"), tab === "signup");
      show($("#formReset"), tab === "reset");
    });
  });

  /* ---------------- 登录 / 注册 / 找回 ---------------- */
  $("#formLogin").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (busy) return;
    const msg = $("#msgLogin");
    setBusy(true);
    say(msg, "登录中…");
    try {
      await WHAuth.signIn($("#loginEmail").value, $("#loginPassword").value);
      say(msg, "");
      await syncBackground();
      await render();
      if ($("#signed").classList.contains("hidden")) say(msg, "登录失败：未拿到会话", "err");
    } catch (err) {
      say(msg, err.message || "登录失败", "err");
    } finally { setBusy(false); }
  });

  $("#formSignup").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (busy) return;
    const msg = $("#msgSignup");
    setBusy(true);
    say(msg, "注册中…");
    try {
      const r = await WHAuth.signUp($("#signupEmail").value, $("#signupPassword").value);
      if (r && r.needConfirm) say(msg, "注册成功，请到邮箱确认后再登录", "ok");
      else { say(msg, "注册成功，已登录", "ok"); await syncBackground(); await render(); }
    } catch (err) {
      say(msg, err.message || "注册失败", "err");
    } finally { setBusy(false); }
  });

  $("#formReset").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (busy) return;
    const msg = $("#msgReset");
    setBusy(true);
    try {
      const step2 = $("#resetStep2");
      if (step2 && !step2.classList.contains("hidden")) {
        say(msg, "重设中…");
        await WHAuth.verifyRecoveryCode($("#resetEmail").value, $("#resetCode").value);
        await WHAuth.setNewPassword($("#resetPassword").value);
        say(msg, "密码已重设，请用新密码登录", "ok");
        show($("#resetStep2"), false);
        show($("#resetStep1"), true);
      } else {
        say(msg, "发送中…");
        await WHAuth.requestPasswordReset($("#resetEmail").value);
        say(msg, "验证码已发送，请查收邮箱", "ok");
        show($("#resetStep1"), false);
        show($("#resetStep2"), true);
      }
    } catch (err) {
      say(msg, err.message || "操作失败", "err");
    } finally { setBusy(false); }
  });

  /* ---------------- 兑换 / 刷新 / 退出 ---------------- */
  $("#btnRedeem").addEventListener("click", async () => {
    if (busy) return;
    const msg = $("#msgSigned");
    const code = ($("#redeem").value || "").trim();
    if (!code) { say(msg, "请输入兑换码", "err"); return; }
    setBusy(true);
    say(msg, "兑换中…");
    try {
      const r = await WHAuth.redeemCode(code);
      say(msg, "兑换成功！PRO 有效期至 " + fmtDate(r && r.expires_at), "ok");
      $("#redeem").value = "";
      await syncBackground();
      await render();
    } catch (err) {
      say(msg, err.message || "兑换失败", "err");
    } finally { setBusy(false); }
  });

  $("#btnRefresh").addEventListener("click", async () => {
    say($("#msgSigned"), "刷新中…");
    await syncBackground();
    await render();
    say($("#msgSigned"), "已刷新", "ok");
  });

  $("#btnSignOut").addEventListener("click", async () => {
    setBusy(true);
    try { await WHAuth.signOut(); } catch (e) { /* ignore */ }
    await syncBackground();
    setBusy(false);
    await render();
    say($("#msgLogin"), "已退出登录");
  });

  /* ---------------- 主题 / 版本 ---------------- */
  try {
    WHTheme.init({ storageKey: "theme", fallback: "auto" });
    WHTheme.onChange((theme, pref) => {
      try { localStorage.setItem("bili_theme", pref); } catch (e) { /* ignore */ }
    });
  } catch (e) { /* ignore */ }

  try {
    const ver = chrome.runtime.getManifest().version;
    $("#appVer").textContent = "v" + ver;
  } catch (e) { /* ignore */ }

  /* ---------------- 跨页同步 ---------------- */
  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && (changes.bili_auth || changes.bili_limits)) render().catch(() => {});
    });
  }

  render().catch(() => {});
})();
