/**
 * background.js —— service worker（MV3）
 *
 * 职责：
 *   · 消息中枢：popup / 页面浮层 / 任务页 / 设置页 ←→ 内容脚本
 *   · 下载编排：名额校验（免费额度 / PRO）→ 生成文件名 → chrome.downloads 落盘
 *   · 任务历史：chip 级进度写进 chrome.storage.local，任务页与浮层共享
 *   · 账号：复用 Panda 登录系统（auth_util.js），定时刷新会员快照
 *
 * 注意：MV3 的 service worker 会被随时回收，所以不在内存里保存关键状态，
 * 任务进度一律落 chrome.storage.local（见 storage.js）。
 */
importScripts("auth_util.js", "limits.js", "storage.js");

const FREE_MAX_QN = 64; // 免费用户可下载的最高清晰度：720P
const TASK_THROTTLE_MS = 800;

WH_LIMITS.init({
  key: "bili_limits",
  accountUrl: "account.html",
  showModal: false,                    // 升级提示由各界面用 Panda 卡片自己画
  proFree: true,
  features: {
    download: { free: 3, unit: "个视频/天", label: "视频下载" },
    batch: { free: 0, unit: "次/天", label: "P 全集批量下载" },
    danmaku: { free: 0, unit: "个/天", label: "弹幕下载" }
  }
});

/* ============================== 小工具 ============================== */
const now = () => Date.now();
const uid = () => "t" + now().toString(36) + Math.random().toString(36).slice(2, 7);

function isProSnapshot(m) {
  if (!m || !m.signed_in || !m.pro) return false;
  if (!m.expires_at) return true;
  const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
  return Number.isFinite(t) && t > now();
}

async function getMembership(force) {
  const cached = await PM_STORAGE.getLocal("bili_membership", null);
  if (!force && cached && cached.__at && now() - cached.__at < 60_000) return cached;
  let m;
  try {
    m = await WHAuth.getMembership();
  } catch (e) {
    m = cached || { signed_in: false, pro: false, plan: "free", reason: "无法连接账号服务" };
  }
  const snap = Object.assign({}, m, { __at: now(), pro: isProSnapshot(m) });
  await PM_STORAGE.setLocal("bili_membership", snap);
  return snap;
}

/* ============================== 文件名 ============================== */
function sanitize(s, max) {
  return String(s || "")
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max || 100);
}

/** 本地日期（YYYY-MM-DD）：toISOString() 是 UTC，东八区 0-8 点会写成前一天 */
function localDate() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
}

function buildBaseName(settings, task) {
  const tpl = settings.filename || "{title}-{quality}";
  const map = {
    title: sanitize(task.title || "video", 70),
    part: sanitize(task.part || "", 40),
    quality: sanitize(task.quality || String(task.qn || ""), 20),
    bvid: task.bvid || "",
    up: sanitize(task.up || "", 30),
    page: String(task.page || 1),
    date: localDate()
  };
  let name = tpl;
  for (const k of Object.keys(map)) name = name.split("{" + k + "}").join(map[k]);
  name = sanitize(name, 110);
  // 模板里没用到的占位（例如封面/弹幕传了空 quality）会留下 "标题-封面-" 这样的尾巴
  name = name.replace(/[-_\s]+$/, "");
  return name || map.title;
}

function buildPath(settings, task, suffix) {
  const folder = String(settings.folder || "").split("/").map((s) => sanitize(s, 40)).filter(Boolean).join("/");
  const base = buildBaseName(settings, task) + (suffix || "");
  return (folder ? folder + "/" : "") + base;
}

/* ============================== 内容脚本通信 ============================== */
async function injectInto(tabId) {
  try {
    await chrome.scripting.insertCSS({ target: { tabId }, files: ["inpage.css", "inpage-panel.css"] });
  } catch (e) { /* 已注入或页面不支持：忽略 */ }
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["bili.js", "content.js"] });
  } catch (e) { /* 忽略 */ }
}

async function askTab(tabId, msg, allowRetry) {
  if (!tabId) throw new Error("没有可用的 B 站页面");
  try {
    const r = await chrome.tabs.sendMessage(tabId, msg);
    if (r) return r;
    throw new Error("页面未响应");
  } catch (e) {
    if (allowRetry === false) throw new Error("无法与页面通信，请刷新 B 站页面后重试");
    await injectInto(tabId);
    await new Promise((r) => setTimeout(r, 300));
    try {
      return await chrome.tabs.sendMessage(tabId, msg);
    } catch (e2) {
      throw new Error("无法与页面通信，请刷新 B 站页面后重试");
    }
  }
}

async function activeTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs[0] ? tabs[0] : null;
}

function isBiliUrl(url) {
  return /^https:\/\/www\.bilibili\.com\/(video|list|bangumi\/play|medialist\/play)\//.test(String(url || ""));
}

/* ============================== 下载编排 ============================== */
const dlThrottle = new Map(); // downloadId → 上次写入时间（仅用于节流，丢了也无害）

function ffmpegCommand(videoFile, audioFile, outFile) {
  const q = (s) => '"' + String(s || "").replace(/"/g, "") + '"';
  return "ffmpeg -i " + q(videoFile) + " -i " + q(audioFile) + " -c copy " + q(outFile);
}

async function touchTask(id, patch) {
  return PM_STORAGE.upsertTask(Object.assign({ id }, patch));
}

/* ---------- 两条下载通道 ----------
 * 通道 A（直连）：chrome.downloads.download(url)。
 *   B 站 CDN 校验 Referer，而下载器发出的请求不带 Referer，
 *   且 declarativeNetRequest 拦不到 chrome.downloads 的请求 → 常见 SERVER_FORBIDDEN。
 * 通道 B（扩展内取流，兼容）：offscreen 文档里 fetch（扩展上下文不受 CORS 限制，
 *   DNR 也能补上 Referer）→ Blob → chrome.downloads.download(blobURL)。
 *   为什么不在内容脚本里 fetch：Chrome 85+ 后内容脚本请求受 CORS 约束，
 *   CDN 返回 403 时浏览器直接把它变成 "Failed to fetch"，拿不到状态也补不了 Referer。
 *
 * 策略：auto = 先试直连，被打断就用 B 通道重下，并记住这个 CDN 主机（24h 内直接走 B）。
 */
const DL_ERR_TEXT = {
  NETWORK_FAILED: "网络错误",
  NETWORK_TIMEOUT: "网络超时",
  NETWORK_INVALID_REQUEST: "CDN 拒绝了直连请求（缺少 Referer）",
  SERVER_FORBIDDEN: "服务器拒绝访问（缺少 Referer）",
  SERVER_UNAUTHORIZED: "未授权，链接可能已过期",
  SERVER_FAILED: "服务器错误",
  SERVER_BAD_CONTENT: "返回内容无效",
  SERVER_NO_RANGE: "服务器不支持分块下载",
  SERVER_UNREACHABLE: "网站无法访问",
  FILE_NO_SPACE: "磁盘空间不足",
  FILE_ACCESS_DENIED: "没有写入权限",
  FILE_NAME_TOO_LONG: "文件名过长",
  USER_CANCELED: "已取消"
};

function dlErrorText(code) {
  if (!code) return "下载中断";
  return DL_ERR_TEXT[code] || ("下载中断（" + code + "）");
}

const MIME_BY_ROLE = { video: "video/mp4", audio: "audio/mp4", mp4: "video/mp4", xml: "application/xml" };

function hostOf(url) {
  try { return new URL(url).host; } catch (e) { return ""; }
}

/* ---------- 记住「这个 CDN 直连不行」，避免每次都先失败一次 ---------- */
const DIRECT_BLOCK_TTL = 24 * 3600 * 1000;

async function getBlockedHosts() {
  const map = (await PM_STORAGE.getLocal("bili_direct_blocked", null)) || {};
  const out = {};
  Object.keys(map).forEach((h) => {
    if (now() - Number(map[h] || 0) < DIRECT_BLOCK_TTL) out[h] = map[h];
  });
  return out;
}

async function markDirectBlocked(url) {
  const host = hostOf(url);
  if (!host) return;
  try {
    const map = (await PM_STORAGE.getLocal("bili_direct_blocked", null)) || {};
    map[host] = now();
    await PM_STORAGE.setLocal("bili_direct_blocked", map);
  } catch (e) { /* ignore */ }
}

/* ---------- offscreen：在扩展上下文里取流 ---------- */
let offscreenCreating = null;

/** offscreen 文档地址：用扩展根拼绝对路径。
 *  该文档由浏览器自己加载，网页永远不能直接请求它，因此不需要（也不应该）写进 web_accessible_resources。 */
function offscreenDocUrl() {
  try {
    return new URL("offscreen.html", chrome.runtime.getURL("")).href;
  } catch (e) {
    return "offscreen.html";
  }
}

async function ensureOffscreen() {
  if (!chrome.offscreen || !chrome.offscreen.createDocument) {
    throw new Error("当前浏览器不支持兼容保存（需要 Chrome/Edge 109+）");
  }
  try {
    if (chrome.runtime.getContexts) {
      const ctxs = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
      if (ctxs && ctxs.length) return;
    }
  } catch (e) { /* 老版本没有 getContexts：继续走 createDocument */ }

  if (offscreenCreating) return offscreenCreating;
  const opts = {
    reasons: ["BLOBS"],
    justification: "在扩展上下文里获取 B 站 CDN 媒体流并生成本地文件（页面内 fetch 会被 CORS 与 Referer 校验拦住）"
  };
  offscreenCreating = chrome.offscreen.createDocument(Object.assign({ url: offscreenDocUrl() }, opts))
    .catch((e) => {
      const msg = String((e && e.message) || e);
      if (/single offscreen|already exists/i.test(msg)) return;
      throw e;
    })
    .finally(() => { offscreenCreating = null; });
  return offscreenCreating;
}

/** 通道 B：扩展内取流 → 拿到 Blob URL → 由 SW 交给下载器（保留子目录与进度）
 *  为什么不在 offscreen 里直接下载：offscreen 文档只有 chrome.runtime 可用，
 *  chrome.downloads / chrome.offscreen 都不存在（1.0.5 在这里踩坑，报的是
 *  "Cannot read properties of undefined (reading 'download')"）。 */
async function saveViaOffscreen(url, filename, mime) {
  await ensureOffscreen();
  const r = await chrome.runtime.sendMessage({
    target: "offscreen",
    type: "SAVE_BLOB",
    payload: { url: url, filename: String(filename || "bili-download"), mime: mime || "" }
  });
  if (!r || !r.ok) throw new Error((r && r.error) || "兼容保存失败");

  const tempUrl = r.blobUrl || r.dataUrl;
  if (!tempUrl) throw new Error("兼容保存失败：没有拿到可下载的临时地址");

  let id;
  try {
    id = await chrome.downloads.download({
      url: tempUrl,
      filename: String(filename || "bili-download"),
      conflictAction: "uniquify",
      saveAs: false
    });
  } catch (e) {
    throw new Error("临时文件转交下载器失败：" + ((e && e.message) || e));
  }
  return { downloadId: id, startUrl: url, bytes: r.bytes || 0, fallback: true };
}

/** 兼容保存的取流进度（offscreen → SW）：还没进入浏览器下载阶段时才写，避免覆盖真实进度 */
async function onSaveProgress(p) {
  const filename = String((p && p.filename) || "");
  if (!filename) return;
  const received = Math.max(0, Number((p && p.received) || 0));
  const total = Math.max(0, Number((p && p.total) || 0));
  if (!received && !total) return;

  await PM_STORAGE.updateTasks((list) => {
    const task = list.find((t) => t && t.status === "downloading" &&
      (t.files || []).some((f) => f && f.filename === filename));
    if (!task) return false;
    const file = task.files.find((f) => f && f.filename === filename);
    if (!file) return false;
    // downloadId 一旦出现，进度就交给 chrome.downloads.onChanged
    if (file.downloadId && file.state === "in_progress") return false;
    if (file.bytes === received && (!total || file.total === total)) return false;
    file.bytes = received;
    if (total) file.total = total;
    task.upd = now();
    return true;
  });
}

/* ---------- 解析节奏（参考 bdl 的 ResolveGate：接口之间留间隔，风控就停） ---------- */
const RESOLVE_INTERVAL_MS = 600;

let lastResolveAt = 0;

async function paceResolve() {
  const wait = RESOLVE_INTERVAL_MS - (now() - lastResolveAt);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastResolveAt = now();
}

/** 是不是被风控/限流拦了：这种错重试没有意义，继续请求只会更糟 */
function isRiskControl(text) {
  const s = String(text || "");
  return /-352|-412|-509|-799|(^|\D)(412|429)(\D|$)|风控|验证码|验证|captcha|too many requests/i.test(s);
}

/** 没有进行中的任务时关掉 offscreen 文档，避免长期占一个渲染进程 */
async function maybeCloseOffscreen() {
  if (!chrome.offscreen || !chrome.offscreen.closeDocument) return;
  try {
    const tasks = await PM_STORAGE.getTasks();
    if (tasks.some((t) => t && t.status === "downloading")) return;
    const ctxs = chrome.runtime.getContexts
      ? await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] })
      : [];
    if (!ctxs || !ctxs.length) return;
    await chrome.offscreen.closeDocument();
  } catch (e) { /* ignore */ }
}

async function startOneDownload(task, stream, role, filename) {
  const settings = task.settings || (await PM_STORAGE.getSettings());
  const targets = [stream.url].concat(stream.backups || []).filter(Boolean);
  const mime = MIME_BY_ROLE[role] || "application/octet-stream";
  const blocked = await getBlockedHosts();
  let lastErr = null;

  // 通道 A：直连（跳过已被证明会被拒的 CDN 主机）
  if (settings.mode !== "page") {
    for (let i = 0; i < targets.length; i++) {
      const url = targets[i];
      if (blocked[hostOf(url)]) continue;
      try {
        const id = await chrome.downloads.download({
          url,
          filename,
          conflictAction: "uniquify",
          saveAs: false
        });
        return { downloadId: id, startUrl: url };
      } catch (e) {
        lastErr = e;
      }
    }
  }

  // 通道 B：扩展内取流
  if (settings.mode !== "direct") {
    for (let i = 0; i < targets.length; i++) {
      try {
        const res = await saveViaOffscreen(targets[i], filename, mime);
        return res;
      } catch (e) {
        lastErr = e;
      }
    }
  }

  throw lastErr || new Error("创建下载失败：直连被 CDN 拒绝，兼容保存也不可用");
}

/** 回填可能早于任务写入的进度事件：downloads.search 只用于校正状态，不做轮询 */
async function reconcileFiles(files) {
  const ids = (files || []).map((f) => f.downloadId).filter(Boolean);
  if (!ids.length) return files;
  try {
    const all = await chrome.downloads.search({});
    (files || []).forEach((f) => {
      const d = (all || []).find((x) => x.id === f.downloadId);
      if (!d) return;
      f.state = d.state || f.state;
      f.bytes = d.bytesReceived || 0;
      f.total = d.totalBytes || 0;
      if (d.state === "complete" && d.filename) f.finalPath = d.filename;
      if (d.error) f.error = dlErrorText(d.error);
    });
  } catch (e) { /* 查询失败就保持原状态，后续 onChanged 仍会补上 */ }
  return files;
}

async function enqueueStreamTask(base, streams, kindLabel) {
  const settings = await PM_STORAGE.getSettings();
  const task = Object.assign({ id: uid(), at: now(), status: "downloading", files: [] }, base, { settings });
  task.quality = task.quality || kindLabel || "";
  await PM_STORAGE.upsertTask({
    id: task.id, at: task.at, title: task.title, part: task.part, page: task.page,
    up: task.up, bvid: task.bvid, epId: task.epId, cid: task.cid, tabId: task.tabId || 0,
    qn: task.qn, quality: task.quality, media: task.media,
    status: "downloading", files: [], error: "", ffmpeg: ""
  });

  const created = [];
  try {
    for (const s of streams) {
      const filename = buildPath(settings, task, s.suffix);
      // 先落库再取流：兼容通道取流可能要几十秒，任务卡从第一秒就能看到进度
      const rec = {
        downloadId: 0,
        role: s.role,
        filename,
        startUrl: "",
        state: "preparing",
        bytes: 0,
        total: 0,
        fallback: false,
        retried: false
      };
      created.push(rec);
      await PM_STORAGE.upsertTask({ id: task.id, files: created.slice() });

      const res = await startOneDownload(task, s.stream, s.role, filename);
      rec.downloadId = res.downloadId;
      rec.startUrl = res.startUrl || "";
      rec.state = "in_progress";
      rec.fallback = !!res.fallback;
      rec.bytes = res.bytes || 0;
      await PM_STORAGE.upsertTask({ id: task.id, files: created.slice() });
    }
  } catch (e) {
    await PM_STORAGE.upsertTask({
      id: task.id, status: "error", error: (e && e.message) || "下载失败", files: created
    });
    return { ok: false, id: task.id, error: (e && e.message) || "下载失败" };
  }

  const patch = { id: task.id, files: created };
  if (streams.length === 2) {
    patch.ffmpeg = ffmpegCommand(created[0].filename.split("/").pop(), created[1].filename.split("/").pop(),
      buildBaseName(settings, task) + ".mp4");
  }
  await reconcileFiles(created);
  patch.status = created.every((f) => f.state === "complete") ? "done"
    : created.some((f) => f.state === "interrupted") ? "error" : "downloading";
  if (patch.status === "error") {
    patch.error = created.filter((f) => f.state === "interrupted").map((f) => f.error || "下载中断").join("；");
  }
  await PM_STORAGE.upsertTask(patch);
  return { ok: true, id: task.id, fallback: created.every((f) => f.fallback) };
}

/* ---------- 单视频下载 ---------- */
async function handleDownload(payload, sender) {
  if (!payload || typeof payload !== "object") return { ok: false, error: "参数缺失" };
  const settings = await PM_STORAGE.getSettings();
  const membership = await getMembership();
  const pro = isProSnapshot(membership);
  const qn = Number(payload.qn || 0);

  /* 先把流校验完再扣额度：单文件流缺失 / 视频流缺失属于「参数不可用」，
   * 扣掉一次免费额度却什么都没下载到，用户会白丢当天的名额。 */
  const pu = payload.playurl || {};
  let streams = [];
  if (payload.media === "mp4") {
    if (!pu.single || !pu.single.url) return { ok: false, error: "单文件流不可用，请改用「音视频分离」" };
    streams = [{ role: "mp4", stream: pu.single, suffix: ".mp4" }];
  } else {
    if (!pu.video || !pu.video.url) return { ok: false, error: "视频流不可用，请重新解析" };
    streams = [{ role: "video", stream: pu.video, suffix: ".mp4" }];
    if (pu.audio && pu.audio.url) streams.push({ role: "audio", stream: pu.audio, suffix: ".m4a" });
  }

  if (!pro && qn > FREE_MAX_QN) {
    return { ok: false, reason: "quality", error: "该清晰度需要 PRO 会员（免费最高 720P）" };
  }
  if (!pro) {
    const r = await WH_LIMITS.consume("download", 1);
    if (!r.allowed) {
      return {
        ok: false,
        reason: "quota",
        error: "今日免费额度已用完（" + r.free + " " + r.unit + "），激活 PRO 不限次数"
      };
    }
  }

  const tabId = (payload.tabId || (sender && sender.tab && sender.tab.id)) || null;
  const base = {
    bvid: payload.bvid || "",
    epId: payload.epId || "",
    cid: payload.cid || "",
    title: payload.title || "B站视频",
    part: payload.part || "",
    page: payload.page || 1,
    up: payload.up || "",
    cover: payload.cover || "",
    qn: qn,
    quality: payload.quality || String(qn),
    media: payload.media === "mp4" ? "mp4" : "dash",
    tabId: tabId
  };

  const r = await enqueueStreamTask(base, streams, base.quality);

  // 封面 / 弹幕（可选，失败不影响主任务）
  if (settings.saveCover && base.cover) {
    saveCoverFile(base.cover, base.title).catch(() => {});
  }
  if (settings.saveDanmaku && base.cid) {
    saveDanmakuFile(base.cid, base.title).catch(() => {});
  }
  return r;
}

/* ---------- P 全集批量（PRO） ---------- */
async function handleBatch(payload, sender) {
  const batch = await WH_LIMITS.check("batch");
  if (!batch.allowed) {
    return { ok: false, reason: "pro", error: "P 全集批量下载是 PRO 功能" };
  }
  const settings = await PM_STORAGE.getSettings();
  const tabId = (payload && payload.tabId) || (sender && sender.tab && sender.tab.id) || null;
  const pages = (payload && payload.pages) || [];
  if (!pages.length) return { ok: false, error: "没有可下载的分 P" };
  if (pages.length > 30) return { ok: false, error: "一次最多 30 个分 P" };

  const maxParallel = Math.max(1, Math.min(4, Number(settings.maxParallel) || 2));
  let started = 0;
  let failed = 0;

  // 第一步：按节奏逐个解析（解析接口最容易触发风控，bdl 也是串行 + 500ms 间隔）
  const resolved = [];
  let riskStopped = false;
  for (const p of pages) {
    await paceResolve();
    try {
      const r = await askTab(tabId, {
        type: "BILI_PLAYURL",
        options: { qn: payload.qn, media: "dash", page: p.page }
      }, false);
      if (!r || !r.ok) {
        failed++;
        if (isRiskControl(r && r.error)) { riskStopped = true; break; }
        continue;
      }
      resolved.push({ page: p, playurl: r.data });
    } catch (e) {
      failed++;
      if (isRiskControl(e && e.message)) { riskStopped = true; break; }
    }
  }

  // 第二步：解析结果按并发上限开下载（传输不再压在解析节奏上）
  for (let i = 0; i < resolved.length; i += maxParallel) {
    const slice = resolved.slice(i, i + maxParallel);
    await Promise.all(slice.map(async (item) => {
      const p = item.page;
      try {
        const res = await handleDownload(Object.assign({
          bvid: payload.bvid,
          cid: p.cid,
          title: payload.title,
          part: p.part,
          page: p.page,
          up: payload.up,
          cover: payload.cover,
          qn: payload.qn,
          quality: payload.quality,
          media: "dash",
          playurl: item.playurl,
          tabId: tabId
        }));
        if (res.ok) started++; else failed++;
      } catch (e) {
        failed++;
      }
    }));
  }

  if (riskStopped) {
    return {
      ok: started > 0,
      started,
      failed,
      total: pages.length,
      error: "触发 B 站风控（-352/412），已停止后续解析。" + (started ? "已开始 " + started + " 个，" : "") + "过几分钟再试"
    };
  }
  return { ok: started > 0, started, failed, total: pages.length, error: failed ? failed + " 个分 P 失败" : "" };
}

/* ---------- 封面 / 弹幕 ---------- */
async function saveCoverFile(url, title) {
  const settings = await PM_STORAGE.getSettings();
  const ext = /\.png(\?|$)/i.test(url) ? ".png" : ".jpg";
  // MIME 跟着扩展名走：写死 image/jpeg 会让 .png 封面按错误类型落盘
  const mime = ext === ".png" ? "image/png" : "image/jpeg";
  const filename = buildPath(settings, {
    title: (title || "cover") + "-封面", quality: "", bvid: "", part: "", up: "", page: 1
  }, ext);
  const res = await saveViaOffscreen(url, filename, mime);
  return { ok: true, downloadId: res.downloadId };
}

async function saveDanmakuFile(cid, title) {
  const check = await WH_LIMITS.check("danmaku");
  if (!check.allowed) throw new Error("弹幕下载是 PRO 功能");
  if (!cid) throw new Error("缺少 cid");
  await WH_LIMITS.consume("danmaku", 1);
  const settings = await PM_STORAGE.getSettings();
  const filename = buildPath(settings, {
    title: (title || "弹幕") + "-弹幕", quality: "", bvid: "", part: "", up: "", page: 1
  }, ".xml");
  const res = await saveViaOffscreen("https://comment.bilibili.com/" + cid + ".xml", filename, "application/xml");
  return { ok: true, downloadId: res.downloadId };
}

/* ---------- 下载进度（chrome.downloads.onChanged） ---------- */
/** 任务状态由文件状态推导（全部完成 = done，任一中断 = error） */
function deriveStatus(task) {
  const files = task.files || [];
  const anyError = files.some((f) => f && f.state === "interrupted");
  const allDone = files.length > 0 && files.every((f) => f && f.state === "complete");
  task.status = allDone ? "done" : anyError ? "error" : "downloading";
  task.error = anyError
    ? files.filter((f) => f && f.state === "interrupted").map((f) => f.error).join("；")
    : "";
  return task;
}

/**
 * 按 downloadId 原子地改一个文件。
 * 读列表、定位、改、写回全部发生在 PM_STORAGE 的写锁内，
 * 否则视频与音频两条进度事件并发时会互相把对方的 bytes 覆盖回 0。
 * mutate(task, file) 可以返回 false 表示「本次不写回」。
 */
async function patchFileByDownload(downloadId, mutate) {
  const out = { task: null, file: null };
  await PM_STORAGE.updateTasks(async (list) => {
    const task = list.find((t) => t && Array.isArray(t.files) &&
      t.files.some((f) => f && f.downloadId === downloadId));
    if (!task) return false; // 不是本扩展的下载：不写存储
    const file = (task.files || []).find((f) => f && f.downloadId === downloadId);
    if (!file) return false;
    const keep = await mutate(task, file);
    if (keep !== false) {
      deriveStatus(task);
      task.upd = now();
    }
    out.task = task;
    out.file = file;
    return keep !== false;
  });
  return out;
}

chrome.downloads.onChanged.addListener(async (delta) => {
  const isStateChange = !!(delta.state || delta.filename || delta.error);
  const last = dlThrottle.get(delta.id) || 0;
  if (!isStateChange && now() - last < TASK_THROTTLE_MS) return;

  let retry = null; // 需要在锁外做的长耗时兜底（取流可能几十秒，不能占着写锁）

  const found = await patchFileByDownload(delta.id, async (task, file) => {
    if (delta.bytesReceived) file.bytes = delta.bytesReceived.current || 0;
    if (delta.totalBytes) file.total = delta.totalBytes.current || 0;
    if (!delta.state) return true;

    if (delta.state.current === "complete") {
      file.state = "complete";
      try {
        const items = await chrome.downloads.search({ id: delta.id });
        if (items && items[0] && items[0].filename) file.finalPath = items[0].filename;
      } catch (e) { /* ignore */ }
      return true;
    }

    if (delta.state.current !== "interrupted") {
      file.state = delta.state.current;
      return true;
    }

    const code = (delta.error && delta.error.current) || "";

    // 关键回退：直连被 CDN 拒绝（最常见是缺 Referer）时，改由扩展内取流重下，
    // 记住这个 CDN 主机（24h 内不再直连），并把失败条目从下载列表里清掉。
    const settings = await PM_STORAGE.getSettings();
    const retriable = settings.mode !== "direct" && !file.retried && file.startUrl &&
      (code === "SERVER_FORBIDDEN" || code === "NETWORK_INVALID_REQUEST" || code === "SERVER_FAILED" || code === "NETWORK_FAILED");
    if (retriable) {
      // 只落「已尝试兼容保存」标记，状态先保持不动：任务卡不会先闪一下「失败」。
      // 取流结果回来后由第二段写入终态（新 downloadId 或真正的错误）。
      file.retried = true;
      retry = { url: file.startUrl, filename: file.filename, role: file.role, code: code };
      return true;
    }

    file.state = "interrupted";
    file.error = dlErrorText(code);
    return true;
  });

  if (!found.task) return; // 未知下载：不节流、不写存储
  dlThrottle.set(delta.id, now());

  if (retry) {
    await markDirectBlocked(retry.url);
    try { await chrome.downloads.erase({ id: delta.id }); } catch (e) { /* ignore */ }
    let res = null;
    let err = null;
    try {
      res = await saveViaOffscreen(retry.url, retry.filename, MIME_BY_ROLE[retry.role]);
    } catch (e) {
      err = e;
    }
    await patchFileByDownload(delta.id, (task, file) => {
      file.retried = true;
      if (res) {
        file.downloadId = res.downloadId;
        file.state = "in_progress";
        file.fallback = true;
        file.bytes = 0;
        file.total = 0;
        file.error = "";
      } else {
        file.state = "interrupted";
        file.error = "直连失败（" + dlErrorText(retry.code) + "），兼容保存也失败：" + ((err && err.message) || "未知错误");
      }
      return true;
    });
  }

  if (found.task.status === "done" || found.task.status === "error") {
    dlThrottle.delete(delta.id);
    setTimeout(() => { maybeCloseOffscreen().catch(() => {}); }, 15000);
  }
});

/* ============================== 消息路由 ============================== */
async function handleMessage(msg, sender) {
  switch (msg.type) {
    /* ---- 状态 ---- */
    case "PM_GET_STATE": {
      const settings = await PM_STORAGE.getSettings();
      const membership = await getMembership();
      const quota = await WH_LIMITS.check("download");
      return {
        ok: true,
        settings: settings,
        membership: membership,
        quota: {
          used: quota.used, free: quota.free, remaining: quota.remaining,
          pro: quota.pro, allowed: quota.allowed
        }
      };
    }
    case "PM_REFRESH_AUTH": {
      const m = await getMembership(true);
      return { ok: true, membership: m };
    }

    /* ---- 解析 ---- */
    case "PM_INFO":
    case "PM_PLAYURL": {
      const tab = msg.tabId ? await chrome.tabs.get(msg.tabId) : await activeTab();
      if (!tab) return { ok: false, error: "没有可用的标签页" };
      if (!isBiliUrl(tab.url)) return { ok: false, error: "当前标签页不是 B 站视频页" };
      const r = await askTab(tab.id, msg.type === "PM_INFO"
        ? { type: "BILI_INFO" }
        : { type: "BILI_PLAYURL", options: msg.options || {} });
      return Object.assign({ tabId: tab.id }, r || { ok: false, error: "解析失败" });
    }
    case "PM_OPEN_PANEL": {
      const tab = msg.tabId ? await chrome.tabs.get(msg.tabId) : await activeTab();
      if (!tab) return { ok: false, error: "没有可用的标签页" };
      await askTab(tab.id, { type: "BILI_OPEN_PANEL" });
      return { ok: true };
    }

    /* ---- 下载 ---- */
    case "PM_DOWNLOAD":
      return handleDownload(msg.payload, sender);
    case "PM_BATCH":
      return handleBatch(msg.payload, sender);
    case "PM_DOWNLOAD_COVER": {
      const p = msg.payload || {};
      if (!p.url) return { ok: false, error: "没有封面地址" };
      try {
        return await saveCoverFile(p.url, p.title);
      } catch (e) {
        return { ok: false, error: (e && e.message) || "封面下载失败" };
      }
    }
    case "PM_DOWNLOAD_DANMAKU": {
      const p = msg.payload || {};
      try {
        return await saveDanmakuFile(p.cid, p.title);
      } catch (e) {
        return { ok: false, error: (e && e.message) || "弹幕下载失败" };
      }
    }

    /* ---- 任务 ---- */
    case "PM_TASKS":
      return { ok: true, tasks: await PM_STORAGE.getTasks() };
    case "PM_TASK_ACTION": {
      const { action, id } = msg;
      const tasks = await PM_STORAGE.getTasks();
      const task = tasks.find((t) => t && t.id === id);
      if (action === "remove") {
        await PM_STORAGE.removeTask(id);
        return { ok: true };
      }
      if (action === "clear") {
        await PM_STORAGE.clearTasks();
        return { ok: true };
      }
      if (!task) return { ok: false, error: "任务不存在" };
      if (action === "openFile") {
        const f = (task.files || [])[0];
        if (!f || !f.downloadId) return { ok: false, error: "没有可打开的文件（页面内保存的请到浏览器下载记录查看）" };
        try { await chrome.downloads.open(f.downloadId); return { ok: true }; } catch (e) {
          await chrome.downloads.show(f.downloadId);
          return { ok: true };
        }
      }
      if (action === "openFolder") {
        const f = (task.files || []).find((x) => x && x.downloadId);
        if (!f) return { ok: false, error: "没有可定位的文件" };
        await chrome.downloads.show(f.downloadId);
        return { ok: true };
      }
      if (action === "retry") {
        const settings = await PM_STORAGE.getSettings();
        const files = task.files || [];
        let started = 0;
        for (const f of files) {
          if (f.state === "complete" || !f.startUrl) continue;
          try {
            const res = await startOneDownload(
              Object.assign({}, task, { settings }),
              { url: f.startUrl, backups: [] },
              f.role,
              f.filename
            );
            f.downloadId = res.downloadId;
            f.state = "in_progress";
            f.fallback = !!res.fallback;
            f.error = "";
            f.bytes = 0;
            f.total = 0;
            f.retried = false;
            started++;
          } catch (e) {
            f.state = "interrupted";
            f.error = (e && e.message) || "重试失败";
          }
        }
        if (!started) {
          return { ok: false, error: "没有可重试的文件（链接已失效，请回到视频页重新解析）" };
        }
        const allDone = files.every((f) => f.state === "complete");
        const anyErr = files.some((f) => f.state === "interrupted");
        await PM_STORAGE.upsertTask({
          id: task.id, files,
          status: allDone ? "done" : anyErr ? "error" : "downloading",
          error: anyErr ? files.filter((f) => f.state === "interrupted").map((f) => f.error).join("；") : ""
        });
        return { ok: true, started };
      }
      if (action === "copyCommand") {
        return { ok: true, command: task.ffmpeg || "" };
      }
      return { ok: false, error: "未知操作" };
    }

    /* ---- 打开页面 ---- */
    case "PM_OPEN": {
      const map = { options: "options.html", account: "account.html", tasks: "tasks.html" };
      const target = map[msg.page] || map.options;
      if (msg.page === "options" && chrome.runtime.openOptionsPage) {
        await chrome.runtime.openOptionsPage();
        return { ok: true };
      }
      await chrome.tabs.create({ url: target });
      return { ok: true };
    }

    /* ---- 设置 ---- */
    case "PM_SET_SETTING": {
      await PM_STORAGE.setSetting(msg.key, msg.value);
      return { ok: true };
    }
    case "PM_SELFTEST": {
      const out = [];
      out.push({ name: "设置存储", ok: !!(await PM_STORAGE.getSettings()) });
      let apiOk = false;
      try {
        const r = await fetch("https://api.bilibili.com/x/web-interface/nav", { credentials: "omit" });
        apiOk = r.ok;
      } catch (e) { apiOk = false; }
      out.push({ name: "B 站接口可达", ok: apiOk });
      const m = await getMembership(true);
      out.push({
        name: "账号服务",
        ok: !!(m && (m.signed_in || m.reason)),
        detail: m && m.signed_in ? (m.email || "已登录") + (m.pro ? " · PRO" : " · 免费") : (m && m.reason) || "未登录"
      });
      out.push({ name: "下载权限", ok: !!(chrome.downloads && chrome.downloads.download) });
      out.push({
        name: "兼容保存通道（offscreen）",
        ok: !!(chrome.offscreen && chrome.offscreen.createDocument),
        detail: "扩展内取流（分段 + 每段重试 + 长度校验），直连被 CDN 拒绝时使用"
      });
      out.push({ name: "请求头改写（Referer）", ok: !!(chrome.declarativeNetRequest) });
      return { ok: true, checks: out, version: chrome.runtime.getManifest().version };
    }
    default:
      return { ok: false, error: "未知消息类型：" + msg.type };
  }
}

/* 兼容通道的取流进度（offscreen 专用，不需要返回） */
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== "PM_SAVE_PROGRESS") return;
  onSaveProgress(msg.payload || {}).catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== "string" || msg.type.indexOf("PM_") !== 0) return;
  if (msg.type === "PM_SAVE_PROGRESS") return;
  handleMessage(msg, sender)
    .then((r) => sendResponse(r))
    .catch((e) => sendResponse({ ok: false, error: (e && e.message) || String(e) }));
  return true;
});

/* ============================== 右键菜单 / 定时任务 ============================== */
function createMenus() {
  try {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: "pm-open-panel",
        title: "用 B站下载器解析此页",
        contexts: ["page", "video", "link"],
        documentUrlPatterns: [
          "https://www.bilibili.com/video/*",
          "https://www.bilibili.com/bangumi/play/*",
          "https://www.bilibili.com/list/*",
          "https://www.bilibili.com/medialist/play/*"
        ]
      });
    });
  } catch (e) { /* ignore */ }
}

/* ---------- 启动收敛：上次浏览器关闭/扩展重载时没写完的任务 ---------- */
const STALE_MS = 10 * 60 * 1000;

async function convergeStaleTasks() {
  try {
    await PM_STORAGE.updateTasks((tasks) => {
      const ts = now();
      let touched = false;
      for (const t of tasks) {
        if (!t || t.status !== "downloading") continue;
        // 用「最近写入时间」而不是创建时间：一个 1.5 GB 的兼容保存任务
        // 创建于 20 分钟前仍在正常下载，按 at 判断会被误标成中断。
        const stamp = Number(t.upd || t.at || 0);
        if (ts - stamp < STALE_MS) continue;
        const files = t.files || [];
        if (files.length && files.every((f) => f && f.state === "complete")) {
          t.status = "done";
          t.upd = ts;
          touched = true;
          continue;
        }
        const err = "下载中断：浏览器关闭或扩展被重载（直链已过期，请回到视频页重新解析再下）";
        files.forEach((f) => {
          if (f && f.state !== "complete") { f.state = "interrupted"; f.error = f.error || err; }
        });
        t.status = "error";
        t.error = err;
        t.upd = ts;
        touched = true;
      }
      return touched;
    });
  } catch (e) { /* 收敛失败不影响主流程 */ }
}

chrome.runtime.onInstalled.addListener(async () => {
  createMenus();
  await getMembership(true).catch(() => {});
  convergeStaleTasks().catch(() => {});
  try {
    chrome.alarms.create("bili_auth_refresh", { periodInMinutes: 60 });
  } catch (e) { /* ignore */ }
});

chrome.runtime.onStartup.addListener(() => {
  createMenus();
  getMembership(true).catch(() => {});
  convergeStaleTasks().catch(() => {});
  try { chrome.alarms.create("bili_auth_refresh", { periodInMinutes: 60 }); } catch (e) { /* ignore */ }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm && alarm.name === "bili_auth_refresh") getMembership(true).catch(() => {});
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "pm-open-panel" || !tab || !tab.id) return;
  try {
    await askTab(tab.id, { type: "BILI_OPEN_PANEL" });
  } catch (e) {
    await injectInto(tab.id);
    try { await askTab(tab.id, { type: "BILI_OPEN_PANEL" }, false); } catch (e2) { /* ignore */ }
  }
});
