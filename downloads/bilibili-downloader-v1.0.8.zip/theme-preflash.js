/* 首屏防闪烁：必须在 <head> 里、CSS 之前同步执行（扩展页面禁止内联脚本，故独立成文件）。
   偏好键：localStorage.bili_theme（light | dark | auto），由 theme.js 在各页面同步写入。 */
(function () {
  try {
    var pref = localStorage.getItem("bili_theme") || "auto";
    var dark = pref === "dark" ||
      (pref === "auto" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
    var root = document.documentElement;
    root.setAttribute("data-wh-theme", dark ? "dark" : "light");
    root.setAttribute("data-wh-theme-pref", pref);
    root.style.colorScheme = dark ? "dark" : "light";
  } catch (e) { /* 隐私模式等：忽略，交给 theme.js 兜底 */ }
})();
