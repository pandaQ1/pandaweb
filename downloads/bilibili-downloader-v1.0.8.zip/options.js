/**
 * options.js —— 设置页（216 侧栏 + 780 主区）
 *
 * 保存模型（与 Panda 设置页一致）：
 *   · 开关 / 分段 / 下拉 → 即时生效（写 chrome.storage.sync，各界面即时跟随）
 *   · 文本（目录、文件名模板）→ 显式保存（底部 .actions + 状态文字）
 */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));

  const QUALITY_LABEL = {
    16: "360P", 32: "480P", 64: "720P", 74: "720P60", 80: "1080P",
    112: "1080P+", 116: "1080P60", 120: "4K", 125: "HDR", 126: "杜比视界", 127: "8K"
  };

  let settings = Object.assign({}, PM_STORAGE.DEFAULTS);

  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r || { ok: false, error: "扩展未响应" });
        });
      } catch (e) {
        resolve({ ok: false, error: String((e && e.message) || e) });
      }
    });
  }

  function setStatus(text, kind) {
    const el = $("#filesStatus");
    el.textContent = text || "";
    el.className = "status" + (kind === "err" ? " err" : "");
    if (kind === "err") el.style.color = "var(--ui-danger)";
    else el.style.color = "";
  }

  /* ---------------- 导航 ---------------- */
  function bindNav() {
    $$(".nav-item[data-pane]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const name = btn.dataset.pane;
        $$(".pane").forEach((p) => p.classList.toggle("active", p.id === "pane-" + name));
        $$(".nav-item").forEach((b) => b.classList.toggle("active", b === btn));
        if (name === "download") refreshQuota();
      });
    });
    $("#navAccount").addEventListener("click", () => {
      chrome.tabs.create({ url: "account.html" });
    });
    $("#navTasks").addEventListener("click", () => {
      chrome.tabs.create({ url: "tasks.html" });
    });
    $("#btnUpgrade").addEventListener("click", () => {
      chrome.tabs.create({ url: "account.html" });
    });
  }

  /* ---------------- 即时生效的控件 ---------------- */
  function paintControls() {
    $("#qualitySelect").value = String(settings.quality || 80);
    $("#modeSelect").value = settings.mode || "auto";
    $("#parallelSelect").value = String(settings.maxParallel || 2);
    $("#saveCover").checked = !!settings.saveCover;
    $("#saveDanmaku").checked = !!settings.saveDanmaku;
    $("#floatBtn").checked = settings.floatBtn !== false;
    $$("#mediaSeg [data-media]").forEach((b) => {
      b.classList.toggle("active", b.dataset.media === (settings.media === "mp4" ? "mp4" : "dash"));
    });
    $("#folderInput").value = settings.folder || "";
    $("#filenameInput").value = settings.filename || "{title}-{quality}";
    paintPreview();
  }

  async function save(key, value) {
    settings[key] = value;
    await send({ type: "PM_SET_SETTING", key: key, value: value });
  }

  function bindInstant() {
    const on = (sel, ev, fn) => {
      const el = $(sel);
      if (el) el.addEventListener(ev, fn);
    };

    on("#qualitySelect", "change", (e) => {
      save("quality", Number(e.target.value));
      paintPreview();
    });
    on("#modeSelect", "change", (e) => save("mode", e.target.value));
    on("#parallelSelect", "change", (e) => save("maxParallel", Number(e.target.value)));
    on("#saveCover", "change", (e) => save("saveCover", e.target.checked));
    on("#saveDanmaku", "change", async (e) => {
      if (e.target.checked) {
        const st = await send({ type: "PM_GET_STATE" });
        const pro = !!(st && st.membership && st.membership.pro);
        if (!pro) {
          e.target.checked = false;
          setStatus("弹幕下载是 PRO 功能，激活后可用", "err");
          setTimeout(() => setStatus(""), 2600);
          return;
        }
      }
      save("saveDanmaku", e.target.checked);
    });
    on("#floatBtn", "change", (e) => save("floatBtn", e.target.checked));

    $("#mediaSeg").addEventListener("click", (ev) => {
      const b = ev.target.closest("[data-media]");
      if (!b) return;
      $$("#mediaSeg [data-media]").forEach((x) => x.classList.toggle("active", x === b));
      save("media", b.dataset.media);
    });

    $("#themeSeg").addEventListener("click", (ev) => {
      const b = ev.target.closest("[data-theme]");
      if (!b) return;
      try { WHTheme.set(b.dataset.theme); } catch (e) { /* ignore */ }
      paintTheme();
      settings.theme = b.dataset.theme;
    });
  }

  function paintTheme() {
    let pref = "auto";
    try { pref = (WHTheme.get() || {}).pref || "auto"; } catch (e) { pref = "auto"; }
    $$("#themeSeg [data-theme]").forEach((b) => b.classList.toggle("active", b.dataset.theme === pref));
  }

  /* ---------------- 文件名预览 ---------------- */
  function sanitize(s, max) {
    return String(s || "").replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").trim().slice(0, max || 100);
  }

  /** 本地日期：toISOString() 是 UTC，东八区凌晨会显示成前一天 */
  function localDate() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
  }

  function buildPreview() {
    const tpl = $("#filenameInput").value || "{title}-{quality}";
    const map = {
      title: "哔哩哔哩 · 示例视频",
      part: "P1 开头",
      quality: QUALITY_LABEL[settings.quality] || String(settings.quality),
      bvid: "BV1xx411c7mD",
      up: "某个UP主",
      page: "1",
      date: localDate()
    };
    let name = tpl;
    Object.keys(map).forEach((k) => { name = name.split("{" + k + "}").join(map[k]); });
    name = sanitize(name, 110).replace(/[-_\s]+$/, "") || "video";
    const folder = String($("#folderInput").value || "").split("/").map((s) => sanitize(s, 40)).filter(Boolean).join("/");
    return (folder ? folder + "/" : "") + name;
  }

  function paintPreview() {
    $("#namePreview").textContent = buildPreview();
  }

  /* ---------------- 显式保存 ---------------- */
  function bindFiles() {
    $("#folderInput").addEventListener("input", paintPreview);
    $("#filenameInput").addEventListener("input", paintPreview);
    $("#btnSaveFiles").addEventListener("click", async () => {
      const folder = sanitize($("#folderInput").value, 80);
      const filename = $("#filenameInput").value.trim() || "{title}-{quality}";
      await send({ type: "PM_SET_SETTING", key: "folder", value: folder });
      await send({ type: "PM_SET_SETTING", key: "filename", value: filename });
      settings.folder = folder;
      settings.filename = filename;
      paintPreview();
      setStatus("已保存", "ok");
      setTimeout(() => setStatus(""), 2200);
    });
  }

  /* ---------------- 额度 / 账号 ---------------- */
  async function refreshQuota() {
    const st = await send({ type: "PM_GET_STATE" });
    const chip = $("#navChip");
    const m = (st && st.membership) || {};
    if (chip) {
      chip.textContent = m.pro ? "PRO" : m.signed_in ? "已登录" : "未登录";
      chip.className = "nav-chip" + (m.pro ? " pro" : m.signed_in ? " on" : "");
    }
    const q = (st && st.quota) || null;
    if (q && q.pro) {
      $("#quotaTitle").textContent = "PRO 会员 · 不限次数";
      $("#quotaDesc").textContent = "全部清晰度 + 弹幕 + P 全集批量下载";
    } else if (q) {
      $("#quotaTitle").textContent = "今日免费剩余 " + q.remaining + " / " + q.free;
      $("#quotaDesc").textContent = m.signed_in
        ? "免费账号每天 3 个视频、最高 720P；激活 PRO 后不限次数"
        : "未登录每日 3 个视频；登录后可同步会员与更稳定的解析";
    }
  }

  /* ---------------- 自检 ---------------- */
  async function runSelfTest() {
    const list = $("#testList");
    list.innerHTML = '<div class="t-row info spin">正在检查…</div>';
    const r = await send({ type: "PM_SELFTEST" });
    list.innerHTML = "";
    const checks = (r && r.checks) || [];
    if (!checks.length) {
      list.innerHTML = '<div class="t-row fail">自检失败：' + ((r && r.error) || "扩展未响应") + "</div>";
      return;
    }
    checks.forEach((c) => {
      const row = document.createElement("div");
      row.className = "t-row " + (c.ok ? "ok" : "fail");
      const mark = document.createElement("span");
      mark.className = "t-mark";
      mark.textContent = c.ok ? "✓" : "✕";
      const name = document.createElement("span");
      name.textContent = c.name;
      row.appendChild(mark);
      row.appendChild(name);
      if (c.detail) {
        const d = document.createElement("span");
        d.className = "t-detail";
        d.textContent = c.detail;
        row.appendChild(d);
      }
      list.appendChild(row);
    });
    const sum = document.createElement("div");
    sum.className = "t-row info";
    sum.textContent = "共 " + checks.length + " 项，通过 " + checks.filter((c) => c.ok).length + " 项";
    list.appendChild(sum);
  }

  /* ---------------- 启动 ---------------- */
  (async function boot() {
    try {
      $("#appVer").textContent = "v" + chrome.runtime.getManifest().version;
      $("#verFoot").textContent = chrome.runtime.getManifest().version;
    } catch (e) { /* ignore */ }

    try {
      WHTheme.init({ storageKey: "theme", fallback: "auto" });
      WHTheme.onChange((theme, pref) => {
        // 首屏防闪烁脚本（theme-preflash.js）读的是 localStorage，必须同步镜像，
        // 否则本页刷新时先用旧主题渲染一帧再跳到新主题。
        try { localStorage.setItem("bili_theme", pref); } catch (e) { /* ignore */ }
        paintTheme();
      });
    } catch (e) { /* ignore */ }
    paintTheme();

    bindNav();
    bindInstant();
    bindFiles();
    $("#btnSelfTest").addEventListener("click", runSelfTest);

    settings = await PM_STORAGE.getSettings();
    paintControls();
    await refreshQuota();

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "sync") {
        let touched = false;
        Object.keys(changes).forEach((k) => {
          if (settings[k] !== undefined) {
            settings[k] = changes[k].newValue;
            touched = true;
          }
        });
        if (touched) paintControls();
      }
      if (area === "local" && changes.bili_membership) refreshQuota();
    });
  })();
})();
