/**
 * content.js —— B 站视频页浮层（Panda 设计语言 · 注入层）
 *
 * 职责：
 *  1) 提供页面数据给 popup / service worker（playurl 需要页面 Cookie，只能在这里请求）
 *  2) 右下角浮动下载按钮 + 面板（清晰度、媒体形态、封面、弹幕、批量）
 *  3) 面板交互：选清晰度/形态、点下载，真正的取流与落盘由 service worker 编排
 *     （直连被 CDN 拒绝时的兼容保存走 offscreen 文档，见 offscreen.js）
 *
 * 只读页面数据、不改 B 站 DOM 结构：面板挂在独立容器里，绝不 replace/remove 宿主节点。
 */
(function () {
  "use strict";
  if (window.__PM_BILI_CONTENT__) return;
  window.__PM_BILI_CONTENT__ = true;

  var PANEL_ID = "pm-bili-panel";
  var BTN_ID = "pm-bili-btn";
  var ROOT_ID = "pm-bili-root";

  var state = {
    settings: null,
    info: null,
    playurl: null,
    qn: 80,
    media: "dash",
    busy: false,
    open: false,
    lastHref: location.href
  };

  /* ---------------- 工具 ---------------- */
  function send(msg) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage(msg, function (resp) {
          void chrome.runtime.lastError;
          resolve(resp || { ok: false, error: "扩展未响应" });
        });
      } catch (e) {
        resolve({ ok: false, error: String((e && e.message) || e) });
      }
    });
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function toast(text, kind) {
    var old = document.getElementById("pm-bili-toast");
    if (old) old.remove();
    var t = el("div", "pm-toast" + (kind === "err" ? " remove" : ""), text);
    t.id = "pm-bili-toast";
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 1300);
  }

  /* ---------------- 主题（注入层用 data-wh-page） ---------------- */
  function applyTheme() {
    var pref = (state.settings && state.settings.theme) || "auto";
    var dark = pref === "dark" || (pref === "auto" &&
      window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.setAttribute("data-wh-page", dark ? "dark" : "light");
  }

  /* ---------------- 浮层 ---------------- */
  function ensureRoot() {
    var root = document.getElementById(ROOT_ID);
    if (root) return root;
    root = el("div");
    root.id = ROOT_ID;
    document.body.appendChild(root);
    return root;
  }

  function buildButton() {
    var root = ensureRoot();
    var btn = document.getElementById(BTN_ID);
    if (btn) return btn;
    btn = el("button");
    btn.id = BTN_ID;
    btn.type = "button";
    btn.title = "B站视频下载器（Alt+D）";
    btn.setAttribute("aria-label", "打开下载面板");
    btn.innerHTML =
      '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<path d="M12 3v11"/><path d="m7 10 5 5 5-5"/><path d="M4 20h16"/></svg>';
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      togglePanel(!state.open);
    });
    root.appendChild(btn);
    return btn;
  }

  function removeButton() {
    var btn = document.getElementById(BTN_ID);
    if (btn) btn.remove();
    var panel = document.getElementById(PANEL_ID);
    if (panel) panel.remove();
    state.open = false;
  }

  function ensurePanel() {
    var p = document.getElementById(PANEL_ID);
    if (p) return p;
    p = el("div", "pm-panel");
    p.id = PANEL_ID;
    p.setAttribute("role", "dialog");
    p.setAttribute("aria-label", "下载面板");
    p.innerHTML =
      '<div class="pm-head">' +
      '  <span class="pm-head-title">下载此视频</span>' +
      '  <button type="button" class="pm-close" aria-label="关闭">✕</button>' +
      '</div>' +
      '<div class="pm-video">' +
      '  <div class="pm-video-title" data-role="title">正在解析…</div>' +
      '  <div class="pm-video-meta" data-role="meta"></div>' +
      '</div>' +
      '<div class="pm-label">清晰度</div>' +
      '<div class="pm-qgrid" data-role="qgrid"></div>' +
      '<div class="pm-label">媒体形态</div>' +
      '<div class="pm-seg" data-role="seg">' +
      '  <button type="button" data-media="dash" class="on">音视频分离</button>' +
      '  <button type="button" data-media="mp4">单文件 MP4</button>' +
      '</div>' +
      '<button type="button" class="pm-dl" data-role="dl">下载</button>' +
      '<div class="pm-hint" data-role="hint"></div>' +
      '<div class="pm-quick">' +
      '  <button type="button" data-act="cover">下载封面</button>' +
      '  <button type="button" data-act="danmaku">下载弹幕</button>' +
      '  <button type="button" data-act="batch" style="display:none">P 全集</button>' +
      '</div>';

    p.addEventListener("click", function (ev) { ev.stopPropagation(); });
    p.querySelector(".pm-close").addEventListener("click", function () { togglePanel(false); });

    p.querySelector('[data-role="qgrid"]').addEventListener("click", function (ev) {
      var b = ev.target.closest("[data-qn]");
      if (!b) return;
      state.qn = Number(b.dataset.qn);
      Array.prototype.forEach.call(p.querySelectorAll("[data-qn]"), function (x) {
        x.classList.toggle("on", Number(x.dataset.qn) === state.qn);
      });
      loadPlayurl();
    });

    p.querySelector('[data-role="seg"]').addEventListener("click", function (ev) {
      var b = ev.target.closest("[data-media]");
      if (!b) return;
      state.media = b.dataset.media;
      Array.prototype.forEach.call(p.querySelectorAll("[data-media]"), function (x) {
        x.classList.toggle("on", x === b);
      });
      loadPlayurl();
    });

    p.querySelector('[data-role="dl"]').addEventListener("click", onDownload);
    p.querySelector('[data-act="cover"]').addEventListener("click", onCover);
    p.querySelector('[data-act="danmaku"]').addEventListener("click", onDanmaku);
    p.querySelector('[data-act="batch"]').addEventListener("click", onBatch);

    ensureRoot().appendChild(p);
    return p;
  }

  function togglePanel(open) {
    var panel = ensurePanel();
    state.open = !!open;
    panel.classList.toggle("open", state.open);
    if (state.open) {
      loadInfo();
    }
  }

  /* ---------------- 数据加载 ---------------- */
  async function loadInfo() {
    var panel = ensurePanel();
    var titleEl = panel.querySelector('[data-role="title"]');
    var metaEl = panel.querySelector('[data-role="meta"]');
    try {
      var info = await PM_BILI.getVideoInfo();
      state.info = info;
      titleEl.textContent = info.title;
      var bits = [];
      if (info.up) bits.push(info.up);
      if (info.durationText) bits.push(info.durationText);
      if (info.pages && info.pages.length > 1) bits.push("P" + info.currentPage + "/" + info.pages.length);
      metaEl.textContent = bits.join(" · ");
      var batchBtn = panel.querySelector('[data-act="batch"]');
      if (batchBtn) batchBtn.style.display = (info.pages && info.pages.length > 1) ? "" : "none";
      await loadPlayurl();
    } catch (e) {
      state.info = null;
      titleEl.textContent = "解析失败";
      metaEl.textContent = (e && e.message) || "请刷新页面后重试";
      panel.querySelector('[data-role="qgrid"]').innerHTML = "";
      panel.querySelector('[data-role="hint"]').textContent = "";
    }
  }

  async function loadPlayurl() {
    var panel = ensurePanel();
    var qgrid = panel.querySelector('[data-role="qgrid"]');
    var hint = panel.querySelector('[data-role="hint"]');
    var dl = panel.querySelector('[data-role="dl"]');
    if (!state.info) return;

    qgrid.innerHTML = '<span class="pm-loading">解析中…</span>';
    dl.disabled = true;
    // 解析期间旧结果作废：否则解析失败时点下载，会拿上一次（可能是另一个分 P /
    // 另一个清晰度）的流去下载，文件名和实际内容对不上。
    state.playurl = null;
    try {
      var st = await send({ type: "PM_GET_STATE" });
      if (st && st.settings) { state.settings = st.settings; applyTheme(); }
      state.isPro = !!(st && st.membership && st.membership.pro);
      // 免费账号：默认清晰度收敛到 720P，避免一点下载就撞上 PRO 门禁
      if (!state.isPro && state.qn > PM_BILI.FREE_MAX_QN) state.qn = PM_BILI.FREE_MAX_QN;

      var pu = await PM_BILI.getPlayurl({
        bvid: state.info.bvid,
        cid: state.info.cid,
        epId: state.info.epId,
        kind: state.info.kind,
        qn: state.media === "mp4" ? 64 : state.qn,
        media: state.media
      });
      state.playurl = pu;

      var formats = pu.formats.slice();
      if (!formats.length) throw new Error("没有可用清晰度");
      if (!formats.some(function (f) { return f.qn === state.qn; })) {
        state.qn = formats[0].qn;
      }
      qgrid.innerHTML = "";
      formats.slice(0, 8).forEach(function (f) {
        var b = el("button", "pm-q" + (f.qn === state.qn ? " on" : ""));
        b.type = "button";
        b.dataset.qn = String(f.qn);
        b.appendChild(el("span", "pm-q-label", f.label));
        if (f.pro) b.appendChild(el("span", "pm-q-pro", "PRO"));
        qgrid.appendChild(b);
      });

      var locked = formats.some(function (f) { return f.pro && f.qn === state.qn; });
      dl.disabled = false;

      if (state.media === "mp4") {
        hint.textContent = "单文件 MP4 清晰度较低，但无需合并，可直接播放。";
        hint.className = "pm-hint";
      } else if (locked && !state.isPro) {
        hint.textContent = "该清晰度需要 PRO，免费账号最高 720P。";
        hint.className = "pm-hint warn";
      } else {
        hint.textContent = "音视频分离下载后，用一条 ffmpeg 命令即可合并成 MP4。";
        hint.className = "pm-hint";
      }
    } catch (e) {
      qgrid.innerHTML = "";
      dl.disabled = true;
      hint.textContent = (e && e.message) || "解析失败";
      hint.className = "pm-hint warn";
    }
  }

  /* ---------------- 下载 ---------------- */
  async function onDownload() {
    if (state.busy) return;
    var panel = ensurePanel();
    var dl = panel.querySelector('[data-role="dl"]');
    var hint = panel.querySelector('[data-role="hint"]');
    if (!state.info || !state.playurl) return;

    state.busy = true;
    dl.disabled = true;
    dl.textContent = "准备中…";
    try {
      var pu = state.playurl;
      var payload = {
        tabId: null,
        bvid: state.info.bvid,
        epId: state.info.epId,
        kind: state.info.kind,
        cid: state.info.cid,
        title: state.info.title,
        part: state.info.currentPart,
        page: state.info.currentPage,
        up: state.info.up,
        cover: state.info.cover,
        qn: pu.qn,
        quality: (pu.formats.filter(function (f) { return f.qn === pu.qn; })[0] || {}).label || PM_BILI.qualityLabel(pu.qn),
        media: pu.media,
        playurl: state.media === "mp4"
          ? { single: pu.single }
          : { video: pu.video, audio: pu.audio }
      };
      var r = await send({ type: "PM_DOWNLOAD", payload: payload });
      if (!r || !r.ok) {
        hint.textContent = (r && r.error) || "下载失败";
        hint.className = "pm-hint warn";
        if (r && r.reason === "quota") {
          hint.textContent = "今日免费额度已用完，激活 PRO 可无限下载。";
        }
        return;
      }
      toast(payload.media === "mp4" ? "已开始下载（单文件）" : "已开始下载（视频 + 音频）", "ok");
      hint.textContent = r.fallback
        ? "CDN 拒绝直连，已改走「兼容保存」（扩展内取流），进度在「任务」页看。"
        : "任务已加入下载队列，可在扩展的「任务」页查看进度。";
      hint.className = "pm-hint";
    } catch (e) {
      hint.textContent = (e && e.message) || "下载失败";
      hint.className = "pm-hint warn";
    } finally {
      state.busy = false;
      dl.disabled = false;
      dl.textContent = "下载";
    }
  }

  async function onCover() {
    if (!state.info) return;
    var r = await send({ type: "PM_DOWNLOAD_COVER", payload: { url: state.info.cover, title: state.info.title } });
    toast(r && r.ok ? "封面已开始下载" : (r && r.error) || "封面下载失败", r && r.ok ? "ok" : "err");
  }

  async function onDanmaku() {
    if (!state.info) return;
    toast("正在准备弹幕…", "ok");
    // 交给 service worker（扩展上下文取流，绕开内容脚本的 CORS 限制）
    var r = await send({
      type: "PM_DOWNLOAD_DANMAKU",
      payload: { cid: state.info.cid, title: state.info.title }
    });
    toast(r && r.ok ? "弹幕已开始保存" : ((r && r.error) || "弹幕下载失败"), r && r.ok ? "ok" : "err");
  }

  /** P 全集批量（PRO）：由 service worker 逐个分 P 解析并加入下载队列 */
  async function onBatch() {
    if (!state.info || state.busy) return;
    var pages = state.info.pages || [];
    if (pages.length < 2) { toast("该视频只有一个分 P", "err"); return; }
    var panel = ensurePanel();
    var hint = panel.querySelector('[data-role="hint"]');
    state.busy = true;
    hint.textContent = "正在批量解析 " + pages.length + " 个分 P…";
    hint.className = "pm-hint";
    try {
      var r = await send({
        type: "PM_BATCH",
        payload: {
          bvid: state.info.bvid,
          epId: state.info.epId,
          title: state.info.title,
          up: state.info.up,
          cover: state.info.cover,
          qn: state.qn,
          quality: PM_BILI.qualityLabel(state.qn),
          pages: pages
        }
      });
      if (r && r.ok) {
        hint.textContent = "已加入 " + r.started + " 个分 P" + (r.failed ? "，失败 " + r.failed + " 个" : "") + "，可在「任务」页看进度。";
        hint.className = "pm-hint";
        toast("开始批量下载 " + r.started + " 个分 P", "ok");
      } else if (r && r.reason === "pro") {
        hint.textContent = "P 全集批量下载是 PRO 功能。";
        hint.className = "pm-hint warn";
      } else {
        hint.textContent = (r && r.error) || "批量下载失败";
        hint.className = "pm-hint warn";
      }
    } catch (e) {
      hint.textContent = (e && e.message) || "批量下载失败";
      hint.className = "pm-hint warn";
    } finally {
      state.busy = false;
    }
  }

  /* ---------------- 消息通道（background / popup → 本页） ---------------- */
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || typeof msg.type !== "string") return;

    if (msg.type === "BILI_PING") {
      sendResponse({ ok: true, url: location.href, ready: !!state.info });
      return true;
    }

    if (msg.type === "BILI_INFO") {
      PM_BILI.getVideoInfo()
        .then(function (info) {
          state.info = info;
          sendResponse({ ok: true, data: info });
        })
        .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) || "解析失败" }); });
      return true;
    }

    if (msg.type === "BILI_PLAYURL") {
      var o = msg.options || {};
      var info = state.info;
      var run = info ? Promise.resolve(info) : PM_BILI.getVideoInfo();
      // 回传「实际解析的那一集/那一 P」的 cid：调用方（弹窗/批量）要用它建任务，
      // 否则多 P 视频里下载 P3 的流、任务却记着 P1 的 cid（弹幕会取错）。
      var resolved = null;
      run.then(function (inf) {
        state.info = inf;
        var page = o.page ? (inf.pages || []).filter(function (p) { return p.page === o.page; })[0] : null;
        resolved = {
          cid: page ? page.cid : inf.cid,
          page: page ? page.page : inf.currentPage,
          part: page ? page.part : inf.currentPart
        };
        return PM_BILI.getPlayurl({
          bvid: inf.bvid,
          cid: page ? page.cid : inf.cid,
          epId: page && page.epId ? page.epId : inf.epId,
          kind: inf.kind,
          qn: o.qn,
          media: o.media
        });
      }).then(function (data) {
        sendResponse({
          ok: true,
          data: data,
          cid: resolved ? resolved.cid : "",
          page: resolved ? resolved.page : 1,
          part: resolved ? resolved.part : ""
        });
      }).catch(function (e) {
        sendResponse({ ok: false, error: (e && e.message) || "解析失败" });
      });
      return true;
    }

    if (msg.type === "BILI_OPEN_PANEL") {
      togglePanel(true);
      sendResponse({ ok: true });
      return true;
    }

    if (msg.type === "BILI_TOAST") {
      toast(msg.text || "", msg.kind);
      sendResponse({ ok: true });
      return true;
    }

    if (msg.type === "BILI_THEME") {
      if (state.settings) state.settings.theme = msg.theme;
      applyTheme();
      sendResponse({ ok: true });
      return true;
    }
    return;
  });

  /* ---------------- 设置同步 / SPA 导航 ---------------- */
  async function boot() {
    var st = await send({ type: "PM_GET_STATE" });
    state.settings = (st && st.settings) || null;
    state.qn = (state.settings && state.settings.quality) || 80;
    applyTheme();
    if (!state.settings || state.settings.floatBtn !== false) buildButton();
    else removeButton();
  }

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "sync") return;
      if (changes.theme) {
        state.settings = state.settings || {};
        state.settings.theme = changes.theme.newValue;
        applyTheme();
      }
      if (changes.floatBtn) {
        state.settings = state.settings || {};
        state.settings.floatBtn = changes.floatBtn.newValue;
        if (changes.floatBtn.newValue === false) removeButton();
        else buildButton();
      }
      if (changes.quality && changes.quality.newValue) state.qn = changes.quality.newValue;
    });
  } catch (e) { /* ignore */ }

  document.addEventListener("click", function (ev) {
    if (!state.open) return;
    var panel = document.getElementById(PANEL_ID);
    if (panel && !panel.contains(ev.target) && ev.target.id !== BTN_ID) togglePanel(false);
  }, true);

  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Escape" && state.open) togglePanel(false);
    if (ev.altKey && (ev.key === "d" || ev.key === "D")) {
      if (state.settings && state.settings.floatBtn === false) return;
      ev.preventDefault();
      togglePanel(!state.open);
    }
  }, true);

  var lastHref = location.href;
  setInterval(function () {
    if (location.href === lastHref) return;
    lastHref = location.href;
    state.info = null;
    state.playurl = null;
    if (state.open) loadInfo();
  }, 900);

  boot();
})();
