/**
 * limits.js —— 非会员（免费用户）功能额度与限制
 *
 * 配合 auth_util.js 使用：按功能配置免费额度（每天 / 总量），超额时给升级引导。
 * PRO 用户默认不受限；计数存在 chrome.storage.local（按本地日期每天自动归零）。
 *
 * 用法：
 *   WH_LIMITS.init({
 *     features: {
 *       translate:  { free: 20, unit: "次/天", label: "整页翻译" },
 *       ytCaption:  { free: 3,  unit: "个视频/天", label: "YouTube 字幕接管" },
 *       exportMarkdown: { free: 0, label: "导出 Markdown" },       // 0 = 完全 PRO
 *     },
 *     accountUrl: "account.html",
 *   });
 *
 *   // 用法一：先判断再执行
 *   if (await WH_LIMITS.tryUse("translate")) doTranslate();
 *
 *   // 用法二：只查询，不计数
 *   const q = await WH_LIMITS.check("ytCaption");   // { allowed, used, free, remaining, pro }
 *
 *   // 用法三：按钮上显示剩余
 *   WH_LIMITS.label("translate");                   // "今日剩余 18 / 20"
 */
(function () {
  "use strict";

  const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);
  const hasLocal = typeof chrome !== "undefined" && !!(chrome.storage && chrome.storage.local);

  const DEFAULTS = {
    key: "wh_limits",          // 本地计数键；多插件共存时改成自己的前缀
    accountUrl: "account.html", // 升级/登录入口
    features: {},
    proFree: true,             // PRO 不受额度限制
    showModal: true,           // 超额时自动弹升级提示
    modalTitle: "免费额度已用完",
    modalAction: "登录 / 激活 PRO",
    onExceeded: null,          // (info) => void，自定义提示时用
    onConsumed: null,          // (info) => void
  };

  let CFG = { ...DEFAULTS };
  let memCache = { at: 0, value: null };   // 会员状态缓存（60s）
  let today = "";

  /** 计数写入串行化：额度是「读计数 → 判断 → 写计数」，并发时必须排队，否则会少扣。 */
  let quotaChain = Promise.resolve();

  function queueQuota(fn) {
    const run = quotaChain.then(fn);
    quotaChain = run.then(() => {}, () => {});
    return run;
  }

  /* ---------- 存储 ---------- */
  function dayKey(d) {
    const x = d || new Date();
    return (
      x.getFullYear() + "-" +
      String(x.getMonth() + 1).padStart(2, "0") + "-" +
      String(x.getDate()).padStart(2, "0")
    );
  }

  async function loadState() {
    let raw = null;
    if (hasLocal) {
      try {
        const o = await chrome.storage.local.get(CFG.key);
        raw = (o && o[CFG.key]) || null;
      } catch (e) { raw = null; }
    } else {
      try { raw = JSON.parse(localStorage.getItem(CFG.key) || "null"); } catch (e) { raw = null; }
    }
    today = dayKey();
    if (!raw || raw.day !== today || !raw.counts || typeof raw.counts !== "object") {
      return { day: today, counts: {} };
    }
    return { day: raw.day, counts: raw.counts };
  }

  async function saveState(st) {
    st.day = today = dayKey();
    if (hasLocal) {
      try { await chrome.storage.local.set({ [CFG.key]: st }); return; } catch (e) { /* ignore */ }
    }
    try { localStorage.setItem(CFG.key, JSON.stringify(st)); } catch (e) { /* ignore */ }
  }

  /* ---------- 会员状态 ---------- */
  function isProMembership(m) {
    if (!m || !m.signed_in || !m.pro) return false;
    if (!m.expires_at) return true;
    const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
    return Number.isFinite(t) && t > Date.now();
  }

  async function isPro(force) {
    if (!CFG.proFree) return false;
    if (!force && memCache.value && Date.now() - memCache.at < 60_000) return memCache.value.pro;
    try {
      if (typeof WHAuth !== "undefined" && WHAuth.getMembership) {
        const m = await WHAuth.getMembership();
        memCache = { at: Date.now(), value: { pro: isProMembership(m) } };
      } else {
        memCache = { at: Date.now(), value: { pro: false } };
      }
    } catch (e) {
      // 网络失败：沿用上次结果（离线不清会话、不禁 PRO）
      if (!memCache.value) memCache = { at: Date.now(), value: { pro: false } };
    }
    return memCache.value.pro;
  }

  /* ---------- 额度计算 ---------- */
  function featureSpec(name) {
    const spec = CFG.features[name];
    if (!spec) return { free: 0, unlimited: true, label: name, unit: "次" }; // 未配置 = 不限
    const free = Math.max(0, Number(spec.free || 0));
    return {
      free: free,
      unlimited: free === Infinity || spec.unlimited === true,
      label: spec.label || name,
      unit: spec.unit || "次/天",
      note: spec.note || "",
    };
  }

  async function check(name, state) {
    const spec = featureSpec(name);
    const st = state || (await loadState());
    const used = Number(st.counts[name] || 0);
    const pro = await isPro();
    const allowed = spec.unlimited || pro || used < spec.free;
    return {
      feature: name,
      label: spec.label,
      unit: spec.unit,
      free: spec.unlimited ? -1 : spec.free,
      unlimited: spec.unlimited,
      used: used,
      // PRO / 未配置功能：remaining = -1 表示"不限"
      remaining: spec.unlimited || pro ? -1 : Math.max(0, spec.free - used),
      pro: pro,
      allowed: allowed,
    };
  }

  /** 消耗一次额度；超额返回 allowed:false 并触发升级提示 */
  function consume(name, n) {
    const count = Math.max(1, Number(n || 1));
    // 先把会员态问好（命中 60s 内存缓存，通常零网络），避免在锁里等网络。
    return isPro().then(() => queueQuota(async () => {
      // 锁内重新读一次：并发下载时两个请求都读到 used=2 会各写一次 3，
      // 免费额度就能被「同时点多个下载」绕过。
      const st = await loadState();
      const before = await check(name, st);
      if (before.unlimited) return { ...before, allowed: true, consumed: false, reason: "unlimited" };
      if (before.pro) return { ...before, allowed: true, consumed: false, reason: "pro" };
      if (before.used + count > before.free) {
        const info = { ...before, allowed: false, consumed: false, reason: "exceeded", need: before.used + count - before.free };
        notifyExceeded(info);
        return info;
      }
      st.counts[name] = before.used + count;
      await saveState(st);
      const after = { ...before, used: st.counts[name], remaining: Math.max(0, before.free - st.counts[name]), allowed: true, consumed: true, reason: "ok" };
      try { if (CFG.onConsumed) CFG.onConsumed(after); } catch (e) { /* ignore */ }
      return after;
    }));
  }

  /** tryUse：允许返回 true，不允许时自动弹升级提示并返回 false */
  async function tryUse(name, n) {
    const r = await consume(name, n);
    return !!r.allowed;
  }

  function reset(name) {
    return queueQuota(async () => {
      const st = await loadState();
      if (name) delete st.counts[name];
      else st.counts = {};
      await saveState(st);
      return true;
    });
  }

  async function stats() {
    const st = await loadState();
    const pro = await isPro();
    const out = { day: st.day, pro: pro, features: {} };
    for (const name of Object.keys(CFG.features)) {
      const spec = featureSpec(name);
      const used = Number(st.counts[name] || 0);
      out.features[name] = {
        label: spec.label,
        free: spec.unlimited ? -1 : spec.free,
        used: used,
        remaining: spec.unlimited ? -1 : Math.max(0, spec.free - used),
        allowed: spec.unlimited || pro || used < spec.free,
      };
    }
    return out;
  }

  /** 一行文案：今日剩余 18 / 20（PRO 或未配置时为空） */
  async function label(name) {
    const q = await check(name);
    if (q.free < 0 || q.pro) return "";
    return "今日剩余 " + q.remaining + " / " + q.free + "（" + q.unit + "）";
  }

  /* ---------- 升级提示 ---------- */
  function notifyExceeded(info) {
    try { if (CFG.onExceeded) { CFG.onExceeded(info); return; } } catch (e) { /* ignore */ }
    if (!CFG.showModal) return;
    showModal(info);
  }

  function showModal(info) {
    if (typeof document === "undefined") return;
    const old = document.getElementById("wh-limit-modal");
    if (old) old.remove();
    const wrap = document.createElement("div");
    wrap.id = "wh-limit-modal";
    wrap.setAttribute("style",
      "position:fixed;inset:0;z-index:2147483647;background:rgba(9,9,11,.55);backdrop-filter:blur(4px);" +
      "display:grid;place-items:center;font-family:system-ui,-apple-system,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;");
    const box = document.createElement("div");
    box.setAttribute("style",
      "width:340px;max-width:calc(100vw - 40px);background:#fff;color:#18181b;border-radius:16px;padding:24px;" +
      "box-shadow:0 24px 64px rgba(0,0,0,.28);text-align:center;");
    // 跟随系统深色：只在深色下覆盖必要的几项（组件里不写死双份主题）
    const style = document.createElement("style");
    style.textContent =
      "@media (prefers-color-scheme: dark){" +
      "#wh-limit-modal>div{background:#121213;color:#f4f4f5;box-shadow:0 24px 64px rgba(0,0,0,.6)}" +
      "#wh-limit-modal .wh-limit-desc{color:#8b8b93}" +
      "#wh-limit-modal .wh-limit-note{color:#71717a}" +
      "#wh-limit-modal .wh-limit-go{background:#f4f4f5;color:#0a0a0a}" +
      "#wh-limit-modal .wh-limit-close{color:#8b8b93}" +
      "}";
    box.innerHTML =
      '<div style="font-size:34px;line-height:1">🔒</div>' +
      '<div class="wh-limit-title" style="font-size:16px;font-weight:700;margin-top:12px"></div>' +
      '<div class="wh-limit-desc" style="font-size:13px;color:#71717a;margin-top:8px;line-height:1.7"></div>' +
      '<div class="wh-limit-note" style="font-size:12px;color:#a1a1aa;margin-top:6px"></div>' +
      '<button class="wh-limit-go" style="margin-top:16px;width:100%;border:0;background:#18181b;color:#fff;font:inherit;' +
      'font-size:14px;font-weight:600;padding:10px 14px;border-radius:10px;cursor:pointer"></button>' +
      '<button class="wh-limit-close" style="margin-top:8px;width:100%;border:0;background:transparent;color:#71717a;' +
      'font:inherit;font-size:12.5px;padding:6px;cursor:pointer">稍后再说</button>';
    box.querySelector(".wh-limit-title").textContent = CFG.modalTitle;
    box.querySelector(".wh-limit-desc").textContent =
      "「" + info.label + "」免费额度为 " + info.free + " " + info.unit + "，今天已用完。激活 PRO 后不限次数。";
    box.querySelector(".wh-limit-note").textContent = info.note || "";
    box.querySelector(".wh-limit-go").textContent = CFG.modalAction;
    box.querySelector(".wh-limit-go").addEventListener("click", () => {
      wrap.remove();
      try {
        if (IS_EXT) chrome.tabs.create({ url: chrome.runtime.getURL(CFG.accountUrl) });
        else location.href = CFG.accountUrl;
      } catch (e) { /* ignore */ }
    });
    box.querySelector(".wh-limit-close").addEventListener("click", () => wrap.remove());
    wrap.addEventListener("click", (e) => { if (e.target === wrap) wrap.remove(); });
    wrap.appendChild(style);
    wrap.appendChild(box);
    (document.body || document.documentElement).appendChild(wrap);
  }

  function init(opts) {
    const o = opts || {};
    CFG = { ...CFG, ...o };
    CFG.features = { ...CFG.features, ...(o.features || {}) };
    memCache = { at: 0, value: null };
    return api;
  }

  /** 跨页同步：别的页面消耗了额度，这里重新读（下次 check 自然生效） */
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes[CFG.key]) return;
      today = ""; // 让下次 loadState 重新判断日期
    });
  }

  const api = { init, check, consume, tryUse, reset, stats, label, isPro, showModal, DEFAULTS };
  if (typeof window !== "undefined") window.WH_LIMITS = api;
  if (typeof globalThis !== "undefined") globalThis.WH_LIMITS = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
