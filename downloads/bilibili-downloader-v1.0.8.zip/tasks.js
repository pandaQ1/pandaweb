/**
 * tasks.js —— 下载任务列表（独立页，780 居中）
 * 数据来自 chrome.storage.local 的 bili_tasks：storage.onChanged 触发实时重绘，
 * 不在内存里维护第二份状态。
 */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const listEl = $("#list");
  const emptyEl = $("#empty");

  const state = { tasks: [], filter: "all", sort: "new", keyword: "" };

  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r || { ok: false, error: "扩展未响应" });
        });
      } catch (e) {
        resolve({ ok: false, error: String((e && e.message) || e) });
      }
    });
  }

  function fmtSize(n) {
    const v = Number(n) || 0;
    if (v <= 0) return "";
    if (v < 1024) return v + " B";
    if (v < 1024 * 1024) return (v / 1024).toFixed(1) + " KB";
    if (v < 1024 * 1024 * 1024) return (v / 1024 / 1024).toFixed(1) + " MB";
    return (v / 1024 / 1024 / 1024).toFixed(2) + " GB";
  }

  function fmtTime(ts) {
    const d = new Date(Number(ts) || 0);
    if (!Number.isFinite(d.getTime())) return "";
    const p = (x) => String(x).padStart(2, "0");
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes());
  }

  const STATUS_TEXT = { downloading: "进行中", done: "已完成", error: "失败" };

  function filtered() {
    const kw = state.keyword.trim().toLowerCase();
    let arr = state.tasks.filter((t) => {
      if (!t) return false;
      if (state.filter !== "all" && t.status !== state.filter) return false;
      if (!kw) return true;
      return [t.title, t.up, t.bvid, t.part].some((v) => String(v || "").toLowerCase().includes(kw));
    });
    arr = arr.slice().sort((a, b) => state.sort === "old" ? (a.at || 0) - (b.at || 0) : (b.at || 0) - (a.at || 0));
    return arr;
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }

  function progressOf(task) {
    const files = task.files || [];
    let bytes = 0;
    let total = 0;
    files.forEach((f) => {
      bytes += Number(f.bytes) || 0;
      total += Number(f.total) || 0;
    });
    if (!total) return 0;
    return Math.max(0, Math.min(100, Math.round((bytes / total) * 100)));
  }

  function renderCard(task) {
    const card = el("div", "c-item");

    const head = el("div", "tk-head");
    head.appendChild(el("div", "tk-title", task.title || "未命名视频"));
    const st = el("span", "tk-status " + (task.status || ""), STATUS_TEXT[task.status] || "未知");
    head.appendChild(st);
    card.appendChild(head);

    const meta = el("div", "tk-meta");
    if (task.quality) meta.appendChild(el("span", "", task.quality));
    if (task.up) meta.appendChild(el("span", "", task.up));
    if (task.part && task.part !== task.title) meta.appendChild(el("span", "", "P" + (task.page || 1) + " " + task.part));
    meta.appendChild(el("span", "mono", task.bvid || task.epId || ""));
    meta.appendChild(el("span", "mono", fmtTime(task.at)));
    if ((task.files || []).some((f) => f && f.fallback)) {
      meta.appendChild(el("span", "", "兼容保存"));
    }
    card.appendChild(meta);

    if (task.status === "downloading") {
      const pct = progressOf(task);
      const bar = el("div", "tk-bar");
      const fill = el("i");
      fill.style.width = pct + "%";
      bar.appendChild(fill);
      card.appendChild(bar);
    }

    const files = task.files || [];
    if (files.length) {
      const wrap = el("div", "tk-files");
      files.forEach((f) => {
        const row = el("div", "tk-file" + (f.state === "interrupted" ? " err" : ""));
        row.appendChild(el("span", "role", f.role || "file"));
        const name = String(f.finalPath || f.filename || "").split(/[\\/]/).pop();
        row.appendChild(el("span", "name", name || (f.state === "interrupted" ? (f.error || "下载中断") : "—")));
        const size = f.state === "complete" ? fmtSize(f.total || f.bytes) : (fmtSize(f.bytes) ? fmtSize(f.bytes) + (f.total ? " / " + fmtSize(f.total) : "") : "");
        if (size) row.appendChild(el("span", "size", size));
        wrap.appendChild(row);
      });
      card.appendChild(wrap);
    }

    if (task.error) {
      const e = el("div", "tk-file err");
      const n = el("span", "name", task.error);
      n.title = task.error;
      e.appendChild(n);
      card.appendChild(e);
    }

    if (task.ffmpeg) {
      const cmd = el("div", "tk-cmd", task.ffmpeg);
      card.appendChild(cmd);
    }

    const actions = el("div", "tk-actions");
    const mk = (label, fn, cls) => {
      const b = el("button", "tk-btn" + (cls ? " " + cls : ""), label);
      b.type = "button";
      b.addEventListener("click", fn);
      return b;
    };

    if (task.status === "error" && files.some((f) => f && f.startUrl)) {
      actions.appendChild(mk("重试下载", async () => {
        const r = await send({ type: "PM_TASK_ACTION", action: "retry", id: task.id });
        if (!r.ok) flash(r.error || "重试失败", true);
        else flash("已重新开始下载");
      }));
    }
    if (task.status === "done" || files.some((f) => f.state === "complete" && f.downloadId)) {
      actions.appendChild(mk("打开文件", async () => {
        const r = await send({ type: "PM_TASK_ACTION", action: "openFile", id: task.id });
        if (!r.ok) alert(r.error || "无法打开");
      }));
      actions.appendChild(mk("定位文件", async () => {
        const r = await send({ type: "PM_TASK_ACTION", action: "openFolder", id: task.id });
        if (!r.ok) alert(r.error || "无法定位");
      }));
    }
    if (task.ffmpeg) {
      actions.appendChild(mk("复制合并命令", async () => {
        try {
          await navigator.clipboard.writeText(task.ffmpeg);
          flash("已复制 ffmpeg 命令");
        } catch (e) {
          flash("复制失败，请手动选中命令", true);
        }
      }));
    }
    actions.appendChild(mk("删除记录", async () => {
      await send({ type: "PM_TASK_ACTION", action: "remove", id: task.id });
    }, "danger"));

    card.appendChild(actions);
    return card;
  }

  function flash(text, isErr) {
    const old = document.getElementById("tk-flash");
    if (old) old.remove();
    const t = el("div", "c-toast " + (isErr ? "remove" : "add"), text);
    t.id = "tk-flash";
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 1300);
  }

  function render() {
    const arr = filtered();
    listEl.innerHTML = "";
    if (!arr.length) {
      emptyEl.classList.remove("hidden");
      emptyEl.querySelector("b").textContent = state.tasks.length
        ? "没有匹配的任务"
        : "还没有下载任务";
      return;
    }
    emptyEl.classList.add("hidden");
    arr.forEach((t) => listEl.appendChild(renderCard(t)));
  }

  async function load() {
    const r = await send({ type: "PM_TASKS" });
    state.tasks = (r && r.tasks) || [];
    render();
  }

  /* ---------------- 事件 ---------------- */
  document.querySelector(".s-tabs").addEventListener("click", (ev) => {
    const b = ev.target.closest("[data-filter]");
    if (!b) return;
    state.filter = b.dataset.filter;
    Array.from(document.querySelectorAll(".s-tab")).forEach((x) => x.classList.toggle("active", x === b));
    render();
  });

  $("#search").addEventListener("input", (e) => {
    state.keyword = e.target.value || "";
    render();
  });

  $("#sort").addEventListener("change", (e) => {
    state.sort = e.target.value;
    render();
  });

  $("#btnClear").addEventListener("click", async () => {
    if (!state.tasks.length) return;
    if (!confirm("清空全部任务记录？已下载的文件不会被删除。")) return;
    await send({ type: "PM_TASK_ACTION", action: "clear" });
  });

  $("#btnOpenFolder").addEventListener("click", async () => {
    const t = state.tasks.find((x) => (x.files || []).some((f) => f.downloadId));
    if (!t) { flash("还没有可定位的下载文件", true); return; }
    const r = await send({ type: "PM_TASK_ACTION", action: "openFolder", id: t.id });
    if (!r.ok) flash(r.error || "无法定位", true);
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.bili_tasks) {
      state.tasks = changes.bili_tasks.newValue || [];
      render();
    }
  });

  try {
    WHTheme.init({ storageKey: "theme", fallback: "auto" });
    WHTheme.onChange((theme, pref) => {
      try { localStorage.setItem("bili_theme", pref); } catch (e) { /* ignore */ }
    });
  } catch (e) { /* ignore */ }

  load();
})();
