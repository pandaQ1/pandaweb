/**
 * popup.js —— 300px 单列弹窗
 * 流程：读当前标签页 → 让内容脚本解析视频 → 取清晰度 → 下载（额度/清晰度在 service worker 端统一校验）
 */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const state = {
    tab: null,
    settings: null,
    membership: null,
    quota: null,
    info: null,
    playurl: null,
    resolved: null,   // 当前 playurl 对应的分 P（cid / page / part）
    qn: 80,
    media: "dash",
    busy: false
  };

  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r || { ok: false, error: "扩展未响应" });
        });
      } catch (e) {
        resolve({ ok: false, error: String((e && e.message) || e) });
      }
    });
  }

  function isBiliUrl(url) {
    return /^https:\/\/www\.bilibili\.com\/(video|list|bangumi\/play|medialist\/play)\//.test(String(url || ""));
  }

  function setHint(text, kind) {
    const el = $("#hint");
    el.textContent = text || "";
    el.className = "pp-hint" + (kind ? " " + kind : "");
  }

  /* ---------------- 主题 ---------------- */
  function initTheme() {
    const seg = $("#themeSeg");
    const paint = (pref) => {
      Array.from(seg.querySelectorAll("[data-theme]")).forEach((b) => {
        b.classList.toggle("active", b.dataset.theme === pref);
      });
    };
    try {
      WHTheme.init({ storageKey: "theme", fallback: "auto" });
      WHTheme.onChange((theme, pref) => {
        try { localStorage.setItem("bili_theme", pref); } catch (e) { /* ignore */ }
        paint(pref);
      });
      paint((WHTheme.get() || {}).pref || "auto");
    } catch (e) { /* ignore */ }
    seg.addEventListener("click", (ev) => {
      const b = ev.target.closest("[data-theme]");
      if (!b) return;
      WHTheme.set(b.dataset.theme);
      paint(b.dataset.theme);
      chrome.tabs.query({ url: "https://www.bilibili.com/*" }).then((tabs) => {
        (tabs || []).forEach((t) => {
          chrome.tabs.sendMessage(t.id, { type: "BILI_THEME", theme: b.dataset.theme }).catch(() => {});
        });
      }).catch(() => {});
    });
  }

  /* ---------------- 账号 / 配额 ---------------- */
  function paintAccount() {
    const m = state.membership || {};
    const chip = $("#planChip");
    if (m.pro) {
      chip.className = "p-chip pro";
      chip.textContent = "PRO";
    } else if (m.signed_in) {
      chip.className = "p-chip on";
      chip.textContent = "免费";
    } else {
      chip.className = "p-chip";
      chip.textContent = "未登录";
    }
    $("#acctText").textContent = m.signed_in ? (m.email || "已登录") : "未登录（免费可用 720P）";
    $("#acctAction").textContent = m.signed_in ? "管理" : "登录";
  }

  function paintQuota() {
    const q = state.quota;
    if (!q) return;
    if (q.pro) {
      if (!state.busy) setHint("PRO 会员：不限次数，可选全部清晰度");
      return;
    }
    if (!state.busy) {
      setHint("今日免费剩余 " + q.remaining + " / " + q.free + " 个 · 免费最高 720P",
        q.remaining <= 0 ? "warn" : "");
    }
  }

  /* ---------------- 视频信息 ---------------- */
  function paintVideo() {
    const info = state.info;
    if (!info) return;
    $("#vTitle").textContent = info.title || "未命名视频";
    const bits = [];
    if (info.up) bits.push(info.up);
    if (info.durationText) bits.push(info.durationText);
    if (info.pages && info.pages.length > 1) bits.push("共 " + info.pages.length + " P");
    $("#vMeta").textContent = bits.join(" · ");
    if (info.cover) {
      const img = $("#thumb");
      img.src = info.cover.replace(/^http:/, "https:");
      img.referrerPolicy = "no-referrer";
      $("#thumbWrap").style.display = "";
    } else {
      $("#thumbWrap").style.display = "none";
    }

    const pages = info.pages || [];
    const row = $("#pageRow");
    const sel = $("#pageSelect");
    if (pages.length > 1) {
      row.style.display = "";
      sel.innerHTML = "";
      pages.forEach((p) => {
        const o = document.createElement("option");
        o.value = String(p.page);
        o.textContent = "P" + p.page + " " + (p.part || "");
        if (p.page === info.currentPage) o.selected = true;
        sel.appendChild(o);
      });
    } else {
      row.style.display = "none";
    }
  }

  function paintFormats() {
    const pu = state.playurl;
    const sel = $("#qualitySelect");
    sel.innerHTML = "";
    if (!pu || !pu.formats || !pu.formats.length) {
      sel.innerHTML = '<option value="">没有可用清晰度</option>';
      $("#btnDownload").disabled = true;
      return;
    }
    const pro = !!(state.membership && state.membership.pro);
    pu.formats.forEach((f) => {
      const o = document.createElement("option");
      o.value = String(f.qn);
      o.textContent = f.label + (f.pro && !pro ? " · PRO" : "");
      if (f.qn === state.qn) o.selected = true;
      sel.appendChild(o);
    });
    $("#btnDownload").disabled = false;

    // 清晰度选择变化：local 记录即可（不改全局默认，避免误改设置）
    const cur = pu.formats.filter((f) => f.qn === state.qn)[0];
    if (cur && cur.pro && !pro) {
      setHint("当前清晰度需 PRO，免费账号最高 720P（720P 也够看）", "warn");
    } else if (state.media === "mp4") {
      setHint("单文件 MP4 无需合并，但清晰度较低", "");
    } else {
      paintQuota();
    }
  }

  /* ---------------- 加载 ---------------- */
  async function loadState() {
    const r = await send({ type: "PM_GET_STATE" });
    if (r && r.ok) {
      state.settings = r.settings;
      state.membership = r.membership;
      state.quota = r.quota;
      state.qn = (r.settings && Number(r.settings.quality)) || 80;
      // 免费账号：默认清晰度收敛到 720P，避免默认值直接撞 PRO 门禁
      if (!(r.membership && r.membership.pro) && state.qn > 64) state.qn = 64;
      state.media = (r.settings && r.settings.media === "mp4") ? "mp4" : "dash";
      Array.from(document.querySelectorAll("#mediaSeg [data-media]")).forEach((b) => {
        b.classList.toggle("active", b.dataset.media === state.media);
      });
    }
    paintAccount();
  }

  async function loadTasks() {
    const r = await send({ type: "PM_TASKS" });
    const tasks = (r && r.tasks) || [];
    const active = tasks.filter((t) => t.status === "downloading").length;
    $("#taskCount").textContent = String(active);
  }

  async function loadPage() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    state.tab = (tabs && tabs[0]) || null;
    if (!state.tab || !isBiliUrl(state.tab.url)) {
      $("#mainBox").classList.add("hidden");
      $("#emptyBox").classList.remove("hidden");
      return;
    }
    $("#emptyBox").classList.add("hidden");
    $("#mainBox").classList.remove("hidden");

    const info = await send({ type: "PM_INFO", tabId: state.tab.id });
    if (!info || !info.ok) {
      $("#vTitle").textContent = "解析失败";
      $("#vMeta").textContent = (info && info.error) || "请刷新 B 站页面后重试";
      $("#btnDownload").disabled = true;
      return;
    }
    state.info = info.data;
    paintVideo();
    await loadPlayurl();
  }

  async function loadPlayurl() {
    if (!state.info) return;
    const page = state.info.pages && state.info.pages.length > 1
      ? Number($("#pageSelect").value || state.info.currentPage)
      : null;
    setHint("正在解析清晰度…");
    $("#btnDownload").disabled = true;
    const r = await send({
      type: "PM_PLAYURL",
      tabId: state.tab.id,
      options: { qn: state.qn, media: state.media, page: page }
    });
    $("#btnDownload").disabled = false;
    if (!r || !r.ok) {
      $("#qualitySelect").innerHTML = '<option value="">解析失败</option>';
      setHint((r && r.error) || "解析失败", "err");
      state.playurl = null;
      state.resolved = null;
      return;
    }
    state.playurl = r.data;
    // 记下这次解析对应的分 P（多 P 视频里 cid 必须跟着流走，不能沿用页面当前 P）
    state.resolved = {
      cid: r.cid || state.info.cid,
      page: r.page || state.info.currentPage || 1,
      part: r.part || state.info.currentPart || ""
    };
    const has = (r.data.formats || []).some((f) => f.qn === state.qn);
    if (!has && r.data.formats && r.data.formats.length) state.qn = r.data.formats[0].qn;
    paintFormats();
  }

  /* ---------------- 下载 ---------------- */
  async function onDownload() {
    if (state.busy || !state.info || !state.playurl) return;
    state.busy = true;
    const btn = $("#btnDownload");
    btn.disabled = true;
    btn.textContent = "准备中…";
    try {
      const pu = state.playurl;
      const res = state.resolved || {};
      const payload = {
        tabId: state.tab.id,
        bvid: state.info.bvid,
        epId: state.info.epId,
        kind: state.info.kind,
        cid: res.cid || state.info.cid,
        title: state.info.title,
        part: res.part || state.info.currentPart,
        page: res.page || Number($("#pageSelect").value || state.info.currentPage || 1),
        up: state.info.up,
        cover: state.info.cover,
        qn: pu.qn,
        quality: (pu.formats.filter((f) => f.qn === pu.qn)[0] || {}).label || String(pu.qn),
        media: state.media,
        playurl: state.media === "mp4"
          ? { single: pu.single }
          : { video: pu.video, audio: pu.audio }
      };
      const r = await send({ type: "PM_DOWNLOAD", payload });
      if (r && r.ok) {
        setHint(r.fallback
          ? "CDN 拒绝直连，已改走兼容保存（扩展内取流）"
          : "已加入下载队列，可在「下载任务」查看进度");
        if (state.quota && !state.quota.pro) {
          state.quota.used = (state.quota.used || 0) + 1;
          state.quota.remaining = Math.max(0, (state.quota.remaining || 0) - 1);
        }
        loadTasks();
      } else if (r && r.reason === "quota") {
        setHint("今日免费额度已用完，激活 PRO 可无限下载", "warn");
      } else if (r && r.reason === "quality") {
        setHint("该清晰度需 PRO：免费最高 720P", "warn");
      } else {
        setHint((r && r.error) || "下载失败", "err");
      }
    } finally {
      state.busy = false;
      btn.disabled = false;
      btn.textContent = "下载";
    }
  }

  /* ---------------- 事件 ---------------- */
  function bind() {
    $("#btnDownload").addEventListener("click", onDownload);
    $("#qualitySelect").addEventListener("change", (e) => {
      state.qn = Number(e.target.value || state.qn);
      // 只改下拉框不会改变已经解析好的流地址（pu.video 还是旧清晰度的），
      // 必须按新 qn 重新解析，否则下载的是旧清晰度、却按新清晰度命名。
      loadPlayurl();
    });
    $("#pageSelect").addEventListener("change", () => {
      state.info = null;
      loadPage();
    });
    $("#mediaSeg").addEventListener("click", (ev) => {
      const b = ev.target.closest("[data-media]");
      if (!b) return;
      state.media = b.dataset.media;
      Array.from($("#mediaSeg").querySelectorAll("[data-media]")).forEach((x) => {
        x.classList.toggle("active", x === b);
      });
      loadPlayurl();
    });
    $("#btnTasks").addEventListener("click", () => send({ type: "PM_OPEN", page: "tasks" }));
    $("#btnOptions").addEventListener("click", () => send({ type: "PM_OPEN", page: "options" }));
    $("#btnAccount").addEventListener("click", () => send({ type: "PM_OPEN", page: "account" }));
    $("#acctRow").addEventListener("click", () => send({ type: "PM_OPEN", page: "account" }));
    $("#btnGoBili").addEventListener("click", () => {
      chrome.tabs.create({ url: "https://www.bilibili.com/" });
    });
  }

  try {
    $("#verText").textContent = "v" + chrome.runtime.getManifest().version;
  } catch (e) { /* ignore */ }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.bili_tasks || changes.bili_membership)) {
      if (changes.bili_membership) {
        state.membership = changes.bili_membership.newValue;
        paintAccount();
      }
      loadTasks();
    }
    if (area === "sync" && changes.quality) state.qn = Number(changes.quality.newValue) || state.qn;
  });

  initTheme();
  bind();
  (async () => {
    await loadState();
    await loadTasks();
    await loadPage();
  })();
})();
