﻿/* Panda 生词高亮 —— 「这页是不是 PDF」判定（v2.26.2，零依赖）
 * 为什么单独抽出来：background（徽标）与 popup（PDF 按钮）都要判断，
 * 而且判定规则不止一条 —— 线上大量 PDF 地址**不带 .pdf**（arxiv /pdf/2501.00001、
 * 各站点的 /download?id=3、/bitstream/…），只看扩展名一定漏。
 *
 * 三层判定（从快到慢、从准到兜底）：
 *   1) 浏览器内置 PDF 阅读器的页面地址（chrome-extension://<viewer>/index.html?file=…）→ 直接取 file 参数
 *   2) 地址/标题里的 PDF 特征（.pdf、/pdf/、format=pdf、bitstream、viewcontent.cgi、epdf …）
 *   3) 真去问一次服务器：content-type 是不是 application/pdf（background 里做，带缓存）
 */
(function (root) {
  "use strict";

  // Chromium / Edge 内置 PDF 阅读器的扩展 ID
  var VIEWER_IDS = ["mhjfbmdgcfjbbpaeojofohoefgiehjai", "oemmndcbldboiebfnladdacbdfmadadm", "ejgfnibgjbemkjnogammjkgkpcdlnhci"];
  var VIEWER_PARAMS = ["file", "url", "src", "pdf"];

  /** 内置阅读器地址 → 真正的 PDF 地址（不是阅读器地址就返回 null） */
  function pdfViewerFile(url) {
    var s = String(url || "");
    if (!/^chrome-extension:\/\//i.test(s) && !/^extension:\/\//i.test(s)) return null;
    var id = (s.match(/^[a-z]+:\/\/([a-p]{32})\//i) || [])[1] || "";
    var isKnown = VIEWER_IDS.indexOf(id) >= 0;
    var file = "";
    for (var i = 0; i < VIEWER_PARAMS.length; i++) {
      var m = s.match(new RegExp("[?&#]" + VIEWER_PARAMS[i] + "=([^&#]+)", "i"));
      if (m && m[1]) { file = decodeURIComponent(m[1]); break; }
    }
    if (file) return file;
    return isKnown ? "" : null;
  }

  /** 地址本身像不像 PDF（不看服务器） */
  function looksLikePdfUrl(url) {
    var s = String(url || "").trim();
    if (!s) return false;
    var viewer = pdfViewerFile(s);
    if (viewer !== null) return true;                    // 已在内置阅读器里
    if (!/^(https?|file):/i.test(s)) return false;
    if (/\.pdf(\?|#|$)/i.test(s)) return true;           // 最常见
    var path = "", query = "";
    try {
      var u = new URL(s);
      path = u.pathname.toLowerCase();
      query = u.search.toLowerCase();
    } catch (e) {
      path = s.toLowerCase();
      query = s.toLowerCase();
    }
    // 路径特征：这些路径一律是「文档下载/查看」，不带扩展名
    if (/\/pdfs?\/[^/]+$/.test(path)) return true;        // arxiv: /pdf/2501.00001、/pdf/2501.00001v2
    if (/\/(bitstream|viewcontent\.cgi|epdf|fulltext|fulltextpdf|article\/download|download\/pdf|document\/download)\b/.test(path)) return true;
    if (/\/(download|file|files|document|documents|paper|papers|preprint|attachment)\//.test(path) && /pdf/.test(query)) return true;
    // 参数特征
    if (/(^|&)(format|type|mime|filetype|output|download)=[^&]*pdf/.test(query)) return true;
    if (/(^|&)(file|url|src)=[^&]*\.pdf/.test(query)) return true;
    return false;
  }

  /** 标题特征（很多预览页标题就是 xxx.pdf） */
  function looksLikePdfTitle(title) {
    var t = String(title || "").trim();
    if (!t) return false;
    return /\.pdf$/i.test(t) || /\.pdf\b/i.test(t) || /^\s*PDF\s*$/i.test(t);
  }

  /** 综合判定（不含联网）：返回 { isPdf, url } —— url 是「真正要交给阅读器的那一份」 */
  function detect(tab) {
    var url = String((tab && tab.url) || "");
    var title = String((tab && tab.title) || "");
    var viewer = pdfViewerFile(url);
    if (viewer !== null) return { isPdf: true, url: viewer || url, via: "viewer" };
    if (looksLikePdfUrl(url)) return { isPdf: true, url: url, via: "url" };
    if (looksLikePdfTitle(title) && /^(https?|file):/i.test(url)) return { isPdf: true, url: url, via: "title" };
    return { isPdf: false, url: url, via: "" };
  }

  var api = {
    pdfViewerFile: pdfViewerFile,
    looksLikePdfUrl: looksLikePdfUrl,
    looksLikePdfTitle: looksLikePdfTitle,
    detect: detect
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;   // node 测试用
  root.WH_PDF_DETECT = api;                                                    // 扩展页与 SW 用
})(typeof globalThis !== "undefined" ? globalThis : this);
