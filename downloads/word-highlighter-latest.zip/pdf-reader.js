﻿/* 生词高亮 & 翻译助手 —— PDF 阅读器 v1.0.0（v2.22.0 起）
 *
 * 为什么需要这个页面：浏览器内置 PDF 阅读器由浏览器自己的扩展渲染，PDF 内容在
 * <embed> 插件对象里，普通 content script 注入不进去，所以「右键取词 / 悬停查词 /
 * 高亮生词」在内置阅读器里一律失效。本页面让插件自己当宿主：
 *   pdf.js 渲染画布 + 自建透明文本层 → 取词/选中/复制照常，
 *   查词卡片复用 content.js 暴露的 window.WH_SHOW_CARD（内部页面模式），
 *   生词高亮走 CSS Custom Highlight API（不改 DOM，不干扰选中与复制）。
 *
 * 三种打开方式：
 *   1) pdf-reader.html?src=<http(s) 地址>   —— 网页上的 PDF（popup / 页面浮标）
 *   2) 拖文件进窗口                        —— 本地 PDF
 *   3) 顶栏「打开」选择文件                 —— 本地 PDF
 *   file:// 地址：扩展页无法 fetch 本地文件（MV3 限制），会退化成 2/3 两种方式。
 */
(function () {
  "use strict";

  const $ = (sel) => document.querySelector(sel);
  const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);
  const PDFJS = window.pdfjsLib || null;

  /* ---------------- 状态 ---------------- */
  const state = {
    pdf: null,
    pageCount: 0,
    scale: 1,          // 手动缩放值（fitWidth 状态下不代表当前显示比例）
    effScale: 1,       // 【v2.26.3】当前实际显示比例（fitWidth 时算出来的那一档）
    fitWidth: true,
    highlightOn: true,
    fileName: "",
    src: "",
    sheets: [],          // { el, num, canvas, text, page, renderedScale, task }
    renderQueue: new Set(),
    hlSet: new Set(),    // 词库等级白名单
    wbSet: new Set(),    // 生词本词（红标）
    current: 1,
    hkBindings: {},      // 【v2.25.10】快捷键中心里的动作 → 按键数组
    hkEnabled: true
  };

  const WORD_RE = /[A-Za-z][A-Za-z'’\-]*[A-Za-z]|[A-Za-z]/g;
  const ASPECT_FALLBACK = 1.414; // A4 竖版，仅用于未渲染页的占位高度


  /* ---------------- 状态栏 ---------------- */
  let statusTimer = 0;
  /** 【v2.25.13】错误提示也自动消失（原来只有普通提示会消失，一条红色提示会一直挂在顶上）。
   *  错误给更长的时间（7s）让人看清，普通提示 4s。 */
  function setStatus(text, isError) {
    const el = $("#status");
    if (!el) return;
    clearTimeout(statusTimer);
    if (!text) {
      el.classList.add("hidden");
      return;
    }
    el.textContent = text;
    el.classList.toggle("wh-pdf-status-error", !!isError);
    el.classList.remove("hidden");
    statusTimer = setTimeout(() => el.classList.add("hidden"), isError ? 7000 : 4000);
  }

  /* ---------------- 主题 ---------------- */
  function applyTheme(dark) {
    document.documentElement.setAttribute("data-wh-theme", dark ? "dark" : "light");
    document.body.classList.toggle("dark", !!dark);
    const use = $("#theme-btn use");
    if (use) use.setAttribute("href", dark ? "#i-sun" : "#i-moon");
    const label = $("#theme-btn-label");
    if (label) label.textContent = dark ? "日间" : "夜间";
    const btn = $("#theme-btn");
    if (btn) btn.title = dark ? "切换到日间模式" : "切换到夜间模式";
  }
  async function initTheme() {
    let theme = "light";
    let invert = false;
    try {
      const s = await chrome.storage.sync.get({ theme: "light", pdfInvert: false });
      theme = s.theme || "light";
      invert = !!s.pdfInvert;
    } catch (e) { /* ignore */ }
    let dark = theme === "dark";
    if (theme === "auto") {
      dark = !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
    }
    applyTheme(dark);
    applyInvert(invert);
    // 【v2.25.8】镜像偏好，供 theme-boot.js 下次首帧同步读取（与 popup/设置页共用 key）
    try { localStorage.setItem("wh_theme", theme); } catch (e) { /* ignore */ }
  }

  function applyInvert(on) {
    document.body.classList.toggle("wh-pdf-invert", !!on);
    const btn = $("#invert-btn");
    if (btn) {
      btn.setAttribute("aria-pressed", on ? "true" : "false");
      btn.title = "反色显示：" + (on ? "开" : "关") + "（白底 PDF 夜间更护眼）";
    }
    const label = $("#invert-label");
    if (label) label.textContent = on ? "反色：开" : "反色：关";
  }

  /* ---------------- 高亮白名单（与网页层同一套规则） ---------------- */
  async function loadHighlightSets() {
    let level = "none";
    let levels = null;
    let userWords = [];
    let knownWords = [];
    try {
      const s = await chrome.storage.sync.get({
        level: "none", levels: null, userWords: [], knownWords: [], color: "#fff1a8", underline: true
      });
      level = s.level || "none";
      levels = Array.isArray(s.levels) ? s.levels : null;
      userWords = s.userWords || [];
      knownWords = s.knownWords || [];
    } catch (e) { /* ignore */ }

    const VOCAB = window.__WH_VOCAB__ || null;
    const order = (VOCAB && Array.isArray(VOCAB.order)) ? VOCAB.order : [];
    // 【v2.25.0】支持多选：levels 数组为准（空数组＝用户清空），没有才回落到旧的单值 level
    const picked = [];
    if (levels) {
      for (const lv of levels) if (order.includes(lv) && !picked.includes(lv)) picked.push(lv);
    } else if (level && level !== "none" && order.includes(level)) {
      picked.push(level);
    }

    const userSet = new Set(userWords.map((w) => String(w).trim().toLowerCase()).filter(Boolean));
    const knownSet = new Set(knownWords.map((w) => String(w).trim().toLowerCase()).filter(Boolean));
    const set = new Set();
    // 与 content.js 的 buildHighlightSet 一致：只高亮「所选等级」的词（多选取并集），排除已掌握/已认识
    for (const lv of picked) {
      const list = (VOCAB && VOCAB.lists && VOCAB.lists[lv]) || [];
      for (const w of list) {
        const lw = String(w).toLowerCase();
        if (!userSet.has(lw) && !knownSet.has(lw)) set.add(lw);
      }
    }
    state.hlSet = set;

    // 收藏的生词：始终红标，不受等级影响
    const wb = new Set();
    try {
      const l = await chrome.storage.local.get("wh_wordbook");
      for (const e of (l.wh_wordbook || [])) {
        if (e && typeof e.word === "string") wb.add(e.word.toLowerCase());
      }
    } catch (e) { /* ignore */ }
    state.wbSet = wb;
  }

  /* ---------------- 高亮：精确单词 Range → 独立矩形 ----------------
   * 不再根据 span 外框、行距或像素墨迹猜高亮位置。Range 已包含 PDF.js 文字层的
   * font-size / scaleX / rotate 等真实排版几何；每个 getClientRects() 矩形直接
   * 变成色块，同一词的换行片段也分别处理。坐标相对于 sheet 计算，不含页面滚动量。
   */
  function ensureHlLayer(sheet) {
    if (sheet.hl && sheet.hl.isConnected) return sheet.hl;
    const el = document.createElement("div");
    el.className = "wh-pdf-hl";
    sheet.el.insertBefore(el, sheet.text);
    sheet.hl = el;
    return el;
  }

  function clearHlLayer(sheet) {
    if (sheet.hl) sheet.hl.textContent = "";
  }

  /* 仅用于拼词：PDF.js 会把一行拆成多个 span，词也可能跨 span。
     位置不参与高亮计算，避免行分组/行高估算再次引入误差。 */
  function groupLines(layer) {
    const lines = [];
    for (const span of layer.querySelectorAll("span")) {
      if (span.classList.contains("markedContent")) continue;
      const r = span.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) continue;
      let line = lines.find((l) => Math.abs(l.top - r.top) < Math.max(2, Math.min(l.height, r.height) * 0.5));
      if (!line) { line = { top: r.top, height: r.height, spans: [] }; lines.push(line); }
      line.spans.push({ span, rect: r });
    }
    for (const line of lines) line.spans.sort((a, b) => a.rect.left - b.rect.left);
    return lines;
  }

  function lineText(line) {
    const pieces = [];
    let text = "", lastRight = null;
    for (const item of line.spans) {
      for (const node of item.span.childNodes) {
        if (node.nodeType !== Node.TEXT_NODE) continue;
        const value = node.nodeValue || "";
        if (!value) continue;
        if (lastRight !== null && item.rect.left - lastRight > 1.5) text += " ";
        pieces.push({ node, start: text.length, end: text.length + value.length });
        text += value;
      }
      lastRight = item.rect.right;
    }
    return { text, pieces };
  }

  function rangeForMatch(pieces, start, end) {
    let first = null, last = null;
    for (const piece of pieces) {
      if (piece.end <= start) continue;
      if (piece.start >= end) break;
      if (!first) first = piece;
      last = piece;
    }
    if (!first || !last) return null;
    try {
      const range = document.createRange();
      range.setStart(first.node, Math.max(0, start - first.start));
      range.setEnd(last.node, Math.min(last.node.nodeValue.length, end - last.start));
      return range;
    } catch (e) { return null; }
  }

  function paintRange(sheet, range, word, kind) {
    const sheetRect = sheet.el.getBoundingClientRect();
    const host = ensureHlLayer(sheet);
    let count = 0;
    for (const rect of range.getClientRects()) {
      if (rect.width < 0.5 || rect.height < 0.5) continue;
      const div = document.createElement("div");
      div.className = kind === "wordbook" ? "wh-pdf-mark wh-pdf-mark-wb" : "wh-pdf-mark";
      div.style.left = (rect.left - sheetRect.left) + "px";
      div.style.top = (rect.top - sheetRect.top) + "px";
      div.style.width = rect.width + "px";
      div.style.height = rect.height + "px";
      div.dataset.word = word;
      // 仅用于验证和滚动后的几何诊断；不要从定位后的色块反推文字位置。
      div.dataset.rangeTop = String(rect.top - sheetRect.top);
      div.dataset.rangeHeight = String(rect.height);
      host.appendChild(div);
      count++;
    }
    return count;
  }

  /* Range 的字体框（ascent+descent）通常比真实字形高，紧排版里会压到邻行。
   * 这里按「行」统一收边：
   *   1) 把同一个 Range top 的色块聚成一行（行距紧的 PDF 里一行高度 27px、行距 21px）；
   *   2) 每行中心取该行色块 Range 中心的众数（不受升部/降部个别词影响）；
   *   3) 行的上下边界取「与相邻行中心的中点」，于是相邻两行刚好相接、不重叠；
   *   4) 左右边界与行内顺序一律不动 —— 那是 Range 给的真实字形范围。
   * 这样每一块都盖住本行字形（字形高度 < 行距），又不会侵入上一行/下一行。
   */
  function alignMarksToLineBands(sheet) {
    const host = sheet.hl;
    if (!host || !host.children.length) return;
    const toItem = (el) => {
      const top = parseFloat(el.style.top);
      const height = parseFloat(el.style.height);
      return { el, top, height, center: top + height / 2 };
    };
    // ① 按 Range top 聚行：容差取字高的一半，避免把上标/小字号碎片拆成独立行
    const lines = [];
    for (const item of Array.from(host.children).map(toItem).sort((a, b) => a.top - b.top)) {
      let line = lines.find((l) => Math.abs(l.top - item.top) < Math.max(2, Math.min(l.boxHeight, item.height) * 0.5));
      if (!line) { line = { top: item.top, boxHeight: item.height, items: [] }; lines.push(line); }
      line.items.push(item);
      line.top = Math.min(line.top, item.top);
      line.boxHeight = Math.max(line.boxHeight, item.height);
    }
    for (const line of lines) {
      // ② 行中心用中位数：个别带升部/降部的词框偏高或偏矮，不参与拉偏整行
      const centers = line.items.map((i) => i.center).sort((a, b) => a - b);
      line.center = centers[Math.floor(centers.length / 2)];
      // 行的横向范围：用来判断「另一行是不是同一栏」（双栏 PDF 左右两栏同高，绝不能被当成上下相邻）
      line.left = Math.min(...line.items.map((i) => parseFloat(i.el.style.left)));
      line.right = Math.max(...line.items.map((i) => parseFloat(i.el.style.left) + parseFloat(i.el.style.width)));
    }
    lines.sort((a, b) => a.center - b.center);
    const sameColumn = (a, b) => Math.min(a.right, b.right) - Math.max(a.left, b.left) > 1;
    /** 在同栏里找最近的上/下一行（跨栏不算相邻） */
    const neighbour = (index, dir) => {
      const cur = lines[index];
      for (let i = index + dir; i >= 0 && i < lines.length; i += dir) {
        if (sameColumn(cur, lines[i])) return lines[i];
      }
      return null;
    };
    // ③ 上下边界 = 与「同栏」相邻行中心的中点；没有邻居、或中点比字体框还远时，用自己的字体框
    //    关键：结果必须夹在字体框之内，否则（代码块短行、找不到同栏邻居时）色块会被拉到多行高。
    for (let i = 0; i < lines.length; i++) {
      const cur = lines[i];
      const prev = neighbour(i, -1);
      const next = neighbour(i, +1);
      const halfBox = cur.boxHeight / 2;
      const boxTop = cur.center - halfBox;
      const boxBottom = cur.center + halfBox;
      const upLimit = prev && (cur.center - prev.center) > halfBox * 0.8
        ? (prev.center + cur.center) / 2 : boxTop;
      const downLimit = next && (next.center - cur.center) > halfBox * 0.8
        ? (cur.center + next.center) / 2 : boxBottom;
      cur.top = Math.max(boxTop, Math.min(upLimit, cur.center - 0.5));
      cur.bottom = Math.min(boxBottom, Math.max(downLimit, cur.center + 0.5));
    }
    // ④ 兜底：同一栏里两行仍相交时，按两行中心的中点再收一次，保证视觉上不粘连
    for (let i = 0; i < lines.length; i++) {
      const prev = neighbour(i, -1);
      const cur = lines[i];
      if (!prev || cur.top >= prev.bottom) continue;
      const boundary = (prev.center + cur.center) / 2;
      prev.bottom = Math.max(prev.center + 0.5, Math.min(prev.bottom, boundary - 0.25));
      cur.top = Math.min(cur.center - 0.5, Math.max(cur.top, boundary + 0.25));
    }
    for (const line of lines) {
      const h = Math.max(1, line.bottom - line.top);
      for (const item of line.items) {
        item.el.style.top = line.top + "px";
        item.el.style.height = h + "px";
      }
    }
  }

  /* ---------------- 【v2.26.0】用 PDF 自身的文本几何出框 ----------------
   * 为什么换掉旧做法：旧做法把高亮框挂在 pdf.js 的「透明文字层」上，而文字层是按浏览器回退字体
   * 排版的 —— 字宽与 PDF 内嵌字体不同（横向累计漂移），span 框高又与行距不一致（纵向盖不住/压行）。
   * 现在直接用 getTextContent() 里每个 item 的 **PDF 坐标 + 精确宽度 + 字体 ascent/descent**，
   * 按空格切成词，在「基线局部坐标」里算出每个词的矩形；旋转文字用同一套矩阵，框跟着转。
   * 这样高亮与页面绘制同源：缩放只是重算一遍，任何百分比、任何字号都准。
   */
  let measureCanvas = null;
  let measureCtx = null;
  function textMeasurer() {
    if (!measureCtx) {
      measureCanvas = document.createElement("canvas");
      measureCtx = measureCanvas.getContext("2d");
    }
    return measureCtx;
  }

  /** 把 textContent 变成"词表"：{ text, ox, oy, w, h, angle }（CSS px，相对页面左上角；ox/oy 是基线起点） */
  function buildWordIndex(sheet, tc, viewport) {
    const words = [];
    if (!tc || !tc.items) return words;
    const styles = tc.styles || {};
    const ctx = textMeasurer();
    const scale = viewport.scale;
    for (const item of tc.items) {
      const str = item.str;
      if (!str || !item.transform) continue;
      if (!/\S/.test(str)) continue;
      const style = styles[item.fontName] || {};
      const fontFamily = style.fontFamily || "sans-serif";
      let ascent = typeof style.ascent === "number" ? style.ascent : 0.8;
      let descent = typeof style.descent === "number" ? style.descent : -0.2;
      if (!(ascent > 0)) ascent = 0.8;
      if (!(descent < 0)) descent = -0.2;
      // PDF 用户空间 → 视口像素
      const m = pdfjsLib.Util.transform(viewport.transform, item.transform);
      const angle = Math.atan2(m[1], m[0]);
      const fontSize = Math.hypot(m[2], m[3]) || 12;
      const itemWidth = (item.width || 0) * scale;
      // 字符宽度（只用来按比例切词；总量会被缩放到 itemWidth，保证总宽与 PDF 一致）
      ctx.font = fontSize + "px " + fontFamily;
      const chars = Array.from(str);
      const widths = chars.map((ch) => (ch === " " ? ctx.measureText(" ").width : ctx.measureText(ch).width));
      const totalMeasured = widths.reduce((a, b) => a + b, 0) || 1;
      const k = itemWidth > 0 ? itemWidth / totalMeasured : 1;
      let acc = 0;
      let startIdx = -1;
      const flush = (endIdx) => {
        if (startIdx < 0) return;
        const text = chars.slice(startIdx, endIdx).join("");
        const offset = accAt(startIdx);
        const wWord = (accAt(endIdx) - offset) * k;
        if (text && wWord > 0.5) {
          const ox = m[4] + offset * k * Math.cos(angle);
          const oy = m[5] + offset * k * Math.sin(angle);
          const h = Math.max(1, (ascent - descent) * fontSize);
          words.push({
            text: text,
            ox: ox,
            oy: oy,
            w: wWord,
            h: h,
            asc: ascent * fontSize,
            angle: angle
          });
        }
        startIdx = -1;
      };
      const accAt = (idx) => { let s = 0; for (let i = 0; i < idx; i++) s += widths[i]; return s; };
      for (let i = 0; i < chars.length; i++) {
        const ch = chars[i];
        if (/\s/.test(ch)) { flush(i); acc = accAt(i + 1); continue; }
        if (startIdx < 0) startIdx = i;
      }
      flush(chars.length);
    }
    return words;
  }

  /** 把整页画布读进内存（软件后端，读回一定是当前这张） */
  function readPageInk(sheet) {
    const canvas = sheet.canvas;
    if (!canvas || !canvas.width || !canvas.height) return null;
    if (!sheet.el.clientWidth || !sheet.el.clientHeight) return null;
    const probe = document.createElement("canvas");
    probe.width = canvas.width;
    probe.height = canvas.height;
    const pctx = probe.getContext("2d", { willReadFrequently: true });
    if (!pctx) return null;
    try { pctx.drawImage(canvas, 0, 0); } catch (e) { return null; }
    let img;
    try { img = pctx.getImageData(0, 0, probe.width, probe.height); } catch (e) { return null; }
    return {
      data: img.data,
      W: img.width,
      H: img.height,
      sx: img.width / sheet.el.clientWidth,
      sy: img.height / sheet.el.clientHeight
    };
  }

  /** 在 [x0,x1) × [y0,y1)（设备像素）范围内找墨迹包围盒；阈值 200（含抗锯齿边缘） */
  function inkBoxIn(page, x0, x1, y0, y1) {
    const { data, W, H } = page;
    const ax0 = Math.max(0, x0), ax1 = Math.min(W, x1);
    const ay0 = Math.max(0, y0), ay1 = Math.min(H, y1);
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (let y = ay0; y < ay1; y++) {
      const base = y * W * 4;
      for (let x = ax0; x < ax1; x++) {
        const i = base + x * 4;
        if (data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114 < 200) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }
    if (minX === Infinity) return null;
    return { minX: minX, maxX: maxX, minY: minY, maxY: maxY };
  }

  /** 【v2.26.0】用画布墨迹把每个词的框再收紧一次。
   *  锚点现在是 **PDF 的基线**（精确知道字在哪一行），所以取样窗口不会跨到邻行 ——
   *  这是之前像素法一直翻车的地方。收紧后：降部（g/y/p）、升部、以及按比例切词带来的
   *  左右误差都会被真实墨迹纠正。读不到墨迹（图上文字/遮挡）就保留几何框。
   */
  function refineWordBoxes(sheet) {
    if (!sheet.words || !sheet.words.length) return 0;
    const page = readPageInk(sheet);
    if (!page) { sheet.__refineDiag = { page: -1 }; return 0; }
    const { W, H, sx, sy } = page;
    const fs = sheet.renderedScale || 1;
    let n = 0;
    for (const w of sheet.words) {
      const ang = w.angle || 0;
      if (Math.abs(ang) > 0.02) continue;          // 旋转文字的框先不动（矩形不同源）
      const x0 = Math.max(0, Math.floor(w.ox * sx) - 2);
      const x1 = Math.min(W, Math.ceil((w.ox + w.w) * sx) + 2);
      const baseY = w.oy * sy;
      const fsPx = (w.asc + w.h - w.asc) || 1;      // 兜底
      const up = w.asc * sy;
      const down = Math.max(2, (w.h - w.asc) * sy);
      const y0 = Math.max(0, Math.floor(baseY - up - 3));
      const y1 = Math.min(H, Math.ceil(baseY + down + 3));
      if (x1 - x0 < 2 || y1 - y0 < 2) continue;
      const ib = inkBoxIn(page, x0, x1, y0, y1);
      const D = (sheet.__refineDiag = sheet.__refineDiag || { words: 0, noInk: 0, badH: 0, ok: 0, rot: 0, tiny: 0, page: 0 });
      D.words++;
      if (!ib) { D.noInk++; continue; }
      const hPx = ib.maxY - ib.minY + 1;
      // 合理性：高度要在"字号"的 0.35~1.6 倍之间，否则宁可不信
      const emPx = (w.h) * sy;
      if (hPx < emPx * 0.3 || hPx > emPx * 1.7) { D.badH++; continue; }
      // 四周只留半像素压住抗锯齿边；右侧多给 0.6 是防止与下一个词贴边时露白
      w.rTop = (ib.minY - 0.5) / sy;
      w.rLeft = (ib.minX - 0.5) / sx;
      w.rW = (ib.maxX + 0.6) / sx - w.rLeft;
      w.rH = (ib.maxY + 0.8) / sy - w.rTop;
      D.ok++;
      n++;
      void fsPx; void fs;
    }
    return n;
  }

  /** 按词表画高亮（DOM 块，旋转文字用 transform 跟着转） */
  function paintHighlightsFromIndex(sheet) {
    const out = { vocab: 0, wordbook: 0 };
    const host = ensureHlLayer(sheet);
    host.textContent = "";
    if (!state.highlightOn || !sheet.words || !sheet.words.length) return out;
    // 【v2.26.0】去重：pdf.js 有时会把同一段文字发两遍（伪粗体/断行），会在同一位置叠两个框
    const seen = new Set();
    for (const w of sheet.words) {
      const lower = String(w.text).toLowerCase();
      if (lower.length < 2) continue;
      const inWb = state.wbSet.has(lower);
      const inVocab = state.hlSet.has(lower);
      if (!inWb && !inVocab) continue;
      const boxKey = lower + "@" + Math.round(w.rTop !== undefined ? w.rTop : w.oy) + "," + Math.round(w.rLeft !== undefined ? w.rLeft : w.ox) + "," + Math.round(w.w);
      if (seen.has(boxKey)) continue;
      seen.add(boxKey);
      const div = document.createElement("div");
      div.className = inWb ? "wh-pdf-mark wh-pdf-mark-wb" : "wh-pdf-mark";
      if (typeof w.rTop === "number" && Math.abs(w.angle) <= 0.02) {
        // 已按真实墨迹收紧：直接用绝对矩形
        div.style.left = w.rLeft + "px";
        div.style.top = w.rTop + "px";
        div.style.width = w.rW + "px";
        div.style.height = w.rH + "px";
      } else {
        div.style.left = w.ox + "px";
        div.style.top = w.oy + "px";
        div.style.width = w.w + "px";
        div.style.height = w.h + "px";
        div.style.transformOrigin = "0 0";
        div.style.transform = "rotate(" + w.angle + "rad) translate(0px, " + (-w.asc) + "px)";
      }
      host.appendChild(div);
      if (inWb) out.wordbook++;
      else out.vocab++;
    }
    return out;
  }

  function scanLayer(layer, sheet) {
    const out = { vocab: 0, wordbook: 0 };
    if (!layer || !sheet) return out;
    for (const line of groupLines(layer)) {
      const { text, pieces } = lineText(line);
      WORD_RE.lastIndex = 0;
      let match;
      while ((match = WORD_RE.exec(text))) {
        const word = match[0].toLowerCase();
        if (word.length < 2) continue;
        const inWb = state.wbSet.has(word);
        const inVocab = state.hlSet.has(word);
        if (!inWb && !inVocab) continue;
        const range = rangeForMatch(pieces, match.index, match.index + match[0].length);
        if (!range || !paintRange(sheet, range, word, inWb ? "wordbook" : "vocab")) continue;
        if (inWb) out.wordbook++;
        else out.vocab++;
      }
    }
    return out;
  }

  function rebuildHighlights() {
    for (const sheet of state.sheets) {
      clearHlLayer(sheet);
      if (state.highlightOn && sheet.renderedScale) {
        // 【v2.26.0】优先用 PDF 文本几何出框；没有词表（老页面/异常）才退回文字层扫描
        if (sheet.words && sheet.words.length) {
          if (sheet.wordsRefinedAt !== sheet.renderedScale) {
            try { refineWordBoxes(sheet); } catch (e) { sheet.__refineErr = String((e && e.stack) || e); }
            sheet.wordsRefinedAt = sheet.renderedScale;
          }
          paintHighlightsFromIndex(sheet);
        } else scanLayer(sheet.text, sheet);
      }
    }
    let vocab = 0, wordbook = 0;
    for (const sheet of state.sheets) {
      if (!sheet.hl) continue;
      vocab += sheet.hl.querySelectorAll(".wh-pdf-mark:not(.wh-pdf-mark-wb)").length;
      wordbook += sheet.hl.querySelectorAll(".wh-pdf-mark-wb").length;
    }
    window.__WH_PDF_HL__ = { vocab, wordbook };
  }

  /* ---------------- 文本层 ---------------- */
  /** 【v2.25.11】文本层改由 pdf.js 自己的 renderTextLayer 生成（与浏览器内置阅读器同一套几何算法）。
   *  为什么要换：手写版把一行当成一个 span，只能整行做 scaleX 等比拉伸；
   *  浏览器字体与 PDF 内嵌字体的字宽本就不一致，拉伸后行内每个词的起止都会偏，
   *  于是高亮色块「长度不对、前后对不齐」，越往行尾越明显。
   *  pdf.js 的 TextLayer 用的是逐 item + 逐段（含连字/字距/旋转）的定位方式，Range 才能对准字形。
   *  拿不到该 API 时退回手写版（虽然不完美，但至少能取词）。 */
  async function buildTextLayer(layer, textContent, viewport) {
    layer.textContent = "";
    if (!textContent) return 0;

    if (PDFJS && typeof PDFJS.renderTextLayer === "function") {
      try {
        const scale = (viewport && viewport.scale) || 1;
        layer.style.setProperty("--scale-factor", String(scale));
        if (typeof PDFJS.setLayerDimensions === "function") {
          try { PDFJS.setLayerDimensions(layer, viewport, true); } catch (e) { /* 尺寸交给 CSS */ }
        }
        const task = PDFJS.renderTextLayer({
          textContentSource: textContent,
          container: layer,
          viewport,
          textDivs: []
        });
        await task.promise;
        return layer.querySelectorAll("span").length;
      } catch (e) {
        console.warn("[WH PDF] renderTextLayer 失败，退回手写文本层", e);
        layer.textContent = "";
      }
    }

    const Util = PDFJS && PDFJS.Util;
    if (!Util) return 0;
    const frag = document.createDocumentFragment();
    const styles = textContent.styles || {};
    let count = 0;
    for (const item of textContent.items) {
      const str = item && item.str;
      if (!str) continue;
      let tx;
      try {
        tx = Util.transform(viewport.transform, item.transform);
      } catch (e) { continue; }
      const angle = Math.atan2(tx[1], tx[0]);
      const fontHeight = Math.hypot(tx[2], tx[3]) || 10;
      const style = styles[item.fontName] || {};
      let ascent = fontHeight;
      if (typeof style.ascent === "number") ascent = style.ascent * fontHeight;
      else if (typeof style.descent === "number") ascent = (1 + style.descent) * fontHeight;

      const span = document.createElement("span");
      span.textContent = str;
      span.dataset.line = str;
      span.style.left = tx[4] + "px";
      span.style.top = (tx[5] - ascent) + "px";
      span.style.fontSize = fontHeight + "px";
      span.style.fontFamily = style.fontFamily || "sans-serif";
      if (angle) span.style.transform = "rotate(" + angle + "rad)";
      // 目标宽度先记下来，等 span 真正进 DOM 有了布局再按它做 scaleX
      const targetW = (Number(item.width) || 0) * (viewport.scale || 1);
      if (!angle && targetW > 0) {
        span.style.display = "inline-block";
        span.style.whiteSpace = "pre";
        span.style.transformOrigin = "0 0";
        span.dataset.targetW = String(targetW);
      }
      frag.appendChild(span);
      count++;
    }
    layer.appendChild(frag);
    for (const span of layer.querySelectorAll("span[data-target-w]")) {
      const target = Number(span.dataset.targetW) || 0;
      if (target <= 0) continue;
      const natural = span.getBoundingClientRect().width;
      if (natural > 1) span.style.transform = "scaleX(" + (target / natural) + ")";
      delete span.dataset.targetW;
    }
    return count;
  }

  /* ---------------- 取词 ---------------- */
  function wordAtPoint(x, y) {
    let node = null;
    let offset = 0;
    try {
      if (document.caretPositionFromPoint) {
        const p = document.caretPositionFromPoint(x, y);
        if (p) { node = p.offsetNode; offset = p.offset; }
      } else if (document.caretRangeFromPoint) {
        const r = document.caretRangeFromPoint(x, y);
        if (r) { node = r.startContainer; offset = r.startOffset; }
      }
    } catch (e) { return null; }
    if (!node || node.nodeType !== Node.TEXT_NODE) return null;
    const text = node.nodeValue || "";
    let a = offset;
    let b = offset;
    while (a > 0 && /[A-Za-z'’\-]/.test(text[a - 1])) a--;
    while (b < text.length && /[A-Za-z'’\-]/.test(text[b])) b++;
    let word = text.slice(a, b);
    if (!word) {
      // 点在词与词之间：往右/往左补一个词
      const right = text.slice(b).match(/^[^A-Za-z]*([A-Za-z][A-Za-z'’\-]*)/);
      const left = text.slice(0, a).match(/([A-Za-z][A-Za-z'’\-]*)[^A-Za-z]*$/);
      word = (right && right[1]) || (left && left[1]) || "";
    }
    word = word.replace(/^[^A-Za-z]+|[^A-Za-z]+$/g, "");
    if (!word || word.length < 2) return null;
    const span = node.parentElement && node.parentElement.closest(".wh-pdf-text span");
    return { word, ctx: span ? (span.dataset.line || "") : "" };
  }

  function openCardAt(x, y) {
    const hit = wordAtPoint(x, y);
    if (!hit) return false;
    if (typeof window.WH_SHOW_CARD !== "function") {
      setStatus("查词卡片未就绪（content.js 未加载），请重新加载扩展", true);
      return false;
    }
    window.WH_SHOW_CARD(hit.word, x, y, hit.ctx);
    return true;
  }

  /* ---------------- 【v2.25.10】快捷键中心 ----------------
   * 阅读器原来只认「右键 / 单击」，完全不看「快捷键中心」里的配置：
   * 用户在设置里把「取词卡片」改了键，阅读器里却按不出；单击还会随手弹卡。
   * 现在和网页层共用同一套规则（hotkeys_util.js）：设置里绑了什么键就按什么键。
   * 阅读器自己没法做的动作（截图翻译 / 整页翻译）给一句明确提示，而不是静默。
   */
  const HKU = (typeof window !== "undefined" && window.WH_HOTKEYS) || null;
  let lastMouse = null;

  async function loadHotkeys() {
    if (!HKU) return;
    try {
      const s = await chrome.storage.sync.get({ hotkeys: null, ocrHotkey: "Alt+X" });
      const raw = s.hotkeys || null;
      state.hkEnabled = !(raw && raw.enabled === false);
      state.hkBindings = HKU.normalizeBindings(raw && raw.bindings, s.ocrHotkey);
    } catch (e) { /* ignore */ }
  }

  function hotkeyActionFor(e) {
    if (!HKU || !state.hkEnabled || !e) return "";
    return HKU.actionFromEvent(e, state.hkBindings);
  }

  /** 取词卡片：锚点用鼠标位置（与网页层一致：按快捷键在鼠标处开卡） */
  function openCardFromHotkey() {
    const x = lastMouse ? lastMouse.x : Math.round(window.innerWidth / 2);
    const y = lastMouse ? lastMouse.y : Math.round(window.innerHeight / 3);
    if (!openCardAt(x, y)) setStatus("鼠标位置没有单词：把光标移到 PDF 里的单词上再按一次", true);
  }

  function runReaderHotkey(action) {
    switch (action) {
      case "openCard": openCardFromHotkey(); break;
      case "toggleHighlight": {
        const btn = document.getElementById("hl-btn");
        if (btn) btn.click();
        setStatus(state.highlightOn ? "PDF 生词高亮：开" : "PDF 生词高亮：关");
        break;
      }
      case "rescan":
        rerenderAll();
        setStatus("已重新渲染当前 PDF");
        break;
      case "openWordlist":
        try { chrome.tabs.create({ url: chrome.runtime.getURL("wordlist.html") }); } catch (e) { /* ignore */ }
        break;
      case "openSettings":
        try { chrome.runtime.openOptionsPage(); } catch (e) { /* ignore */ }
        break;
      case "ocrShot":
        setStatus("截图翻译要在普通网页上用（阅读器里没有可框选的网页层）", true);
        break;
      case "toggleTranslate":
        setStatus("整页翻译要在普通网页上用", true);
        break;
      case "pdfOpen":
        setStatus("已经在 Panda 阅读器里了");
        break;
      default:
        break;
    }
  }

  window.__WH_BUILD__ = "2.26.0";

  /* ---------------- 页面渲染 ---------------- */
  /** 页面可用宽度：工具栏已移到左侧，这里只需扣掉内容区左右内边距 */
  function viewerContentWidth() {
    const el = $("#viewer");
    const pad = document.body.classList.contains("wh-pdf-narrow") ? 16 : 40;
    return Math.max(200, (el ? el.clientWidth : window.innerWidth) - pad);
  }

  function fitScaleFor(viewWidth, page) {
    const base = page.getViewport({ scale: 1 });
    if (!state.fitWidth) return state.scale;
    return viewWidth / base.width;
  }

  async function renderSheet(sheet) {
    if (!state.pdf || sheet.rendering) return;
    sheet.rendering = true;
    try {
      const page = sheet.page || (sheet.page = await state.pdf.getPage(sheet.num));
      const scale = fitScaleFor(viewerContentWidth(), page);
      if (sheet.renderedScale && Math.abs(sheet.renderedScale - scale) < 0.001) {
        // 尺寸没变（如主题切换）→ 重建高亮即可
        rebuildHighlights();
        return;
      }
      const viewport = page.getViewport({ scale });
      state.effScale = scale;      // 记录"当前真正显示的比例"，供 +/- 以它为基准
      const ratio = Math.min(3, Math.max(1, window.devicePixelRatio || 1));
      const canvas = sheet.canvas;
      canvas.width = Math.floor(viewport.width * ratio);
      canvas.height = Math.floor(viewport.height * ratio);
      canvas.style.width = viewport.width + "px";
      canvas.style.height = viewport.height + "px";
      sheet.el.style.width = viewport.width + "px";
      sheet.el.style.height = viewport.height + "px";
      sheet.text.style.width = viewport.width + "px";
      sheet.text.style.height = viewport.height + "px";

      // 【v2.25.22】willReadFrequently：让画布走软件后端，drawImage 读回来一定是当前内容
      // （之前高倍率下读到的可能是上一张/未落盘的位图，导致逐词拟合反而更差）
      const ctx = canvas.getContext("2d", { alpha: false, willReadFrequently: true });
      const task = page.render({
        canvasContext: ctx,
        viewport,
        transform: ratio !== 1 ? [ratio, 0, 0, ratio, 0, 0] : null
      });
      sheet.task = task;
      await task.promise;
      sheet.task = null;
      sheet.canvasKey = canvas.width + "x" + canvas.height + "@" + scale;

      const tc = await page.getTextContent();
      sheet.words = buildWordIndex(sheet, tc, viewport);
      await buildTextLayer(sheet.text, tc, viewport);
      sheet.renderedScale = scale;
      // 【v2.26.0】画布刚画完、词表刚建好，就在这一刻按墨迹收紧（此时画布一定是当前这张）
      try { refineWordBoxes(sheet); sheet.wordsRefinedAt = scale; } catch (e) { sheet.__refineErr = String((e && e.stack) || e); }
      sheet.text.dataset.rendered = "1";
      const zoomLabel = $("#zoom-label");
      if (zoomLabel) zoomLabel.textContent = Math.round(scale * 100) + "%";
      rebuildHighlights();
      updateStats();
    } catch (e) {
      if (e && e.name === "RenderingCancelledException") return;
      console.warn("[WH PDF] 渲染失败 #" + sheet.num, e);
    } finally {
      sheet.rendering = false;
    }
  }

  function updateStats() {
    const spans = state.sheets.reduce((n, s) => n + (s.renderedScale ? s.text.querySelectorAll("span").length : 0), 0);
    window.__WH_PDF_STATS__ = {
      pages: state.pageCount,
      rendered: state.sheets.filter((s) => !!s.renderedScale).length,
      textSpans: spans,
      src: state.src || "(file)",
      fileName: state.fileName,
      highlightOn: state.highlightOn
    };
  }

  /** 建页骨架（先按比例占位，渲染时再校正尺寸） */
  function buildSheets(aspect) {
    const viewer = $("#viewer");
    viewer.textContent = "";
    state.sheets = [];
    if (observer) observer.disconnect();

    const frag = document.createDocumentFragment();
    for (let i = 1; i <= state.pageCount; i++) {
      const el = document.createElement("div");
      el.className = "wh-pdf-sheet";
      el.dataset.page = String(i);
      const width = viewerContentWidth();
      el.style.width = width + "px";
      el.style.height = Math.round(width * aspect) + "px";

      const canvas = document.createElement("canvas");
      const text = document.createElement("div");
      text.className = "wh-pdf-text";
      el.appendChild(canvas);
      el.appendChild(text);
      frag.appendChild(el);

      const sheet = { el, num: i, canvas, text, page: null, renderedScale: 0, rendering: false, task: null };
      state.sheets.push(sheet);
      if (observer) observer.observe(el);
    }
    viewer.appendChild(frag);
  }

  let observer = null;
  function ensureObserver() {
    if (observer || typeof IntersectionObserver !== "function") return;
    observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        const num = Number(entry.target.dataset.page);
        const sheet = state.sheets[num - 1];
        if (sheet) renderSheet(sheet);
      }
    }, { root: null, rootMargin: "900px 0px" });
  }

  /** 当前页跟随滚动：取「顶边已越过视口顶部」的最后一页，避免多页同时相交时页码乱跳 */
  let scrollRaf = 0;
  function syncCurrentFromScroll() {
    if (!state.sheets.length) return;
    const edge = 12;
    let best = 1;
    for (const sheet of state.sheets) {
      const rect = sheet.el.getBoundingClientRect();
      if (rect.top - edge <= 0) best = sheet.num;
      else break;
    }
    if (best === state.current) return;
    state.current = best;
    const pi = $("#page-input");
    if (pi && document.activeElement !== pi) pi.value = String(best);
  }
  function onScroll() {
    if (scrollRaf) return;
    scrollRaf = requestAnimationFrame(() => { scrollRaf = 0; syncCurrentFromScroll(); });
  }

  /* ---------------- 打开文档 ---------------- */
  function showEmpty(err) {
    const empty = $("#empty");
    if (empty) empty.classList.remove("hidden");
    if (err) {
      const box = $("#empty-err");
      if (box) { box.textContent = err; box.classList.remove("hidden"); }
    }
  }
  function hideEmpty() {
    const empty = $("#empty");
    if (empty) empty.classList.add("hidden");
    const cands = $("#shell-cands");
    if (cands) { cands.textContent = ""; cands.classList.add("hidden"); }
  }

  /* ---------- 【v2.25.2】外壳 → 真 PDF 的候选列表 & 记忆 ---------- */
  const SHELL_MAP_KEY = "wh_pdfShellMap";
  const SHELL_MAP_TTL = 7 * 24 * 3600e3;

  async function shellMapGet(shellUrl) {
    try {
      if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) return "";
      const o = await chrome.storage.local.get(SHELL_MAP_KEY);
      const map = o[SHELL_MAP_KEY] || {};
      const hit = map[shellUrl];
      if (hit && hit.pdf && Date.now() - (hit.ts || 0) < SHELL_MAP_TTL) return hit.pdf;
    } catch (e) { /* ignore */ }
    return "";
  }

  async function shellMapSet(shellUrl, pdfUrl) {
    try {
      if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) return;
      const o = await chrome.storage.local.get(SHELL_MAP_KEY);
      const map = o[SHELL_MAP_KEY] || {};
      map[shellUrl] = { pdf: pdfUrl, ts: Date.now() };
      // 只留最近 50 条，避免越攒越大
      const keys = Object.keys(map);
      if (keys.length > 50) {
        keys.sort((a, b) => (map[a].ts || 0) - (map[b].ts || 0));
        for (const k of keys.slice(0, keys.length - 50)) delete map[k];
      }
      await chrome.storage.local.set({ [SHELL_MAP_KEY]: map });
    } catch (e) { /* ignore */ }
  }

  /** 空状态里列出「这个网页里找到的 PDF 地址」，点哪个开哪个 */
  function renderShellCandidates(list, shellUrl) {
    const box = $("#shell-cands");
    if (!box) return;
    box.textContent = "";
    if (!Array.isArray(list) || list.length < 2) { box.classList.add("hidden"); return; }
    const title = document.createElement("div");
    title.className = "wh-pdf-cands-title";
    title.textContent = "这个网页里找到 " + list.length + " 个可能的 PDF 地址（点一下打开）：";
    box.appendChild(title);
    for (const url of list.slice(0, 6)) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "wh-pdf-cand";
      btn.title = url;
      const short = (() => {
        try {
          const u = new URL(url);
          const name = decodeURIComponent(u.pathname.split("/").pop() || u.hostname);
          return name.length > 46 ? name.slice(0, 44) + "…" : name;
        } catch (e) { return url.slice(0, 46); }
      })();
      btn.textContent = short;
      btn.addEventListener("click", async () => {
        setStatus("正在打开：" + short);
        const opened = await openRemote(url, 1, shellUrl);
        if (!opened) setStatus("这个地址没能打开，换一个试试", true);
      });
      box.appendChild(btn);
    }
    box.classList.remove("hidden");
  }

  /** 把一个地址当 PDF 取下来（成功返回 true） */
  async function loadUrlAsPdf(url, name) {
    try {
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return false;
      const buf = new Uint8Array(await res.arrayBuffer());
      if (!looksLikePdf(buf)) return false;
      await loadDocument(buf, name || decodeURIComponent((url.split("?")[0].split("/").pop() || url)));
      return true;
    } catch (e) {
      return false;
    }
  }

  async function loadDocument(source, name) {
    if (!PDFJS) {
      showEmpty("pdf.js 未能加载（vendor/pdfjs 缺失），请重新安装扩展。");
      return;
    }
    try {
      setStatus("正在解析 PDF …");
      const task = source instanceof Uint8Array
        ? PDFJS.getDocument({ data: source })
        : PDFJS.getDocument({ url: source, withCredentials: true });
      const pdf = await task.promise;
      state.pdf = pdf;
      state.pageCount = pdf.numPages;
      state.fileName = name || "";
      state.current = 1;
      hideEmpty();
      const totalEl = $("#page-total");
      if (totalEl) totalEl.textContent = "/" + pdf.numPages;
      const pageInput = $("#page-input");
      if (pageInput) pageInput.value = "1";
      const openBtn = $("#open-btn");
      if (openBtn) openBtn.title = "打开本地 PDF 文件 · 当前：" + (name || "未打开");

      let aspect = ASPECT_FALLBACK;
      try {
        const first = await pdf.getPage(1);
        const vp = first.getViewport({ scale: 1 });
        if (vp.width > 0) aspect = vp.height / vp.width;
      } catch (e) { /* ignore */ }

      ensureObserver();
      buildSheets(aspect);
      await loadHighlightSets();
      setStatus("已打开：" + (name || "PDF") + "（" + pdf.numPages + " 页）");
      // 首屏立刻渲染第一页（其余交给 IntersectionObserver）
      if (state.sheets[0]) renderSheet(state.sheets[0]);
      document.title = (name || "PDF") + " - Panda PDF 阅读";
    } catch (e) {
      const msg = String((e && e.message) || e);
      showEmpty("打开失败：" + msg);
      setStatus("打开失败：" + msg, true);
    }
  }

  /** 字节流是不是 PDF（实现见 pdf-open-util.js，方便单测） */
  const PDFOPEN = (typeof window !== "undefined" && window.WH_PDF_OPEN) || null;
  function looksLikePdf(buf) {
    return PDFOPEN ? PDFOPEN.looksLikePdf(buf) : false;
  }
  /** 从「网页外壳」里找真正的 PDF 地址（pdf.js viewer 之类的 ?file=xxx.pdf） */
  function findPdfUrlInHtml(html, baseUrl) {
    return PDFOPEN ? PDFOPEN.findPdfUrlInHtml(html, baseUrl) : [];
  }
  function describeNonPdf(contentType, htmlLike) {
    return PDFOPEN ? PDFOPEN.describeContent(contentType, htmlLike) : "非 PDF 内容";
  }

  /** 打开远程/本地地址。
   *  @param {string} src   要打开的地址
   *  @param {number} depth 已经剥过几层「网页外壳」（防死循环）
   *  @param {string} root  最初粘进来的地址（成功后用来记「外壳 → 真 PDF」）
   *  @returns {Promise<string>} 成功打开的 PDF 地址（失败返回 ""） */
  async function openRemote(src, depth, root) {
    const level = depth || 0;
    const rootSrc = root || src;
    state.src = src;
    if (/^file:/i.test(src)) {
      // 本地文件：扩展被允许访问文件网址时可直接 fetch（实测 200 + 完整字节），失败才引导手动选文件
      try {
        setStatus("正在读取本地文件 …");
        const res = await fetch(src);
        if (!res.ok) throw new Error("HTTP " + res.status);
        const buf = new Uint8Array(await res.arrayBuffer());
        await loadDocument(buf, decodeURIComponent(src.split("/").pop() || src));
        return src;
      } catch (e) {
        const msg = String((e && e.message) || e);
        const allowed = await fileAccessAllowed();
        hideEmpty();
        showEmpty(allowed
          ? "读取本地文件失败（" + msg + "）。可以改用「选择本地 PDF」，或把文件拖进这个窗口。"
          : "本插件还没有「访问文件网址」权限，所以读不到 file:// 路径。\n"
            + "开启方法：edge://extensions（Chrome 是 chrome://extensions）→ 本插件「详情」→ 打开「允许访问文件网址」/「允许访问文件 URL」，回到这个页面按 F5 重试。\n"
            + "不想改权限的话：直接用「选择本地 PDF」或把文件拖进窗口。");
        return "";
      }
    }

    const baseName = decodeURIComponent((src.split("?")[0].split("#")[0].split("/").pop() || src));

    // 【v2.25.2】同一个外壳地址成功过一次就记住，下次直接开，省掉整轮探测
    if (level === 0) {
      const mapped = await shellMapGet(src);
      if (mapped) {
        setStatus("用上次记住的地址打开 …");
        if (await loadUrlAsPdf(mapped)) return mapped;
        // 记住的地址失效了（文件被删/换签）：走正常流程重新探测
      }
    }

    // 自己取字节再判断类型：pdf.js 直接吃 URL 时，网页外壳只会抛「Invalid PDF structure」，
    // 用户看不出「你粘的是阅读器页面，不是 PDF 文件」（v2.25.1）
    try {
      setStatus("正在获取 PDF …");
      const res = await fetch(src, { credentials: "include" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const buf = new Uint8Array(await res.arrayBuffer());
      const ctype = String(res.headers.get("content-type") || "").toLowerCase();

      if (looksLikePdf(buf) || ctype.includes("application/pdf")) {
        await loadDocument(buf, baseName);
        return src;
      }

      // 不是 PDF：多半是网页（HTML 外壳）。先把真正的 PDF 地址挖出来
      const text = new TextDecoder("utf-8", { fatal: false }).decode(buf.subarray(0, 400000));
      const cands = findPdfUrlInHtml(text, src);

      // 【v2.25.2】HTML 里没有线索时，顺着页面引用的同源脚本再找一层：
      // pdf.js 官方的 viewer.html 就是这样——默认文件写在 viewer.mjs 的 defaultUrl 里
      if (!cands.length && level < 2) {
        const scripts = PDFOPEN ? PDFOPEN.collectScriptSrcs(text, src, { limit: 3 }) : [];
        const hits = [];
        for (const jsUrl of scripts) {
          setStatus("在页面脚本里找 PDF 地址 …");
          try {
            const jr = await fetch(jsUrl, { credentials: "include" });
            if (!jr.ok) continue;
            const jsText = (await jr.text()).slice(0, 2 * 1024 * 1024);
            const ranked = PDFOPEN.findPdfInTextRanked(jsText, jsUrl);
            if (ranked.length) hits.push(ranked);
            // 命中「明确的默认地址」就不用再翻其它脚本
            if (ranked.some((x) => x.score === 0)) break;
          } catch (e) { /* 单个脚本失败不影响其它 */ }
        }
        for (const u of PDFOPEN.mergeScriptCandidates(hits, src)) {
          if (!cands.includes(u)) cands.push(u);
        }
      }

      if (cands.length && level < 2) {
        setStatus("这是网页外壳，正在打开里面的 PDF …");
        renderShellCandidates(cands, rootSrc);
        const opened = await openRemote(cands[0], level + 1, rootSrc);
        if (opened) {
          if (level === 0 && opened !== rootSrc) await shellMapSet(rootSrc, opened);
          return opened;
        }
        // 第一个没开成：把候选列表重新铺上让用户手选（递归层里的 hideEmpty 会清掉它）
        showEmpty("外壳里找到的 " + cands.length + " 个地址没能直接打开，可以点下面的候选试试，或直接粘 PDF 直链。");
        renderShellCandidates(cands, rootSrc);
        return "";
      }

      const kind = describeNonPdf(ctype, /^\s*</.test(text));
      hideEmpty();
      showEmpty(
        "这个地址返回的是" + kind + "，不是 PDF 文件本身 —— 所以 pdf.js 报「Invalid PDF structure」。\n"
        + "你粘的多半是别人网站的「PDF 阅读器页面」（比如 pdf.js 的 viewer.html），那只是外壳，里面才指向真正的 PDF。\n\n"
        + "三种可行做法：\n"
        + "· 粘 PDF 直链：以 .pdf 结尾的地址（或带 ?file=xxx.pdf 的阅读器地址，我会自动取里面那一个）；\n"
        + "· 在阅读器页面里先把 PDF 下载/另存到本地，再用「选择本地 PDF」打开（取词体验最稳）；\n"
        + "· 如果是网页里嵌的 PDF，用页面右下角的「用 Panda 打开此 PDF」浮标，它会自动取真实地址。"
      );
      setStatus("打开失败：这不是 PDF 文件", true);
      return "";
    } catch (e) {
      const msg = String((e && e.message) || e);
      hideEmpty();
      showEmpty("打开失败：" + msg + "\n（如果这个地址在浏览器里也打不开，可能是需要登录、或站点禁止第三方读取）");
      setStatus("打开失败：" + msg, true);
      return "";
    }
  }

  /** 扩展是否被允许访问 file:// （没权限时 fetch 本地文件必然失败） */
  async function fileAccessAllowed() {
    try {
      if (chrome.extension && chrome.extension.isAllowedFileSchemeAccess) {
        return await chrome.extension.isAllowedFileSchemeAccess();
      }
    } catch (e) { /* ignore */ }
    return false;
  }

  async function openFile(file) {
    if (!file) return;
    if (!/\.pdf$/i.test(file.name) && file.type !== "application/pdf") {
      showEmpty("这个文件看起来不是 PDF：" + file.name);
      return;
    }
    const buf = new Uint8Array(await file.arrayBuffer());
    await loadDocument(buf, file.name);
  }

  /* ---------------- 交互绑定 ---------------- */
  function bindUI() {
    $("#open-btn").addEventListener("click", () => $("#file-input").click());
    $("#empty-open").addEventListener("click", () => $("#file-input").click());
    $("#file-input").addEventListener("change", (e) => {
      const f = e.target.files && e.target.files[0];
      if (f) openFile(f);
    });

    // 在线 PDF：直接粘链接（不少站点地址不以 .pdf 结尾，如 ?file=123）
    const openUrlInput = () => {
      const input = $("#url-input");
      const raw = (input && input.value || "").trim();
      if (!raw) { input && input.focus(); return; }
      let url = raw;
      if (!/^https?:\/\//i.test(url) && !/^file:/i.test(url)) url = "https://" + url;
      state.src = "";
      hideEmpty();
      setStatus("正在加载：" + url);
      openRemote(url);
    };
    $("#url-open").addEventListener("click", openUrlInput);
    $("#url-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") openUrlInput();
    });

    // 拖放
    let dragDepth = 0;
    window.addEventListener("dragenter", (e) => {
      if (!e.dataTransfer || !Array.from(e.dataTransfer.types || []).includes("Files")) return;
      dragDepth++;
      document.body.classList.add("wh-pdf-dragging");
    });
    window.addEventListener("dragover", (e) => { e.preventDefault(); });
    window.addEventListener("dragleave", () => {
      dragDepth = Math.max(0, dragDepth - 1);
      if (!dragDepth) document.body.classList.remove("wh-pdf-dragging");
    });
    window.addEventListener("drop", (e) => {
      if (!e.dataTransfer || !e.dataTransfer.files || !e.dataTransfer.files.length) return;
      e.preventDefault();
      dragDepth = 0;
      document.body.classList.remove("wh-pdf-dragging");
      openFile(e.dataTransfer.files[0]);
    });

    // 翻页
    const goPage = (n) => {
      const num = Math.min(Math.max(1, n | 0), state.pageCount || 1);
      const sheet = state.sheets[num - 1];
      if (!sheet) return;
      sheet.el.scrollIntoView({ block: "start", behavior: "smooth" });
      state.current = num;
      $("#page-input").value = String(num);
    };
    $("#prev-btn").addEventListener("click", () => goPage(state.current - 1));
    $("#next-btn").addEventListener("click", () => goPage(state.current + 1));
    $("#page-input").addEventListener("keydown", (e) => {
      if (e.key !== "Enter") return;
      const n = parseInt(e.target.value, 10);
      if (Number.isFinite(n)) goPage(n);
      e.target.blur();
    });

    // 缩放
    const setZoom = (next) => {
      state.fitWidth = false;
      state.scale = Math.min(4, Math.max(0.4, next));
      rerenderAll();
    };
    // 【v2.26.3】+/- 必须以"当前实际显示比例"为基准。
    // 旧写法用 state.scale，而 fitWidth 状态下 state.scale 一直停在 1（真实比例在 effScale 里），
    // 于是"251% 点 + 变成 115%"—— 用户看到的就是这个。
    const curScale = () => (state.fitWidth ? (state.effScale || state.scale || 1) : (state.scale || 1));
    $("#zoom-in").addEventListener("click", () => setZoom(curScale() * 1.15));
    $("#zoom-out").addEventListener("click", () => setZoom(curScale() / 1.15));
    $("#fit-btn").addEventListener("click", () => { state.fitWidth = true; rerenderAll(); });
    window.addEventListener("resize", () => {
      if (!state.fitWidth || !state.pdf) return;
      debouncedRerender();
    });

    // 高亮开关
    $("#hl-btn").addEventListener("click", () => {
      state.highlightOn = !state.highlightOn;
      const btn = $("#hl-btn");
      btn.setAttribute("aria-pressed", state.highlightOn ? "true" : "false");
      btn.title = "生词高亮：" + (state.highlightOn ? "开" : "关") + "（点击切换）";
      const label = $("#hl-label");
      if (label) label.textContent = state.highlightOn ? "高亮：开" : "高亮：关";
      rebuildHighlights();
      updateStats();
    });

    // 反色（白底 PDF 在夜间模式下更护眼；深色幻灯片保持原样）
    $("#invert-btn").addEventListener("click", async () => {
      const next = !document.body.classList.contains("wh-pdf-invert");
      applyInvert(next);
      try { await chrome.storage.sync.set({ pdfInvert: next }); } catch (e) { /* ignore */ }
    });

    // 当前页跟随滚动
    window.addEventListener("scroll", onScroll, { passive: true });

    // 主题 / 生词本
    $("#theme-btn").addEventListener("click", async () => {
      const dark = document.documentElement.getAttribute("data-wh-theme") === "dark";
      applyTheme(!dark);
      try { await chrome.storage.sync.set({ theme: dark ? "light" : "dark" }); } catch (e) { /* ignore */ }
    });
    $("#wordlist-btn").addEventListener("click", () => {
      try { chrome.tabs.create({ url: chrome.runtime.getURL("wordlist.html") }); } catch (e) { /* ignore */ }
    });
    // 侧边栏里给一个出口：同一份 PDF 换到独立标签页看
    $("#tab-open-btn").addEventListener("click", () => {
      const base = chrome.runtime.getURL("pdf-reader.html");
      const target = state.src ? base + "?src=" + encodeURIComponent(state.src) : base;
      try { chrome.tabs.create({ url: target }); } catch (e) { /* ignore */ }
    });

    // 取词：右键开卡（无命中时保留浏览器原生菜单）—— 与网页层一致
    $("#viewer").addEventListener("contextmenu", (e) => {
      if (openCardAt(e.clientX, e.clientY)) e.preventDefault();
    });
    // 【v2.25.10】单击不再开卡：网页层也不会「点一下就弹卡」，触发方式统一为
    // 「右键」或「快捷键中心 → 取词卡片」绑定的键（原来那一下单击很容易误触）。
    // 记录鼠标位置，供快捷键在「鼠标处的单词」上开卡。
    document.addEventListener("mousemove", (e) => { lastMouse = { x: e.clientX, y: e.clientY }; }, { passive: true });

    // 键盘
    document.addEventListener("keydown", (e) => {
      const tag = (e.target && e.target.tagName) || "";
      if (/INPUT|TEXTAREA|SELECT/.test(tag)) return;
      // Esc 关释义卡片（内部页面里 content.js 不注册按键监听，这里自己处理）
      if (e.key === "Escape") {
        if (typeof window.WH_HIDE_CARD === "function") window.WH_HIDE_CARD();
        return;
      }
      // 先走「快捷键中心」的绑定（用户在设置里改的键要优先）
      const action = hotkeyActionFor(e);
      if (action) {
        e.preventDefault();
        runReaderHotkey(action);
        return;
      }
      if (e.key === "ArrowRight" || e.key === "PageDown") { goPage(state.current + 1); e.preventDefault(); }
      else if (e.key === "ArrowLeft" || e.key === "PageUp") { goPage(state.current - 1); e.preventDefault(); }
      else if (e.key === "+" || e.key === "=") { setZoom((state.scale || 1) * 1.15); }
      else if (e.key === "-") { setZoom((state.scale || 1) / 1.15); }
    });

    // 设置/生词本变化 → 重算高亮
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        // 【v2.25.10】快捷键改了要立刻生效（不用重开阅读器）
        if (area === "sync" && (changes.hotkeys || changes.ocrHotkey)) loadHotkeys();
        const hitSync = area === "sync" && (changes.level || changes.levels || changes.userWords || changes.knownWords);
        const hitLocal = area === "local" && changes.wh_wordbook;
        if (!hitSync && !hitLocal) return;
        loadHighlightSets().then(rebuildHighlights);
      });
    } catch (e) { /* ignore */ }
  }

  let rerenderTimer = 0;
  function debouncedRerender() {
    clearTimeout(rerenderTimer);
    rerenderTimer = setTimeout(rerenderAll, 180);
  }

  /** 尺寸/缩放变化：清掉已渲染标记，重新渲染视口内的页 */
  function rerenderAll() {
    const viewer = $("#viewer");
    if (!state.pdf) return;
    const width = viewerContentWidth();
    for (const sheet of state.sheets) {
      if (sheet.task) { try { sheet.task.cancel(); } catch (e) { /* ignore */ } }
      sheet.renderedScale = 0;
      sheet.text.textContent = "";
      sheet.text.removeAttribute("data-rendered");
    }
    // 【v2.25.13】高亮是自绘矩形，清空即可（原来这里调 CSS.highlights 的注册表，已移除）
    for (const sheet of state.sheets) clearHlLayer(sheet);
    // 高度先按最新宽度占位，避免滚动条跳动
    const first = state.sheets[0];
    const aspect = first && first.canvas.height && first.canvas.width
      ? first.canvas.height / first.canvas.width
      : ASPECT_FALLBACK;
    for (const sheet of state.sheets) {
      sheet.el.style.width = width + "px";
      sheet.el.style.height = Math.round(width * aspect) + "px";
    }
    const zoomLabel = $("#zoom-label");
    if (zoomLabel) zoomLabel.textContent = Math.round((state.fitWidth ? (state.effScale || 1) : (state.scale || 1)) * 100) + "%";
    // 只重渲当前页附近，其余靠 IntersectionObserver 自然补上
    const near = [state.current - 1, state.current, state.current + 1];
    for (const idx of near) {
      const sheet = state.sheets[idx];
      if (sheet) renderSheet(sheet);
    }
  }

  /** 侧边栏（窄栏）布局：只改标签与间距，不改结构 —— 面板里还要能翻页/缩放/取词 */
  function updateLayoutMode() {
    const narrow = window.innerWidth < 620;
    const changed = document.body.classList.contains("wh-pdf-narrow") !== narrow;
    document.body.classList.toggle("wh-pdf-narrow", narrow);
    const t = $("#tab-open-btn");
    if (t) t.classList.toggle("hidden", !narrow);
    if (changed && state.pdf && state.fitWidth) debouncedRerender();
  }

  /* ---------------- 启动 ---------------- */
  async function boot() {
    if (PDFJS) {
      try {
        PDFJS.GlobalWorkerOptions.workerSrc = IS_EXT
          ? chrome.runtime.getURL("vendor/pdfjs/pdf.worker.min.js")
          : "vendor/pdfjs/pdf.worker.min.js";
      } catch (e) { /* ignore */ }
    }
    await initTheme();
    await loadHotkeys(); // 【v2.25.10】先读到快捷键配置，再绑交互
    bindUI();
    updateLayoutMode();
    window.addEventListener("resize", updateLayoutMode, { passive: true });
    $("#hl-btn").setAttribute("aria-pressed", "true");
    const params = new URLSearchParams(location.search);
    const src = params.get("src") || "";
    if (src) {
      await openRemote(src);
      return;
    }
    showEmpty("");
  }

  document.addEventListener("DOMContentLoaded", boot);
  window.__WH_PDF__ = { state, loadDocument, openFile, openRemote, wordAtPoint, rebuildHighlights };
  // 调试用：看「行」是怎么分的（不参与业务逻辑）
  window.__WH_PDF_LINES__ = (sheetEl) => groupLines((sheetEl || document.querySelector(".wh-pdf-sheet")).querySelector(".wh-pdf-text"));
})();
