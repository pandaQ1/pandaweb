/* 生词高亮 & 翻译助手 —— popup 逻辑 v2.1 */
"use strict";

const $ = (sel) => document.querySelector(sel);
const IS_EXT = WH_STORE.IS_EXT;

/* 存储 helper：使用共享 storage.js 模块 */
const STORE = {
  async get(defs) { return WH_STORE.syncGet(defs); },
  async set(patch) { return WH_STORE.syncSet(patch); },
  async localGet(key) { return WH_STORE.localGet(key); }
};

function isProMembership(st) {
  if (!st || !st.signed_in || !st.pro) return false;
  if (!st.expires_at) return true;
  const t = typeof st.expires_at === "number" ? st.expires_at : Date.parse(st.expires_at);
  return Number.isFinite(t) && t > Date.now();
}

async function refreshState() {
  const s = await STORE.get({ enabled: true, theme: "light", translateEnabled: false, level: "none", translateMode: "replace", noTranslateSites: [] });
  $("#toggle").checked = s.enabled;
  updateThemeBtn(s.theme);
  updateTrBtn(s.translateEnabled);
  updateTrModeBtn(s.translateMode);
  // 白名单按钮状态（当前标签页 hostname 是否已加入）
  updateWlBtn(await currentTabInWhitelist(s.noTranslateSites || []));
  // 【v2.22.0】PDF 入口：当前页是 PDF 才显示
  updatePdfBtn(await currentTabInfo());
  // 小窗口自身跟随主题（与设置页一致）
  let resolved = s.theme;
  if (s.theme === "auto") {
    resolved = (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light";
  }
  document.documentElement.setAttribute("data-wh-theme", resolved);
  // 【v2.25.8】镜像偏好到 localStorage：theme-boot.js 下次同步读它，首帧就是正确明暗
  try { localStorage.setItem("wh_theme", s.theme); } catch (e) { /* 忽略 */ }
  const ver = $("#ver");
  if (ver && IS_EXT && chrome.runtime && chrome.runtime.getManifest) {
    ver.textContent = "v" + chrome.runtime.getManifest().version;
  }
  try {
    const w = await STORE.localGet("wh_wordbook");
    const wb = w.wh_wordbook || [];
    const cnt = $("#wb-count");
    const prev = cnt.textContent;
    cnt.textContent = wb.length;
    // 数字变化时轻微回弹（prefers-reduced-motion 时 ui-tokens.css 已禁用）
    if (prev !== String(wb.length)) {
      cnt.classList.remove("ui-pop");
      void cnt.offsetWidth;
      cnt.classList.add("ui-pop");
    }
  } catch (e) { /* ignore */ }
  // 账号状态：先读缓存立即渲染（PRO 用户不会因后台网络慢被误禁用），
  // 再等后台最新结果；超时则保留缓存，避免 1.5s 直接把 PRO 按钮锁死。
  if (IS_EXT) {
    let cached = null;
    try {
      const c = await STORE.localGet("wh_membership");
      cached = (c && c.wh_membership) || null;
    } catch (e) { /* ignore */ }
    updateAcctBtn(cached);
    applyProGate(cached);

    const st = await new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        resolve(cached);
      }, 6000);
      try {
        chrome.runtime.sendMessage({ type: "WH_AUTH_STATE" }, (r) => {
          void chrome.runtime.lastError;
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          resolve(r || cached);
        });
      } catch (e) {
        clearTimeout(timer);
        if (!settled) { settled = true; resolve(cached); }
      }
    });
    updateAcctBtn(st);
    applyProGate(st);
  }
}

/* 【v2.17.20】会员门禁：非 PRO 禁用 popup 内所有功能入口，显示激活横幅 */
function applyProGate(st) {
  const pro = isProMembership(st);
  const gate = $("#pro-gate");
  if (gate) gate.classList.toggle("hidden", pro);
  const ids = ["#toggle", "#tr-btn", "#trmode-btn", "#wl-btn", "#wordlist-btn", "#learn-btn", "#rescan", "#tr-go", "#tr-swap", "#tr-in", "#tr-shot"];
  for (const id of ids) {
    const el = $(id);
    if (el) el.disabled = !pro;
  }
  const toggle = $("#toggle");
  if (toggle && toggle.closest) {
    const row = toggle.closest(".switch-row");
    if (row) row.classList.toggle("is-disabled", !pro);
  }
}

/* 账号按钮：未登录显示“登录 / 注册”；已登录显示邮箱前缀，PRO 加金色徽章 */
function updateAcctBtn(st) {
  const lbl = document.querySelector("#acct-btn .lbl");
  const badge = $("#acct-badge");
  if (!lbl) return;
  if (!st || !st.signed_in) {
    lbl.textContent = "登录 / 注册";
    if (badge) badge.classList.add("hidden");
    return;
  }
  const prefix = (st.email || "").split("@")[0] || st.email || "";
  const pro = isProMembership(st);
  lbl.textContent = "账号：" + (prefix.length > 12 ? prefix.slice(0, 12) + "…" : prefix);
  if (badge) {
    badge.textContent = "PRO";
    badge.classList.toggle("hidden", !pro);
    badge.classList.toggle("pro", pro);
  }
}

/* 点击账号按钮 → 打开（或聚焦已打开的）设置页并定位到账号分区 */
async function openAccountPage() {
  if (!IS_EXT) return;
  const url = chrome.runtime.getURL("options.html#account");
  try {
    const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL("options.html") + "*" });
    if (tabs && tabs.length) {
      const t = tabs[0];
      await chrome.tabs.update(t.id, { url, active: true });
      if (t.windowId) { try { await chrome.windows.update(t.windowId, { focused: true }); } catch (e) { /* ignore */ } }
    } else {
      await chrome.tabs.create({ url });
    }
  } catch (e) {
    await chrome.tabs.create({ url });
  }
}

$("#acct-btn").addEventListener("click", async () => { await openAccountPage(); window.close(); });
$("#pro-gate-btn").addEventListener("click", async () => { await openAccountPage(); window.close(); });

/* 日/月线性图标（黑白极简风，stroke=currentColor 跟随按钮颜色） */
const ICON_MOON = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
const ICON_SUN = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';

function setLbl(sel, text) {
  const el = document.querySelector(sel + " .lbl");
  if (el) el.textContent = text;
}

function updateThemeBtn(theme) {
  const dark = theme === "dark";
  const btn = $("#theme-btn");
  if (btn) btn.innerHTML = (dark ? ICON_MOON : ICON_SUN) + '<span class="lbl">' + (dark ? "夜间" : "日间") + "</span>";
}

function updateTrBtn(on) {
  setLbl("#tr-btn", on ? "翻译：开" : "翻译：关");
}

function updateTrModeBtn(mode) {
  setLbl("#trmode-btn", mode === "replace" ? "覆盖式" : "对照式");
}

/* ============ 网页翻译白名单（命中的网址不进行网页翻译，生词高亮不受影响） ============ */

/** 当前标签页 hostname */
async function currentTabHost() {
  if (!IS_EXT) return "";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return (new URL(tab.url).hostname || "").replace(/^www\./, "");
  } catch (e) { return ""; }
}

/** 当前标签页是否已在白名单（hostname 匹配，支持子域） */
async function currentTabInWhitelist(list) {
  const host = await currentTabHost();
  if (!host) return false;
  return (list || []).some((raw) => {
    let entry = String(raw || "").trim().toLowerCase().replace(/^www\./, "");
    if (entry.includes("://")) { try { entry = new URL(entry).hostname.replace(/^www\./, ""); } catch (e) { return false; } }
    return host === entry || host.endsWith("." + entry);
  });
}

function updateWlBtn(inList) {
  setLbl("#wl-btn", inList ? "本站已不翻译（点击恢复）" : "本站不翻译");
  const btn = $("#wl-btn");
  if (btn) btn.classList.toggle("wl-active", inList);
}

/* 【v2.22.0】当前标签页是 PDF 时显示「PDF 取词」入口（内置阅读器无法注入取词） */
async function currentTabInfo() {
  if (!IS_EXT) return { url: "", title: "" };
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return { url: (tab && tab.url) || "", title: (tab && tab.title) || "" };
  } catch (e) { return { url: "", title: "" }; }
}

/** 【v2.25.9】PDF 取词入口常驻：不因当前页不是 PDF 而隐藏。
 *  当前页是 PDF（地址以 .pdf 结尾，或标题是 xxx.pdf —— 很多在线预览地址不带 .pdf）时记下地址，
 *  点击直接打开那一份；否则点击打开空白阅读器（可粘链接 / 拖文件）。 */
function updatePdfBtn(info) {
  const btn = $("#pdf-btn");
  if (!btn) return;
  const url = String((info && info.url) || "");
  const title = String((info && info.title) || "");
  // 【v2.26.2】用统一的判定模块（地址 / 标题 / 内置阅读器地址都能认）；
  // arxiv 那种 /pdf/2501.00001 不带 .pdf 的地址，靠这里就认出来了。
  const D = typeof WH_PDF_DETECT !== "undefined" ? WH_PDF_DETECT : null;
  const quick = D ? D.detect({ url: url, title: title }) : { isPdf: /\.pdf(\?|#|$)/i.test(url), url: url };
  let isPdf = !!quick.isPdf;
  const pdfUrl = quick.url || url;
  const paint = (on, target) => {
    btn.dataset.pdfUrl = on && /^(https?|file|chrome-extension):/i.test(target || "") && !/^chrome-extension:\/\//i.test(target || "") ? target : "";
    btn.classList.toggle("is-pdf", on);
    btn.title = on
      ? "当前页是 PDF：点这里用 Panda 阅读器打开（可悬停/右键取词、高亮生词）"
      : "用 Panda 阅读器打开 PDF：可以粘链接、拖入文件，或选本地 PDF";
  };
  paint(isPdf, pdfUrl);
  if (isPdf || !IS_EXT) return;
  // 地址/标题看不出来 → 让 background 问一次服务器（content-type），认出来就把按钮点亮
  try {
    chrome.runtime.sendMessage({ type: "WH_PDF_DETECT", tab: { url: url, title: title } }, (res) => {
      void chrome.runtime.lastError;
      if (res && res.isPdf) paint(true, res.url || url);
    });
  } catch (e) { /* ignore */ }
}

$("#wl-btn").addEventListener("click", async () => {
  const host = await currentTabHost();
  if (!host) return;
  const s = await STORE.get({ noTranslateSites: [] });
  const list = (s.noTranslateSites || []).map((x) => String(x || "").trim().toLowerCase()).filter(Boolean);
  const i = list.findIndex((e) => e.replace(/^www\./, "") === host);
  let added;
  if (i >= 0) { list.splice(i, 1); added = false; } else { list.push(host); added = true; }
  await STORE.set({ noTranslateSites: list });
  updateWlBtn(added);
});

$("#tr-btn").addEventListener("click", async () => {
  const s = await STORE.get({ translateEnabled: false });
  const next = !s.translateEnabled;
  await STORE.set({ translateEnabled: next });
  updateTrBtn(next);
});

/* 翻译效果切换：覆盖原文（整页翻译风格）/ 保留原文对照 */
$("#trmode-btn").addEventListener("click", async () => {
  const s = await STORE.get({ translateMode: "replace" });
  const next = s.translateMode === "replace" ? "inline" : "replace";
  await STORE.set({ translateMode: next, modeMigrated266: true });
  updateTrModeBtn(next);
});

$("#toggle").addEventListener("change", async (e) => {
  await STORE.set({ enabled: e.target.checked });
});

$("#theme-btn").addEventListener("click", async () => {
  const s = await STORE.get({ theme: "light" });
  const next = s.theme === "dark" ? "light" : "dark";
  await STORE.set({ theme: next });
  updateThemeBtn(next);
  // 实时同步小窗口自身主题（此前仅存 storage，需关闭重开 popup 才变化）
  document.documentElement.setAttribute("data-wh-theme", next);
});

$("#wordlist-btn").addEventListener("click", () => {
  if (!IS_EXT) return;
  chrome.tabs.create({ url: chrome.runtime.getURL("wordlist.html") });
});

/* 【v2.12.0】背单词：独立页面（与生词本模块分离） */
$("#learn-btn").addEventListener("click", () => {
  if (!IS_EXT) return;
  chrome.tabs.create({ url: chrome.runtime.getURL("learn.html") });
});

/* 【v2.25.9】PDF 取词常驻：当前页是 PDF 就直接打开它；不是 PDF 就打开空白阅读器（不拿网页地址去充数） */
$("#pdf-btn").addEventListener("click", async () => {
  if (!IS_EXT) return;
  const btn = $("#pdf-btn");
  const url = (btn && btn.dataset && btn.dataset.pdfUrl) || "";
  const target = chrome.runtime.getURL("pdf-reader.html") + (url ? "?src=" + encodeURIComponent(url) : "");
  chrome.tabs.create({ url: target });
  window.close();
});

$("#rescan").addEventListener("click", async () => {
  if (!IS_EXT) { window.close(); return; }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id) {
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "WH_RESCAN" });
    } catch (e) { /* ignore */ }
  }
  window.close();
});

$("#open-options").addEventListener("click", (e) => {
  e.preventDefault();
  if (!IS_EXT) return;
  chrome.runtime.openOptionsPage();
});

/* ============ 【v2.20.0】文本翻译框（中 ⇄ 英，跟随设置页的翻译服务） ============ */
const TR_BOX = {
  /** 含汉字 → 译成英文；否则 → 译成中文 */
  target(text) { return /[\u3400-\u9fff]/.test(String(text || "")) ? "en" : "zh-CN"; },
  setStatus(msg, kind) {
    const el = $("#tr-status");
    if (!el) return;
    el.textContent = msg || "";
    el.className = "tr-status" + (kind ? " tr-status-" + kind : "");
  },
  showResult(text) {
    const out = $("#tr-out");
    const copy = $("#tr-copy");
    if (!out) return;
    out.textContent = text;
    out.classList.toggle("hidden", !text);
    if (copy) copy.classList.toggle("hidden", !text);
  }
};

/* 【v2.20.1】发音：只朗读英文那一侧（英→中时读原文，中→英时读译文） */
const TR_SPEAK = {
  english: "",       // 当前可朗读的英文
  autoPending: false // 本次翻译是否要自动发音（输入像单词才读）
};

function looksLikeWord(text) {
  const t = String(text || "").trim();
  if (!t) return false;
  if (/[.!?。！？;；,，\n]/.test(t)) return false;   // 句子不自动读
  if (t.length > 32) return false;
  return t.split(/\s+/).filter(Boolean).length <= 2; // 单个词 / 两个词的短语
}

function speakEnglish() {
  const btn = $("#tr-speak");
  const text = TR_SPEAK.english;
  if (!text || !/^[\x00-\x7F]*[A-Za-z]/.test(text)) return;
  try {
    if (btn) {
      btn.classList.remove("ui-pop");
      void btn.offsetWidth;
      btn.classList.add("ui-pop");
    }
    if (window.WH_TTS && window.WH_TTS.speakText) window.WH_TTS.speakText(text);
  } catch (e) { /* ignore */ }
}

function updateSpeakButton(english) {
  TR_SPEAK.english = english && /[A-Za-z]/.test(english) ? english : "";
  const btn = $("#tr-speak");
  if (btn) btn.classList.toggle("hidden", !TR_SPEAK.english);
}

async function popupTranslate() {
  const input = $("#tr-in");
  if (!input) return;
  const text = String(input.value || "").trim();
  if (!text) { TR_BOX.setStatus("先输入要翻译的内容", "warn"); return; }
  const to = TR_BOX.target(text);
  const dir = $("#tr-dir");
  if (dir) dir.textContent = to === "en" ? "中 → 英" : "英 → 中";
  TR_BOX.setStatus("翻译中…", "busy");
  TR_BOX.showResult("");
  updateSpeakButton("");
  TR_SPEAK.autoPending = looksLikeWord(text);
  const s = await STORE.get({ translateService: "auto" });
  let res = null;
  try {
    res = await new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { type: "WH_TRANSLATE", text, service: s.translateService || "auto", lang: "auto", to },
        (r) => { void chrome.runtime.lastError; resolve(r || null); }
      );
    });
  } catch (e) {
    res = { ok: false, error: String((e && e.message) || e) };
  }
  if (!res || !res.ok) {
    TR_BOX.setStatus((res && (res.error || (res.need_pro ? "需要 PRO 会员" : ""))) || "翻译失败，请稍后重试", "warn");
    return;
  }
  const translated = String(res.text || "").trim();
  TR_BOX.setStatus("");
  TR_BOX.showResult(translated);
  // 朗读对象永远是英文那侧：中→英读译文，英→中读原文
  const english = to === "en" ? translated : text;
  updateSpeakButton(english);
  if (TR_SPEAK.autoPending && TR_SPEAK.english) speakEnglish();
  TR_SPEAK.autoPending = false;
}

/* 截图翻译：回到网页进入框选模式（与 Alt+X 一致，由内容脚本执行） */
async function startOcrFromPopup() {
  if (!IS_EXT) return;
  const btn = $("#tr-shot");
  if (btn) btn.disabled = true;
  TR_BOX.setStatus("回到网页后按住左键框选要翻译的区域…", "ok");
  let ok = false, err = "";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error("找不到当前标签页");
    const r = await chrome.tabs.sendMessage(tab.id, { type: "WH_OCR_START" });
    ok = !!(r && r.ok);
    err = (r && r.error) || "";
  } catch (e) {
    err = "当前页面不支持截图翻译（请在普通网页上使用）";
  }
  if (!ok) {
    if (btn) btn.disabled = false;
    TR_BOX.setStatus(err || "无法开始截图翻译", "warn");
    return;
  }
  window.close();
}

$("#tr-go").addEventListener("click", () => { popupTranslate(); });
$("#tr-in").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    popupTranslate();
  }
});
$("#tr-speak").addEventListener("click", () => { speakEnglish(); });
$("#tr-shot").addEventListener("click", () => { startOcrFromPopup(); });
/* ⇄：把译文放回输入框（等于"反向再翻一次"，方便对照） */
$("#tr-swap").addEventListener("click", () => {
  const out = $("#tr-out");
  const input = $("#tr-in");
  if (!out || !input) return;
  const t = String(out.textContent || "").trim();
  if (!t) return;
  input.value = t;
  input.focus();
  TR_BOX.showResult("");
  updateSpeakButton("");
  TR_BOX.setStatus("已放回输入框，按翻译可再翻回去", "ok");
});
$("#tr-copy").addEventListener("click", async () => {
  const out = $("#tr-out");
  const btn = $("#tr-copy");
  const t = out ? String(out.textContent || "").trim() : "";
  if (!t || !btn) return;
  try {
    await navigator.clipboard.writeText(t);
    btn.textContent = "已复制";
    setTimeout(() => (btn.textContent = "复制"), 1200);
  } catch (e) { /* ignore */ }
});

if (!IS_EXT) {
  const w = $("#env-warn");
  if (w) w.classList.remove("hidden");
  document.querySelectorAll("button").forEach((b) => (b.disabled = true));
  $("#toggle").disabled = false;
}

refreshState();
