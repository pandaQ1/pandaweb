"""Regenerate the small icon sizes from icons/icon128.png.

The artwork (panda face + play triangle) is kept in icon128.png so this script
does not overwrite it. Edit icon128.png first, then run:
    python make_icon.py
"""
from pathlib import Path

from PIL import Image

base = Path(__file__).resolve().parent / "icons"
src = base / "icon128.png"
if not src.exists():
    raise SystemExit("icons/icon128.png is missing")

img = Image.open(src).convert("RGBA")
for size in (16, 48):
    img.resize((size, size), Image.LANCZOS).save(base / f"icon{size}.png")
print("icons 16/48 regenerated from icon128.png")
