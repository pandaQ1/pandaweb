"use strict";

const $ = (id) => document.getElementById(id);
const currentSpeedEl = $("currentSpeed");
const statusEl = $("status");
const powerBtn = $("powerBtn");
const playPauseBtn = $("playPause");
const volumeToggle = $("volumeToggle");
const volumeSlider = $("volumeSlider");
const volumeValue = $("volumeValue");
const pandaTabs = document.querySelector(".panda-tabs");

const DEFAULT_FILTERS = {
  brightness: 100, contrast: 100, saturation: 100, hue: 0, gamma: 100,
  rotate: 0, flipH: false, flipV: false, scale: 100, aspect: "auto"
};
const DEFAULT_SUBTITLE = {
  fontSize: 22, fontFamily: "system", color: "#ffffff", stroke: "#000000",
  opacity: 1, position: "bottom", offset: 0
};
const accountBar = $("accountBar");
const accountText = $("accountText");
const accountAction = $("accountAction");
const authLoading = $("authLoading");
const gate = $("gate");
const gateDesc = $("gateDesc");
const gateBtn = $("gateBtn");
const controls = $("controls");
const actions = $("actions");
const rescanBtn = $("rescan");

const MANIFEST_VERSION = (() => {
  try { return chrome.runtime.getManifest().version; } catch (e) { return "2.1.0"; }
})();
$("ver").textContent = "v" + MANIFEST_VERSION;

let state = {
  rate: 1, hasVideo: false, playing: false, enabled: true,
  volume: 1, muted: false, time: 0, duration: 0,
  loop: "none", ab: { a: 0, b: 0 }, intro: 0, outro: 0, skipRules: [],
  filters: { ...DEFAULT_FILTERS }, subtitle: { ...DEFAULT_SUBTITLE },
  subtitleCues: { primary: 0, secondary: 0 },
  display: { fullscreen: false, webFullscreen: false, pip: false },
  recording: false, quality: null, audioTracks: [],
  pageError: ""
};
let membership = null;
let loading = true;
let authError = "";
let injectCache = { tabId: null, promise: null };
let lastVideoFrameId = null;
let statusTimer = null;
let volumeTimer = null;
let volumeDragging = false;
let filterTimer = null;
let subtitleTimer = null;

function isMembershipPro(m) {
  if (!m || !m.signed_in || !m.pro) return false;
  if (!m.expires_at) return true;
  const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
  return Number.isFinite(t) && t > Date.now();
}

function isPro() { return isMembershipPro(membership); }

function formatRate(r) {
  const n = Math.round(r * 100) / 100;
  return (Number.isInteger(n) ? n.toFixed(1) : String(n)) + "x";
}

/* ---------------- 与页面内容脚本通信 ---------------- */

async function getActiveTab() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs && tabs[0] ? tabs[0] : null;
  } catch (e) {
    return null;
  }
}

function isRestrictedUrl(url) {
  const u = String(url || "");
  if (!u) return false;
  if (/^(chrome|edge|about|devtools|view-source|chrome-extension|extension):/i.test(u)) return true;
  return /^https?:\/\/(chrome\.google\.com\/webstore|chromewebstore\.google\.com|microsoftedge\.microsoft\.com\/addons)/i.test(u);
}

function ensureInjected(tab) {
  if (!tab || !tab.id) return Promise.reject(new Error("no_tab"));
  if (injectCache.tabId === tab.id && injectCache.promise) return injectCache.promise;
  const p = (async () => {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        files: ["content.js", "advanced.js"]
      });
      try {
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id, allFrames: true },
          files: ["advanced.css"]
        });
      } catch (e) { /* CSS 注入失败时 advanced.js 仍会回退到内联样式 */ }
      return;
    } catch (e) {
      // 个别受限子框架会导致整批注入失败 → 逐帧重试，能注入的都注入
      const frames = await getFrameIds(tab.id);
      const results = await Promise.all(frames.map((frameId) =>
        chrome.scripting.executeScript({
          target: { tabId: tab.id, frameIds: [frameId] },
          files: ["content.js", "advanced.js"]
        }).then(() => true).catch(() => false)
      ));
      if (!results.some(Boolean)) throw e;
    }
  })();
  injectCache = { tabId: tab.id, promise: p };
  p.catch(() => {
    if (injectCache.promise === p) injectCache = { tabId: null, promise: null };
  });
  return p;
}

function getAllFrames(tabId) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (frames) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve(Array.isArray(frames) ? frames : []);
    };
    const timer = setTimeout(() => finish([]), 800);
    try {
      chrome.webNavigation.getAllFrames({ tabId }, (frames) => {
        if (chrome.runtime.lastError) {
          finish([]);
          return;
        }
        finish(frames);
      });
    } catch (e) {
      finish([]);
    }
  });
}

async function getFrameIds(tabId) {
  const frames = await getAllFrames(tabId);
  if (frames.length) return frames.map((f) => f.frameId);
  return [0];
}

function sendToFrame(tabId, frameId, message, timeoutMs = 2500) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve(null);
    }, timeoutMs);
    try {
      chrome.tabs.sendMessage(tabId, message, { frameId }, (resp) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (chrome.runtime.lastError) {
          resolve(null);
          return;
        }
        resolve(resp == null ? null : resp);
      });
    } catch (e) {
      clearTimeout(timer);
      if (!settled) { settled = true; resolve(null); }
    }
  });
}

async function queryVideoFrames(tab, frames) {
  const states = await Promise.all(
    frames.map((frameId) => sendToFrame(tab.id, frameId, { type: "GET_STATE" }, 2500))
  );
  const withVideo = states
    .map((s, i) => ({ state: s, frameId: frames[i] }))
    .filter((x) => x.state && x.state.hasVideo)
    .sort((a, b) => (b.state.area || 0) - (a.state.area || 0));
  return { states, best: withVideo[0] || null };
}

async function sendActive(type, extra = {}, opts = {}) {
  const tab = await getActiveTab();
  if (!tab || !tab.id) return { error: "没有可操作的活动标签页" };
  if (isRestrictedUrl(tab.url)) return { error: "浏览器内置页面 / 扩展商店页面不支持插件" };

  try {
    await ensureInjected(tab);
  } catch (e) {
    return { error: "无法在当前页面运行（页面受保护或未授予访问权限）" };
  }

  const frames = await getFrameIds(tab.id);

  // 音量滑块等高频操作可复用上次识别到的视频 frame，避免每次拖动都重新查询所有 frame
  if (opts.frameId != null) {
    const directTimeout = type === "GIF_RANGE" ? 60000
      : type === "DOWNLOAD_VIDEO" ? 30000
        : type === "RECORD_RANGE" ? 8000
          : type === "SCREENSHOT" || type === "SCREENSHOT_SUB" ? 8000
            : type === "LOAD_SUBTITLE" || type === "GET_QUALITY" ? 5000 : 2000;
    const direct = await sendToFrame(tab.id, opts.frameId, { type, ...extra }, directTimeout);
    if (direct) return direct;
  }

  // 开关 / 步进同步给所有框架；其余操作只作用于“面积最大的视频所在框架”，
  // 避免同一页面里的广告、预览视频被一起改速或一起截图。
  if (type === "SET_ENABLED" || type === "SET_STEP") {
    const results = await Promise.all(
      frames.map((frameId) => sendToFrame(tab.id, frameId, { type, ...extra }, 2500))
    );
    const valid = results.filter((r) => r && typeof r === "object");
    if (!valid.length) return { error: "当前页面没有可控制的视频" };
    return valid.find((r) => !r.blocked && !r.error) || valid[0];
  }

  const query = await queryVideoFrames(tab, frames);
  if (query.best) lastVideoFrameId = query.best.frameId;
  if (type === "GET_STATE") {
    if (query.best) return query.best.state;
    return query.states.find((s) => s && typeof s === "object") || { error: "当前页面没有可控制的视频" };
  }

  const target = query.best;
  if (!target) return { error: "当前页面没有可控制的视频" };
  lastVideoFrameId = target.frameId;

  const resp = await sendToFrame(tab.id, target.frameId, { type, ...extra }, type === "SCREENSHOT" ? 8000 : (type === "GIF_RANGE" ? 60000 : (type === "DOWNLOAD_VIDEO" ? 30000 : (type === "RECORD_RANGE" ? 8000 : 2500))));
  if (resp) return resp;
  return { error: type === "SCREENSHOT" ? "截图超时，视频可能过大" : "操作超时，请重试" };
}

/* ---------------- 会员状态 ---------------- */

function sendBg(type, extra = {}, timeoutMs = 15000) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({ ok: false, error: "账号服务响应超时" });
    }, timeoutMs);
    try {
      chrome.runtime.sendMessage({ type, ...extra }, (resp) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message || "后台服务不可用" });
          return;
        }
        resolve(resp || { ok: false, error: "后台服务无响应" });
      });
    } catch (e) {
      clearTimeout(timer);
      if (!settled) { settled = true; resolve({ ok: false, error: String((e && e.message) || e) }); }
    }
  });
}

async function readCachedMembership() {
  try {
    const o = await chrome.storage.local.get("panda_membership");
    return (o && o.panda_membership) || null;
  } catch (e) {
    return null;
  }
}

async function loadMembership(force = false) {
  authError = "";

  const cached = await readCachedMembership();
  if (cached) {
    membership = cached;
    loading = false;
    paintAuth();
  } else if (!membership) {
    loading = true;
    paintAuth();
  }

  const res = await sendBg(force ? "PANDA_REFRESH" : "PANDA_AUTH_STATE");
  if (res && res.ok && res.membership) {
    membership = res.membership;
    authError = "";
  } else if (!membership) {
    authError = (res && res.error) || "账号服务无响应";
  }
  loading = false;
  paintAuth();
  return membership;
}

/* ---------------- 渲染 ---------------- */

function paintAuth() {
  const pro = isPro();
  const signedIn = !!(membership && membership.signed_in);
  const showLoading = loading && !membership;

  accountBar.dataset.state = showLoading ? "loading" : pro ? "pro" : signedIn ? "free" : authError ? "error" : "anon";

  if (showLoading) {
    accountText.textContent = "正在校验会员状态…";
    accountAction.textContent = "…";
  } else if (pro) {
    accountText.textContent = (membership.offline ? "离线 · PRO · " : "PRO · ") + (membership.email || "已登录");
    accountAction.textContent = "管理";
  } else if (signedIn) {
    accountText.textContent = (membership.offline ? "离线 · " : "") + "免费版 · " + (membership.email || "已登录");
    accountAction.textContent = "激活";
  } else if (authError) {
    accountText.textContent = "账号状态校验失败";
    accountAction.textContent = "重试";
  } else {
    accountText.textContent = "未登录";
    accountAction.textContent = "登录";
  }

  authLoading.classList.toggle("hidden", !showLoading);
  gate.classList.toggle("hidden", pro || showLoading);
  controls.classList.toggle("hidden", !pro);
  rescanBtn.classList.toggle("hidden", !pro);
  actions.classList.toggle("solo", !pro);

  if (!pro && !showLoading) {
    if (authError && !signedIn) {
      gateDesc.textContent = "无法连接账号服务：" + authError + "。请检查网络后重试。";
      gateBtn.textContent = "重试";
    } else if (signedIn) {
      const who = membership.email ? "当前账号 " + membership.email : "当前账号";
      const reason = String(membership.reason || "");
      const expired = /过期/.test(reason);
      const invalid = /异常/.test(reason);
      gateDesc.textContent = invalid
        ? who + " 的会员有效期数据异常，请联系客服处理。"
        : expired
          ? who + " 的会员已过期。续费或兑换后即可继续使用。"
          : who + " 尚未开通会员。激活后即可使用倍速、逐帧、定格与截图功能。";
      gateBtn.textContent = "激活会员";
    } else {
      gateDesc.textContent = "登录 Panda 账号并激活会员后，即可使用倍速、逐帧、定格与截图全部功能。";
      gateBtn.textContent = "登录 / 注册";
    }
  }

  render();
}

function paintVolume() {
  const muted = !!state.muted || !(Number(state.volume) > 0);
  const percent = muted ? 0 : Math.round(Number(state.volume) * 100);
  volumeSlider.value = String(percent);
  volumeValue.textContent = percent + "%";
  volumeToggle.classList.toggle("muted", muted);
  volumeToggle.title = muted ? "取消静音" : "静音";
  volumeToggle.setAttribute("aria-label", muted ? "取消静音" : "静音");
  const disabled = !isPro() || !state.enabled || !state.hasVideo;
  volumeSlider.disabled = disabled;
  volumeToggle.disabled = disabled;
}

function fmtTime(sec) {
  const s = Math.max(0, Math.floor(Number(sec) || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  return (h ? h + ":" : "") + String(m).padStart(2, "0") + ":" + String(r).padStart(2, "0");
}

function applyAdvancedState(r) {
  if (!r) return;
  if (typeof r.loop === "string") state.loop = r.loop;
  if (r.ab && typeof r.ab === "object") state.ab = { a: Number(r.ab.a) || 0, b: Number(r.ab.b) || 0 };
  if (Number.isFinite(Number(r.intro))) state.intro = Math.max(0, Number(r.intro));
  if (Number.isFinite(Number(r.outro))) state.outro = Math.max(0, Number(r.outro));
  if (Array.isArray(r.skipRules)) state.skipRules = r.skipRules;
  if (r.filters && typeof r.filters === "object") state.filters = { ...state.filters, ...r.filters };
  if (r.subtitle && typeof r.subtitle === "object") state.subtitle = { ...state.subtitle, ...r.subtitle };
  if (r.subtitleCues && typeof r.subtitleCues === "object") state.subtitleCues = r.subtitleCues;
  if (r.display && typeof r.display === "object") state.display = { ...state.display, ...r.display };
  if (typeof r.recording === "boolean") state.recording = r.recording;
  if (r.quality && typeof r.quality === "object") state.quality = r.quality;
  if (Array.isArray(r.audioTracks)) state.audioTracks = r.audioTracks;
  if (Number.isFinite(Number(r.time))) state.time = Number(r.time);
  if (Number.isFinite(Number(r.duration))) state.duration = Number(r.duration);
}

function setValue(id, value) {
  const el = $(id);
  if (el && document.activeElement !== el) el.value = String(value);
}

function paintRecordUI() {
  const modeEl = $("recordMode");
  const durationEl = $("recordDuration");
  const btn = $("recordBtn");
  const hint = $("recordHint");
  if (!modeEl || !btn) return;
  const mode = modeEl.value;
  if (durationEl) durationEl.classList.toggle("hidden", mode !== "duration");
  if (state.recording) {
    btn.textContent = "录制中…";
  } else {
    btn.textContent = mode === "full" ? "录制片头 → 片尾"
      : mode === "current" ? "录制当前 → 片尾" : "录制当前片段";
  }
  if (hint) {
    hint.textContent = mode === "full"
      ? "从片头 0:00 录制到片尾；长视频文件会较大。"
      : mode === "current"
        ? "从当前播放位置录制到片尾。"
        : "从当前位置录制所选秒数；跨域 / DRM 视频可能没有声音。";
  }
}

function paintAdvanced() {
  if (!pandaTabs) return;
  setValue("loopMode", state.loop);
  const abInfo = $("abInfo");
  if (abInfo) {
    abInfo.textContent = state.ab.b > state.ab.a
      ? "A " + fmtTime(state.ab.a) + " → B " + fmtTime(state.ab.b)
      : "未设置 A/B 点";
  }
  setValue("skipIntro", state.intro);
  setValue("skipOutro", state.outro);

  const ruleList = $("ruleList");
  if (ruleList) {
    ruleList.textContent = "";
    state.skipRules.forEach((rule, index) => {
      const row = document.createElement("div");
      row.className = "adv-rule";
      const span = document.createElement("span");
      span.textContent = fmtTime(rule.start) + " → " + fmtTime(rule.end) + " · " + (rule.label || "跳过");
      const del = document.createElement("button");
      del.type = "button";
      del.className = "x";
      del.textContent = "移除";
      del.addEventListener("click", () => removeSkipRule(index));
      row.appendChild(span);
      row.appendChild(del);
      ruleList.appendChild(row);
    });
  }

  const f = state.filters;
  const filterDefs = [
    ["filterBrightness", "brightness", "valBrightness", "%"],
    ["filterContrast", "contrast", "valContrast", "%"],
    ["filterSaturation", "saturation", "valSaturation", "%"],
    ["filterHue", "hue", "valHue", "°"],
    ["filterGamma", "gamma", "valGamma", "%"]
  ];
  for (const [id, key, valId, unit] of filterDefs) {
    setValue(id, f[key]);
    const val = $(valId);
    if (val) val.textContent = f[key] + unit;
  }
  setValue("rotateSelect", f.rotate);
  setValue("aspectSelect", f.aspect);
  setValue("scaleSelect", f.scale);
  const fh = $("flipH");
  const fv = $("flipV");
  if (fh) fh.setAttribute("aria-pressed", String(!!f.flipH));
  if (fv) fv.setAttribute("aria-pressed", String(!!f.flipV));

  const sub = state.subtitle;
  setValue("subSize", sub.fontSize);
  setValue("subFont", sub.fontFamily || "system");
  setValue("subPosition", sub.position);
  setValue("subColor", sub.color);
  setValue("subStroke", sub.stroke);
  setValue("subOffset", sub.offset);
  setValue("subOpacity", Math.round((Number(sub.opacity) || 1) * 100));
  const subInfo = $("subInfo");
  if (subInfo) {
    const p = state.subtitleCues.primary || 0;
    const s = state.subtitleCues.secondary || 0;
    subInfo.textContent = p || s
      ? "主字幕 " + p + " 条" + (s ? " · 第二字幕 " + s + " 条" : "")
      : "未加载字幕";
  }
  const opacityVal = $("valSubOpacity");
  if (opacityVal) opacityVal.textContent = Math.round((Number(sub.opacity) || 1) * 100) + "%";

  const full = $("fullscreenBtn");
  const web = $("webFullscreenBtn");
  const pip = $("pipBtn");
  if (full) full.setAttribute("aria-pressed", String(!!state.display.fullscreen));
  if (web) web.setAttribute("aria-pressed", String(!!state.display.webFullscreen));
  if (pip) pip.setAttribute("aria-pressed", String(!!state.display.pip));

  const q = state.quality;
  const qualityInfo = $("qualityInfo");
  if (qualityInfo) {
    qualityInfo.classList.toggle("hidden", !q);
    qualityInfo.textContent = q
      ? q.width + "×" + q.height + " · " + (q.fps ? "~" + q.fps + " fps" : "FPS 未知")
        + " · 码率 " + (q.bitrate ? q.bitrate + " kbps" : "未知")
        + " · " + (q.codec || "编码未知")
      : "";
  }

  const audio = $("audioTrack");
  const audioBlock = $("audioBlock");
  if (audioBlock) audioBlock.classList.toggle("hidden", !(state.audioTracks || []).length);
  if (audio) {
    const tracks = state.audioTracks || [];
    const prev = audio.value;
    audio.textContent = "";
    if (!tracks.length) {
      const o = document.createElement("option");
      o.value = "";
      o.textContent = "当前视频未暴露多音轨";
      audio.appendChild(o);
      audio.disabled = true;
    } else {
      audio.disabled = false;
      for (const t of tracks) {
        const o = document.createElement("option");
        o.value = String(t.index);
        o.textContent = (t.label || t.language || "音轨 " + (t.index + 1)) + (t.enabled ? "（当前）" : "");
        audio.appendChild(o);
      }
      audio.value = tracks.find((t) => t.enabled) ? String(tracks.find((t) => t.enabled).index) : prev;
    }
  }
  const recordBtn = $("recordBtn");
  if (recordBtn) recordBtn.textContent = state.recording ? "录制中…" : "录制当前片段";
  paintRecordUI();

  const locked = !isPro() || !state.enabled || !state.hasVideo;
  document.querySelectorAll("#controls .panda-pane button, #controls .panda-pane input, #controls .panda-pane select")
    .forEach((el) => {
      // 总开关必须在“已关闭”状态下仍可点击，否则关闭后就再也打不开了
      if (el.id !== "powerBtn") el.disabled = locked;
    });
  const audio2 = $("audioTrack");
  if (audio2) audio2.disabled = locked || !(state.audioTracks || []).length;
}

function render() {
  const pro = isPro();
  const locked = !pro || !state.enabled;
  const r = Math.round(state.rate * 100) / 100;

  currentSpeedEl.textContent = formatRate(r);
  document.querySelectorAll(".q-btn[data-rate]").forEach((b) => {
    b.classList.toggle("active", Math.abs(parseFloat(b.dataset.rate) - r) < 0.001);
  });
  // 显示“点击后会执行的动作”：播放中 → 定格；已暂停 → 播放
  playPauseBtn.querySelector(".lbl").textContent = state.playing ? "定格" : "播放";
  powerBtn.checked = state.enabled;

  document.querySelectorAll(".q-btn, .mini-btn").forEach((el) => {
    el.disabled = locked;
  });
  powerBtn.disabled = !pro;
  paintVolume();
  paintAdvanced();

  if (state.pageError) {
    statusEl.textContent = state.pageError;
  } else if (!state.enabled) {
    statusEl.textContent = "插件已关闭";
  } else if (state.hasVideo) {
    statusEl.textContent = "已连接视频 · " + formatRate(r);
  } else {
    statusEl.textContent = "当前页面未检测到视频";
  }
}

function flashStatus(text, ms = 2400) {
  statusEl.textContent = text;
  if (statusTimer) clearTimeout(statusTimer);
  statusTimer = setTimeout(() => {
    statusTimer = null;
    render();
  }, ms);
}

async function syncVideoState() {
  const r = await sendActive("GET_STATE");
  if (r && !r.error) {
    state.rate = Number.isFinite(r.rate) ? r.rate : 1;
    state.hasVideo = !!r.hasVideo;
    state.playing = !!r.playing;
    state.volume = Number.isFinite(r.volume) ? Math.max(0, Math.min(1, r.volume)) : 1;
    state.muted = !!r.muted;
    state.time = Number.isFinite(r.time) ? r.time : 0;
    state.duration = Number.isFinite(r.duration) ? r.duration : 0;
    state.pageError = "";
    if (typeof r.enabled === "boolean") state.enabled = r.enabled;
    applyAdvancedState(r);
  } else {
    state.hasVideo = false;
    state.pageError = (r && r.error) || "无法连接当前页面";
  }
  render();
  return r;
}

async function refresh() {
  try {
    const stored = await chrome.storage.local.get(["enabled"]);
    state.enabled = stored.enabled !== false;
  } catch (e) { /* ignore */ }

  await loadMembership(false);
  if (isPro()) {
    await syncVideoState();
  } else {
    state.hasVideo = false;
    render();
  }
}

/* ---------------- 操作封装 ---------------- */

async function act(type, extra, opts) {
  if (!isPro()) {
    paintAuth();
    return null;
  }
  const r = await sendActive(type, extra, opts || { frameId: lastVideoFrameId });
  if (!r) return null;
  if (r.error) {
    flashStatus(r.error);
    return null;
  }
  if (r.blocked) {
    if (r.need_pro) {
      flashStatus("会员状态已失效，请重新登录");
      loading = true;
      paintAuth();
      await loadMembership(true);
    } else if (r.disabled) {
      state.enabled = false;
      flashStatus("插件已关闭");
      render();
    } else {
      flashStatus("操作被拦截");
    }
    return null;
  }
  return r;
}

function openAccount() {
  try {
    const p = chrome.tabs.create({ url: chrome.runtime.getURL("options.html#account") });
    if (p && typeof p.catch === "function") {
      p.catch(() => {
        try { chrome.runtime.openOptionsPage(); } catch (e) { /* ignore */ }
      });
    }
  } catch (e) {
    chrome.runtime.openOptionsPage();
  }
  window.close();
}

/* ---------------- 交互 ---------------- */

async function applyVolume() {
  if (!isPro()) return;
  const r = await act("SET_VOLUME", { volume: state.volume }, { frameId: lastVideoFrameId });
  if (r && Number.isFinite(r.volume) && !volumeDragging) {
    state.volume = Math.max(0, Math.min(1, r.volume));
    state.muted = !!r.muted;
    paintVolume();
  }
}

volumeSlider.addEventListener("input", () => {
  const v = Math.max(0, Math.min(100, Number(volumeSlider.value) || 0)) / 100;
  state.volume = v;
  state.muted = v === 0;
  volumeDragging = true;
  paintVolume();
  if (volumeTimer) clearTimeout(volumeTimer);
  volumeTimer = setTimeout(() => {
    volumeTimer = null;
    applyVolume();
  }, 160);
});

volumeSlider.addEventListener("change", () => {
  volumeDragging = false;
  if (volumeTimer) { clearTimeout(volumeTimer); volumeTimer = null; }
  applyVolume();
});

volumeToggle.onclick = async () => {
  const r = await act("TOGGLE_MUTE", {}, { frameId: lastVideoFrameId });
  if (r && Number.isFinite(r.volume)) {
    state.volume = Math.max(0, Math.min(1, r.volume));
    state.muted = !!r.muted;
    render();
  }
};

/* ---------------- 功能模块可见性 ---------------- */
let modules = {
  speed: true, volume: true, frame: true, display: true,
  loop: true, skip: true, subtitle: true, filters: true, tools: true
};

function applyModules() {
  const show = (id, on) => {
    const el = $(id);
    if (el) el.classList.toggle("hidden", !on);
  };
  show("volumeRow", modules.volume);
  show("rateRow", modules.speed);
  show("speedGrid", modules.speed);
  show("frameGrid", modules.frame);
  show("displayBlock", modules.display);
  show("loopBlock", modules.loop);
  show("abBlock", modules.loop);
  show("skipBlock", modules.skip);

  const tabs = {
    play: true,
    loop: modules.display || modules.loop,
    picture: modules.filters,
    subtitle: modules.subtitle,
    skip: modules.skip,
    tools: modules.tools
  };
  if (pandaTabs) {
    pandaTabs.querySelectorAll("button[data-tab]").forEach((b) => {
      b.classList.toggle("hidden", !tabs[b.dataset.tab]);
    });
    const active = pandaTabs.querySelector("button[data-tab].active");
    if (active && active.classList.contains("hidden")) {
      const play = pandaTabs.querySelector('button[data-tab="play"]');
      if (play) play.click();
    }
  }
}

async function loadModules() {
  try {
    const o = await chrome.storage.local.get("panda_settings");
    const m = o && o.panda_settings && o.panda_settings.modules;
    if (m && typeof m === "object") modules = { ...modules, ...m };
  } catch (e) { /* ignore */ }
  applyModules();
}

/* ---------------- 分类 tabs ---------------- */
if (pandaTabs) {
  pandaTabs.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-tab]");
    if (!btn) return;
    const tab = btn.dataset.tab;
    pandaTabs.querySelectorAll("button[data-tab]").forEach((b) => b.classList.toggle("active", b === btn));
    document.querySelectorAll(".panda-pane").forEach((p) => {
      p.classList.toggle("active", p.id === "pane-" + tab);
    });
  });
  const initialTab = (location.hash || "").replace("#", "");
  if (initialTab) {
    const btn = pandaTabs.querySelector('button[data-tab="' + initialTab + '"]');
    if (btn) btn.click();
  }
}

/* ---------------- 循环 / 显示 / 跳过 ---------------- */
$("loopMode").onchange = async () => {
  const r = await act("SET_LOOP", { mode: $("loopMode").value });
  if (r && r.loop) { state.loop = r.loop; paintAdvanced(); }
  else { $("loopMode").value = state.loop; }
};

$("fullscreenBtn").onclick = async () => {
  const r = await act("TOGGLE_FULLSCREEN");
  if (r && r.display) { applyAdvancedState(r); paintAdvanced(); }
  else if (r && r.pendingGesture) flashStatus("请在页面上点击“进入全屏”按钮");
};
$("webFullscreenBtn").onclick = async () => {
  const r = await act("TOGGLE_WEB_FULLSCREEN");
  if (r && r.display) { applyAdvancedState(r); paintAdvanced(); }
};
$("pipBtn").onclick = async () => {
  const r = await act("TOGGLE_PIP");
  if (r && r.display) { applyAdvancedState(r); paintAdvanced(); }
  else if (r && r.pendingGesture) flashStatus("请在页面上点击“进入画中画”按钮");
};

async function sendAB(action) {
  const r = await act("SET_AB", { action });
  if (r && r.ab) { state.ab = r.ab; paintAdvanced(); }
}
$("markA").onclick = () => sendAB("a");
$("markB").onclick = () => sendAB("b");
$("clearAB").onclick = () => sendAB("clear");

async function sendSkip(patch) {
  const r = await act("SET_SKIP", patch);
  if (r && !r.error) { applyAdvancedState(r); paintAdvanced(); }
  return r;
}
$("saveSkip").onclick = async () => {
  const intro = Math.max(0, Number($("skipIntro").value) || 0);
  const outro = Math.max(0, Number($("skipOutro").value) || 0);
  const r = await sendSkip({ intro, outro });
  if (r && !r.error) flashStatus("已保存跳过设置");
};
$("addRule").onclick = async () => {
  const start = Number($("ruleStart").value);
  const end = Number($("ruleEnd").value);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
    flashStatus("请输入有效的规则起止时间");
    return;
  }
  const rules = state.skipRules.concat({ start, end, label: "自定义片段" });
  await sendSkip({ rules });
  $("ruleStart").value = "";
  $("ruleEnd").value = "";
};
function removeSkipRule(index) {
  const rules = state.skipRules.filter((_, i) => i !== index);
  sendSkip({ rules });
}
$("clearProgress").onclick = async () => {
  const r = await act("CLEAR_PROGRESS");
  if (r && r.ok) flashStatus("已清除本视频播放进度");
};

/* ---------------- 画面 ---------------- */
function filterStateFromInputs() {
  return {
    brightness: Number($("filterBrightness").value),
    contrast: Number($("filterContrast").value),
    saturation: Number($("filterSaturation").value),
    hue: Number($("filterHue").value),
    gamma: Number($("filterGamma").value),
    rotate: Number($("rotateSelect").value),
    flipH: $("flipH").getAttribute("aria-pressed") === "true",
    flipV: $("flipV").getAttribute("aria-pressed") === "true",
    scale: Number($("scaleSelect").value),
    aspect: $("aspectSelect").value
  };
}

async function sendFilters() {
  const filters = filterStateFromInputs();
  state.filters = { ...state.filters, ...filters };
  const r = await act("SET_FILTERS", { filters });
  if (r && r.filters) state.filters = { ...state.filters, ...r.filters };
  paintAdvanced();
}

function queueFilters() {
  if (filterTimer) clearTimeout(filterTimer);
  filterTimer = setTimeout(() => { filterTimer = null; sendFilters(); }, 160);
}

const filterInputs = ["filterBrightness", "filterContrast", "filterSaturation", "filterHue", "filterGamma"];
filterInputs.forEach((id) => {
  const el = $(id);
  if (!el) return;
  el.addEventListener("input", () => {
    state.filters[id.replace("filter", "").toLowerCase()] = Number(el.value);
    paintAdvanced();
    queueFilters();
  });
});
["rotateSelect", "aspectSelect", "scaleSelect"].forEach((id) => {
  const el = $(id);
  if (el) el.addEventListener("change", sendFilters);
});
$("flipH").onclick = () => {
  const pressed = $("flipH").getAttribute("aria-pressed") === "true";
  $("flipH").setAttribute("aria-pressed", String(!pressed));
  state.filters.flipH = !pressed;
  sendFilters();
};
$("flipV").onclick = () => {
  const pressed = $("flipV").getAttribute("aria-pressed") === "true";
  $("flipV").setAttribute("aria-pressed", String(!pressed));
  state.filters.flipV = !pressed;
  sendFilters();
};
$("resetFilters").onclick = async () => {
  const r = await act("RESET_FILTERS");
  if (r && r.filters) { state.filters = { ...DEFAULT_FILTERS, ...r.filters }; paintAdvanced(); }
};

/* ---------------- 字幕 ---------------- */
async function loadSubtitleFile(input, track) {
  const file = input && input.files && input.files[0];
  if (!file) return;
  const name = String(file.name || "");
  const ext = (name.split(".").pop() || "").toLowerCase();
  let text = "";
  try { text = await file.text(); } catch (e) { flashStatus("读取字幕文件失败"); return; }
  const r = await act("LOAD_SUBTITLE", { text, format: ext, track });
  if (r && r.ok) {
    state.subtitleCues[track] = r.count;
    paintAdvanced();
    flashStatus("已加载 " + r.count + " 条字幕");
  }
  input.value = "";
}
$("subPrimary").onchange = () => loadSubtitleFile($("subPrimary"), "primary");
$("subSecondary").onchange = () => loadSubtitleFile($("subSecondary"), "secondary");
$("clearSub").onclick = async () => {
  const r = await act("CLEAR_SUBTITLE", { track: "primary" });
  if (r && r.cues) { state.subtitleCues = r.cues; paintAdvanced(); }
};
$("clearSub2").onclick = async () => {
  const r = await act("CLEAR_SUBTITLE", { track: "secondary" });
  if (r && r.cues) { state.subtitleCues = r.cues; paintAdvanced(); }
};

async function sendSubtitleStyle() {
  const style = {
    fontSize: Number($("subSize").value) || 22,
    fontFamily: $("subFont").value,
    position: $("subPosition").value,
    color: $("subColor").value,
    stroke: $("subStroke").value,
    opacity: Math.max(0.1, Math.min(1, (Number($("subOpacity").value) || 100) / 100)),
    offset: Number($("subOffset").value) || 0
  };
  state.subtitle = { ...state.subtitle, ...style };
  const r = await act("SET_SUBTITLE_STYLE", { style });
  if (r && r.subtitle) state.subtitle = { ...state.subtitle, ...r.subtitle };
  paintAdvanced();
}
function queueSubtitleStyle() {
  if (subtitleTimer) clearTimeout(subtitleTimer);
  subtitleTimer = setTimeout(() => { subtitleTimer = null; sendSubtitleStyle(); }, 180);
}
["subSize", "subFont", "subPosition", "subColor", "subStroke", "subOpacity", "subOffset"].forEach((id) => {
  const el = $(id);
  if (el) el.addEventListener("input", () => {
    if (id === "subOpacity") {
      const val = $("valSubOpacity");
      if (val) val.textContent = el.value + "%";
    }
    queueSubtitleStyle();
  });
});

/* ---------------- 工具 ---------------- */
$("qualityBtn").onclick = async () => {
  const r = await act("GET_QUALITY");
  if (r && r.width !== undefined) {
    state.quality = r;
    paintAdvanced();
  }
};
$("screenshotSub").onclick = async () => {
  const r = await act("SCREENSHOT_SUB");
  if (r && r.ok) flashStatus("已保存照片：" + r.filename, 3000);
};
$("recordMode").onchange = paintRecordUI;
$("recordBtn").onclick = async () => {
  if (state.recording) return;
  await syncVideoState();
  const mode = $("recordMode").value;
  const total = Number(state.duration) || 0;
  let start = Math.max(0, Number(state.time) || 0);
  let end = 0;
  if (mode === "full") {
    start = 0;
    end = total;
  } else if (mode === "current") {
    end = total;
  } else {
    const duration = Number($("recordDuration").value) || 10;
    end = start + duration;
    if (total > 0) end = Math.min(end, total);
  }
  if (!state.hasVideo) { flashStatus("当前页面没有可录制的视频"); return; }
  if ((mode === "full" || mode === "current") && (!Number.isFinite(total) || total <= 0)) {
    flashStatus("无法读取视频时长，不能录制到片尾");
    return;
  }
  if (end <= start + 0.2) {
    flashStatus("当前位置已接近片尾，请先回到前面");
    return;
  }
  const r = await act("RECORD_RANGE", { start, end });
  if (r && r.ok) {
    const actualStart = Number.isFinite(r.start) ? r.start : start;
    const actualEnd = Number.isFinite(r.end) ? r.end : end;
    const secs = Math.max(1, actualEnd - actualStart);
    state.recording = true;
    paintAdvanced();
    flashStatus(
      mode === "full" ? "开始录制片头 → 片尾…"
        : mode === "current" ? "开始录制当前 → 片尾…"
          : "开始录制 " + Math.round(secs) + " 秒…",
      3000
    );
    setTimeout(() => {
      state.recording = false;
      paintAdvanced();
    }, secs * 1000 + 800);
  }
};
$("audioTrack").onchange = async () => {
  const r = await act("SET_AUDIO_TRACK", { index: Number($("audioTrack").value) });
  if (r && r.audioTracks) { state.audioTracks = r.audioTracks; paintAdvanced(); }
};

$("downloadVideo").onclick = async () => {
  flashStatus("正在请求视频文件…", 30000);
  const r = await act("DOWNLOAD_VIDEO");
  if (r && r.ok) flashStatus("已开始下载：" + r.filename, 4000);
  else render();
};

$("gifBtn").onclick = async () => {
  await syncVideoState();
  const start = Math.max(0, state.time || 0);
  const duration = Number($("gifDuration").value) || 3;
  const fps = Number($("gifFps").value) || 8;
  const width = Number($("gifWidth").value) || 480;
  flashStatus("GIF 生成中，请保持页面打开…", 60000);
  const r = await act("GIF_RANGE", { start, duration, fps, width });
  if (r && r.ok) flashStatus("GIF 已保存：" + r.filename, 4000);
  else render();
};

$("decSpeed").onclick = async () => {
  const r = await act("ADJUST_RATE", { delta: -0.1 });
  if (r && Number.isFinite(r.rate)) { state.rate = r.rate; render(); }
};
$("incSpeed").onclick = async () => {
  const r = await act("ADJUST_RATE", { delta: 0.1 });
  if (r && Number.isFinite(r.rate)) { state.rate = r.rate; render(); }
};
currentSpeedEl.onclick = async () => {
  const r = await act("SET_RATE", { rate: 1 });
  if (r && Number.isFinite(r.rate)) { state.rate = r.rate; render(); }
};
document.querySelectorAll(".q-btn[data-rate]").forEach((b) => {
  b.onclick = async () => {
    const r = await act("SET_RATE", { rate: parseFloat(b.dataset.rate) });
    if (r && Number.isFinite(r.rate)) { state.rate = r.rate; render(); }
  };
});

playPauseBtn.onclick = async () => {
  const r = await act("PLAY_PAUSE");
  if (r) {
    state.playing = !!r.playing;
    if (Number.isFinite(r.rate)) state.rate = r.rate;
    render();
  }
};
$("prevFrame").onclick = async () => {
  const r = await act("STEP_FRAME", { dir: -1 });
  if (r) { state.playing = false; render(); }
};
$("nextFrame").onclick = async () => {
  const r = await act("STEP_FRAME", { dir: 1 });
  if (r) { state.playing = false; render(); }
};
$("screenshot").onclick = async () => {
  const r = await act("SCREENSHOT");
  if (r && r.ok) flashStatus("已保存照片：" + r.filename, 3000);
};

powerBtn.onchange = async () => {
  const want = powerBtn.checked;
  if (!isPro()) {
    powerBtn.checked = !want;
    return;
  }
  state.enabled = want;
  try { await chrome.storage.local.set({ enabled: want }); } catch (e) { /* ignore */ }

  const r = await sendActive("SET_ENABLED", { enabled: want });
  if (r && r.blocked) {
    state.enabled = false;
    powerBtn.checked = false;
    try { await chrome.storage.local.set({ enabled: false }); } catch (e) { /* ignore */ }
    flashStatus(r.need_pro ? "会员状态已失效，请重新登录" : "插件未启用");
    if (r.need_pro) await loadMembership(true);
    render();
    return;
  }
  if (r && r.error) flashStatus(r.error);
  if (want) await syncVideoState();
  else render();
};

accountBar.onclick = async () => {
  if (authError && !membership) {
    await loadMembership(true);
    if (isPro()) await syncVideoState();
    return;
  }
  openAccount();
};

gateBtn.onclick = async () => {
  if (authError && !membership) {
    await loadMembership(true);
    if (isPro()) await syncVideoState();
    return;
  }
  openAccount();
};

$("settingsBtn").onclick = (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
};

rescanBtn.onclick = async () => {
  const tab = await getActiveTab();
  if (tab && tab.id) {
    try { await chrome.tabs.reload(tab.id); } catch (e) { /* ignore */ }
  }
  window.close();
};

try {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.panda_membership) {
      membership = changes.panda_membership.newValue || null;
      loading = false;
      authError = "";
      paintAuth();
      if (isPro()) syncVideoState();
    }
    if (changes.panda_settings) loadModules();
  });
} catch (e) { /* ignore */ }

loadModules();
paintAuth();
refresh();
