/**
 * Panda视频控制&录屏截图 —— Background Service Worker
 *
 * 职责：
 *  1. 账号鉴权与会员状态的唯一数据源（options / popup 都经此查询，避免多处缓存不一致）。
 *  2. 会员状态缓存到 chrome.storage.local 的 panda_membership：
 *     popup 与 content 只读缓存做本地判定，不直接联网。
 *  3. 定时刷新会员状态；断网时沿用上次成功校验的结果，联网后自动恢复。
 *
 * 安全说明：扩展内的“门禁”只能提高破解成本，无法绝对阻止有心人修改扩展代码。
 * 真正的权限必须由服务端（Supabase RLS / 业务接口）强制，见 CODE_REVIEW.md。
 */
"use strict";

importScripts("auth_util.js");

const MEM_KEY = "panda_membership";
const ALARM_NAME = "panda_membership_refresh";
/** 缓存新鲜期：期间 popup/options 查询不联网，直接返回缓存。 */
const STATE_TTL = 15 * 60 * 1000;

let MEM = null;
let refreshPromise = null;
let authEpoch = 0;
const memReady = (async () => {
  try {
    const o = await chrome.storage.local.get(MEM_KEY);
    MEM = (o && o[MEM_KEY]) || null;
  } catch (e) {
    MEM = null;
  }
})();

function parseTime(v) {
  if (!v) return 0;
  const t = typeof v === "number" ? v : Date.parse(v);
  return Number.isFinite(t) ? t : NaN;
}

/** 把服务端结果与上次缓存合并成统一结构，并计算真实可用性。
 *  - 只有 pro 且未过期才算可用；
 *  - 到期时间缺失视为永久；到期时间格式异常按不可用处理；
 *  - offline 时沿用上次有效 PRO（断网不能把付费用户降级）。 */
function normalizeMembership(m, prev) {
  const now = Date.now();
  const offline = !!(m && m.offline);
  const signedIn = !!(m && m.signed_in) || !!(offline && prev && prev.signed_in);
  let plan = (m && m.plan) || (prev && prev.plan) || "free";
  let expiresAt = (m && m.expires_at) || (prev && prev.expires_at) || 0;
  let pro = signedIn && plan === "pro";
  if (pro && expiresAt) {
    const exp = parseTime(expiresAt);
    if (!Number.isFinite(exp) || exp <= now) pro = false;
  }

  if (offline && prev && prev.signed_in && prev.pro) {
    const prevExp = parseTime(prev.expires_at);
    if (!prev.expires_at || (Number.isFinite(prevExp) && prevExp > now)) {
      pro = true;
      plan = "pro";
      expiresAt = prev.expires_at || expiresAt;
    }
  }

  return {
    signed_in: signedIn,
    pro,
    plan,
    expires_at: expiresAt,
    email: signedIn ? ((m && m.email) || (prev && prev.email) || "") : "",
    offline,
    reason: (m && m.reason) || (offline && prev ? "离线：沿用上次校验结果" : ""),
    checked_at: now
  };
}

function clearBadge() {
  try { chrome.action.setBadgeText({ text: "" }); } catch (e) { /* ignore */ }
}

async function persistMembership(m) {
  MEM = m;
  clearBadge();
  try { await chrome.storage.local.set({ [MEM_KEY]: m }); } catch (e) { /* ignore */ }
  return m;
}

async function refreshMembership(force) {
  // 并发锁：多个页面同时查询时只发一轮网络请求，避免 refresh_token 被并发轮换导致互相失效。
  // force=true 用于登录/兑换后的强制重查，不受旧请求影响。
  if (!force && refreshPromise) return refreshPromise;
  const p = doRefreshMembership();
  refreshPromise = p;
  p.finally(() => {
    if (refreshPromise === p) refreshPromise = null;
  }).catch(() => {});
  return p;
}

async function doRefreshMembership() {
  await memReady;
  const epoch = authEpoch;
  const prev = MEM;
  let m = null;

  try {
    m = await PandaAuth.getMembership();
  } catch (e) {
    const peek = await PandaAuth.peekSession().catch(() => null);
    m = {
      signed_in: !!(peek && peek.signed_in),
      pro: false,
      plan: "free",
      expires_at: 0,
      email: (peek && peek.email) || "",
      offline: true,
      reason: "网络错误：" + ((e && e.message) || e)
    };
  }

  // 服务端没有明确判定“会话失效”时，不要只因临时错误把已登录用户踢出
  if (m && m.signed_in === false && prev && prev.signed_in && !/失效/.test(String(m.reason || ""))) {
    const peek = await PandaAuth.peekSession().catch(() => null);
    if (peek && peek.signed_in) {
      m = {
        signed_in: true,
        pro: false,
        plan: "free",
        expires_at: prev.expires_at || 0,
        email: peek.email || prev.email || "",
        offline: true,
        reason: "网络错误：沿用上次登录状态，联网后自动校验"
      };
    }
  }

  // 登录 / 退出 / 兑换发生在等待网络期间：丢弃过期结果，避免把新状态覆盖回去
  if (epoch !== authEpoch) return MEM;

  return persistMembership(normalizeMembership(m || { signed_in: false, pro: false }, prev));
}

async function ensureMembership(force) {
  await memReady;
  const fresh = MEM && MEM.checked_at && Date.now() - MEM.checked_at < STATE_TTL;
  if (!force && fresh) {
    // 缓存写着“未登录”，但本地其实还有会话（例如 SW 在登录前启动过）→ 立即重查
    if (!MEM.signed_in) {
      const peek = await PandaAuth.peekSession().catch(() => null);
      if (peek && peek.signed_in) return refreshMembership();
    }
    return MEM;
  }
  return refreshMembership();
}

/* ---------------- 账号操作（集中在本模块，页面不直接持有 token） ---------------- */

function fail(e) {
  return {
    ok: false,
    error: (e && e.message) || String(e),
    code: (e && e.code) || "",
    needLogin: !!(e && e.needLogin)
  };
}

async function handleSignIn(msg) {
  authEpoch++;
  await PandaAuth.signIn(msg.email, msg.password);
  const membership = await refreshMembership(true);
  return { ok: true, membership };
}

async function handleSignUp(msg) {
  authEpoch++;
  const r = await PandaAuth.signUp(msg.email, msg.password);
  if (r.needConfirm) return { ok: true, needConfirm: true };
  const membership = await refreshMembership(true);
  return { ok: true, needConfirm: false, membership };
}

async function handleLogout() {
  authEpoch++;
  await PandaAuth.signOut();
  await memReady;
  const membership = await persistMembership({
    signed_in: false,
    pro: false,
    plan: "free",
    expires_at: 0,
    email: "",
    offline: false,
    reason: "已退出登录",
    checked_at: Date.now()
  });
  return { ok: true, membership };
}

async function handleResetRequest(msg) {
  await PandaAuth.requestPasswordReset(msg.email);
  return { ok: true, sent: true };
}

async function handleResetSubmit(msg) {
  authEpoch++;
  await PandaAuth.verifyRecoveryCode(msg.email, msg.code);
  await PandaAuth.setNewPassword(msg.password);
  const membership = await refreshMembership(true);
  return { ok: true, membership };
}

async function handleRedeem(msg) {
  authEpoch++;
  const r = await PandaAuth.redeemCode(msg.code);
  const membership = await refreshMembership(true);
  return { ok: true, redeem: r, membership };
}

const HANDLERS = {
  PANDA_AUTH_STATE: async () => ({ ok: true, membership: await ensureMembership(false) }),
  PANDA_REFRESH: async () => ({ ok: true, membership: await refreshMembership() }),
  PANDA_SIGN_IN: handleSignIn,
  PANDA_SIGN_UP: handleSignUp,
  PANDA_LOGOUT: handleLogout,
  PANDA_RESET_REQUEST: handleResetRequest,
  PANDA_RESET_SUBMIT: handleResetSubmit,
  PANDA_REDEEM: handleRedeem
};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg.type !== "string") return;
  const handler = HANDLERS[msg.type];
  if (!handler) {
    sendResponse({ ok: false, error: "unknown_message" });
    return;
  }
  Promise.resolve()
    .then(() => handler(msg))
    .then(sendResponse)
    .catch((e) => sendResponse(fail(e)));
  return true; // 异步响应
});

/* ---------------- 生命周期 ---------------- */

chrome.runtime.onInstalled.addListener((details) => {
  if (details && details.reason === "install") {
    chrome.storage.local.get(["enabled", "stepSec"]).then((s) => {
      const defaults = {};
      if (s.enabled === undefined) defaults.enabled = true;
      if (!s.stepSec) defaults.stepSec = 0.033;
      if (Object.keys(defaults).length) chrome.storage.local.set(defaults);
    }).catch(() => {});
  }
  refreshMembership().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  refreshMembership().catch(() => {});
});

// 每 6 小时重新校验一次会员状态（Chrome 会对闹钟做随机抖动，属正常现象）
chrome.alarms.create(ALARM_NAME, { periodInMinutes: 360 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a && a.name === ALARM_NAME) refreshMembership().catch(() => {});
});

// 启动时清掉历史版本可能残留的 PRO 角标
memReady.then(() => clearBadge()).catch(() => {});
