"use strict";

const $ = (id) => document.getElementById(id);

const stepEl = $("step");
const stepMsg = $("msg");
const acctMsg = $("acctMsg");
const acctBadge = $("acctBadge");
const loginSec = $("loginSec");
const infoSec = $("infoSec");
const loginForm = $("loginForm");
const resetForm = $("resetForm");
const emailInput = $("acctEmail");
const passInput = $("acctPass");
const rememberBox = $("rememberEmail");

const REMEMBER_KEY = "panda_remember_email";
let busy = false;
let sayTimer = null;
let lastRefreshError = "";

/* ---------------- 通用 ---------------- */

try {
  $("ver").textContent = "v" + chrome.runtime.getManifest().version;
} catch (e) { /* ignore */ }

function sendBg(type, extra = {}, timeoutMs = 20000) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({ ok: false, error: "账号服务响应超时，请检查网络后重试" });
    }, timeoutMs);
    try {
      chrome.runtime.sendMessage({ type, ...extra }, (resp) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message || "后台服务不可用" });
          return;
        }
        resolve(resp || { ok: false, error: "后台服务无响应" });
      });
    } catch (e) {
      clearTimeout(timer);
      if (!settled) { settled = true; resolve({ ok: false, error: String((e && e.message) || e) }); }
    }
  });
}

function say(text, isErr) {
  if (!acctMsg) return;
  acctMsg.textContent = text || "";
  acctMsg.classList.toggle("err", !!isErr);
  acctMsg.classList.toggle("ok", !isErr && !!text);
  if (sayTimer) { clearTimeout(sayTimer); sayTimer = null; }
  if (text) {
    sayTimer = setTimeout(() => {
      acctMsg.textContent = "";
      acctMsg.classList.remove("err", "ok");
      sayTimer = null;
    }, isErr ? 7000 : 4000);
  }
}

function setBusy(b) {
  busy = b;
  ["loginBtn", "signupBtn", "forgotBtn", "sendCodeBtn", "resetSubmitBtn", "redeemBtn", "refreshBtn", "logoutBtn"]
    .forEach((id) => {
      const el = $(id);
      if (el) el.disabled = b;
    });
}

function isPro(m) {
  if (!m || !m.signed_in || !m.pro) return false;
  if (!m.expires_at) return true;
  const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
  return Number.isFinite(t) && t > Date.now();
}

function fmtDate(iso) {
  if (!iso) return "永久";
  const raw = String(iso);
  // 纯日期不经过时区换算，避免 UTC 零点在东/西半球显示成前一天
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return raw;
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function validEmail(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v || "").trim());
}

/* ---------------- 账号面板 ---------------- */

async function readCachedMembership() {
  try {
    const o = await chrome.storage.local.get("panda_membership");
    return (o && o.panda_membership) || null;
  } catch (e) {
    return null;
  }
}

function paintAccount(m) {
  const pro = isPro(m);
  const signedIn = !!(m && m.signed_in);

  acctBadge.classList.remove("pro", "free", "err");
  if (pro) {
    acctBadge.textContent = "PRO";
    acctBadge.classList.add("pro");
  } else if (signedIn) {
    acctBadge.textContent = "免费版";
    acctBadge.classList.add("free");
  } else {
    acctBadge.textContent = "未登录";
  }

  // 侧栏账号项的状态 chip（账号是唯一的蓝色导航项；PRO 用金色）
  const navChip = $("navAcctChip");
  if (navChip) {
    navChip.className = "p-chip" + (pro ? " pro" : "");
    navChip.textContent = pro ? "PRO" : signedIn ? "免费版" : "未登录";
  }

  if (signedIn) {
    loginSec.classList.add("hidden");
    infoSec.classList.remove("hidden");
    $("acctEmailLabel").textContent = (m.email || "—") + (m.offline ? "（离线）" : "");
    $("acctPlanLabel").textContent = pro
      ? "PRO 会员"
      : (m.reason && /异常/.test(String(m.reason)) ? "会员数据异常，请联系客服"
        : m.reason && /过期/.test(String(m.reason)) ? "会员已过期"
          : "免费版 · 激活后解锁全部功能");
    $("acctExpiresLabel").textContent = pro ? fmtDate(m.expires_at) : "—";

    const note = $("offlineNote");
    note.classList.toggle("hidden", !m.offline);
    if (m.offline) {
      note.textContent = "⚠ 当前处于离线状态：登录状态与会员权益沿用上次校验结果（"
        + (pro ? "PRO" : "免费版") + "）。联网后会自动重新校验，无需重新登录。";
    }
  } else {
    loginSec.classList.remove("hidden");
    infoSec.classList.add("hidden");
  }
}

async function refreshUI(force = false) {
  const cached = await readCachedMembership();
  if (cached) paintAccount(cached);

  const res = await sendBg(force ? "PANDA_REFRESH" : "PANDA_AUTH_STATE", {}, force ? 50000 : 15000);
  if (res && res.ok && res.membership) {
    lastRefreshError = "";
    paintAccount(res.membership);
    return res.membership;
  }
  lastRefreshError = (res && res.error) || "无法获取会员状态";
  if (force || !cached) say(lastRefreshError, true);
  if (!cached) {
    acctBadge.textContent = "校验失败";
    acctBadge.classList.remove("pro", "free");
    acctBadge.classList.add("err");
  }
  return cached;
}

/* ---------------- 记住邮箱 ---------------- */

async function loadRememberedEmail() {
  try {
    const o = await chrome.storage.local.get(REMEMBER_KEY);
    const v = o && o[REMEMBER_KEY];
    if (v && v.email) {
      rememberBox.checked = true;
      if (!emailInput.value) emailInput.value = v.email;
    }
  } catch (e) { /* ignore */ }
}

async function persistRememberedEmail(email) {
  try {
    if (rememberBox.checked && email) await chrome.storage.local.set({ [REMEMBER_KEY]: { email } });
    else await chrome.storage.local.remove(REMEMBER_KEY);
  } catch (e) { /* ignore */ }
}

rememberBox.addEventListener("change", () => {
  if (rememberBox.checked && validEmail(emailInput.value)) {
    chrome.storage.local.set({ [REMEMBER_KEY]: { email: emailInput.value.trim() } }).catch(() => {});
  } else if (!rememberBox.checked) {
    chrome.storage.local.remove(REMEMBER_KEY).catch(() => {});
  }
});

/* ---------------- 登录 / 注册 / 找回 ---------------- */

function getCreds() {
  const email = String(emailInput.value || "").trim();
  const password = String(passInput.value || "");
  if (!validEmail(email)) { say("请输入有效的邮箱地址", true); emailInput.focus(); return null; }
  if (password.length < 6) { say("密码至少 6 位", true); passInput.focus(); return null; }
  return { email, password };
}

async function doLogin() {
  if (busy) return;
  const c = getCreds();
  if (!c) return;
  setBusy(true);
  say("登录中…");
  try {
    const res = await sendBg("PANDA_SIGN_IN", c, 55000);
    if (!res || !res.ok) throw new Error((res && res.error) || "登录失败");
    passInput.value = "";
    await persistRememberedEmail(c.email);
    paintAccount(res.membership);
    say("登录成功");
  } catch (e) {
    say(e.message || "登录失败", true);
  } finally {
    setBusy(false);
  }
}

async function doSignup() {
  if (busy) return;
  const c = getCreds();
  if (!c) return;
  setBusy(true);
  say("注册中…");
  try {
    const res = await sendBg("PANDA_SIGN_UP", c, 55000);
    if (!res || !res.ok) throw new Error((res && res.error) || "注册失败");
    await persistRememberedEmail(c.email);
    if (res.needConfirm) {
      say("注册成功！请到邮箱点击验证链接后再登录");
    } else {
      passInput.value = "";
      paintAccount(res.membership);
      say("注册成功，已自动登录");
    }
  } catch (e) {
    say(e.message || "注册失败", true);
  } finally {
    setBusy(false);
  }
}

function showReset(show) {
  resetForm.classList.toggle("hidden", !show);
  if (show) {
    $("resetEmail").value = String(emailInput.value || "").trim();
    $("resetCode").value = "";
    $("resetPass").value = "";
    $("resetCode").focus();
  }
}

$("forgotBtn").onclick = () => {
  const email = String(emailInput.value || "").trim();
  if (!validEmail(email)) {
    say("请先在上方输入注册邮箱，再点“忘记密码？”", true);
    emailInput.focus();
    return;
  }
  showReset(true);
  say("已展开重置表单，点“发送验证码”后查收邮件");
};

$("sendCodeBtn").onclick = async () => {
  if (busy) return;
  const email = String($("resetEmail").value || "").trim();
  if (!validEmail(email)) { say("请输入注册邮箱", true); $("resetEmail").focus(); return; }
  setBusy(true);
  say("验证码发送中…");
  try {
    const res = await sendBg("PANDA_RESET_REQUEST", { email }, 55000);
    if (!res || !res.ok) throw new Error((res && res.error) || "发送失败");
    say("验证码已发送（收不到请检查垃圾箱），1 小时内有效");
  } catch (e) {
    say(e.message || "发送失败", true);
  } finally {
    setBusy(false);
  }
};

resetForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (busy) return;
  const email = String($("resetEmail").value || "").trim();
  const code = String($("resetCode").value || "").trim();
  const password = String($("resetPass").value || "");
  if (!validEmail(email)) { say("请输入注册邮箱", true); return; }
  if (!/^\d{6,8}$/.test(code)) { say("请输入邮件中的数字验证码（6-8 位）", true); return; }
  if (password.length < 6) { say("新密码至少 6 位", true); return; }
  setBusy(true);
  say("验证中…");
  try {
    const res = await sendBg("PANDA_RESET_SUBMIT", { email, code, password }, 55000);
    if (!res || !res.ok) throw new Error((res && res.error) || "重置失败");
    showReset(false);
    passInput.value = "";
    paintAccount(res.membership);
    say("密码已重置并自动登录");
  } catch (err) {
    say(err.message || "重置失败", true);
  } finally {
    setBusy(false);
  }
});

$("resetCancelBtn").onclick = () => showReset(false);

/* ---------------- 已登录操作 ---------------- */

$("logoutBtn").onclick = async () => {
  if (busy) return;
  if (!confirm("退出登录后，本机将清除登录凭证；再次使用会员功能需要重新登录。确定退出？")) return;
  setBusy(true);
  say("退出中…");
  try {
    const res = await sendBg("PANDA_LOGOUT", {}, 20000);
    if (!res || !res.ok) throw new Error((res && res.error) || "退出失败");
    paintAccount(res.membership);
    passInput.value = "";
    say("已退出登录");
    await loadRememberedEmail();
  } catch (e) {
    say(e.message || "退出失败", true);
  } finally {
    setBusy(false);
  }
};

$("redeemBtn").onclick = async () => {
  if (busy) return;
  const input = $("redeemCode");
  const code = String(input.value || "").trim();
  if (!code) { say("请输入兑换码", true); input.focus(); return; }
  setBusy(true);
  say("兑换中…");
  try {
    const res = await sendBg("PANDA_REDEEM", { code }, 55000);
    if (!res || !res.ok) throw new Error((res && res.error) || "兑换失败");
    input.value = "";
    paintAccount(res.membership);
    const exp = res.membership && res.membership.expires_at;
    say("兑换成功！会员有效期至 " + fmtDate(exp));
  } catch (e) {
    say(e.message || "兑换失败", true);
  } finally {
    setBusy(false);
  }
};

$("redeemCode").addEventListener("keydown", (e) => {
  if (e.key === "Enter") { e.preventDefault(); $("redeemBtn").click(); }
});

$("refreshBtn").onclick = async () => {
  if (busy) return;
  setBusy(true);
  say("刷新中…");
  try {
    const m = await refreshUI(true);
    if (lastRefreshError) {
      say(lastRefreshError, true);
    } else if (m) {
      say(isPro(m) ? "会员状态已刷新" : "已刷新：当前账号未开通会员", !isPro(m));
    }
  } finally {
    setBusy(false);
  }
};

loginForm.addEventListener("submit", (e) => {
  e.preventDefault();
  doLogin();
});
$("signupBtn").onclick = doSignup;
passInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") { e.preventDefault(); doLogin(); }
});
$("resetCode").addEventListener("keydown", (e) => {
  if (e.key === "Enter") { e.preventDefault(); resetForm.requestSubmit(); }
});

/* ---------------- 帧步进设置 ---------------- */

chrome.storage.local.get(["stepSec"]).then((s) => {
  stepEl.value = s.stepSec ?? 0.033;
}).catch(() => {});

function saveStep() {
  const v = Number(stepEl.value);
  if (!Number.isFinite(v) || v < 0.005 || v > 1) {
    stepMsg.textContent = "请输入 0.005 ~ 1 之间的数字";
    stepMsg.style.color = "var(--ui-danger)";
    return;
  }
  chrome.storage.local.set({ stepSec: v }).then(() => {
    stepMsg.textContent = "已保存";
    stepMsg.style.color = "var(--ui-known)";
    setTimeout(() => { stepMsg.textContent = ""; }, 2500);
  }).catch(() => {
    stepMsg.textContent = "保存失败";
    stepMsg.style.color = "var(--ui-danger)";
  });
}

$("save").onclick = saveStep;
stepEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") { e.preventDefault(); saveStep(); }
});

/* ---------------- 播放默认 / 站点 / 模块 ---------------- */

const SETTINGS_KEY = "panda_settings";
const DEFAULT_MODULES = {
  speed: true, volume: true, frame: true, display: true,
  loop: true, skip: true, subtitle: true, filters: true, tools: true
};

function normalizeSettings(raw) {
  const r = raw && typeof raw === "object" ? raw : {};
  const d = r.defaults && typeof r.defaults === "object" ? r.defaults : {};
  return {
    defaults: {
      rate: Number.isFinite(Number(d.rate)) ? Number(d.rate) : 1,
      volume: Number.isFinite(Number(d.volume)) ? Math.max(0, Math.min(1, Number(d.volume))) : 1,
      aspect: d.aspect || "auto",
      loop: d.loop || "none",
      intro: Math.max(0, Number(d.intro) || 0),
      outro: Math.max(0, Number(d.outro) || 0),
      filters: d.filters && typeof d.filters === "object" ? d.filters : {},
      subtitle: d.subtitle && typeof d.subtitle === "object" ? d.subtitle : {},
      skipRules: Array.isArray(d.skipRules) ? d.skipRules : []
    },
    sites: r.sites && typeof r.sites === "object" ? r.sites : {},
    modules: { ...DEFAULT_MODULES, ...(r.modules && typeof r.modules === "object" ? r.modules : {}) }
  };
}

async function readSettings() {
  try {
    const o = await chrome.storage.local.get(SETTINGS_KEY);
    return normalizeSettings(o && o[SETTINGS_KEY]);
  } catch (e) {
    return normalizeSettings(null);
  }
}

function setStatus(id, text, isError) {
  const el = $(id);
  if (!el) return;
  el.textContent = text;
  el.style.color = isError ? "var(--ui-danger)" : "var(--ui-known)";
  if (id !== "defaultsMsg" && id !== "siteMsg" && id !== "modulesMsg") {
    setTimeout(() => { if (el.textContent === text) el.textContent = ""; }, 2500);
  }
}

function fillDefaultForm(s) {
  $("defRate").value = String(s.defaults.rate);
  $("defVolume").value = String(Math.round(s.defaults.volume * 100));
  $("defAspect").value = s.defaults.aspect;
  $("defLoop").value = s.defaults.loop;
  $("defIntro").value = String(s.defaults.intro);
  $("defOutro").value = String(s.defaults.outro);
}

function fillModules(s) {
  document.querySelectorAll("#pane-modules input[data-module]").forEach((el) => {
    el.checked = s.modules[el.dataset.module] !== false;
  });
}

function renderSiteList(s) {
  const list = $("siteList");
  if (!list) return;
  list.textContent = "";
  const hosts = Object.keys(s.sites).sort();
  if (!hosts.length) {
    const empty = document.createElement("p");
    empty.className = "p-hint";
    empty.textContent = "还没有站点规则。";
    list.appendChild(empty);
    return;
  }
  for (const host of hosts) {
    const site = s.sites[host] || {};
    const row = document.createElement("div");
    row.className = "site-item";
    const name = document.createElement("span");
    name.className = "site-name";
    name.textContent = host;
    const meta = document.createElement("span");
    meta.className = "site-meta";
    const parts = [];
    if (Number.isFinite(Number(site.rate))) parts.push(Number(site.rate) + "x");
    if (Number.isFinite(Number(site.volume))) parts.push(Math.round(Number(site.volume) * 100) + "%");
    if (site.aspect) parts.push(site.aspect);
    meta.textContent = parts.join(" · ") || "继承默认";
    const edit = document.createElement("button");
    edit.type = "button";
    edit.className = "p-btn";
    edit.textContent = "编辑";
    edit.addEventListener("click", () => {
      $("siteHost").value = host;
      $("siteRate").value = Number.isFinite(Number(site.rate)) ? String(site.rate) : "";
      $("siteVolume").value = Number.isFinite(Number(site.volume)) ? String(Math.round(Number(site.volume) * 100)) : "";
      $("siteAspect").value = site.aspect || "auto";
    });
    const del = document.createElement("button");
    del.type = "button";
    del.className = "p-btn p-btn-danger";
    del.textContent = "移除";
    del.addEventListener("click", async () => {
      if (!confirm("移除 " + host + " 的站点规则？")) return;
      const next = await readSettings();
      delete next.sites[host];
      await chrome.storage.local.set({ [SETTINGS_KEY]: next });
      renderSiteList(next);
      setStatus("siteStatus", "已移除 " + host);
    });
    row.appendChild(name);
    row.appendChild(meta);
    row.appendChild(edit);
    row.appendChild(del);
    list.appendChild(row);
  }
}

async function loadSettingsUI() {
  const s = await readSettings();
  fillDefaultForm(s);
  fillModules(s);
  renderSiteList(s);
}

$("saveDefaults").onclick = async () => {
  const rate = Number($("defRate").value);
  const volume = Number($("defVolume").value);
  const intro = Number($("defIntro").value);
  const outro = Number($("defOutro").value);
  if (!Number.isFinite(rate) || rate < 0.1 || rate > 5) return setStatus("defaultsStatus", "倍速需在 0.1 ~ 5 之间", true);
  if (!Number.isFinite(volume) || volume < 0 || volume > 100) return setStatus("defaultsStatus", "音量需在 0 ~ 100 之间", true);
  if (!Number.isFinite(intro) || intro < 0 || !Number.isFinite(outro) || outro < 0) return setStatus("defaultsStatus", "片头/片尾不能为负数", true);
  const s = await readSettings();
  s.defaults = {
    ...s.defaults,
    rate,
    volume: volume / 100,
    aspect: $("defAspect").value,
    loop: $("defLoop").value,
    intro,
    outro
  };
  await chrome.storage.local.set({ [SETTINGS_KEY]: s });
  fillDefaultForm(s);
  setStatus("defaultsStatus", "已保存默认参数");
};

$("saveSite").onclick = async () => {
  let host = String($("siteHost").value || "").trim().toLowerCase();
  host = host.replace(/^https?:\/\//, "").split("/")[0].replace(/^www\./, "");
  if (!host) return setStatus("siteStatus", "请输入域名", true);
  const rateRaw = $("siteRate").value;
  const volumeRaw = $("siteVolume").value;
  const rate = rateRaw === "" ? null : Number(rateRaw);
  const volume = volumeRaw === "" ? null : Number(volumeRaw);
  if (rate !== null && (!Number.isFinite(rate) || rate < 0.1 || rate > 5)) {
    return setStatus("siteStatus", "站点倍速需在 0.1 ~ 5 之间", true);
  }
  if (volume !== null && (!Number.isFinite(volume) || volume < 0 || volume > 100)) {
    return setStatus("siteStatus", "站点音量需在 0 ~ 100 之间", true);
  }
  const s = await readSettings();
  const next = { ...(s.sites[host] || {}) };
  if (rate === null) delete next.rate; else next.rate = rate;
  if (volume === null) delete next.volume; else next.volume = volume / 100;
  next.aspect = $("siteAspect").value;
  s.sites[host] = next;
  await chrome.storage.local.set({ [SETTINGS_KEY]: s });
  renderSiteList(s);
  setStatus("siteStatus", "已保存 " + host);
};

$("clearSite").onclick = () => {
  $("siteHost").value = "";
  $("siteRate").value = "";
  $("siteVolume").value = "";
  $("siteAspect").value = "auto";
};

$("saveModules").onclick = async () => {
  const s = await readSettings();
  s.modules = { ...s.modules };
  document.querySelectorAll("#pane-modules input[data-module]").forEach((el) => {
    s.modules[el.dataset.module] = !!el.checked;
  });
  await chrome.storage.local.set({ [SETTINGS_KEY]: s });
  setStatus("modulesStatus", "已保存模块设置");
};

/* ---------------- 初始化 ---------------- */

function showPane(name) {
  const pane = document.getElementById("pane-" + name);
  if (!pane) return false;
  document.querySelectorAll(".s-pane").forEach((p) => p.classList.toggle("active", p === pane));
  document.querySelectorAll(".s-nav-item[data-pane]").forEach((b) => {
    b.classList.toggle("active", b.dataset.pane === name);
  });
  if (location.hash !== "#" + name) {
    try { history.replaceState(null, "", "#" + name); } catch (e) { /* ignore */ }
  }
  return true;
}

document.querySelectorAll(".s-nav-item[data-pane]").forEach((btn) => {
  btn.addEventListener("click", () => showPane(btn.dataset.pane));
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.panda_membership) {
    paintAccount(changes.panda_membership.newValue || null);
  }
});

(async function init() {
  await loadRememberedEmail();
  await refreshUI(false);
  await loadSettingsUI();

  const initial = (location.hash || "#account").slice(1);
  showPane(["account", "defaults", "sites", "modules", "step", "help"].includes(initial) ? initial : "account");

  if (initial === "account" && loginSec && !loginSec.classList.contains("hidden") && emailInput) {
    emailInput.focus();
  }
})();
