(() => {
  // 本脚本运行在 content script 隔离世界，globalThis 上的标记页面 JS 访问不到。
  if (globalThis.__panda_vc_loaded) return;
  globalThis.__panda_vc_loaded = true;

  const DEFAULT_STEP = 0.033;
  const MIN_RATE = 0.1;
  const MAX_RATE = 5;

  let stepSec = DEFAULT_STEP;
  let activeVideo = null;
  let pluginEnabled = true;
  let entitled = false;
  let stateDirty = false;

  function clampStep(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) return DEFAULT_STEP;
    return Math.min(1, Math.max(0.005, n));
  }

  /** 会员凭证是否可用：必须已登录 + pro + 未过期（无到期时间视为永久）。 */
  function isEntitled(m) {
    if (!m || !m.signed_in || !m.pro) return false;
    if (!m.expires_at) return true;
    const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
    return Number.isFinite(t) && t > Date.now();
  }

  function applyStoredState(s) {
    pluginEnabled = s.enabled !== false;
    stepSec = clampStep(s.stepSec);
    entitled = isEntitled(s.panda_membership);
    notifyEntitled();
  }

  function notifyEntitled() {
    try { document.dispatchEvent(new CustomEvent("panda-entitled-change")); } catch (e) { /* ignore */ }
  }

  // 启动时读回开关、帧步进与会员缓存；按需注入时避免状态丢失。
  // 若读取期间又发生 storage 变更，则重新读取，避免旧值覆盖新值（异步竞态）。
  const ready = (async () => {
    try {
      let last = null;
      for (let i = 0; i < 10; i++) {
        stateDirty = false;
        last = await chrome.storage.local.get(["enabled", "stepSec", "panda_membership"]);
        if (!stateDirty) {
          applyStoredState(last);
          return;
        }
      }
      if (last) applyStoredState(last);
    } catch (e) {
      // 扩展被重新加载后 context 可能失效：保持默认值，后续消息会返回错误
    }
  })();

  // 设置页 / 账号状态变化时实时同步，不必刷新页面
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.enabled || changes.stepSec || changes.panda_membership) stateDirty = true;
      if (changes.enabled) {
        pluginEnabled = changes.enabled.newValue !== false;
        if (!pluginEnabled) resetAllRates();
        notifyEntitled();
      }
      if (changes.stepSec) stepSec = clampStep(changes.stepSec.newValue);
      if (changes.panda_membership) {
        const was = entitled;
        entitled = isEntitled(changes.panda_membership.newValue);
        // 会员被撤销/过期：立刻恢复原速，避免控制效果残留
        if (was && !entitled) resetAllRates();
        notifyEntitled();
      }
    });
  } catch (e) { /* ignore */ }

  function isVisible(v) {
    if (!v || !v.getClientRects().length) return false;
    const r = v.getBoundingClientRect();
    if (r.width < 20 || r.height < 20) return false;
    const cs = getComputedStyle(v);
    return cs.visibility !== "hidden" && cs.display !== "none" && Number(cs.opacity) > 0;
  }

  function score(v) {
    const r = v.getBoundingClientRect();
    return Math.max(0, r.width) * Math.max(0, r.height) + (!v.paused && !v.ended ? 1e9 : 0);
  }

  function pickVideo() {
    // 优先沿用当前控制的视频：逐帧/定格后它处于暂停状态，不能因此切到别的广告视频
    if (activeVideo && document.contains(activeVideo) && isVisible(activeVideo)) return activeVideo;
    const all = Array.from(document.querySelectorAll("video"));
    if (!all.length) return null;
    const visible = all.filter(isVisible);
    const pool = visible.length ? visible : all;
    const playing = pool.filter((v) => !v.paused && !v.ended && v.readyState > 1);
    const candidates = (playing.length ? playing : pool).slice().sort((a, b) => score(b) - score(a));
    const best = candidates[0] || null;
    if (best) activeVideo = best;
    return best;
  }

  function resetAllRates() {
    document.querySelectorAll("video").forEach((v) => {
      try { v.playbackRate = 1; } catch (e) { /* ignore */ }
    });
  }

  function getRate() {
    const v = pickVideo();
    return v ? v.playbackRate : 1;
  }

  function setRate(rate) {
    const n = Number(rate);
    const r = Math.round(Math.max(MIN_RATE, Math.min(MAX_RATE, Number.isFinite(n) ? n : 1)) * 100) / 100;
    const v = pickVideo();
    if (v) {
      try { v.playbackRate = r; } catch (e) { /* ignore */ }
    }
    return { rate: r, hasVideo: !!v };
  }

  function stepFrame(dir) {
    const v = pickVideo();
    if (!v) return null;
    if (!Number.isFinite(v.currentTime)) return { error: "视频尚未加载完成，请稍后再试" };
    const step = Number(dir) < 0 ? -stepSec : stepSec;
    try {
      if (!v.paused) v.pause();
      const dur = Number.isFinite(v.duration) ? v.duration : Infinity;
      const target = Math.max(0, Math.min(v.currentTime + step, dur));
      v.currentTime = target;
      return { playing: false, rate: v.playbackRate, time: target, duration: v.duration };
    } catch (e) {
      return { error: "该视频不支持逐帧跳转（可能是直播流）" };
    }
  }

  async function playPause() {
    const v = pickVideo();
    if (!v) return null;
    if (v.paused) {
      let outcome = null;
      try {
        const p = v.play();
        outcome = await Promise.race([
          p.then(() => true).catch((e) => e),
          new Promise((resolve) => setTimeout(() => resolve("pending"), 1500))
        ]);
      } catch (e) {
        outcome = e;
      }
      if (outcome instanceof Error) {
        const blocked = /NotAllowedError|user gesture|autoplay/i.test(outcome.name + " " + outcome.message);
        return {
          error: blocked ? "浏览器阻止了播放，请先在页面上点一下视频再试" : "播放失败：" + (outcome.message || outcome),
          playing: !v.paused,
          rate: v.playbackRate
        };
      }
    } else {
      v.pause();
    }
    return { playing: !v.paused, rate: v.playbackRate };
  }

  /** 设置当前主视频音量（0~1）。调到 0 视作静音；从 0 往上调会自动取消静音。 */
  function setVolume(volume) {
    const v = pickVideo();
    if (!v) return { error: "页面没有视频" };
    const n = Number(volume);
    const level = Math.max(0, Math.min(1, Number.isFinite(n) ? n : 1));
    try {
      if (level === 0) {
        v.muted = true;
      } else {
        if (v.muted) v.muted = false;
        v.volume = level;
      }
      return { volume: v.volume, muted: !!v.muted };
    } catch (e) {
      return { error: "该视频不支持音量控制" };
    }
  }

  /** 静音/取消静音；取消静音时若音量为 0，恢复到 50%。 */
  function toggleMute() {
    const v = pickVideo();
    if (!v) return { error: "页面没有视频" };
    try {
      if (v.muted || v.volume === 0) {
        v.muted = false;
        if (v.volume === 0) v.volume = 0.5;
      } else {
        v.muted = true;
      }
      return { volume: v.volume, muted: !!v.muted };
    } catch (e) {
      return { error: "该视频不支持音量控制" };
    }
  }

  function pad(n) { return String(n).padStart(2, "0"); }

  async function screenshot() {
    const v = pickVideo();
    if (!v) return { ok: false, error: "页面没有视频" };
    const w = v.videoWidth;
    const h = v.videoHeight;
    if (!w || !h) return { ok: false, error: "视频尚未加载出画面，请稍后再试" };

    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return { ok: false, error: "当前浏览器无法创建画布" };

    let blob = null;
    try {
      ctx.drawImage(v, 0, 0, w, h);
      blob = await new Promise((resolve, reject) => {
        try {
          canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("图片编码失败"))), "image/png");
        } catch (e) {
          reject(e);
        }
      });
    } catch (e) {
      const tainted = /SecurityError|tainted|cross-origin|insecure/i.test(String((e && e.name) + " " + (e && e.message)));
      return {
        ok: false,
        error: tainted
          ? "该视频受跨域/版权保护，浏览器禁止截图（可尝试全屏后使用系统截图）"
          : "截图失败：" + ((e && e.message) || e)
      };
    }
    if (!blob) return { ok: false, error: "截图编码失败" };

    const ts = new Date();
    const name = "panda_" + ts.getFullYear() + pad(ts.getMonth() + 1) + pad(ts.getDate())
      + "_" + pad(ts.getHours()) + pad(ts.getMinutes()) + pad(ts.getSeconds()) + ".png";

    const url = URL.createObjectURL(blob);
    try {
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      (document.body || document.documentElement).appendChild(a);
      a.click();
      a.remove();
    } catch (e) {
      URL.revokeObjectURL(url);
      return { ok: false, error: "保存失败：" + ((e && e.message) || e) };
    }
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
    return { ok: true, filename: name, width: w, height: h };
  }

  async function handle(msg) {
    if (!msg || !msg.type) return { error: "empty_message" };

    if (msg.type === "GET_STATE") {
      const v = pickVideo();
      const rect = v ? v.getBoundingClientRect() : null;
      const adv = globalThis.__PANDA_ADV__;
      return Object.assign({
        hasVideo: !!v,
        rate: v ? v.playbackRate : 1,
        playing: v ? !v.paused : false,
        volume: v ? v.volume : 1,
        muted: v ? !!v.muted : false,
        time: v ? v.currentTime : 0,
        duration: v ? v.duration : 0,
        area: rect ? Math.max(0, rect.width) * Math.max(0, rect.height) : 0,
        enabled: pluginEnabled,
        entitled,
        stepSec
      }, adv && typeof adv.getState === "function" ? adv.getState() : {});
    }

    if (msg.type === "SET_ENABLED") {
      const enabled = !!msg.enabled;
      if (enabled && !entitled) return { blocked: true, need_pro: true };
      pluginEnabled = enabled;
      if (!pluginEnabled) resetAllRates();
      notifyEntitled();
      return { ok: true, enabled: pluginEnabled };
    }

    // 会员门禁：非会员 / 未登录不执行任何实际控制
    if (!entitled) return { blocked: true, need_pro: true };
    if (!pluginEnabled) return { blocked: true, disabled: true };

    switch (msg.type) {
      case "SET_RATE":
        return setRate(msg.rate);
      case "ADJUST_RATE":
        return setRate(getRate() + msg.delta);
      case "PLAY_PAUSE":
        return playPause();
      case "SET_VOLUME":
        return setVolume(msg.volume);
      case "TOGGLE_MUTE":
        return toggleMute();
      case "STEP_FRAME":
        return stepFrame(msg.dir);
      case "SCREENSHOT":
        return screenshot();
      case "SET_STEP":
        stepSec = clampStep(msg.stepSec);
        return { ok: true, stepSec };
      default: {
        const adv = globalThis.__PANDA_ADV__;
        if (adv && typeof adv.handle === "function") return adv.handle(msg);
        return { error: "unknown_message" };
      }
    }
  }

  // 供进阶功能模块（advanced.js）复用的最小 API；不向页面 world 暴露
  globalThis.__PANDA_VC__ = {
    getVideo: pickVideo,
    getAllVideos: () => Array.from(document.querySelectorAll("video")),
    isEntitled: () => entitled,
    isEnabled: () => pluginEnabled,
    setActiveVideo: (v) => { activeVideo = v; }
  };

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.type) return;
    ready
      .then(() => handle(msg))
      .then((resp) => sendResponse(resp))
      .catch((e) => sendResponse({ error: String((e && e.message) || e) }));
    return true; // 异步响应
  });

  // 不注册全局键盘监听（避免 keydown 捕获被网课平台检测）。
  // 逐帧操作统一通过扩展弹窗按钮完成。
})();
