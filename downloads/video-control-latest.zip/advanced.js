/**
 * Panda视频控制&录屏截图 —— 进阶功能模块（v2.1.0）
 *
 * 由 content.js 暴露的 __PANDA_VC__ API 驱动，负责：
 *   · 全屏 / 网页全屏 / 画中画
 *   · AB 片段循环、单视频 / 列表 / 随机循环
 *   · 全局进度记忆、片头片尾跳过、自定义跳过规则
 *   · 外挂字幕 SRT/ASS/SSA、双语、样式、偏移
 *   · 画面亮度/对比度/饱和度/色相/伽马、旋转/镜像/缩放/比例
 *   · 画质信息、带字幕截图、区间录制
 *
 * 安全：所有字幕/画质文本都通过 textContent / fillText 输出；不把外部文本拼进 innerHTML。
 * 会员门禁由 content.js 在分发前统一校验，本模块只处理已授权指令。
 */
(() => {
  "use strict";
  if (globalThis.__panda_adv_loaded) return;
  globalThis.__panda_adv_loaded = true;

  const api = globalThis.__PANDA_VC__;
  if (!api) return;

  const SETTINGS_KEY = "panda_settings";
  const PROGRESS_KEY = "panda_progress";
  const MAX_PROGRESS = 300;

  const DEFAULT_FILTERS = {
    brightness: 100, contrast: 100, saturation: 100, hue: 0, gamma: 100,
    rotate: 0, flipH: false, flipV: false, scale: 100, aspect: "auto"
  };
  const DEFAULT_SUBTITLE = {
    fontSize: 22, fontFamily: "system", color: "#ffffff", stroke: "#000000",
    opacity: 1, position: "bottom", offset: 0
  };
  const DEFAULT_SETTINGS = {
    defaults: {
      rate: 1, volume: 1, aspect: "auto", loop: "none", intro: 0, outro: 0,
      filters: { ...DEFAULT_FILTERS }, subtitle: { ...DEFAULT_SUBTITLE }, skipRules: []
    },
    sites: {},
    modules: {
      speed: true, volume: true, frame: true, display: true,
      loop: true, skip: true, subtitle: true, filters: true, tools: true
    }
  };

  const state = {
    loop: "none",
    ab: { a: 0, b: 0 },
    intro: 0,
    outro: 0,
    skipRules: [],
    filters: { ...DEFAULT_FILTERS },
    subtitle: { ...DEFAULT_SUBTITLE },
    cues: { primary: [], secondary: [] },
    display: { fullscreen: false, webFullscreen: false, pip: false },
    recording: false,
    quality: null,
    audioTracks: []
  };

  let settings = normalizeSettings({});
  let settingsReady = false;
  let lastSavedAt = 0;
  let lastRuleJump = 0;
  let abSeeking = false;
  let introDone = false;
  let outroDone = false;
  let restored = new WeakSet();
  let appliedDefaults = new WeakSet();
  let originalStyles = new WeakMap();
  let subtitleEl = null;
  let toastTimer = null;
  let progressStore = {};
  let progressReady = false;
  let recordTimer = null;
  let lastQuality = null;
  let gifCapturing = false;
  let entitlementApplied = false;

  function isAllowed() {
    try { return !!(api.isEntitled() && api.isEnabled()); } catch (e) { return false; }
  }

  function handleEntitlementChange() {
    if (isAllowed()) {
      if (entitlementApplied) return;
      entitlementApplied = true;
      applyConfig();
      const v = api.getVideo();
      if (v) {
        applyDefaults(v);
        restoreProgress(v);
      }
    } else {
      entitlementApplied = false;
      appliedDefaults = new WeakSet();
      if (state.display.webFullscreen) setWebFullscreen(false);
      resetFilters();
      if (subtitleEl) subtitleEl.style.display = "none";
    }
  }

  /* ============================================================
   * 设置：默认值 + 站点覆盖
   * ============================================================ */
  function isObj(v) { return v && typeof v === "object" && !Array.isArray(v); }

  function normalizeSettings(raw) {
    const r = isObj(raw) ? raw : {};
    const d = isObj(r.defaults) ? r.defaults : {};
    return {
      defaults: {
        ...DEFAULT_SETTINGS.defaults,
        ...d,
        filters: { ...DEFAULT_FILTERS, ...(isObj(d.filters) ? d.filters : {}) },
        subtitle: { ...DEFAULT_SUBTITLE, ...(isObj(d.subtitle) ? d.subtitle : {}) },
        skipRules: Array.isArray(d.skipRules) ? d.skipRules : []
      },
      sites: isObj(r.sites) ? r.sites : {},
      modules: { ...DEFAULT_SETTINGS.modules, ...(isObj(r.modules) ? r.modules : {}) }
    };
  }

  function hostKey() {
    try {
      return (location.hostname || "").replace(/^www\./i, "").toLowerCase();
    } catch (e) { return ""; }
  }

  function currentSiteSettings() {
    const host = hostKey();
    const site = isObj(settings.sites[host]) ? settings.sites[host] : {};
    const base = settings.defaults;
    const siteVol = Number(site.volume);
    const baseVol = Number(base.volume);
    const siteRate = Number(site.rate);
    const baseRate = Number(base.rate);
    return {
      rate: Number.isFinite(siteRate) ? siteRate : (Number.isFinite(baseRate) ? baseRate : 1),
      volume: Number.isFinite(siteVol)
        ? Math.max(0, Math.min(1, siteVol))
        : (Number.isFinite(baseVol) ? Math.max(0, Math.min(1, baseVol)) : 1),
      aspect: site.aspect || base.aspect || "auto",
      loop: site.loop || base.loop || "none",
      intro: Math.max(0, Number(site.intro ?? base.intro) || 0),
      outro: Math.max(0, Number(site.outro ?? base.outro) || 0),
      filters: { ...DEFAULT_FILTERS, ...(isObj(base.filters) ? base.filters : {}), ...(isObj(site.filters) ? site.filters : {}) },
      subtitle: { ...DEFAULT_SUBTITLE, ...(isObj(base.subtitle) ? base.subtitle : {}), ...(isObj(site.subtitle) ? site.subtitle : {}) },
      skipRules: Array.isArray(site.skipRules) ? site.skipRules : (Array.isArray(base.skipRules) ? base.skipRules : []),
      modules: { ...DEFAULT_SETTINGS.modules, ...(isObj(settings.modules) ? settings.modules : {}) }
    };
  }

  async function loadSettings() {
    try {
      const o = await chrome.storage.local.get(SETTINGS_KEY);
      settings = normalizeSettings(o && o[SETTINGS_KEY]);
    } catch (e) { /* ignore */ }
    settingsReady = true;
    applyConfig();
  }

  function applyConfig() {
    const s = currentSiteSettings();
    state.loop = s.loop;
    state.intro = s.intro;
    state.outro = s.outro;
    state.skipRules = s.skipRules;
    state.filters = { ...DEFAULT_FILTERS, ...s.filters };
    // “默认画面比例”只在没有单独保存画面比例时生效；用户手动选过 auto 时尊重 auto
    if (!s.filters || s.filters.aspect === undefined) {
      state.filters.aspect = s.aspect || "auto";
    }
    state.subtitle = { ...DEFAULT_SUBTITLE, ...s.subtitle };
    if (!isAllowed()) return;
    const v = api.getVideo();
    if (v) {
      applyFilters();
      applyDefaults(v);
      updateSubtitle();
    }
  }

  async function persistSite(patch) {
    const host = hostKey();
    if (!host) return;
    try {
      const o = await chrome.storage.local.get(SETTINGS_KEY);
      const s = normalizeSettings(o && o[SETTINGS_KEY]);
      s.sites[host] = Object.assign({}, isObj(s.sites[host]) ? s.sites[host] : {}, patch);
      await chrome.storage.local.set({ [SETTINGS_KEY]: s });
      settings = s;
    } catch (e) { /* ignore */ }
  }

  async function persistSubtitleStyle() {
    try {
      const o = await chrome.storage.local.get(SETTINGS_KEY);
      const s = normalizeSettings(o && o[SETTINGS_KEY]);
      s.defaults.subtitle = { ...s.defaults.subtitle, ...state.subtitle };
      await chrome.storage.local.set({ [SETTINGS_KEY]: s });
      settings = s;
    } catch (e) { /* ignore */ }
  }

  /* ============================================================
   * 进度记忆
   * ============================================================ */
  function videoKey(v) {
    let idx = 0;
    try {
      const all = api.getAllVideos();
      idx = Math.max(0, all.indexOf(v));
    } catch (e) { /* ignore */ }
    const src = String(v.currentSrc || v.src || "").split("?")[0];
    let h = 0;
    for (let i = 0; i < src.length; i++) h = (h * 31 + src.charCodeAt(i)) | 0;
    return location.origin + location.pathname + "|" + idx + "|" + (h >>> 0).toString(36);
  }

  async function loadProgress() {
    try {
      const o = await chrome.storage.local.get(PROGRESS_KEY);
      progressStore = isObj(o && o[PROGRESS_KEY]) ? o[PROGRESS_KEY] : {};
    } catch (e) { progressStore = {}; }
    progressReady = true;
    const v = api.getVideo();
    if (v && v.readyState >= 1) restoreProgress(v);
  }

  function saveProgress(v, force) {
    if (!progressReady || !v || !restored.has(v) || !isAllowed()) return;
    const now = Date.now();
    if (!force && now - lastSavedAt < 3000) return;
    lastSavedAt = now;
    const duration = Number(v.duration);
    if (!Number.isFinite(duration) || duration <= 0) return;
    const key = videoKey(v);
    const time = v.currentTime >= duration - 3 ? 0 : Math.max(0, v.currentTime);
    progressStore[key] = { time, duration, ts: now, title: document.title.slice(0, 120) };
    const entries = Object.entries(progressStore);
    if (entries.length > MAX_PROGRESS) {
      entries.sort((a, b) => (a[1].ts || 0) - (b[1].ts || 0));
      while (entries.length > MAX_PROGRESS) delete progressStore[entries.shift()[0]];
    }
    try { chrome.storage.local.set({ [PROGRESS_KEY]: progressStore }); } catch (e) { /* ignore */ }
  }

  function restoreProgress(v) {
    if (!progressReady || !v || restored.has(v) || !isAllowed()) return;
    restored.add(v);
    const p = progressStore[videoKey(v)];
    const duration = Number(v.duration);
    if (!p || !Number.isFinite(p.time) || p.time < 5) return;
    if (Number.isFinite(duration) && duration > 0 && p.time >= duration - 8) return;
    try {
      v.currentTime = p.time;
      toast("已恢复上次播放位置 · " + fmtTime(p.time));
    } catch (e) { /* ignore */ }
  }

  function fmtTime(sec) {
    const s = Math.max(0, Math.floor(Number(sec) || 0));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const r = s % 60;
    return (h ? h + ":" : "") + String(m).padStart(2, "0") + ":" + String(r).padStart(2, "0");
  }

  /* ============================================================
   * 样式 / 浮层
   * ============================================================ */
  function ensureStyle() {
    if (document.getElementById("panda-adv-style")) return;
    const st = document.createElement("style");
    st.id = "panda-adv-style";
    st.textContent = `
      video.panda-webfs {
        position: fixed !important;
        inset: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        max-width: none !important;
        max-height: none !important;
        z-index: 2147483641 !important;
        object-fit: contain !important;
        background: #000 !important;
      }
      #panda-webfs-overlay {
        position: fixed; inset: 0; z-index: 2147483640;
        background: #000; pointer-events: none;
      }
      #panda-webfs-exit {
        position: fixed; top: 14px; right: 14px; z-index: 2147483646;
        border: 1px solid rgba(255,255,255,.28);
        border-radius: 8px; padding: 7px 12px;
        background: rgba(10,10,10,.82); color: #f4f4f5;
        font: 12.5px/1.2 system-ui, "PingFang SC", "Microsoft YaHei", sans-serif;
        cursor: pointer;
      }
      #panda-webfs-exit:hover { background: rgba(255,255,255,.09); }
      .panda-subtitle {
        position: fixed; z-index: 2147483644; display: none;
        pointer-events: none; text-align: center;
        font-family: system-ui, "PingFang SC", "Microsoft YaHei", sans-serif;
        line-height: 1.35; white-space: pre-wrap; overflow-wrap: break-word;
      }
      .panda-subtitle-line { display: block; }
      .panda-subtitle-secondary { opacity: .9; }
      .panda-toast {
        position: fixed; left: 50%; bottom: 36px; transform: translateX(-50%);
        z-index: 2147483646; max-width: 88vw; pointer-events: none;
        background: rgba(15,15,17,.9); color: #f4f4f5;
        border: 1px solid #33333a; border-radius: 999px;
        padding: 8px 14px; font: 12.5px/1.4 system-ui, "PingFang SC", "Microsoft YaHei", sans-serif;
        box-shadow: 0 4px 18px rgba(0,0,0,.4);
      }
      .panda-toast.off { opacity: 0; transition: opacity .2s ease; }
    `;
    try { (document.head || document.documentElement).appendChild(st); } catch (e) { /* CSP 下由 advanced.css 兜底 */ }
  }

  function toast(text) {
    try {
      ensureStyle();
      let el = document.getElementById("panda-toast");
      if (!el) {
        el = document.createElement("div");
        el.id = "panda-toast";
        el.className = "panda-toast";
        (document.body || document.documentElement).appendChild(el);
      }
      el.classList.remove("off");
      el.textContent = text;
      if (toastTimer) clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        el.classList.add("off");
        toastTimer = setTimeout(() => { try { el.remove(); } catch (e) { /* ignore */ } }, 220);
      }, 2200);
    } catch (e) { /* ignore */ }
  }

  /* ============================================================
   * 画面：亮度/对比度/饱和度/色相/伽马、旋转/镜像/缩放
   * ============================================================ */
  function ensureGammaSvg() {
    let svg = document.getElementById("panda-gamma-svg");
    if (svg) return svg;
    svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.id = "panda-gamma-svg";
    svg.setAttribute("width", "0");
    svg.setAttribute("height", "0");
    svg.style.position = "absolute";
    svg.style.pointerEvents = "none";
    const filter = document.createElementNS("http://www.w3.org/2000/svg", "filter");
    filter.setAttribute("id", "panda-gamma");
    const transfer = document.createElementNS("http://www.w3.org/2000/svg", "feComponentTransfer");
    for (const ch of ["R", "G", "B"]) {
      const fn = document.createElementNS("http://www.w3.org/2000/svg", "feFunc" + ch);
      fn.setAttribute("type", "gamma");
      fn.setAttribute("exponent", "1");
      fn.setAttribute("amplitude", "1");
      fn.setAttribute("offset", "0");
      transfer.appendChild(fn);
    }
    filter.appendChild(transfer);
    svg.appendChild(filter);
    try { (document.body || document.documentElement).appendChild(svg); } catch (e) { /* ignore */ }
    return svg;
  }

  function rememberVideoStyle(v) {
    if (!originalStyles.has(v)) {
      originalStyles.set(v, {
        filter: v.style.filter || "",
        transform: v.style.transform || "",
        transformOrigin: v.style.transformOrigin || "",
        objectFit: v.style.objectFit || ""
      });
    }
  }

  function applyFilters() {
    const v = api.getVideo();
    if (!v || !isAllowed()) return;
    rememberVideoStyle(v);
    const f = state.filters;
    const num = (x, d) => Number.isFinite(Number(x)) ? Number(x) : d;
    const bright = Math.max(0, Math.min(300, num(f.brightness, 100)));
    const contrast = Math.max(0, Math.min(300, num(f.contrast, 100)));
    const sat = Math.max(0, Math.min(300, num(f.saturation, 100)));
    const hue = Math.max(-180, Math.min(180, num(f.hue, 0)));
    const gamma = Math.max(20, Math.min(300, num(f.gamma, 100)));
    const changed = bright !== 100 || contrast !== 100 || sat !== 100 || hue !== 0 || gamma !== 100;
    if (changed) {
      const parts = [`brightness(${bright}%)`, `contrast(${contrast}%)`, `saturate(${sat}%)`];
      if (hue) parts.push(`hue-rotate(${hue}deg)`);
      if (gamma !== 100) {
        const svg = ensureGammaSvg();
        const exp = (gamma / 100).toFixed(3);
        svg.querySelectorAll("feFuncR,feFuncG,feFuncB").forEach((el) => el.setAttribute("exponent", exp));
        parts.push("url(#panda-gamma)");
      }
      v.style.filter = parts.join(" ");
    } else {
      v.style.filter = originalStyles.get(v).filter;
    }

    const rotate = [0, 90, 180, 270].includes(Number(f.rotate)) ? Number(f.rotate) : 0;
    const scale = Math.max(50, Math.min(200, num(f.scale, 100)));
    const transforms = [];
    if (rotate) transforms.push(`rotate(${rotate}deg)`);
    if (f.flipH) transforms.push("scaleX(-1)");
    if (f.flipV) transforms.push("scaleY(-1)");
    if (scale !== 100) transforms.push(`scale(${scale / 100})`);
    if (transforms.length) {
      v.style.transform = transforms.join(" ");
      v.style.transformOrigin = "center center";
    } else {
      v.style.transform = originalStyles.get(v).transform;
      v.style.transformOrigin = originalStyles.get(v).transformOrigin;
    }

    const aspect = f.aspect || "auto";
    if (aspect === "cover" || aspect === "fill" || aspect === "contain") v.style.objectFit = aspect;
    else v.style.objectFit = originalStyles.get(v).objectFit;
  }

  function resetFilters() {
    state.filters = { ...DEFAULT_FILTERS };
    const v = api.getVideo();
    if (v && originalStyles.has(v)) {
      const o = originalStyles.get(v);
      v.style.filter = o.filter;
      v.style.transform = o.transform;
      v.style.transformOrigin = o.transformOrigin;
      v.style.objectFit = o.objectFit;
    }
    return { filters: state.filters };
  }

  /* ============================================================
   * 字幕
   * ============================================================ */
  function decodeEntities(s) {
    return String(s || "")
      .replace(/&nbsp;/gi, " ")
      .replace(/&amp;/gi, "&")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'");
  }

  function cleanSubText(s) {
    return decodeEntities(String(s || "")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<[^>]*>/g, "")
      .replace(/\{[^}]*\}/g, "")
      .replace(/\\N/g, "\n")
      .replace(/\\n/g, "\n")
      .replace(/\\h/g, " "))
      .replace(/[ \t]+\n/g, "\n")
      .trim();
  }

  function parseTimeSRT(t) {
    const m = String(t).trim().match(/^(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})$/);
    if (!m) return NaN;
    return (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / 1000;
  }

  function parseTimeASS(t) {
    const m = String(t).trim().match(/^(\d{1,2}):(\d{2}):(\d{2})[.](\d{1,2})$/);
    if (!m) return NaN;
    return (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / (m[4].length === 2 ? 100 : 1000);
  }

  function parseSRT(text) {
    const out = [];
    const blocks = String(text || "").replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n").split(/\n{2,}/);
    for (const block of blocks) {
      const lines = block.split("\n").filter((l) => l.trim() !== "");
      if (!lines.length) continue;
      let i = 0;
      if (/^\d+$/.test(lines[0].trim())) i = 1;
      const timeLine = lines[i] || "";
      const m = timeLine.match(/(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})/);
      if (!m) continue;
      const start = parseTimeSRT(m[1]);
      const end = parseTimeSRT(m[2]);
      const body = cleanSubText(lines.slice(i + 1).join("\n"));
      if (Number.isFinite(start) && Number.isFinite(end) && end > start && body) out.push({ start, end, text: body });
    }
    return out.sort((a, b) => a.start - b.start);
  }

  function parseASS(text) {
    const src = String(text || "").replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
    const lines = src.split("\n");
    let inEvents = false;
    let fields = [];
    const out = [];
    for (const raw of lines) {
      const line = raw.trim();
      if (/^\[Events\]$/i.test(line)) { inEvents = true; continue; }
      if (!inEvents) continue;
      if (/^Format:/i.test(line)) {
        fields = line.slice(7).split(",").map((s) => s.trim());
        continue;
      }
      if (!/^Dialogue:/i.test(line)) continue;
      const body = line.slice(9);
      const parts = body.split(",");
      if (!fields.length) continue;
      const idxStart = fields.indexOf("Start");
      const idxEnd = fields.indexOf("End");
      const idxText = fields.indexOf("Text");
      if (idxStart < 0 || idxEnd < 0 || idxText < 0) continue;
      const max = fields.length - 1;
      const head = parts.slice(0, max);
      const textPart = parts.slice(max).join(",");
      const start = parseTimeASS(head[idxStart]);
      const end = parseTimeASS(head[idxEnd]);
      const content = cleanSubText(textPart);
      if (Number.isFinite(start) && Number.isFinite(end) && end > start && content) {
        out.push({ start, end, text: content });
      } else if (start === 0 && end === 0) {
        void idxText;
      }
    }
    return out.sort((a, b) => a.start - b.start);
  }

  function parseSubtitle(text, format) {
    const f = String(format || "").toLowerCase();
    const s = String(text || "");
    if (f === "ass" || f === "ssa" || /\[Events\]/i.test(s)) return parseASS(s);
    return parseSRT(s);
  }

  function findCue(cues, t) {
    if (!cues || !cues.length) return null;
    for (let i = 0; i < cues.length; i++) {
      const c = cues[i];
      if (t < c.start) break;
      if (t <= c.end) return c;
    }
    return null;
  }

  function ensureSubtitleEl() {
    if (subtitleEl) return subtitleEl;
    ensureStyle();
    const d = document.createElement("div");
    d.id = "panda-subtitle";
    d.className = "panda-subtitle";
    const secondary = document.createElement("div");
    secondary.className = "panda-subtitle-line panda-subtitle-secondary";
    const primary = document.createElement("div");
    primary.className = "panda-subtitle-line panda-subtitle-primary";
    d.appendChild(secondary);
    d.appendChild(primary);
    try { (document.fullscreenElement || document.body || document.documentElement).appendChild(d); } catch (e) { /* ignore */ }
    subtitleEl = d;
    return d;
  }

  function moveSubtitleToFullscreen() {
    if (!subtitleEl) return;
    const target = document.fullscreenElement || document.body || document.documentElement;
    if (subtitleEl.parentNode !== target) target.appendChild(subtitleEl);
  }

  function applySubtitleStyle(el) {
    const s = state.subtitle;
    const color = /^#[0-9a-f]{3,8}$/i.test(String(s.color || "")) ? s.color : "#ffffff";
    const stroke = /^#[0-9a-f]{3,8}$/i.test(String(s.stroke || "")) ? s.stroke : "#000000";
    const size = Math.max(12, Math.min(64, Number(s.fontSize) || 22));
    const fonts = {
      system: 'system-ui, "PingFang SC", "Microsoft YaHei", sans-serif',
      sans: '"Microsoft YaHei", "PingFang SC", "Noto Sans SC", sans-serif',
      serif: '"Songti SC", SimSun, "Noto Serif SC", serif',
      mono: 'ui-monospace, "Cascadia Mono", "Courier New", monospace'
    };
    el.style.fontFamily = fonts[s.fontFamily] || fonts.system;
    el.style.fontSize = size + "px";
    el.style.color = color;
    el.style.opacity = String(Math.max(0.1, Math.min(1, Number(s.opacity) || 1)));
    el.style.fontWeight = "600";
    el.style.textShadow = `-1.5px -1.5px 0 ${stroke}, 1.5px -1.5px 0 ${stroke}, -1.5px 1.5px 0 ${stroke}, 1.5px 1.5px 0 ${stroke}, 0 2px 3px rgba(0,0,0,.7)`;
  }

  function updateSubtitle() {
    const v = api.getVideo();
    if (!isAllowed()) {
      if (subtitleEl) subtitleEl.style.display = "none";
      return;
    }
    if (!v || (!state.cues.primary.length && !state.cues.secondary.length)) {
      if (subtitleEl) subtitleEl.style.display = "none";
      return;
    }
    const t = v.currentTime - (Number(state.subtitle.offset) || 0);
    const p = findCue(state.cues.primary, t);
    const s = findCue(state.cues.secondary, t);
    if (!p && !s) {
      if (subtitleEl) subtitleEl.style.display = "none";
      return;
    }
    const el = ensureSubtitleEl();
    moveSubtitleToFullscreen();
    applySubtitleStyle(el);
    const pEl = el.querySelector(".panda-subtitle-primary");
    const sEl = el.querySelector(".panda-subtitle-secondary");
    pEl.textContent = p ? p.text : "";
    sEl.textContent = s ? s.text : "";
    pEl.style.display = p ? "block" : "none";
    sEl.style.display = s ? "block" : "none";

    const r = v.getBoundingClientRect();
    if (r.width < 20 || r.height < 20) { el.style.display = "none"; return; }
    const full = !!document.fullscreenElement || state.display.webFullscreen;
    el.style.display = "block";
    el.style.left = Math.max(0, full ? 0 : r.left) + "px";
    el.style.width = Math.max(80, full ? window.innerWidth : r.width) + "px";
    el.style.bottom = "auto";
    el.style.top = "auto";
    if (state.subtitle.position === "top") {
      el.style.top = Math.max(8, (full ? 0 : r.top) + Math.max(12, r.height * 0.06)) + "px";
    } else {
      el.style.bottom = Math.max(8, (full ? 0 : window.innerHeight - r.bottom) + Math.max(12, r.height * 0.06)) + "px";
    }
    el.style.padding = "0 12px";
  }

  /* ============================================================
   * 全屏 / 网页全屏 / 画中画
   * ============================================================ */
  function webFsOverlay() {
    let ov = document.getElementById("panda-webfs-overlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "panda-webfs-overlay";
      (document.body || document.documentElement).appendChild(ov);
    }
    return ov;
  }

  function setWebFullscreen(on) {
    const v = api.getVideo();
    if (!v) return { error: "页面没有视频" };
    ensureStyle();
    if (on) {
      if (document.fullscreenElement) { try { document.exitFullscreen(); } catch (e) { /* ignore */ } }
      webFsOverlay();
      v.classList.add("panda-webfs");
      let exit = document.getElementById("panda-webfs-exit");
      if (!exit) {
        exit = document.createElement("button");
        exit.id = "panda-webfs-exit";
        exit.type = "button";
        exit.textContent = "退出网页全屏";
        exit.addEventListener("click", (e) => { e.stopPropagation(); setWebFullscreen(false); });
        (document.body || document.documentElement).appendChild(exit);
      }
      state.display.webFullscreen = true;
    } else {
      v.classList.remove("panda-webfs");
      const ov = document.getElementById("panda-webfs-overlay");
      if (ov) ov.remove();
      const exit = document.getElementById("panda-webfs-exit");
      if (exit) exit.remove();
      state.display.webFullscreen = false;
    }
    updateSubtitle();
    return { display: { ...state.display } };
  }

  async function toggleFullscreen() {
    const v = api.getVideo();
    if (!v) return { error: "页面没有视频" };
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await v.requestFullscreen();
      return { display: { ...state.display } };
    } catch (e) {
      // 浏览器要求“用户手势”，扩展弹窗的消息回调可能丢失激活态 → 在页面内放一个一次性按钮
      armGesture("fullscreen");
      return { pendingGesture: "fullscreen" };
    }
  }

  async function togglePip() {
    const v = api.getVideo();
    if (!v) return { error: "页面没有视频" };
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else await v.requestPictureInPicture();
      return { display: { ...state.display } };
    } catch (e) {
      armGesture("pip");
      return { pendingGesture: "pip" };
    }
  }

  function armGesture(kind) {
    try {
      ensureStyle();
      let btn = document.getElementById("panda-gesture");
      if (!btn) {
        btn = document.createElement("button");
        btn.id = "panda-gesture";
        btn.type = "button";
        btn.style.cssText = "position:fixed;left:50%;top:18%;transform:translateX(-50%);z-index:2147483646;border:1px solid rgba(255,255,255,.3);border-radius:999px;padding:9px 16px;background:rgba(10,10,10,.92);color:#f4f4f5;font:13px/1.2 system-ui,'PingFang SC','Microsoft YaHei',sans-serif;cursor:pointer;box-shadow:0 6px 24px rgba(0,0,0,.45)";
        (document.body || document.documentElement).appendChild(btn);
      }
      btn.textContent = kind === "pip" ? "点击进入画中画" : "点击进入全屏";
      btn.onclick = async (e) => {
        e.stopPropagation();
        btn.remove();
        const v = api.getVideo();
        if (!v) return;
        try {
          if (kind === "pip") {
            if (document.pictureInPictureElement) await document.exitPictureInPicture();
            else await v.requestPictureInPicture();
          } else {
            if (document.fullscreenElement) await document.exitFullscreen();
            else await v.requestFullscreen();
          }
        } catch (err) {
          toast(kind === "pip" ? "浏览器未允许画中画" : "浏览器未允许全屏");
        }
      };
    } catch (e) { /* ignore */ }
  }

  /* ============================================================
   * 循环 / AB / 跳过
   * ============================================================ */
  function setLoop(mode) {
    const m = ["none", "single", "list", "shuffle"].includes(mode) ? mode : "none";
    state.loop = m;
    const v = api.getVideo();
    if (v) v.loop = false;
    persistSite({ loop: m });
    return { loop: m };
  }

  function setAB(action, a, b) {
    const v = api.getVideo();
    if (!v) return { error: "页面没有视频" };
    let next = { ...state.ab };
    if (action === "a") next.a = v.currentTime;
    else if (action === "b") next.b = v.currentTime;
    else if (action === "set") {
      next.a = Math.max(0, Number(a) || 0);
      next.b = Math.max(0, Number(b) || 0);
    } else if (action === "clear") {
      next = { a: 0, b: 0 };
    }
    if (next.b > 0 && next.b <= next.a + 0.3) {
      return { error: "B 点必须晚于 A 点至少 0.3 秒" };
    }
    state.ab = next;
    if (next.b > next.a && next.b > 0) {
      try { if (v.currentTime < next.a || v.currentTime >= next.b) v.currentTime = next.a; } catch (e) { /* ignore */ }
    }
    return { ab: { ...state.ab } };
  }

  function setSkip(patch) {
    if (isObj(patch)) {
      if (patch.intro !== undefined) state.intro = Math.max(0, Number(patch.intro) || 0);
      if (patch.outro !== undefined) state.outro = Math.max(0, Number(patch.outro) || 0);
      if (Array.isArray(patch.rules)) {
        state.skipRules = patch.rules
          .filter((r) => r && Number.isFinite(Number(r.start)) && Number.isFinite(Number(r.end)) && Number(r.end) > Number(r.start))
          .map((r) => ({ start: Math.max(0, Number(r.start)), end: Math.max(0, Number(r.end)), label: String(r.label || "跳过片段") }));
      }
    }
    persistSite({ intro: state.intro, outro: state.outro, skipRules: state.skipRules });
    return { intro: state.intro, outro: state.outro, skipRules: state.skipRules };
  }

  function onTimeUpdate(v) {
    if (!v || gifCapturing || !isAllowed()) return;
    // 录制期间不要触发 AB / 片头片尾 / 自定义跳过，否则“片头→片尾”会被截断
    if (state.recording) {
      saveProgress(v, false);
      updateSubtitle();
      return;
    }
    const t = v.currentTime;
    const d = v.duration;

    // AB 循环
    if (!abSeeking && state.ab.b > 0 && state.ab.b > state.ab.a + 0.3) {
      if (t >= state.ab.b - 0.04) {
        abSeeking = true;
        try { v.currentTime = state.ab.a; } catch (e) { /* ignore */ }
        setTimeout(() => { abSeeking = false; }, 120);
      }
    }

    // 片头 / 片尾 / 自定义跳过规则
    if (state.intro > 0 && !introDone && t < state.intro) {
      introDone = true;
      try { v.currentTime = state.intro; toast("已跳过片头 " + fmtTime(state.intro)); } catch (e) { /* ignore */ }
      return;
    }
    if (Number.isFinite(d) && state.outro > 0 && !outroDone && d - t <= state.outro) {
      outroDone = true;
      try { v.currentTime = Math.max(0, d - 0.05); } catch (e) { /* ignore */ }
      return;
    }
    const now = Date.now();
    for (const r of state.skipRules) {
      if (t >= r.start && t < r.end && now - lastRuleJump > 800) {
        lastRuleJump = now;
        try { v.currentTime = r.end; toast("已跳过：" + r.label); } catch (e) { /* ignore */ }
        return;
      }
    }

    saveProgress(v, false);
    updateSubtitle();
  }

  function onEnded(v) {
    if (!v || v !== api.getVideo() || !isAllowed() || state.recording) return;
    if (state.loop === "single") {
      try { v.currentTime = 0; v.play().catch(() => {}); } catch (e) { /* ignore */ }
      return;
    }
    if (state.loop === "list" || state.loop === "shuffle") {
      const all = api.getAllVideos().filter((x) => x && x.offsetWidth > 0);
      if (!all.length) return;
      let next = null;
      if (state.loop === "shuffle") {
        const pool = all.filter((x) => x !== v);
        next = pool.length ? pool[Math.floor(Math.random() * pool.length)] : v;
      } else {
        const i = all.indexOf(v);
        next = all[(i + 1) % all.length] || v;
      }
      try {
        api.setActiveVideo(next);
        next.currentTime = 0;
        next.play().catch(() => {});
      } catch (e) { /* ignore */ }
      return;
    }
    saveProgress(v, true);
  }

  /* ============================================================
   * GIF：3-3-2 调色板 + LZW；不依赖第三方库
   * ============================================================ */
  function gifPalette() {
    const table = new Uint8Array(256 * 3);
    for (let i = 0; i < 256; i++) {
      const r = (i >> 5) & 7;
      const g = (i >> 2) & 7;
      const b = i & 3;
      table[i * 3] = Math.round((r * 255) / 7);
      table[i * 3 + 1] = Math.round((g * 255) / 7);
      table[i * 3 + 2] = Math.round((b * 255) / 3);
    }
    return table;
  }

  function gifLzw(indices) {
    const clear = 256;
    const end = 257;
    const out = [];
    let bitBuf = 0;
    let bitCount = 0;
    let codeSize = 9;
    let nextCode = 258;
    let dict = new Map();
    const emit = (code) => {
      bitBuf |= code << bitCount;
      bitCount += codeSize;
      while (bitCount >= 8) {
        out.push(bitBuf & 255);
        bitBuf >>= 8;
        bitCount -= 8;
      }
    };
    const reset = () => {
      dict = new Map();
      codeSize = 9;
      nextCode = 258;
    };
    emit(clear);
    if (!indices.length) {
      emit(end);
      if (bitCount > 0) out.push(bitBuf & 255);
      return out;
    }
    let prefix = indices[0];
    for (let i = 1; i < indices.length; i++) {
      const k = indices[i];
      const key = prefix + "," + k;
      const found = dict.get(key);
      if (found !== undefined) {
        prefix = found;
      } else {
        emit(prefix);
        if (nextCode < 4096) {
          dict.set(key, nextCode++);
          if (nextCode > (1 << codeSize) && codeSize < 12) codeSize++;        } else {
          emit(clear);
          reset();
        }
        prefix = k;
      }
    }
    emit(prefix);
    emit(end);
    if (bitCount > 0) out.push(bitBuf & 255);
    return out;
  }

  function encodeGif(frames, width, height, delayMs) {
    const parts = [];
    const push = (...bytes) => { for (const b of bytes) parts.push(b & 255); };
    const ascii = (s) => { for (let i = 0; i < s.length; i++) parts.push(s.charCodeAt(i)); };
    ascii("GIF89a");
    push(width & 255, (width >> 8) & 255, height & 255, (height >> 8) & 255, 0xF7, 0, 0);
    const palette = gifPalette();
    for (const v of palette) parts.push(v);
    // Netscape loop
    push(0x21, 0xFF, 0x0B);
    ascii("NETSCAPE2.0");
    push(0x03, 0x01, 0, 0, 0);
    const delay = Math.max(2, Math.round(delayMs / 10));
    const delayLo = delay & 255;
    const delayHi = (delay >> 8) & 255;
    for (const frame of frames) {
      push(0x21, 0xF9, 0x04, 0x00, delayLo, delayHi, 0x00, 0x00);
      push(0x2C, 0, 0, 0, 0, width & 255, (width >> 8) & 255, height & 255, (height >> 8) & 255, 0x00);
      const compressed = gifLzw(frame.index);
      push(8);
      for (let i = 0; i < compressed.length; i += 255) {
        const chunk = compressed.slice(i, i + 255);
        push(chunk.length);
        for (const b of chunk) parts.push(b);
      }
      push(0);
    }
    push(0x3B);
    return new Blob([new Uint8Array(parts)], { type: "image/gif" });
  }

  function quantizeGif(data) {
    const out = new Uint8Array(data.length / 4);
    for (let i = 0, j = 0; i < data.length; i += 4, j++) {
      const r = Math.round((data[i] * 7) / 255);
      const g = Math.round((data[i + 1] * 7) / 255);
      const b = Math.round((data[i + 2] * 3) / 255);
      out[j] = (r << 5) | (g << 2) | b;
    }
    return out;
  }

  async function gifRange(start, duration, fps, maxWidth) {
    const v = api.getVideo();
    if (!v) return { error: "页面没有视频" };
    const w0 = v.videoWidth, h0 = v.videoHeight;
    if (!w0 || !h0) return { error: "视频尚未加载出画面" };
    const dur = Math.max(1, Math.min(6, Number(duration) || 3));
    const rate = Math.max(4, Math.min(12, Number(fps) || 8));
    const width = Math.max(240, Math.min(480, Number(maxWidth) || 360));
    const height = Math.max(2, Math.round((h0 / w0) * width));
    const count = Math.max(1, Math.round(dur * rate));
    const startTime = Math.max(0, Math.min(Number(v.duration) || Infinity, Number(start) || 0));
    const oldTime = v.currentTime;
    const wasPlaying = !v.paused;
    const frames = [];
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return { error: "无法创建画布" };
    gifCapturing = true;
    try {
      try { v.pause(); } catch (e) { /* ignore */ }
      for (let i = 0; i < count; i++) {
        v.currentTime = Math.min((Number(v.duration) || Infinity), startTime + i / rate);
        await waitSeeked(v, 1600);
        ctx.drawImage(v, 0, 0, width, height);
        const img = ctx.getImageData(0, 0, width, height);
        frames.push({ index: quantizeGif(img.data) });
        if (i === 0 || i === count - 1) toast("GIF 截取 " + (i + 1) + "/" + count + "…");
      }
      const blob = encodeGif(frames, width, height, 1000 / rate);
      const ts = new Date();
      const pad = (n) => String(n).padStart(2, "0");
      const name = "panda_gif_" + ts.getFullYear() + pad(ts.getMonth() + 1) + pad(ts.getDate())
        + "_" + pad(ts.getHours()) + pad(ts.getMinutes()) + pad(ts.getSeconds()) + ".gif";
      downloadBlob(blob, name);
      toast("GIF 已保存 · " + count + " 帧");
      return { ok: true, filename: name, frames: count, width, height };
    } catch (e) {
      return { error: "GIF 生成失败（跨域/版权视频无法读取画面）" };
    } finally {
      gifCapturing = false;
      try { v.currentTime = oldTime; } catch (e) { /* ignore */ }
      if (wasPlaying) { try { v.play().catch(() => {}); } catch (e) { /* ignore */ } }
    }
  }

  async function downloadVideo() {
    const v = api.getVideo();
    if (!v) return { error: "页面没有视频" };
    const src = String(v.currentSrc || v.src || "");
    if (!src) return { error: "没有可下载的视频地址" };
    try {
      const resp = await fetch(src, { credentials: "include" });
      if (!resp.ok) return { error: "下载失败：HTTP " + resp.status };
      const blob = await resp.blob();
      let name = "panda_video";
      try {
        const u = new URL(src, location.href);
        const last = decodeURIComponent(u.pathname.split("/").pop() || "");
        if (last) name = last.replace(/[\\/:*?"<>|]/g, "_").slice(0, 80);
      } catch (e) { /* ignore */ }
      if (!/\.[a-z0-9]{2,5}$/i.test(name)) {
        const type = String(blob.type || "");
        name += type.includes("mp4") ? ".mp4" : type.includes("webm") ? ".webm" : ".bin";
      }
      downloadBlob(blob, name);
      return { ok: true, filename: name };
    } catch (e) {
      return { error: "下载失败（跨域 / 受保护视频无法直接下载）" };
    }
  }

  /* ============================================================
   * 画质 / 音轨 / 截图 / 录制
   * ============================================================ */
  async function getQuality() {
    const v = api.getVideo();
    if (!v) return { error: "页面没有视频" };
    const width = v.videoWidth || 0;
    const height = v.videoHeight || 0;
    let fps = 0;
    if (typeof v.requestVideoFrameCallback === "function") {
      fps = await new Promise((resolve) => {
        let frames = 0;
        let finished = false;
        const start = performance.now();
        const finish = (value) => {
          if (finished) return;
          finished = true;
          clearTimeout(timer);
          resolve(value);
        };
        const timer = setTimeout(() => finish(0), 1000);
        const tick = () => {
          if (finished) return;
          frames++;
          if (performance.now() - start < 700) {
            try { v.requestVideoFrameCallback(tick); } catch (e) { finish(0); }
          } else {
            finish(Math.round((frames * 1000) / (performance.now() - start)));
          }
        };
        try { v.requestVideoFrameCallback(tick); } catch (e) { finish(0); }
      });
    }
    let bitrate = null;
    try {
      const src = String(v.currentSrc || "");
      const entry = performance.getEntriesByType("resource").find((x) => src && x.name === src);
      if (entry && entry.transferSize > 0 && entry.duration > 0) {
        bitrate = Math.round((entry.transferSize * 8) / (entry.duration / 1000) / 1000);
      }
    } catch (e) { /* ignore */ }
    const q = v.getVideoPlaybackQuality ? v.getVideoPlaybackQuality() : {};
    lastQuality = {
      width, height, fps,
      frames: q.totalVideoFrames || 0,
      dropped: q.droppedVideoFrames || 0,
      bitrate,
      codec: "浏览器未暴露"
    };
    state.quality = lastQuality;
    return lastQuality;
  }

  function getAudioTracks(v) {
    try {
      if (!v || !v.audioTracks) return [];
      return Array.from(v.audioTracks).map((t, i) => ({
        index: i, label: t.label || "", language: t.language || "", enabled: !!t.enabled
      }));
    } catch (e) { return []; }
  }

  function setAudioTrack(index) {
    const v = api.getVideo();
    if (!v || !v.audioTracks) return { error: "当前视频/浏览器不暴露多音轨" };
    const tracks = Array.from(v.audioTracks);
    if (!tracks.length) return { error: "没有可切换的音轨" };
    const i = Math.max(0, Math.min(tracks.length - 1, Number(index) || 0));
    tracks.forEach((t, n) => { t.enabled = n === i; });
    return { audioTracks: getAudioTracks(v) };
  }

  function drawSubtitleOnCanvas(ctx, w, h, t) {
    const p = findCue(state.cues.primary, t);
    const s = findCue(state.cues.secondary, t);
    if (!p && !s) return;
    const size = Math.max(14, Math.round((Number(state.subtitle.fontSize) || 22) * (h / 480)));
    const fonts = {
      system: 'system-ui, "PingFang SC", "Microsoft YaHei", sans-serif',
      sans: '"Microsoft YaHei", "PingFang SC", "Noto Sans SC", sans-serif',
      serif: '"Songti SC", SimSun, "Noto Serif SC", serif',
      mono: 'ui-monospace, "Cascadia Mono", "Courier New", monospace'
    };
    ctx.font = `600 ${size}px ${fonts[state.subtitle.fontFamily] || fonts.system}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";
    ctx.lineJoin = "round";
    const stroke = /^#[0-9a-f]{3,8}$/i.test(String(state.subtitle.stroke || "")) ? state.subtitle.stroke : "#000";
    const color = /^#[0-9a-f]{3,8}$/i.test(String(state.subtitle.color || "")) ? state.subtitle.color : "#fff";
    const maxW = w * 0.86;
    const x = w / 2;
    let y = state.subtitle.position === "top" ? size * 1.4 : h - size * 1.2;
    if (s) {
      ctx.lineWidth = Math.max(2, size / 8);
      ctx.strokeStyle = stroke;
      ctx.fillStyle = color;
      if (typeof ctx.strokeText === "function") ctx.strokeText(s.text, x, y, maxW);
      ctx.fillText(s.text, x, y, maxW);
      y += size * 1.25;
    }
    if (p) {
      ctx.lineWidth = Math.max(2, size / 8);
      ctx.strokeStyle = stroke;
      ctx.fillStyle = color;
      if (typeof ctx.strokeText === "function") ctx.strokeText(p.text, x, y, maxW);
      ctx.fillText(p.text, x, y, maxW);
    }
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    (document.body || document.documentElement).appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 20000);
  }

  async function screenshotWithSubtitle() {
    const v = api.getVideo();
    if (!v) return { ok: false, error: "页面没有视频" };
    const w = v.videoWidth, h = v.videoHeight;
    if (!w || !h) return { ok: false, error: "视频尚未加载出画面" };
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    const ctx = c.getContext("2d");
    if (!ctx) return { ok: false, error: "无法创建画布" };
    try {
      ctx.drawImage(v, 0, 0, w, h);
      drawSubtitleOnCanvas(ctx, w, h, v.currentTime - (Number(state.subtitle.offset) || 0));
      const blob = await new Promise((resolve, reject) => {
        try { c.toBlob((b) => b ? resolve(b) : reject(new Error("encode")), "image/png"); } catch (e) { reject(e); }
      });
      const ts = new Date();
      const pad = (n) => String(n).padStart(2, "0");
      const name = "panda_sub_" + ts.getFullYear() + pad(ts.getMonth() + 1) + pad(ts.getDate())
        + "_" + pad(ts.getHours()) + pad(ts.getMinutes()) + pad(ts.getSeconds()) + ".png";
      downloadBlob(blob, name);
      return { ok: true, filename: name };
    } catch (e) {
      return { ok: false, error: "截图失败（跨域/版权视频无法导出）" };
    }
  }

  function waitSeeked(v, timeout = 1800) {
    return new Promise((resolve) => {
      let done = false;
      const finish = () => { if (done) return; done = true; v.removeEventListener("seeked", finish); resolve(); };
      v.addEventListener("seeked", finish, { once: true });
      setTimeout(finish, timeout);
    });
  }

  async function recordRange(start, end) {
    const v = api.getVideo();
    if (!v) return { error: "页面没有视频" };
    if (state.recording) return { error: "正在录制中" };
    if (typeof MediaRecorder === "undefined" || typeof v.captureStream !== "function") {
      return { error: "当前浏览器不支持视频片段录制" };
    }
    const d = Number(v.duration);
    const total = Number.isFinite(d) && d > 0 ? d : 0;
    const s = Math.max(0, Math.min(total || Infinity, Number(start) || 0));
    let e = Number(end);
    if (!Number.isFinite(e) || e <= s) e = s + 10;
    if (total) e = Math.min(total, e);
    if (e <= s + 0.2) {
      return { error: "录制范围无效：当前位置已接近片尾" };
    }
    let endedHandler = null;
    try {
      v.currentTime = s;
      await waitSeeked(v);
      const stream = v.captureStream();
      const mime = [
        "video/webm;codecs=vp9,opus",
        "video/webm;codecs=vp8,opus",
        "video/webm"
      ].find((m) => MediaRecorder.isTypeSupported(m)) || "";
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      const chunks = [];
      const stop = () => {
        try { if (rec.state !== "inactive") rec.stop(); } catch (e) { /* ignore */ }
      };
      endedHandler = () => stop();
      v.addEventListener("ended", endedHandler, { once: true });
      rec.ondataavailable = (ev) => { if (ev.data && ev.data.size) chunks.push(ev.data); };
      rec.onstop = () => {
        state.recording = false;
        if (endedHandler) v.removeEventListener("ended", endedHandler);
        if (recordTimer) { clearTimeout(recordTimer); recordTimer = null; }
        try {
          const blob = new Blob(chunks, { type: mime || "video/webm" });
          const ts = new Date();
          const pad = (n) => String(n).padStart(2, "0");
          downloadBlob(blob, `panda_clip_${ts.getFullYear()}${pad(ts.getMonth() + 1)}${pad(ts.getDate())}_${pad(ts.getHours())}${pad(ts.getMinutes())}${pad(ts.getSeconds())}.webm`);
          toast("录制完成，已保存 WebM");
        } catch (e) { /* ignore */ }
      };
      v.play().catch(() => {});
      rec.start(500);
      state.recording = true;
      if (recordTimer) clearTimeout(recordTimer);
      recordTimer = setTimeout(stop, Math.max(500, (e - s) * 1000));
      return { ok: true, start: s, end: e, mime: mime || "video/webm" };
    } catch (e) {
      state.recording = false;
      if (endedHandler) { try { v.removeEventListener("ended", endedHandler); } catch (err) { /* ignore */ } }
      return { error: "录制失败：" + ((e && e.message) || e) };
    }
  }

  /* ============================================================
   * 状态 / 指令
   * ============================================================ */
  function getState() {
    const v = api.getVideo();
    return {
      loop: state.loop,
      ab: { ...state.ab },
      intro: state.intro,
      outro: state.outro,
      skipRules: state.skipRules.slice(0, 50),
      filters: { ...state.filters },
      subtitle: { ...state.subtitle },
      subtitleCues: { primary: state.cues.primary.length, secondary: state.cues.secondary.length },
      display: { ...state.display },
      recording: state.recording,
      quality: state.quality,
      time: v ? v.currentTime : 0,
      duration: v ? v.duration : 0,
      audioTracks: v ? getAudioTracks(v) : []
    };
  }

  async function handle(msg) {
    if (!msg || !msg.type) return { error: "empty_message" };
    switch (msg.type) {
      case "SET_LOOP":
        return setLoop(msg.mode);
      case "SET_AB":
        return setAB(msg.action, msg.a, msg.b);
      case "SET_SKIP":
        return setSkip(msg);
      case "TOGGLE_FULLSCREEN":
        return toggleFullscreen();
      case "TOGGLE_WEB_FULLSCREEN":
        return setWebFullscreen(!state.display.webFullscreen);
      case "TOGGLE_PIP":
        return togglePip();
      case "SET_FILTERS":
        state.filters = { ...state.filters, ...(isObj(msg.filters) ? msg.filters : {}) };
        applyFilters();
        persistSite({ filters: state.filters });
        return { filters: { ...state.filters } };
      case "RESET_FILTERS":
        resetFilters();
        persistSite({ filters: state.filters });
        return { filters: { ...state.filters } };
      case "GET_QUALITY":
        return getQuality();
      case "LOAD_SUBTITLE": {
        const cues = parseSubtitle(msg.text, msg.format);
        if (!cues.length) return { error: "未识别到字幕，请确认文件为 SRT/ASS/SSA" };
        const track = msg.track === "secondary" ? "secondary" : "primary";
        state.cues[track] = cues;
        updateSubtitle();
        return { ok: true, track, count: cues.length };
      }
      case "CLEAR_SUBTITLE": {
        const track = msg.track === "secondary" ? "secondary" : (msg.track === "all" ? "all" : "primary");
        if (track === "all") state.cues = { primary: [], secondary: [] };
        else state.cues[track] = [];
        updateSubtitle();
        return { ok: true, cues: { primary: state.cues.primary.length, secondary: state.cues.secondary.length } };
      }
      case "SET_SUBTITLE_STYLE":
        state.subtitle = { ...state.subtitle, ...(isObj(msg.style) ? msg.style : {}) };
        updateSubtitle();
        persistSubtitleStyle();
        return { subtitle: { ...state.subtitle } };
      case "SET_SUBTITLE_OFFSET":
        state.subtitle.offset = Number(msg.offset) || 0;
        updateSubtitle();
        persistSubtitleStyle();
        return { subtitle: { ...state.subtitle } };
      case "SCREENSHOT_SUB":
        return screenshotWithSubtitle();
      case "GIF_RANGE":
        return gifRange(msg.start, msg.duration, msg.fps, msg.width);
      case "RECORD_RANGE":
        return recordRange(msg.start, msg.end);
      case "DOWNLOAD_VIDEO":
        return downloadVideo();
      case "SET_AUDIO_TRACK":
        return setAudioTrack(msg.index);
      case "CLEAR_PROGRESS": {
        const v = api.getVideo();
        if (v) {
          delete progressStore[videoKey(v)];
          try { chrome.storage.local.set({ [PROGRESS_KEY]: progressStore }); } catch (e) { /* ignore */ }
        }
        return { ok: true };
      }
      default:
        return { error: "unknown_message" };
    }
  }

  /* ============================================================
   * 事件
   * ============================================================ */
  function onReady() {
    try {
      ensureStyle();
      ensureGammaSvg();
    } catch (e) { /* 页面 CSP/Trusted Types 限制时仍继续加载设置 */ }
    loadSettings();
    loadProgress();
    const v = api.getVideo();
    if (v && v.readyState >= 1) {
      applyDefaults(v);
      restoreProgress(v);
    }
  }

  function applyDefaults(v) {
    if (!settingsReady || !v || appliedDefaults.has(v) || !isAllowed()) return;
    appliedDefaults.add(v);
    const s = currentSiteSettings();
    try {
      if (Number.isFinite(s.rate)) v.playbackRate = Math.max(0.1, Math.min(5, s.rate));
      if (Number.isFinite(s.volume)) v.volume = Math.max(0, Math.min(1, s.volume));
      if (s.aspect && s.aspect !== "auto") v.style.objectFit = s.aspect;
    } catch (e) { /* ignore */ }
    state.filters = { ...DEFAULT_FILTERS, ...s.filters };
    applyFilters();
  }

  document.addEventListener("loadedmetadata", (e) => {
    const v = e.target;
    if (!v || v.tagName !== "VIDEO") return;
    introDone = false;
    outroDone = false;
    applyDefaults(v);
    restoreProgress(v);
    updateSubtitle();
  }, true);

  document.addEventListener("timeupdate", (e) => {
    const v = e.target;
    if (!v || v.tagName !== "VIDEO" || v !== api.getVideo()) return;
    onTimeUpdate(v);
  }, true);

  document.addEventListener("ended", (e) => {
    const v = e.target;
    if (!v || v.tagName !== "VIDEO") return;
    onEnded(v);
  }, true);

  document.addEventListener("play", (e) => {
    const v = e.target;
    if (!v || v.tagName !== "VIDEO") return;
    applyDefaults(v);
  }, true);

  document.addEventListener("seeking", () => { updateSubtitle(); }, true);
  document.addEventListener("seeked", () => { updateSubtitle(); }, true);
  window.addEventListener("resize", updateSubtitle);
  window.addEventListener("scroll", updateSubtitle, { passive: true });
  window.addEventListener("pagehide", () => {
    const v = api.getVideo();
    if (v) saveProgress(v, true);
  });

  document.addEventListener("fullscreenchange", () => {
    state.display.fullscreen = !!document.fullscreenElement;
    moveSubtitleToFullscreen();
    updateSubtitle();
  });
  document.addEventListener("enterpictureinpicture", () => { state.display.pip = true; });
  document.addEventListener("leavepictureinpicture", () => { state.display.pip = false; });

  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && state.display.webFullscreen) {
      setWebFullscreen(false);
      e.preventDefault();
    }
  }, true);

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.panda_membership) {
        // content.js 的会员缓存监听先注册；延后一拍再决定是否恢复进阶效果
        setTimeout(handleEntitlementChange, 0);
      }
      if (changes[SETTINGS_KEY]) {
        loadSettings().then(() => {
          applyFilters();
          updateSubtitle();
        });
      }
    });
  } catch (e) { /* ignore */ }

  globalThis.__PANDA_ADV__ = { handle, getState, _encodeGif: encodeGif };

  document.addEventListener("panda-entitled-change", handleEntitlementChange);

  // content.js 的会员缓存读取是异步的；若事件在 advanced 注册前已经派发，补一次短轮询
  if (isAllowed()) handleEntitlementChange();
  let gateTries = 0;
  const gateTimer = setInterval(() => {
    gateTries++;
    if (isAllowed()) {
      clearInterval(gateTimer);
      handleEntitlementChange();
    } else if (gateTries > 20) {
      clearInterval(gateTimer);
    }
  }, 250);

  onReady();
})();
