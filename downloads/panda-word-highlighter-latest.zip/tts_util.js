/* 生词高亮 & 翻译助手 —— TTS 共享模块 v2.10.8
 * 本地引擎：浏览器 speechSynthesis（用户可选语音，[本地] 标记离线可用）
 * 在线引擎：OpenAI 兼容 audio/speech（需地址+Key）/ 有道 dictvoice（免 Key）/
 *          Google 翻译 TTS（免 Key，超长自动分段）
 * 使用方：content.js（卡片发音）、wordlist.js（生词本发音）——统一入口 WH_TTS
 */
(function () {
  "use strict";

  const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);

  async function getCfg() {
    const defs = {
      ttsVoice: "",            // ""=自动（本地优先）；auto:local/auto:online/online:服务/语音名
      ttsRate: 0.85,           // 语速 0.5~1.5
      ttsProvider: "youdao",   // 自动模式的在线服务：youdao | google | openai
      ttsOnlineUrl: "",
      ttsOnlineKey: "",
      ttsOnlineVoice: "alloy"
    };
    if (IS_EXT) {
      try { return Object.assign(defs, await chrome.storage.sync.get(defs)); } catch (e) { /* fallthrough */ }
    }
    for (const k of Object.keys(defs)) {
      try {
        const v = JSON.parse(localStorage.getItem("wh_" + k));
        if (v !== undefined && v !== null) defs[k] = v;
      } catch (e) { /* ignore */ }
    }
    return defs;
  }

  /* ---------- 本地：speechSynthesis ---------- */
  // 【v2.17.5】本地播报序号：新请求会 cancel 旧请求，被顶替的旧请求的 onend/onerror
  // 不再当作"本地失败"（否则快速连点会误触发在线 TTS 回退）
  let localSpeakSeq = 0;
  // 【v2.17.5】Chrome 首次 getVoices() 常返回空列表（需等 voiceschanged），
  // 否则首次发音会被误判"无语音"而回退在线；列表为空时等待事件（带超时兜底）
  function getVoicesAsync(timeout) {
    return new Promise((resolve) => {
      try {
        const synth = window.speechSynthesis;
        if (!synth) return resolve([]);
        const first = synth.getVoices() || [];
        if (first.length) return resolve(first);
        let settled = false;
        const finish = () => {
          if (settled) return;
          settled = true;
          try { synth.removeEventListener("voiceschanged", finish); } catch (e) { /* ignore */ }
          resolve(synth.getVoices() || []);
        };
        synth.addEventListener("voiceschanged", finish);
        setTimeout(finish, timeout || 800);
      } catch (e) { resolve([]); }
    });
  }
  // 模块加载即预热语音列表，消除首次发音的等待与误判
  try {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.addEventListener("voiceschanged", () => {}, { once: true });
    }
  } catch (e) { /* ignore */ }
  function localSpeak(text, rate, voiceName) {
    return new Promise((resolve) => {
      try {
        if (!("speechSynthesis" in window)) return resolve(false);
        const mySeq = ++localSpeakSeq;
        // 被更新请求顶替 → 视为成功（新请求已接管发音），不回退在线
        const done = (ok) => resolve(mySeq === localSpeakSeq ? ok : true);
        window.speechSynthesis.cancel();
        getVoicesAsync().then((voices) => {
          if (mySeq !== localSpeakSeq) return done(true); // 等待期间被新请求顶替
          let v = null;
          if (voiceName) v = voices.find((x) => x.name === voiceName || x.lang === voiceName) || null;
          if (!v) {
            // 默认：本地离线英语 → 任意英语 → 任意本地
            v = voices.find((x) => x.localService && x.lang && x.lang.toLowerCase().startsWith("en"))
              || voices.find((x) => x.lang && x.lang.toLowerCase().startsWith("en"))
              || voices.find((x) => x.localService)
              || null;
          }
          if (!v && voices.length === 0) {
            // 无任何语音（列表未加载/不支持）→ 报告失败，让"自动（本地优先）"切在线
            return resolve(false);
          }
          const u = new SpeechSynthesisUtterance(text);
          u.lang = "en-US";
          u.rate = rate;
          if (v) { u.voice = v; u.lang = v.lang; }
          u.onend = () => done(true);
          u.onerror = () => done(false);
          window.speechSynthesis.speak(u);
        });
      } catch (e) { resolve(false); }
    });
  }

  /* ---------- 在线：Audio 播放 ---------- */
  let curAudio = null;
  function stopAudio() {
    if (curAudio) {
      try { curAudio.pause(); } catch (e) { /* ignore */ }
      try { if (curAudio._whUrl) URL.revokeObjectURL(curAudio._whUrl); } catch (e) { /* ignore */ }
      curAudio = null;
    }
  }
  /** 顺序播放一组音频 URL（分段 TTS 拼接） */
  function playAudioSeq(urls, rate) {
    stopAudio();
    if (!urls.length) return;
    let i = 0;
    const next = () => {
      if (i >= urls.length) { curAudio = null; return; }
      const a = new Audio(urls[i++]);
      a.playbackRate = rate || 1;
      curAudio = a;
      a.onended = next;
      a.onerror = next;
      a.play().catch(() => { next(); });
    };
    next();
  }

  /* 有道 dictvoice（免 Key）：type=2 美音；支持整句 */
  function youdaoUrl(text) {
    return "https://dict.youdao.com/dictvoice?audio=" + encodeURIComponent(text) + "&type=2";
  }

  /* Google 翻译 TTS（免 Key）：单段 ≤190 字符，超长按标点切分顺序播放 */
  function googleChunks(text) {
    const t = String(text || "").trim();
    if (!t) return [];
    if (t.length <= 190) return [t];
    const parts = [];
    let cur = "";
    for (const seg of t.split(/(?<=[,.!?;: ])/)) {
      if (cur && (cur + seg).length > 190) { parts.push(cur.trim()); cur = ""; }
      cur += seg;
    }
    if (cur.trim()) parts.push(cur.trim());
    return parts;
  }
  function googleUrl(chunk) {
    return "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q="
      + encodeURIComponent(chunk);
  }

  /* OpenAI 兼容 audio/speech（需地址 + 可选 Key） */
  async function openaiSpeak(text, cfg, rate) {
    const base = String(cfg.ttsOnlineUrl || "").trim().replace(/\/+$/, "");
    if (!base) return false;
    const endpoint = /\/audio\/speech$/.test(base) ? base : base + "/audio/speech";
    const headers = { "Content-Type": "application/json" };
    if (cfg.ttsOnlineKey) headers["Authorization"] = "Bearer " + cfg.ttsOnlineKey;
    const res = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: "tts-1",
        input: text,
        voice: cfg.ttsOnlineVoice || "alloy",
        format: "mp3"
      }),
      signal: AbortSignal.timeout(15000)
    });
    if (!res.ok) return false;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    stopAudio();
    const a = new Audio(url);
    a.playbackRate = rate || 1;
    a._whUrl = url;
    curAudio = a;
    a.onended = () => { try { URL.revokeObjectURL(url); } catch (e) { /* ignore */ } a._whUrl = ""; };
    a.play().catch(() => { try { URL.revokeObjectURL(url); } catch (e) { /* ignore */ } a._whUrl = ""; });
    return true;
  }

  async function onlineSpeak(text, cfg, rate) {
    const provider = cfg.ttsProvider || "youdao";
    if (provider === "youdao") {
      playAudioSeq([youdaoUrl(text)], rate);
      return true;
    }
    if (provider === "google") {
      const chunks = googleChunks(text);
      if (!chunks.length) return false;
      playAudioSeq(chunks.map(googleUrl), rate);
      return true;
    }
    try { return await openaiSpeak(text, cfg, rate); } catch (e) { return false; }
  }

  /* ---------- v2.10.9 统一 TTS 选择（设置页单下拉，两种自动策略） ----------
   * ttsVoice 取值：
   *   ""            → 自动（本地优先）：本地先读，失败/无语音切在线（服务见 ttsProvider）
   *   "auto:local"  → 同上（显式）
   *   "auto:online" → 自动（在线优先）：在线先读，失败切本地
   *   "online:youdao" / "online:google" / "online:openai" → 指定在线服务
   *   其他           → 本地语音名（speechSynthesis）
   */
  async function speakText(text, opts) {
    if (!text) return false;
    const cfg = await getCfg();
    const isSent = !!(opts && opts.sentence);
    let rate = Math.min(1.5, Math.max(0.5, parseFloat(cfg.ttsRate) || 0.85));
    if (isSent) rate = Math.max(0.5, rate * 0.92); // 整句略慢，便于听清
    const sel = String(cfg.ttsVoice || "");
    const prov = cfg.ttsProvider || "youdao";
    const tryOnline = (p) => onlineSpeak(text, { ...cfg, ttsProvider: p }, rate);
    // 本地发音：语音名仅在选择具体本地语音时传入；auto 模式交给 localSpeak 内部挑选
    const tryLocal = () => localSpeak(text, rate,
      (sel && !sel.startsWith("auto:") && !sel.startsWith("online:")) ? sel : "");

    if (sel === "auto:online") {
      // 自动（在线优先）：在线先读，失败（未配置/接口故障）→ 降级本地
      return (await tryOnline(prov)) || (await tryLocal());
    }
    if (sel === "auto:local" || sel === "") {
      // 自动（本地优先）：本地先读；本地不可用（无语音/出错）→ 切在线
      const okLocal = await tryLocal();
      if (okLocal) return true;
      return await tryOnline(prov);
    }
    if (sel.startsWith("online:")) {
      return await tryOnline(sel.slice(7));
    }
    return localSpeak(text, rate, sel);
  }

  window.WH_TTS = {
    speakText,
    stop: () => {
      localSpeakSeq++; // 手动停止也视为"顶替"，避免被取消的本地播报误回退在线
      stopAudio();
      try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
    }
  };
})();
