/* 生词高亮 & 翻译助手 —— 选项页逻辑 v2.1 */
"use strict";

const DEFAULTS = {
  enabled: true,
  autoSpeak: true,
  minLength: 3,
  color: "#fff1a8",
  underline: true,
  userWords: [],
  knownWords: [],
  level: "none",
  theme: "light",
  quickTip: true,
  translateEnabled: false,
  translateService: "auto",
  translateMode: "replace",
  ytCaptionSingleLine: true,
  ytCaptionTrMode: "sentence",
  ytHoverPause: true,
  ytSentencePause: true,
  compatMode: false,      // 兼容模式：框架页面内跳过高亮（翻译不受影响）
  customAIs: [],
  ttsVoice: "",           // ""=自动(本地优先)；auto:local/auto:online/online:服务/本地语音名
  ttsRate: 0.85,          // 语速
  ttsProvider: "youdao",  // 自动模式的在线服务：youdao | google | openai
  ttsOnlineUrl: "",       // 在线 TTS 接口（OpenAI 兼容 audio/speech）
  ttsOnlineKey: "",
  ttsOnlineVoice: ""
};

const $ = (sel) => document.querySelector(sel);
const VOCAB = (typeof window.__WH_VOCAB__ !== "undefined") ? window.__WH_VOCAB__ : null;

/* ---------- 存储（使用共享 storage.js 模块） ---------- */
const IS_EXT = WH_STORE.IS_EXT;
const STORE = {
  async get(defs) { return WH_STORE.syncGet(defs); },
  async set(patch) { return WH_STORE.syncSet(patch); }
};

/* ---------- 等级 UI ---------- */
let currentLevelVal = "none";

function renderLevels(level) {
  currentLevelVal = level;
  const box = $("#levels");
  box.textContent = "";
  if (!VOCAB || !VOCAB.order) {
    box.innerHTML = '<div class="env-warn">词库数据未加载（vocab-data.js 缺失）。</div>';
    return;
  }
  // 「无」= 默认不启用生词高亮
  const noneBtn = document.createElement("button");
  noneBtn.type = "button";
  noneBtn.className = "level-btn" + (level === "none" || !level ? " active" : "");
  noneBtn.textContent = "无（默认）";
  noneBtn.dataset.level = "none";
  noneBtn.addEventListener("click", () => {
    document.querySelectorAll(".level-btn").forEach((b) => b.classList.toggle("active", b === noneBtn));
    currentLevelVal = "none";
    updateLevelStats("none");
    STORE.set({ level: "none" }).then(() => {
      setStatus("已关闭生词高亮（默认：页面无任何高亮）");
      broadcast();
    });
  });
  box.appendChild(noneBtn);
  for (const lv of VOCAB.order) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "level-btn" + (lv === level ? " active" : "");
    btn.textContent = VOCAB.labels[lv];
    btn.dataset.level = lv;
    btn.addEventListener("click", () => {
      document.querySelectorAll(".level-btn").forEach((b) => b.classList.toggle("active", b === btn));
      currentLevelVal = lv;
      updateLevelStats(lv);
      // 即时生效：保存等级并通知已打开的网页
      STORE.set({ level: lv }).then(() => {
        setStatus("已切换等级为「" + VOCAB.labels[lv] + "」：仅高亮该等级词汇，网页生词已刷新");
        broadcast();
      });
    });
    box.appendChild(btn);
  }
  updateLevelStats(level);
}

function updateLevelStats(level) {
  if (!VOCAB) return;
  if (level === "none" || !level) {
    $("#level-stats").textContent = "默认状态：页面不高亮任何单词（未选择词汇等级）。选择下方等级后，仅高亮「该等级」词汇。";
    return;
  }
  const idx = VOCAB.order.indexOf(level);
  const cnt = idx >= 0 ? VOCAB.lists[level].length : 0;
  const line1 = "当前等级「" + VOCAB.labels[level] + "」：页面仅高亮该等级词库 " + cnt + " 词；";
  const line2 = "低于该等级（已学过）、高于该等级、词库未收录的词汇均不高亮。";
  const line3 = "各等级词数（已去重）：" + VOCAB.order.map((lv) => VOCAB.labels[lv] + " " + VOCAB.lists[lv].length).join(" / ") + "。";
  $("#level-stats").textContent = line1 + line2 + line3;
}

/* ---------- 主题分段 ---------- */
function renderThemeSeg(theme) {
  document.querySelectorAll("#theme-seg button").forEach((b) => {
    b.classList.toggle("active", b.dataset.theme === theme);
  });
}

/* ---------- 加载 ---------- */
let customAIs = [];

async function load() {
  const s = await STORE.get(DEFAULTS);
  customAIs = Array.isArray(s.customAIs) ? s.customAIs : [];
  // 元素缺失时跳过（防御：避免单元素缺失导致整页功能不可用）
  const setCheck = (sel, v) => { const el = $(sel); if (el) el.checked = v; };
  const setVal = (sel, v) => { const el = $(sel); if (el) el.value = v; };
  setCheck("#enabled", s.enabled);
  setCheck("#quickTip", s.quickTip);
  setCheck("#autoSpeak", s.autoSpeak);
  setCheck("#compatMode", !!s.compatMode);
  setCheck("#translateEnabled", s.translateEnabled);
  setCheck("#ytCaptionSingleLine", !!s.ytCaptionSingleLine);
  setVal("#ytCaptionTrMode", ["word", "sentence", "word2"].includes(s.ytCaptionTrMode) ? s.ytCaptionTrMode : "sentence");
  setCheck("#ytHoverPause", !!s.ytHoverPause);
  setCheck("#ytSentencePause", !!s.ytSentencePause);
  renderTranslateService(s.translateService || "auto");
  setVal("#translateMode", s.translateMode || "replace");
  renderCustomAIList();
  setVal("#minLength", String(s.minLength));
  setVal("#color", s.color);
  setCheck("#underline", s.underline);
  setVal("#userWords", (s.userWords || []).join("\n"));
  renderLevels(s.level);
  renderThemeSeg(s.theme);
  applyPageTheme(s.theme);

  // TTS 设置（v2.10.9 统一 TTS 下拉；旧 ttsVoice=语音名/空 自动兼容）
  setVal("#ttsRate", String(s.ttsRate || 0.85));
  setVal("#ttsOnlineUrl", s.ttsOnlineUrl || "");
  setVal("#ttsOnlineKey", s.ttsOnlineKey || "");
  setVal("#ttsOnlineVoice", s.ttsOnlineVoice || "");
  setVal("#ttsProvider", s.ttsProvider || "youdao");
  buildTtsOptions(s.ttsVoice || "");
  renderTtsUi();

  document.querySelectorAll(".color-dot").forEach((dot) => {
    dot.classList.toggle("active", dot.dataset.color === s.color);
  });
}

/* ---------- 主题应用到设置页自身 ---------- */
function applyPageTheme(theme) {
  let resolved = theme;
  if (theme === "auto") {
    resolved = (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light";
  }
  document.documentElement.setAttribute("data-wh-theme", resolved);
}

/* ---------- TTS 统一下拉（v2.10.9：两种自动策略 + 本地语音 + 在线服务） ---------- */
function buildTtsOptions(selected) {
  const sel = $("#ttsVoice");
  if (!sel) return;
  sel.textContent = "";
  const mk = (label, value, group) => {
    const o = document.createElement("option");
    o.value = value;
    o.textContent = label;
    if (value === selected) o.selected = true;
    (group || sel).appendChild(o);
  };
  const gLocal = document.createElement("optgroup");
  gLocal.label = "本地语音（离线可用）";
  const gOnline = document.createElement("optgroup");
  gOnline.label = "在线服务";
  mk("自动（本地优先：本地不可用时联网）", "auto:local");
  mk("自动（在线优先：联网失败时用本地）", "auto:online");
  const voices = ("speechSynthesis" in window) ? window.speechSynthesis.getVoices() : [];
  const en = voices.filter((v) => v.lang && v.lang.toLowerCase().startsWith("en"));
  const list = en.length ? en : voices;
  for (const v of list) {
    mk((v.name || v.lang) + (v.localService ? "（本地）" : "（在线）"), v.name || v.lang, gLocal);
  }
  mk("有道 TTS（免 Key，美音，支持整句）", "online:youdao", gOnline);
  mk("谷歌翻译 TTS（免 Key，需能访问谷歌）", "online:google", gOnline);
  mk("OpenAI 兼容接口（自定义地址 + Key）", "online:openai", gOnline);
  sel.appendChild(gLocal);
  sel.appendChild(gOnline);
}
/** 依 TTS 选择联动显示：自动模式的服务下拉、OpenAI 兼容字段 */
function renderTtsUi() {
  const sel = ($("#ttsVoice") && $("#ttsVoice").value) || "auto:local";
  const isAuto = sel === "auto:local" || sel === "auto:online" || sel === "";
  const prov = ($("#ttsProvider") && $("#ttsProvider").value) || "youdao";
  const provRow = $("#auto-provider-row");
  if (provRow && provRow.style) provRow.style.display = isAuto ? "" : "none";
  const fields = $("#openai-tts-fields");
  if (fields && fields.style) fields.style.display = (sel === "online:openai" || (isAuto && prov === "openai")) ? "" : "none";
  const box = $("#online-tts-box");
  if (box && box.style) box.style.display = (isAuto || sel.startsWith("online:")) ? "" : "none";
}
if ("speechSynthesis" in window) {
  window.speechSynthesis.onvoiceschanged = () => buildTtsOptions(document.querySelector("#ttsVoice") ? document.querySelector("#ttsVoice").value : "");
}

/* ---------- 自定义 AI 翻译 ---------- */
function renderTranslateService(selected) {
  const sel = $("#translateService");
  if (!sel) return;
  sel.textContent = "";
  const mkOpt = (v, label) => {
    const o = document.createElement("option");
    o.value = v;
    o.textContent = label;
    if (v === selected) o.selected = true;
    sel.appendChild(o);
  };
  const mkGroup = (label, items) => {
    const g = document.createElement("optgroup");
    g.label = label;
    for (const [v, text] of items) {
      const o = document.createElement("option");
      o.value = v;
      o.textContent = text;
      if (v === selected) o.selected = true;
      g.appendChild(o);
    }
    sel.appendChild(g);
  };
  mkOpt("auto", "自动（Edge 优先 + 国内直连兜底 + 国外并发，全部失败用有道）");
  mkGroup("国内可直连（无需代理）", [
    ["edge", "微软 Edge 翻译（推荐，免 token、批量、全语种）"],
    ["mymemory", "MyMemory（免费，多语种，无需代理）"],
    ["youdao", "有道翻译（国内接口，限频约 4 秒/句）"]
  ]);
  mkGroup("国外服务（部分网络需代理）", [
    ["microsoft", "微软 Bing 翻译（token 流程，Edge 不可用时备用）"],
    ["google", "Google 翻译（需代理，超时自动降级）"]
  ]);
  if (customAIs.length) {
    mkGroup("自定义 AI", customAIs.map((a) => ["custom:" + a.id, "⚡ " + (a.name || a.id)]));
  }
  // 兜底：仅对"已失效的自定义 AI id"补一个占位项（其余选项已在上方分组列出）
  if (selected && !["auto", "edge", "mymemory", "youdao", "microsoft", "google"].includes(selected) && !customAIs.some((a) => "custom:" + a.id === selected)) {
    mkOpt(selected, selected);
  }
}

function renderCustomAIList() {
  const box = $("#custom-ai-list");
  if (!box) return;
  box.textContent = "";
  if (!customAIs.length) {
    box.innerHTML = '<div class="env-warn">尚未添加自定义 AI。填写下方信息后点击「添加」。</div>';
    return;
  }
  for (const ai of customAIs) {
    const row = document.createElement("div");
    row.className = "custom-ai-item";
    const nameSpan = document.createElement("span");
    nameSpan.className = "ai-name";
    nameSpan.textContent = ai.name || ai.id;
    const urlSpan = document.createElement("span");
    urlSpan.className = "ai-url";
    urlSpan.textContent = (ai.url || "") + (ai.model ? " · " + ai.model : "");
    const del = document.createElement("button");
    del.type = "button";
    del.textContent = "删除";
    del.addEventListener("click", () => {
      customAIs = customAIs.filter((x) => x.id !== ai.id);
      renderCustomAIList();
      renderTranslateService($("#translateService") ? $("#translateService").value : "mymemory");
      STORE.set({ customAIs }).then(() => setStatus("已删除「" + (ai.name || ai.id) + "」"));
    });
    row.appendChild(nameSpan);
    row.appendChild(urlSpan);
    row.appendChild(del);
    box.appendChild(row);
  }
}

function addCustomAI() {
  const name = $("#aiName").value.trim();
  const url = $("#aiUrl").value.trim();
  const key = $("#aiKey").value.trim();
  const model = $("#aiModel").value.trim();
  if (!name || !url) {
    setStatus("请填写名称与 API 地址");
    return;
  }
  if (customAIs.length >= 6) { setStatus("最多添加 6 个自定义 AI"); return; }
  const id = "ai" + Date.now().toString(36);
  customAIs.push({ id, name, url, key, model });
  ["aiName", "aiUrl", "aiKey", "aiModel"].forEach((x) => { const el = $("#" + x); if (el) el.value = ""; });
  renderCustomAIList();
  renderTranslateService("custom:" + id);
  STORE.set({ customAIs }).then(() => setStatus("已添加「" + name + "」，可在「翻译服务」中选择"));
}

/* ---------- 保存 ---------- */
function currentTheme() {
  const btn = document.querySelector("#theme-seg button.active");
  return btn ? btn.dataset.theme : "light";
}

/* 模块级读取辅助（save 与自检共用；此前仅定义在 save 内，自检调用报 ReferenceError） */
function getCheck(sel) { const el = $(sel); return el ? el.checked : DEFAULTS[sel.replace("#", "")]; }
function getVal(sel) { const el = $(sel); return el ? el.value : ""; }

async function save() {
  const words = $("#userWords").value
    .split(/[\n,;，；]+/)
    .map((w) => w.trim())
    .filter(Boolean);

  await STORE.set({
    enabled: getCheck("#enabled"),
    quickTip: getCheck("#quickTip"),
    compatMode: getCheck("#compatMode"),
    autoSpeak: getCheck("#autoSpeak"),
    translateEnabled: getCheck("#translateEnabled"),
    ytCaptionSingleLine: getCheck("#ytCaptionSingleLine"),
    ytCaptionTrMode: ["word", "sentence", "word2"].includes(getVal("#ytCaptionTrMode")) ? getVal("#ytCaptionTrMode") : "sentence",
  ytHoverPause: getCheck("#ytHoverPause"),
  ytSentencePause: getCheck("#ytSentencePause"),
    translateService: getVal("#translateService") || "auto",
    translateMode: getVal("#translateMode") || "inline",
    customAIs: customAIs,
    ttsProvider: getVal("#ttsProvider") || "youdao",
    ttsVoice: getVal("#ttsVoice") || "",
    ttsRate: parseFloat(getVal("#ttsRate")) || 0.85,
    ttsOnlineUrl: getVal("#ttsOnlineUrl") || "",
    ttsOnlineKey: getVal("#ttsOnlineKey") || "",
    ttsOnlineVoice: getVal("#ttsOnlineVoice") || "",
    minLength: parseInt(getVal("#minLength"), 10) || 3,
    color: getVal("#color") || DEFAULTS.color,
    underline: getCheck("#underline"),
    userWords: words,
    level: currentLevelVal,
    theme: currentTheme()
  });
  setStatus(IS_EXT ? "✓ 已保存并立即生效" : "✓ 已保存（预览环境，未写入扩展）");
  broadcast();
}

function broadcast() {
  if (!IS_EXT) return;
  try {
    // 向所有标签页广播重扫（不依赖"活动标签"，避免设置页自身成为活动页时漏发）
    chrome.tabs.query({}, (tabs) => {
      for (const t of tabs || []) {
        if (t.id != null) {
          try { chrome.tabs.sendMessage(t.id, { type: "WH_RESCAN" }).catch(() => {}); } catch (e) { /* ignore */ }
        }
      }
    });
  } catch (e) { /* ignore */ }
}

let statusTimer = null;
function setStatus(text) {
  const st = $("#status");
  st.textContent = text;
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => (st.textContent = ""), 2600);
}

/* ---------- 自检 ---------- */
async function runSelfTest() {
  const box = $("#selftest-result");
  box.innerHTML = '<div class="info spin">正在检测…</div>';
  const lines = [];

  // 1. 分级词库 + 内置释义（检测词用词库内真实存在的词）
  if (VOCAB && VOCAB.order && VOCAB.order.length === 8 && VOCAB.meta) {
    const probes = ["hello", "silent", "explosive"];
    const hasTrans = probes.every((w) => VOCAB.meta[w] && VOCAB.meta[w][0] && VOCAB.meta[w][0].length);
    const hasPhone = probes.some((w) => VOCAB.meta[w] && VOCAB.meta[w][1]);
    lines.push([hasTrans ? "ok" : "fail",
      (hasTrans ? "✓ " : "✗ ") + "分级词库：8 级 " + VOCAB.order.reduce((n, lv) => n + VOCAB.lists[lv].length, 0) +
      " 词，内置释义 " + (hasTrans ? "正常" : "缺失（" + probes.join("/") + "）") +
      "，音标 " + (hasPhone ? "正常" : "缺失")]);
  } else {
    lines.push(["fail", "✗ 分级词库未加载"]);
  }

  // 2. 有道翻译接口（真实查词）
  const t0 = Date.now();
  try {
    const r = await new Promise((resolve) => {
      if (!IS_EXT) { resolve({ ok: false, error: "非扩展环境" }); return; }
      chrome.runtime.sendMessage({ type: "WH_DICT", word: "hello" }, resolve);
    });
    if (r && r.ok) {
      lines.push(["ok", "✓ 有道词典 API：正常（" + (Date.now() - t0) + "ms） hello → " + ((r.translations && r.translations[0]) || "")]);
    } else {
      lines.push([r && r.error && r.error === "非扩展环境" ? "info" : "fail",
        (r && r.error === "非扩展环境" ? "· 有道 API 需在扩展环境检测（当前为预览页）" : "✗ 有道词典 API：失败 " + ((r && r.error) || ""))]);
    }
  } catch (e) {
    lines.push(["fail", "✗ 有道词典 API 异常：" + e.message]);
  }

  // 3. AI 机器翻译兜底（直接测 MyMemory 翻译接口连通性）
  const t1 = Date.now();
  try {
    const r = await new Promise((resolve) => {
      if (!IS_EXT) { resolve({ ok: false, error: "非扩展环境" }); return; }
      chrome.runtime.sendMessage({ type: "WH_AI_TEST" }, resolve);
    });
    if (r && r.ok) {
      const aiTxt = (r.translations && r.translations[0]) || "";
      lines.push(["ok", "✓ AI 翻译兜底：正常（" + (Date.now() - t1) + "ms） → " + aiTxt.replace(/^\[AI 翻译\] /, "").slice(0, 30)]);
    } else {
      lines.push(["info", "· AI 兜底不可用（" + ((r && r.error) || "未知") + "），极端生僻词可能无释义"]);
    }
  } catch (e) {
    lines.push(["info", "· AI 兜底异常：" + e.message]);
  }

  // 4. 语音合成
  lines.push(["speechSynthesis" in window ? "ok" : "fail",
    ("speechSynthesis" in window ? "✓ 语音合成 TTS：可用（优先本地离线语音）" : "✗ 语音合成不可用")]);

  // 4.3 发音（v2.10.9 统一 TTS 下拉）
  const ttsSel = getVal("#ttsVoice") || "auto:local";
  const ttsProv = getVal("#ttsProvider") || "youdao";
  const ttsUrl = getVal("#ttsOnlineUrl") || "";
  const provLabel = ttsProv === "youdao" ? "有道免 Key" : ttsProv === "google" ? "谷歌免 Key" : "OpenAI 兼容";
  if (ttsSel === "auto:local" || ttsSel === "") {
    lines.push(["ok", "✓ TTS：自动（本地优先，失败切" + provLabel + "）"]);
  } else if (ttsSel === "auto:online") {
    lines.push(["ok", "✓ TTS：自动（在线优先【" + provLabel + "】，失败切本地）"]);
  } else if (ttsSel === "online:openai") {
    if (ttsUrl) lines.push(["ok", "✓ TTS：OpenAI 兼容（" + ttsUrl + "）"]);
    else lines.push(["fail", "✗ TTS 为 OpenAI 兼容但未填写接口地址"]);
  } else if (ttsSel.startsWith("online:")) {
    lines.push(["ok", "✓ TTS：在线服务（" + provLabel + "）"]);
  } else {
    lines.push(["ok", "✓ TTS：本地语音「" + ttsSel + "」（离线可用）"]);
  }

  // 4.5 自定义 AI
  lines.push([customAIs.length ? "ok" : "info",
    customAIs.length ? "✓ 自定义 AI：已配置 " + customAIs.length + " 个（" + customAIs.map((a) => a.name || a.id).join("、") + "）" : "· 自定义 AI：未配置（可在上方添加 OpenAI 兼容接口）"]);

  // 4.6 网页翻译服务链路（content → background → 翻译服务整条通道）
  try {
    const cfg = await STORE.get({ translateService: "auto", translateMode: "replace" });
    const svc = cfg.translateService || "auto";
    const mode = cfg.translateMode || "inline";
    const r = await new Promise((resolve) => {
      if (!IS_EXT) { resolve({ ok: false, error: "非扩展环境" }); return; }
      chrome.runtime.sendMessage({ type: "WH_TRANSLATE", text: "Hello world. This is a quick test.", service: svc, lang: "en" }, resolve);
    });
    if (r && r.ok) {
      lines.push(["ok", "✓ 网页翻译链路（" + svc + "/" + mode + "）：正常 → " + String(r.text).slice(0, 34)]);
    } else {
      lines.push([r && r.error === "非扩展环境" ? "info" : "fail",
        (r && r.error === "非扩展环境" ? "· 网页翻译链路需在扩展环境检测（当前为预览页）" : "✗ 网页翻译链路（" + svc + "）：" + ((r && r.error) || "失败") + "，可在弹窗切换翻译服务后重试")]);
    }
  } catch (e) {
    lines.push(["fail", "✗ 网页翻译链路异常：" + e.message]);
  }

  // 5. 存储
  try {
    await STORE.set({ __selftest: 1 });
    await STORE.set({ __selftest: 0 });
    lines.push(["ok", IS_EXT ? "✓ 扩展存储：可读写" : "✓ 本地存储：可读写（预览环境降级）"]);
  } catch (e) {
    lines.push(["fail", "✗ 存储异常：" + e.message]);
  }

  // 自检结果里可能包含翻译接口/自定义 AI 返回的文本，必须用 textContent 渲染，
  // 不能拼 innerHTML（扩展页 XSS 可直接读取 chrome.storage 中的登录 token）。
  box.textContent = "";
  for (const [cls, txt] of lines) {
    const div = document.createElement("div");
    div.className = String(cls || "info").replace(/[^\w-]/g, "");
    div.textContent = String(txt);
    box.appendChild(div);
  }
}

/* ---------- 事件 ---------- */
document.querySelectorAll(".color-dot").forEach((dot) => {
  dot.addEventListener("click", () => {
    $("#color").value = dot.dataset.color;
    document.querySelectorAll(".color-dot").forEach((d) => d.classList.toggle("active", d === dot));
  });
});
$("#color").addEventListener("input", () => {
  document.querySelectorAll(".color-dot").forEach((dot) => {
    dot.classList.toggle("active", dot.dataset.color === $("#color").value);
  });
});
document.querySelectorAll("#theme-seg button").forEach((b) => {
  b.addEventListener("click", () => {
    document.querySelectorAll("#theme-seg button").forEach((x) => x.classList.toggle("active", x === b));
    STORE.set({ theme: b.dataset.theme }).then(() => {
      applyPageTheme(b.dataset.theme);
      setStatus("主题已切换为「" + (b.dataset.theme === "dark" ? "夜间" : b.dataset.theme === "light" ? "日间" : "自动") + "」，设置页与悬浮卡片已同步");
      broadcast();
    });
  });
});
// 【v2.10.9】TTS 选择联动：自动模式显示服务下拉；OpenAI 兼容显示地址/Key 字段
const ttsVoiceSel = $("#ttsVoice");
if (ttsVoiceSel) ttsVoiceSel.addEventListener("change", renderTtsUi);
const providerSel = $("#ttsProvider");
if (providerSel) providerSel.addEventListener("change", renderTtsUi);
// 版本号
const verEl = $("#ver");
if (verEl) {
  verEl.textContent = (IS_EXT && chrome.runtime && chrome.runtime.getManifest)
    ? "v" + chrome.runtime.getManifest().version
    : "预览版";
}
$("#save").addEventListener("click", save);
$("#selftest").addEventListener("click", runSelfTest);
const aiAdd = $("#aiAdd");
if (aiAdd) aiAdd.addEventListener("click", addCustomAI);

/* ---------- 侧边栏导航（Read Frog 风格分区切换） ---------- */
document.querySelectorAll(".nav-item").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((b) => b.classList.toggle("active", b === btn));
    document.querySelectorAll(".pane").forEach((p) =>
      p.classList.toggle("active", p.id === "pane-" + btn.dataset.pane)
    );
  });
});

/* 【v2.17.19】支持 URL hash 直达分区（popup 账号按钮跳转 options.html#account） */
(function () {
  const h = (location.hash || "").replace("#", "");
  if (!h) return;
  const btn = document.querySelector('.nav-item[data-pane="' + h + '"]');
  if (btn) btn.click();
  history.replaceState(null, "", location.pathname); // 清除 hash，避免刷新时重复定位
})();

/* 环境提示 */
if (!IS_EXT) {
  const w = $("#env-warn");
  if (w) w.classList.remove("hidden");
}

load();

/* ---------- 账号（Supabase Auth，v2.17.18） ---------- */
(function initAccount() {
  const loginSec = $("#account-login-sec");
  const infoSec = $("#account-info-sec");
  if (!loginSec || !infoSec || typeof WHAuth === "undefined") return;

  const emailInput = $("#acctEmail");
  const passInput = $("#acctPass");
  const msgEl = $("#acctMsg");
  const emailLabel = $("#acctEmailLabel");
  const planLabel = $("#acctPlanLabel");
  const planBadge = $("#acctPlanBadge");

  let busy = false;

  let sayTimer = null;
  function say(text, isErr) {
    if (!msgEl) return;
    msgEl.textContent = text || "";
    msgEl.classList.toggle("err", !!isErr);
    msgEl.classList.toggle("ok", !isErr && !!text);
    if (sayTimer) { clearTimeout(sayTimer); sayTimer = null; }
    if (text) {
      // 自动消失：成功/进行中 4 秒，错误 6 秒（给足阅读时间）
      sayTimer = setTimeout(() => {
        msgEl.textContent = "";
        msgEl.classList.remove("err", "ok");
        sayTimer = null;
      }, isErr ? 6000 : 4000);
    }
  }

  function fmtDate(iso) {
    if (!iso) return "永久";
    const raw = String(iso);
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
    try {
      const d = new Date(iso);
      return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
    } catch (e) { return raw; }
  }

  function isProMembership(m) {
    if (!m || !m.signed_in || !m.pro) return false;
    if (!m.expires_at) return true;
    const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
    return Number.isFinite(t) && t > Date.now();
  }

  function updateNavChip(m) {
    const chip = document.getElementById("nav-acct-chip");
    if (!chip) return;
    chip.classList.remove("on", "pro");
    if (!m || !m.signed_in) { chip.textContent = "未登录"; return; }
    if (isProMembership(m)) { chip.textContent = "PRO"; chip.classList.add("pro"); return; }
    chip.textContent = "已登录";
    chip.classList.add("on");
  }

  /** 【v2.17.26】只用本地数据拼出"已登录"状态（不联网）：离线/网络慢时先立即渲染，
   *  PRO 与到期时间取 background 上次成功校验的缓存（local.wh_membership） */
  async function localMembership() {
    const peek = WHAuth.peekSession ? await WHAuth.peekSession().catch(() => null) : null;
    if (!peek || !peek.signed_in) return null;
    let cached = null;
    try { cached = ((await chrome.storage.local.get("wh_membership")) || {}).wh_membership || null; } catch (e) { /* ignore */ }
    return {
      signed_in: true,
      offline: true,
      pro: isProMembership(cached),
      plan: (cached && cached.plan) || "free",
      expires_at: (cached && cached.expires_at) || 0,
      email: peek.email || (cached && cached.email) || "",
      reason: "离线/未校验：显示上次校验的会员状态"
    };
  }

  /** 渲染账号面板（refreshUI 的本地预览与联网结果共用） */
  function paintAccount(m) {
    const pro = isProMembership(m);
    updateNavChip(m);
    const offlineNote = $("#acctOfflineNote");
    if (offlineNote) {
      offlineNote.classList.toggle("hidden", !(m && m.offline));
      if (m && m.offline) {
        offlineNote.textContent = "⚠ 当前处于离线状态：登录状态与会员权益沿用上次校验结果（"
          + (pro ? "PRO" : "免费版") + "）。联网后会自动重新校验，无需重新登录。";
      }
    }
    if (m && m.signed_in) {
      loginSec.classList.add("hidden");
      infoSec.classList.remove("hidden");
      if (emailLabel) emailLabel.textContent = (m.email || "—") + (m.offline ? "（离线）" : "");
      if (planBadge) {
        planBadge.textContent = pro ? "PRO" : "免费版";
        planBadge.classList.toggle("pro", pro);
      }
      if (planLabel) {
        planLabel.textContent = pro
          ? "Pro 会员 · 有效期至 " + fmtDate(m.expires_at) + (m.offline ? "（离线，未联网校验）" : "")
          : (m.reason || "免费版，升级后解锁会员功能");
      }
      if (m.offline) say("离线中：已保留登录状态，联网后自动校验", false);
    } else if (m) {
      loginSec.classList.remove("hidden");
      infoSec.classList.add("hidden");
      if (m.reason && m.reason.indexOf("失效") >= 0) say(m.reason, true);
    }
  }

  async function refreshUI() {
    // ① 先用本地会话 + 上次校验缓存立即渲染（离线时不至于干等网络重试十几秒）
    try {
      const lm = await localMembership();
      if (lm) paintAccount(lm);
    } catch (e) { /* ignore */ }
    // ② 联网校验后用真实结果覆盖
    try {
      let m = await WHAuth.getMembership();
      const uncertain = m && /查询失败|拒绝访问|未创建|不存在|异常|网络错误/i.test(String(m.reason || ""));
      if (m && (m.offline || uncertain)) {
        const lm = await localMembership();
        if (lm) {
          m = Object.assign({}, m, lm, {
            offline: !!m.offline,
            reason: m.offline ? "离线：显示上次校验的会员状态" : "会员校验异常：显示上次校验的会员状态"
          });
        }
      }
      paintAccount(m);
      // 【v2.17.20】同步最新会员状态到 background 缓存（content/popup 立即生效）；
      // 离线结果不同步，避免把 PRO 缓存覆盖成免费版
      if (IS_EXT && m && !m.offline && !uncertain) {
        try { chrome.runtime.sendMessage({ type: "WH_MEMBERSHIP_SYNC", membership: m }, () => { void chrome.runtime.lastError; }); } catch (e) { /* ignore */ }
      }
      return m;
    } catch (e) {
      say("状态查询失败：" + (e.message || e), true);
      return null;
    }
  }

  function getCreds() {
    const email = String(emailInput.value || "").trim();
    const pass = String(passInput.value || "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say("请输入有效的邮箱地址", true); return null; }
    if (pass.length < 6) { say("密码至少 6 位", true); return null; }
    return { email, pass };
  }

  /* 【v2.17.26】记住邮箱：浏览器内置密码管理器不作用于 chrome-extension:// 页面，
     这里用插件自己的"记住邮箱"兜底（只存邮箱，绝不存密码） */
  const rememberBox = $("#acctRemember");
  const REMEMBER_KEY = "wh_remember_email";

  async function loadRememberedEmail() {
    if (!rememberBox) return;
    try {
      const o = await chrome.storage.local.get(REMEMBER_KEY);
      const v = o && o[REMEMBER_KEY];
      if (v && v.email) {
        rememberBox.checked = true;
        if (!emailInput.value) emailInput.value = v.email;
      } else {
        rememberBox.checked = false;
      }
    } catch (e) { /* ignore */ }
  }

  async function rememberEmail(email) {
    try {
      if (rememberBox && rememberBox.checked) await chrome.storage.local.set({ [REMEMBER_KEY]: { email } });
      else await chrome.storage.local.remove(REMEMBER_KEY);
    } catch (e) { /* ignore */ }
  }

  if (rememberBox) {
    rememberBox.addEventListener("change", () => {
      if (!rememberBox.checked) { try { chrome.storage.local.remove(REMEMBER_KEY); } catch (e) { /* ignore */ } }
      else if (String(emailInput.value || "").trim()) { try { chrome.storage.local.set({ [REMEMBER_KEY]: { email: String(emailInput.value).trim() } }); } catch (e) { /* ignore */ } }
    });
  }
  loadRememberedEmail();

  async function doLogin() {
    if (busy) return;
    const c = getCreds();
    if (!c) return;
    busy = true; say("登录中…");
    try {
      await WHAuth.signIn(c.email, c.pass);
      passInput.value = "";
      rememberEmail(c.email); // 【v2.17.26】按勾选记住邮箱，下次自动填充
      say("登录成功");
      await refreshUI();
    } catch (e) {
      say(e.message || "登录失败", true);
    } finally { busy = false; }
  }

  async function doSignup() {
    if (busy) return;
    const c = getCreds();
    if (!c) return;
    busy = true; say("注册中…");
    try {
      const r = await WHAuth.signUp(c.email, c.pass);
      if (r.needConfirm) {
        say("注册成功！请到邮箱查收验证邮件，点击链接后再登录");
      } else {
        passInput.value = "";
        say("注册成功，已自动登录");
        await refreshUI();
      }
    } catch (e) {
      say(e.message || "注册失败", true);
    } finally { busy = false; }
  }

  async function doLogout() {
    if (busy) return;
    busy = true;
    try {
      await WHAuth.signOut();
      say("已退出登录");
      emailInput.value = ""; passInput.value = "";
      await refreshUI();
    } catch (e) {
      say("退出失败：" + (e.message || e), true);
    } finally { busy = false; }
  }

  /* 【v2.17.21】忘记密码：验证码重置（邮件 6 位验证码 → 验证 → 设新密码，全程插件内完成） */
  const resetForm = $("#acctResetForm");
  const resetEmail = $("#resetEmail");
  const resetCode = $("#resetCode");
  const resetPass = $("#resetPass");

  function showResetForm(show) {
    if (!resetForm) return;
    resetForm.classList.toggle("hidden", !show);
    if (show) {
      resetEmail.value = String(emailInput.value || "").trim();
      resetCode.value = "";
      resetPass.value = "";
    }
  }

  function doForgot() {
    const email = String(emailInput.value || "").trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say("请先在上方输入你的注册邮箱，再点“忘记密码？”", true); return; }
    showResetForm(true);
    say("已展开重置表单，点“发送验证码”后查收邮件");
  }

  async function doResetSend() {
    if (busy) return;
    const email = String(resetEmail.value || "").trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say("请输入注册邮箱", true); return; }
    busy = true; say("验证码发送中…");
    try {
      await WHAuth.requestPasswordReset(email);
      say("验证码已发送到邮箱（收不到请检查垃圾箱），1 小时内有效");
    } catch (e) {
      say(e.message || "发送失败", true);
    } finally { busy = false; }
  }

  async function doResetSubmit() {
    if (busy) return;
    const email = String(resetEmail.value || "").trim();
    const code = String(resetCode.value || "").trim();
    const pass = String(resetPass.value || "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say("请输入注册邮箱", true); return; }
    if (!/^\d{6,8}$/.test(code)) { say("请输入邮件中的数字验证码（6-8 位）", true); return; }
    if (pass.length < 6) { say("新密码至少 6 位", true); return; }
    busy = true; say("验证中…");
    try {
      await WHAuth.verifyRecoveryCode(email, code);
      await WHAuth.setNewPassword(pass);
      showResetForm(false);
      say("密码已重置并自动登录");
      await refreshUI();
    } catch (e) {
      say(e.message || "重置失败", true);
    } finally { busy = false; }
  }

  async function doRedeem() {
    if (busy) return;
    const input = $("#acctRedeem");
    const code = String(input.value || "").trim();
    if (!code) { say("请输入兑换码", true); return; }
    busy = true; say("兑换中…");
    try {
      const r = await WHAuth.redeemCode(code);
      input.value = "";
      say("兑换成功！Pro 会员有效期至 " + fmtDate(r.expires_at));
      await refreshUI();
    } catch (e) {
      say(e.message || "兑换失败", true);
    } finally { busy = false; }
  }

  // 【v2.17.26】标准 <form> 语义：回车即提交（密码管理器也据此识别登录表单）
  const loginForm = $("#acctLoginForm");
  if (loginForm) loginForm.addEventListener("submit", (e) => { e.preventDefault(); doLogin(); });
  else $("#acctLogin").addEventListener("click", doLogin);
  $("#acctSignup").addEventListener("click", doSignup);
  $("#acctForgot").addEventListener("click", doForgot);
  if ($("#resetSend")) $("#resetSend").addEventListener("click", doResetSend);
  if (resetForm) resetForm.addEventListener("submit", (e) => { e.preventDefault(); doResetSubmit(); });
  else if ($("#resetSubmit")) $("#resetSubmit").addEventListener("click", doResetSubmit);
  if ($("#resetCancel")) $("#resetCancel").addEventListener("click", () => showResetForm(false));
  if (resetCode) resetCode.addEventListener("keydown", (e) => { if (e.key === "Enter") doResetSubmit(); });
  $("#acctLogout").addEventListener("click", doLogout);
  $("#acctRedeemBtn").addEventListener("click", doRedeem);
  $("#acctRedeem").addEventListener("keydown", (e) => { if (e.key === "Enter") doRedeem(); });
  $("#acctRefresh").addEventListener("click", async () => {
    say("刷新中…");
    const m = await refreshUI();
    if (m) say(m.signed_in ? "已刷新" : "", !m.signed_in);
  });
  passInput.addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });

  refreshUI();
})();
