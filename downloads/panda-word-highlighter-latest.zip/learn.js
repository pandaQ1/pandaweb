/* 生词高亮 & 翻译助手 —— 背单词独立页面 v2.13.0
 * 学习 + 复习两个模块，数据与生词本（wordlist）完全分离：
 *   wh_learn_words   [{word, ts}]        本模块学过的词
 *   wh_learn_review  {word:{s,due,last,ok,fail}}  艾宾浩斯调度（独立于 wh_review）
 *   wh_learn_daily   {"YYYY-MM-DD": n}   每日已学新词数（强度额度）
 *   wh_learn_rv_daily{"YYYY-MM-DD": {r,f}} 复习打卡统计（独立于 wh_daily）
 */
"use strict";

const $ = (sel) => document.querySelector(sel);
const VOCAB = (typeof window.__WH_VOCAB__ !== "undefined") ? window.__WH_VOCAB__ : null;
const IS_EXT = WH_STORE.IS_EXT;

/* ---------- 存储（使用共享 storage.js 模块） ---------- */
const STORE = {
  async syncGet(defs) { return WH_STORE.syncGet(defs); },
  async syncSet(patch) { return WH_STORE.syncSet(patch); },
  async localGet(key) { return WH_STORE.localGet(key); },
  async localSet(patch) { return WH_STORE.localSet(patch); }
};

/* ---------- 主题 ---------- */
async function applyTheme() {
  const s = await STORE.syncGet({ theme: "light" });
  const dark = s.theme === "dark" ||
    (s.theme === "auto" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.body.classList.toggle("dark", dark);
  document.documentElement.setAttribute("data-wh-theme", dark ? "dark" : "light");
  $("#theme-btn").textContent = dark ? "☀️ 日间" : "🌙 夜间";
}
$("#theme-btn").addEventListener("click", async () => {
  const s = await STORE.syncGet({ theme: "light" });
  await STORE.syncSet({ theme: s.theme === "dark" ? "light" : "dark" });
  applyTheme();
});

/* ---------- 词表元数据 / 发音 ---------- */
function wordMetaOf(word) {
  return (VOCAB && VOCAB.meta && VOCAB.meta[word]) || null;
}
function speak(word) {
  // 统一走共享 TTS 模块；模块未加载时降级本地朗读
  try {
    if (window.WH_TTS && window.WH_TTS.speakText) {
      window.WH_TTS.speakText(word);
      return;
    }
  } catch (e) { /* ignore */ }
  try {
    const u = new SpeechSynthesisUtterance(word);
    u.lang = "en-US";
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  } catch (e) { /* ignore */ }
}

/* ---------- 艾宾浩斯调度（本模块独立数据，与生词本 wh_review 互不相干） ---------- */
const LEARN_WORDS_KEY = "wh_learn_words";
const LEARN_REVIEW_KEY = "wh_learn_review";
const LEARN_DAILY_KEY = "wh_learn_daily";
const LEARN_RV_DAILY_KEY = "wh_learn_rv_daily";
const WB_KEY = "wh_wordbook"; // 仅读：用于选词时跳过已收藏词
const DAY_MS = 24 * 3600 * 1000;
const RV_STAGES = [0, 1, 2, 4, 7, 15, 30, 60];
const RV_GRADUATED = RV_STAGES.length - 1;
const LN_BATCH = 10; // 每批词数

let learnWords = [];      // 本模块学过的词 [{word, ts}]
let learnReview = {};     // 艾宾浩斯调度
let learnDaily = {};      // 每日已学新词数
let learnRvDaily = {};    // 复习打卡统计

function todayStr(ts) {
  const d = new Date(ts == null ? Date.now() : ts);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

async function loadAll() {
  const a = await STORE.localGet(LEARN_WORDS_KEY);
  learnWords = Array.isArray(a[LEARN_WORDS_KEY]) ? a[LEARN_WORDS_KEY].filter((e) => e && typeof e.word === "string") : [];
  const b = await STORE.localGet(LEARN_REVIEW_KEY);
  learnReview = b[LEARN_REVIEW_KEY] && typeof b[LEARN_REVIEW_KEY] === "object" ? b[LEARN_REVIEW_KEY] : {};
  const c = await STORE.localGet(LEARN_DAILY_KEY);
  learnDaily = c[LEARN_DAILY_KEY] && typeof c[LEARN_DAILY_KEY] === "object" ? c[LEARN_DAILY_KEY] : {};
  const d = await STORE.localGet(LEARN_RV_DAILY_KEY);
  learnRvDaily = d[LEARN_RV_DAILY_KEY] && typeof d[LEARN_RV_DAILY_KEY] === "object" ? d[LEARN_RV_DAILY_KEY] : {};
}

async function saveLearnData() {
  await STORE.localSet({
    [LEARN_WORDS_KEY]: learnWords,
    [LEARN_REVIEW_KEY]: learnReview,
    [LEARN_DAILY_KEY]: learnDaily,
    [LEARN_RV_DAILY_KEY]: learnRvDaily
  });
}

/** 调度：ok=认识进阶 / fuzzy=模糊同阶段重复 / fail=忘了归零 10 分钟后 */
function scheduleWord(word, g, now) {
  const r = learnReview[word] || { s: 0, due: 0, last: 0, ok: 0, fail: 0 };
  now = now == null ? Date.now() : now;
  if (g === "ok") {
    r.s = Math.min((r.s || 0) + 1, RV_GRADUATED);
    r.ok = (r.ok || 0) + 1;
  } else if (g === "fail") {
    r.s = 0;
    r.fail = (r.fail || 0) + 1;
  }
  const gapDays = RV_STAGES[r.s];
  r.due = g === "fail" ? now + 10 * 60 * 1000 : now + Math.max(gapDays, 1) * DAY_MS;
  r.last = now;
  learnReview[word] = r;
  return r;
}

/* ---------- 学习批次（纯逻辑） ---------- */

/** 从词表构建学习批次——跳过已学（本模块/生词本/快筛认识/已掌握），最多 n 个，保持词表顺序 */
function buildLearnBatch(list, learnedSet, n) {
  const out = [];
  for (const item of list) {
    if (learnedSet.has(item.word)) continue;
    out.push(item.word);
    if (out.length >= n) break;
  }
  return out;
}

/** 待学集合 = 本模块已学 ∪ 生词本 ∪ 快筛认识 ∪ 已掌握 */
async function learnedWordsSet() {
  const [s, wb] = await Promise.all([
    STORE.syncGet({ userWords: [], knownWords: [] }),
    STORE.localGet(WB_KEY)
  ]);
  const set = new Set(s.userWords || []);
  for (const w of s.knownWords || []) set.add(w);
  for (const e of wb[WB_KEY] || []) set.add(e.word);
  for (const e of learnWords) set.add(e.word);
  return set;
}

/** 等级词表（与 wordlist 快筛同规则：只留等于所选等级的词，按字母序） */
function buildLevelList(level) {
  if (!VOCAB || !VOCAB.meta) return [];
  const idx = VOCAB.order.indexOf(level);
  if (idx < 0) return [];
  const out = [];
  for (const w of Object.keys(VOCAB.meta)) {
    const m = VOCAB.meta[w];
    if (m[2] === undefined || m[2] !== idx) continue;
    out.push({ word: w, meta: m });
  }
  out.sort((a, b) => a.word.localeCompare(b.word));
  return out;
}

/** 今日还能学多少：每日强度 - 今日已学（下限 0），单批不超过 LN_BATCH */
function learnRemainToday(learnedToday, dailyLimit) {
  return Math.max(0, Math.min(dailyLimit - learnedToday, LN_BATCH));
}

/** 复习队列：本模块学过、无记录（阶段 0）或 due 到期的词，按到期时间升序 */
function buildReviewQueue() {
  const now = Date.now();
  return learnWords
    .map((e) => e.word)
    .filter((w) => {
      const r = learnReview[w];
      return !r || (r.due || 0) <= now;
    })
    .sort((a, b) => ((learnReview[a] && learnReview[a].due) || 0) - ((learnReview[b] && learnReview[b].due) || 0));
}

/* ---------- 学习状态 ---------- */
let lnLevel = "primary";
let lnQueue = [];
let lnTotal = 0;
let lnDone = { ok: 0, fuzzy: 0, fail: 0 };
let lnBonus = false; // 加练模式：今日额度用完后手动加练
let lnPending = null; // 当前卡片暂存的评分 {word, grade}

function dailyLimit() {
  const v = parseInt(($("#ln-daily") && $("#ln-daily").value) || "10", 10);
  return isNaN(v) ? 10 : v;
}
function learnedToday() {
  return learnDaily[todayStr()] || 0;
}

function setLearnPane(name) {
  for (const id of ["ln-start", "ln-box", "ln-finish", "ln-daily-done", "ln-empty"]) {
    $("#" + id).classList.toggle("hidden", id !== name);
  }
}

/** 渲染学习面板：等级/强度下拉 + 统计 + 分流（额度用完 → 完成面板） */
async function renderLearn() {
  const sel = $("#ln-select");
  sel.textContent = "";
  if (!VOCAB) return;
  for (const lv of VOCAB.order) {
    const opt = document.createElement("option");
    opt.value = lv;
    opt.textContent = VOCAB.labels[lv];
    sel.appendChild(opt);
  }
  sel.value = lnLevel;
  const s = await STORE.syncGet({ learnDaily: 10 });
  $("#ln-daily").value = String(s.learnDaily || 10);
  const today = learnedToday();
  $("#ln-sub").textContent = "今日已学 " + today + " 词";
  if (today >= dailyLimit() && !lnBonus) {
    $("#ln-daily-text").textContent = "今日强度已完成（" + today + " / " + dailyLimit() + " 词）";
    setLearnPane("ln-daily-done");
    return;
  }
  setLearnPane("ln-start");
  await updateLearnInfo();
}

async function updateLearnInfo() {
  const list = buildLevelList(lnLevel);
  const learned = await learnedWordsSet();
  const remain = buildLearnBatch(list, learned, Infinity).length;
  const today = learnedToday();
  const left = dailyLimit() - today;
  $("#ln-info").textContent = "「" + VOCAB.labels[lnLevel] + "」词库共 " + list.length
    + " 词，待学 " + remain + " 词；今日已学 " + today + " / " + dailyLimit()
    + " 词" + (left > 0 ? "（还可学 " + left + " 词）" : "（已达强度）") + "。";
  $("#ln-start-btn").textContent = remain > 0 && left > 0
    ? "🚀 开始学习（" + Math.min(remain, left, LN_BATCH) + " 词）"
    : "🚀 开始学习";
}

async function startLearnBatch(count) {
  const list = buildLevelList(lnLevel);
  const learned = await learnedWordsSet();
  lnQueue = buildLearnBatch(list, learned, count);
  lnTotal = lnQueue.length;
  lnDone = { ok: 0, fuzzy: 0, fail: 0 };
  if (!lnQueue.length) {
    setLearnPane("ln-empty");
    return;
  }
  setLearnPane("ln-box");
  showNextLearn();
}

function showNextLearn() {
  const word = lnQueue[0];
  if (!word) {
    setLearnPane("ln-finish");
    $("#ln-finish-text").textContent = "本批 " + lnTotal + " 词学完：认识 " + lnDone.ok
      + " · 模糊 " + lnDone.fuzzy + " · 忘记 " + lnDone.fail;
    $("#ln-sub").textContent = "今日已学 " + learnedToday() + " 词";
    return;
  }
  lnPending = null;
  $("#ln-count").textContent = "第 " + ((lnTotal - lnQueue.length) + 1) + " / " + lnTotal + " 个";
  $("#ln-word").textContent = word;
  const m = wordMetaOf(word);
  $("#ln-ph").textContent = (m && m[1]) || "";
  $("#ln-detail").classList.add("hidden");
  $("#ln-detail").textContent = "";
  $("#ln-actions").classList.remove("hidden");
  $("#ln-after-actions").classList.add("hidden");
  speak(word); // 切换单词时自动发音一次
}

/** 学习反馈：调度（独立 wh_learn_review）+ 计每日已学数 + 记入本模块已学词表（不写生词本） */
async function gradeLearn(word, g) {
  scheduleWord(word, g);
  lnDone[g] = (lnDone[g] || 0) + 1;
  const t = todayStr();
  learnDaily[t] = (learnDaily[t] || 0) + 1;
  if (!learnWords.some((e) => e.word === word)) {
    learnWords.unshift({ word, ts: Date.now() });
  }
  saveLearnData();
}

/* ---------- 复习状态（本模块独立） ---------- */
let lrQueue = [];
let lrTotal = 0;
let lrPending = null;

function setReviewPane(name) {
  for (const id of ["lr-box", "lr-finish", "lr-empty", "lr-none"]) {
    $("#" + id).classList.toggle("hidden", id !== name);
  }
}

function renderReview() {
  lrQueue = buildReviewQueue();
  lrTotal = lrQueue.length;
  const today = learnRvDaily[todayStr()] || { r: 0 };
  $("#lr-today").textContent = lrQueue.length;
  $("#lr-done").textContent = today.r || 0;
  $("#lr-total").textContent = learnWords.length;
  if (!learnWords.length) {
    setReviewPane("lr-empty");
    return;
  }
  showNextReview();
}

function showNextReview() {
  const word = lrQueue[0];
  if (!word) {
    setReviewPane(lrTotal === 0 ? "lr-none" : "lr-finish");
    return;
  }
  lrPending = null;
  setReviewPane("lr-box");
  $("#lr-count").textContent = "第 " + ((lrTotal - lrQueue.length) + 1) + " / " + lrTotal + " 个";
  $("#lr-word").textContent = word;
  const m = wordMetaOf(word);
  $("#lr-ph").textContent = (m && m[1]) || "";
  $("#lr-detail").classList.add("hidden");
  $("#lr-detail").textContent = "";
  $("#lr-actions").classList.remove("hidden");
  $("#lr-after-actions").classList.add("hidden");
  speak(word); // 切换复习单词时自动发音一次
}

/** 复习反馈：调度 + 复习打卡（独立 wh_learn_rv_daily，与生词本 wh_daily 互不相干） */
function gradeReview(word, g) {
  scheduleWord(word, g);
  const t = todayStr();
  const d = learnRvDaily[t] || { r: 0, f: 0 };
  d.r += 1;
  if (g === "fail") d.f += 1;
  learnRvDaily[t] = d;
  saveReviewData();
}
function saveReviewData() {
  STORE.localSet({ [LEARN_REVIEW_KEY]: learnReview, [LEARN_RV_DAILY_KEY]: learnRvDaily });
}

/* ---------- 学习事件 ---------- */
document.querySelectorAll("#ln-actions .rv-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const word = lnQueue[0];
    if (!word) return;
    lnPending = { word, grade: btn.dataset.g };
    $("#ln-actions").classList.add("hidden");
    $("#ln-after-actions").classList.remove("hidden");
    const detail = $("#ln-detail");
    window.WH_DETAIL.loading(detail);
    window.WH_DETAIL.fetch(word).then((data) => {
      window.WH_DETAIL.render(detail, data);
    });
  });
});

async function finishLearnGrade() {
  if (!lnPending) return;
  await gradeLearn(lnPending.word, lnPending.grade);
  lnQueue.shift();
  lnPending = null;
  showNextLearn();
}

$("#ln-wrong").addEventListener("click", () => {
  if (!lnPending) return;
  lnPending.grade = "fail";
  finishLearnGrade();
});
$("#ln-next").addEventListener("click", finishLearnGrade);

$("#ln-speak").addEventListener("click", () => {
  const w = lnQueue[0];
  if (w) speak(w);
});
$("#ln-start-btn").addEventListener("click", () => {
  const left = dailyLimit() - learnedToday();
  const n = Math.max(1, Math.min(left, LN_BATCH)); // 剩余额度不足一批时按剩余数开批
  startLearnBatch(n);
});
$("#ln-again").addEventListener("click", () => {
  const left = dailyLimit() - learnedToday();
  if (left <= 0) {
    $("#ln-daily-text").textContent = "今日强度已完成（" + learnedToday() + " / " + dailyLimit() + " 词）";
    setLearnPane("ln-daily-done");
    return;
  }
  startLearnBatch(Math.min(left, LN_BATCH));
});
$("#ln-bonus").addEventListener("click", () => {
  lnBonus = true; // 加练：突破今日额度
  startLearnBatch(LN_BATCH);
});
$("#ln-select").addEventListener("change", (e) => {
  lnLevel = e.target.value;
  updateLearnInfo();
});
$("#ln-daily").addEventListener("change", async (e) => {
  const v = parseInt(e.target.value, 10) || 10;
  await STORE.syncSet({ learnDaily: v });
  lnBonus = false;
  renderLearn();
});

/* ---------- 复习事件 ---------- */
document.querySelectorAll("#lr-actions .rv-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const word = lrQueue[0];
    if (!word) return;
    lrPending = { word, grade: btn.dataset.g };
    $("#lr-actions").classList.add("hidden");
    $("#lr-after-actions").classList.remove("hidden");
    const detail = $("#lr-detail");
    window.WH_DETAIL.loading(detail);
    window.WH_DETAIL.fetch(word).then((data) => {
      window.WH_DETAIL.render(detail, data);
    });
  });
});

function finishReviewGrade() {
  if (!lrPending) return;
  gradeReview(lrPending.word, lrPending.grade);
  lrQueue.shift();
  lrPending = null;
  const today = learnRvDaily[todayStr()] || { r: 0 };
  $("#lr-done").textContent = today.r || 0;
  showNextReview();
}

$("#lr-wrong").addEventListener("click", () => {
  if (!lrPending) return;
  lrPending.grade = "fail";
  finishReviewGrade();
});
$("#lr-next").addEventListener("click", finishReviewGrade);

$("#lr-speak").addEventListener("click", () => {
  const w = lrQueue[0];
  if (w) speak(w);
});


/* ---------- 数据统计面板（本模块独立数据：wh_learn_words / wh_learn_review / wh_learn_rv_daily） ---------- */
function computeLearnStats() {
  const total = learnWords.length;
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  const monthNew = learnWords.filter((e) => (e.ts || 0) >= monthStart.getTime()).length;
  // 复习完成率 = 累计复习次数 / (累计复习次数 + 当前过期未复习词数)；遗忘率 = 遗忘次数 / 累计复习次数
  let totalReviews = 0;
  let totalFails = 0;
  const now = Date.now();
  let overdue = 0;
  for (const e of learnWords) {
    const r = learnReview[e.word];
    if (r) {
      totalReviews += (r.ok || 0) + (r.fail || 0);
      totalFails += r.fail || 0;
      if ((r.due || 0) <= now) overdue += 1;
    } else {
      overdue += 1; // 未复习过的到期词
    }
  }
  const doneRate = totalReviews + overdue > 0 ? Math.round((totalReviews / (totalReviews + overdue)) * 100) : null;
  const forgetRate = totalReviews > 0 ? Math.round((totalFails / totalReviews) * 100) : null;
  const graduated = learnWords.filter((e) => learnReview[e.word] && learnReview[e.word].s >= RV_GRADUATED).length;
  return { total, monthNew, doneRate, forgetRate, overdue, graduated, totalReviews, totalFails };
}

/** 学习曲线（近 30 天）：SVG 双折线（新学单词来自 learnWords.ts；复习次数来自 learnRvDaily） */
function renderLearnChart() {
  const days = 30;
  const now = Date.now();
  const newCnt = new Array(days).fill(0);
  for (const e of learnWords) {
    const idx = Math.floor((now - (e.ts || 0)) / DAY_MS);
    if (idx >= 0 && idx < days) newCnt[days - 1 - idx] += 1;
  }
  const rvCnt = new Array(days).fill(0);
  for (let i = 0; i < days; i++) {
    const d = learnRvDaily[todayStr(now - (days - 1 - i) * DAY_MS)];
    rvCnt[i] = (d && d.r) || 0;
  }
  const W = 700, H = 200, PAD = 34;
  const maxV = Math.max(1, ...newCnt, ...rvCnt);
  const x = (i) => PAD + (i * (W - PAD * 2)) / (days - 1);
  const y = (v) => H - PAD - (v * (H - PAD * 2)) / maxV;
  const line = (arr) => arr.map((v, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1)).join(" ");
  let labels = "";
  for (let i = 0; i < days; i += 7) {
    labels += '<text x="' + x(i).toFixed(0) + '" y="' + (H - 8) + '" class="ax">' + todayStr(now - (days - 1 - i) * DAY_MS).slice(5) + "</text>";
  }
  const gridV = Math.ceil(maxV / 2) || 1;
  let grid = "";
  for (let v = gridV; v <= maxV; v += gridV) {
    grid += '<line x1="' + PAD + '" y1="' + y(v) + '" x2="' + (W - PAD) + '" y2="' + y(v) + '" class="grid"/><text x="4" y="' + (y(v) + 4) + '" class="ax">' + v + "</text>";
  }
  const svg = '<svg viewBox="0 0 ' + W + " " + H + '" preserveAspectRatio="xMidYMid meet">'
    + grid
    + '<path d="' + line(newCnt) + '" class="ln-new" fill="none"/>'
    + '<path d="' + line(rvCnt) + '" class="ln-rv" fill="none"/>'
    + labels + "</svg>";
  $("#st-chart").innerHTML = svg;
}

function renderStats() {
  const s = computeLearnStats();
  $("#st-total").textContent = s.total;
  $("#st-month").textContent = s.monthNew;
  $("#st-done-rate").textContent = s.doneRate == null ? "—" : s.doneRate + "%";
  $("#st-forget-rate").textContent = s.forgetRate == null ? "—" : s.forgetRate + "%";
  const ex = $("#st-extra");
  ex.textContent = "";
  const parts = [
    "累计复习 " + s.totalReviews + " 次",
    "当前过期待复习 " + s.overdue + " 词",
    "已通过全部复习阶段（60 天长期间隔）" + s.graduated + " 词",
    "累计遗忘 " + s.totalFails + " 次"
  ];
  for (const p of parts) {
    const span = document.createElement("span");
    span.className = "st-chip";
    span.textContent = p;
    ex.appendChild(span);
  }
  renderLearnChart();
}

/* ---------- 标签页切换 ---------- */
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t === tab));
    document.querySelectorAll(".tab-pane").forEach((p) => {
      p.classList.toggle("active", p.id === "tab-" + tab.dataset.tab);
    });
    if (tab.dataset.tab === "learn") renderLearn();
    else if (tab.dataset.tab === "stats") renderStats();
    else renderReview();
  });
});

/* ---------- 初始化 ---------- */
if (!IS_EXT) {
  const w = $("#env-warn");
  if (w) w.classList.remove("hidden");
}
/* 【v2.18.0】会员门禁：使用共享 pro-gate.js 模块 */
WH_PRO_GATE.init();

applyTheme();
(async () => {
  const s = await STORE.syncGet({ level: "none" });
  if (s.level && s.level !== "none" && VOCAB && VOCAB.order.includes(s.level)) lnLevel = s.level;
  await loadAll();
  renderLearn();
})();
