/**
 * 生词高亮 & 翻译助手 —— 内容脚本（Content Script）v2.1
 * 功能：
 *  - 按所选词汇等级自动高亮生词（8 级去重词库，内置释义/音标，离线秒出）
 *  - 悬停高亮词 → 简略翻译气泡（中文含义一行）
 *  - 右键单击单词 → 打开详细释义卡片（音标/释义/词根词缀/关联词汇/发音/生词本管理）；再次右键同一单词关闭；卡片打开后点击外部区域或按 Esc 也可关闭
 *  - 日间 / 夜间主题
 */
(() => {
  "use strict";
  if (window.__WH_LOADED__) return;
  window.__WH_LOADED__ = true;

  // 内部页面（背单词 / 生词本 / 设置 / popup）复用悬浮卡片时，不执行网页高亮/翻译
  const IS_INTERNAL_PAGE = document.documentElement.hasAttribute("data-wh-internal");

  /* ============================================================
   * 一、词根词缀表（用于卡片"词根词缀"区展示）
   * ============================================================ */
  const AFFIXES = [
    // 前缀
    { type: "prefix", aff: "un", mean: "不，非" },
    { type: "prefix", aff: "re", mean: "再，重新，返回" },
    { type: "prefix", aff: "dis", mean: "不，相反，分离" },
    { type: "prefix", aff: "mis", mean: "错误，坏" },
    { type: "prefix", aff: "pre", mean: "预先，在前" },
    { type: "prefix", aff: "post", mean: "在……之后" },
    { type: "prefix", aff: "anti", mean: "反对，抵抗，防" },
    { type: "prefix", aff: "sub", mean: "在……之下，次级" },
    { type: "prefix", aff: "super", mean: "在……之上，超" },
    { type: "prefix", aff: "inter", mean: "在……之间，相互" },
    { type: "prefix", aff: "trans", mean: "跨越，转变，穿过" },
    { type: "prefix", aff: "ex", mean: "向外，出，前任" },
    { type: "prefix", aff: "en", mean: "使……，进入" },
    { type: "prefix", aff: "em", mean: "使……（置于 b/p/m 前）" },
    { type: "prefix", aff: "in", mean: "不，向内" },
    { type: "prefix", aff: "im", mean: "不（置于 b/p/m 前）" },
    { type: "prefix", aff: "il", mean: "不（置于 l 前）" },
    { type: "prefix", aff: "ir", mean: "不（置于 r 前）" },
    { type: "prefix", aff: "non", mean: "不，非" },
    { type: "prefix", aff: "over", mean: "过度，在……上方" },
    { type: "prefix", aff: "under", mean: "在……之下，不足" },
    { type: "prefix", aff: "auto", mean: "自己，自动" },
    { type: "prefix", aff: "bi", mean: "二，两" },
    { type: "prefix", aff: "co", mean: "共同，一起" },
    { type: "prefix", aff: "de", mean: "向下，去除，相反" },
    { type: "prefix", aff: "fore", mean: "前，预先" },
    { type: "prefix", aff: "micro", mean: "微小，百万分之一" },
    { type: "prefix", aff: "mid", mean: "中间" },
    { type: "prefix", aff: "mini", mean: "小，迷你" },
    { type: "prefix", aff: "mono", mean: "单一" },
    { type: "prefix", aff: "multi", mean: "多" },
    { type: "prefix", aff: "out", mean: "向外，超出" },
    { type: "prefix", aff: "semi", mean: "半，部分" },
    { type: "prefix", aff: "tele", mean: "远距离" },
    { type: "prefix", aff: "tri", mean: "三" },
    { type: "prefix", aff: "uni", mean: "一，单一" },
    { type: "prefix", aff: "up", mean: "向上，更新" },
    { type: "prefix", aff: "ab", mean: "离开，相反" },
    { type: "prefix", aff: "ad", mean: "朝向，加强" },
    { type: "prefix", aff: "com", mean: "共同，加强（置于 b/p/m 前）" },
    { type: "prefix", aff: "con", mean: "共同，加强" },
    { type: "prefix", aff: "col", mean: "共同（置于 l 前）" },
    { type: "prefix", aff: "cor", mean: "共同（置于 r 前）" },
    { type: "prefix", aff: "contra", mean: "相反，相对" },
    { type: "prefix", aff: "hyper", mean: "超过，过度" },
    { type: "prefix", aff: "macro", mean: "大，宏观" },
    { type: "prefix", aff: "para", mean: "在旁边，类似，辅助" },
    { type: "prefix", aff: "per", mean: "每，贯穿，彻底" },
    { type: "prefix", aff: "pro", mean: "向前，支持，赞成" },
    { type: "prefix", aff: "retro", mean: "向后，追溯" },
    { type: "prefix", aff: "se", mean: "分离，分开" },
    { type: "prefix", aff: "syn", mean: "相同，一起" },
    { type: "prefix", aff: "sym", mean: "相同（置于 b/p/m 前）" },
    { type: "prefix", aff: "sur", mean: "在……之上，超" },
    { type: "prefix", aff: "with", mean: "向后，相对，离开" },
    // 后缀
    { type: "suffix", aff: "tion", mean: "名词：动作、状态、结果（-ation/-ition）" },
    { type: "suffix", aff: "sion", mean: "名词：动作、状态（-ssion）" },
    { type: "suffix", aff: "ment", mean: "名词：行为、结果、手段" },
    { type: "suffix", aff: "ness", mean: "名词：性质、状态" },
    { type: "suffix", aff: "ity", mean: "名词：性质、状态（-ty）" },
    { type: "suffix", aff: "er", mean: "名词：……的人/物（-or/-ar）" },
    { type: "suffix", aff: "ist", mean: "名词：……主义者、……家" },
    { type: "suffix", aff: "ee", mean: "名词：被……的人" },
    { type: "suffix", aff: "ism", mean: "名词：主义、学说" },
    { type: "suffix", aff: "ship", mean: "名词：身份、状态、关系" },
    { type: "suffix", aff: "hood", mean: "名词：时期、状态、身份" },
    { type: "suffix", aff: "dom", mean: "名词：领域、状态" },
    { type: "suffix", aff: "ance", mean: "名词：性质、状态（-ence）" },
    { type: "suffix", aff: "ence", mean: "名词：性质、状态" },
    { type: "suffix", aff: "al", mean: "形容词：……的（-ial）" },
    { type: "suffix", aff: "ous", mean: "形容词：充满……的（-ious）" },
    { type: "suffix", aff: "ful", mean: "形容词：充满……的" },
    { type: "suffix", aff: "less", mean: "形容词：无……的，不……的" },
    { type: "suffix", aff: "ive", mean: "形容词：有……倾向/性质的（-ative/-itive）" },
    { type: "suffix", aff: "able", mean: "形容词：可……的（-ible）" },
    { type: "suffix", aff: "ic", mean: "形容词：……的" },
    { type: "suffix", aff: "ical", mean: "形容词：……的" },
    { type: "suffix", aff: "ish", mean: "形容词：略带……的，……似的" },
    { type: "suffix", aff: "ly", mean: "副词：……地" },
    { type: "suffix", aff: "ward", mean: "形容词/副词：朝……方向（-wards）" },
    { type: "suffix", aff: "wise", mean: "副词：以……方式，在……方面" },
    { type: "suffix", aff: "en", mean: "动词：使成为……；形容词：由……制成" },
    { type: "suffix", aff: "ize", mean: "动词：使……化（-ise）" },
    { type: "suffix", aff: "ify", mean: "动词：使……，……化" },
    { type: "suffix", aff: "ate", mean: "动词：使成为……；形容词：……的" },
    { type: "suffix", aff: "ing", mean: "现在分词/动名词：……的，正在……" },
    { type: "suffix", aff: "ed", mean: "过去式/过去分词：已……的" },
    { type: "suffix", aff: "y", mean: "形容词：多……的，有……的" },
    { type: "suffix", aff: "ant", mean: "形容词：处于……状态的（-ent）" },
    { type: "suffix", aff: "ent", mean: "形容词：处于……状态的，具有……性质的" },
    // 常用词根
    { type: "root", aff: "bio", mean: "生命（biology 生物学）" },
    { type: "root", aff: "geo", mean: "大地（geography 地理）" },
    { type: "root", aff: "graph", mean: "写，画，记录（photograph 照片）" },
    { type: "root", aff: "chron", mean: "时间（chronicle 编年史）" },
    { type: "root", aff: "aqua", mean: "水（aquarium 水族馆）" },
    { type: "root", aff: "hydr", mean: "水（hydrogen 氢）" },
    { type: "root", aff: "psych", mean: "心理，灵魂（psychology 心理学）" },
    { type: "root", aff: "path", mean: "感情，疾病（sympathy 同情）" },
    { type: "root", aff: "phil", mean: "爱（philosophy 哲学）" },
    { type: "root", aff: "phob", mean: "恐惧（phobia 恐惧症）" },
    { type: "root", aff: "dict", mean: "说，宣告（dictation 听写）" },
    { type: "root", aff: "port", mean: "搬运，携带（transport 运输）" },
    { type: "root", aff: "duct", mean: "引导，带领（conduct 引导）" },
    { type: "root", aff: "struct", mean: "建造（structure 结构）" },
    { type: "root", aff: "form", mean: "形状，形成（inform 通知）" },
    { type: "root", aff: "spect", mean: "看（inspect 检查）" },
    { type: "root", aff: "vis", mean: "看（visible 可见的）" },
    { type: "root", aff: "vid", mean: "看（video 视频）" },
    { type: "root", aff: "aud", mean: "听（audio 音频）" },
    { type: "root", aff: "voc", mean: "声音，喊叫（vocal 嗓音的）" },
    { type: "root", aff: "mot", mean: "移动（motion 运动）" },
    { type: "root", aff: "mov", mean: "移动（movement 运动）" },
    { type: "root", aff: "cred", mean: "相信（credit 信用）" },
    { type: "root", aff: "terr", mean: "土地（territory 领土）" },
    { type: "root", aff: "mar", mean: "海洋（marine 海洋的）" },
    { type: "root", aff: "astro", mean: "星，天体（astronomy 天文学）" },
    { type: "root", aff: "therm", mean: "热（thermometer 温度计）" },
    { type: "root", aff: "photo", mean: "光（photograph 照片）" },
    { type: "root", aff: "phon", mean: "声音（phonetics 语音学）" },
    { type: "root", aff: "log", mean: "说话，学科（dialogue 对话）" },
    { type: "root", aff: "man", mean: "手（manual 手工的）" },
    { type: "root", aff: "manu", mean: "手（manufacture 制造）" },
    { type: "root", aff: "ped", mean: "脚（pedal 踏板）" },
    { type: "root", aff: "pod", mean: "脚（tripod 三脚架）" },
    { type: "root", aff: "gen", mean: "出生，产生，种类（generate 产生）" },
    { type: "root", aff: "nat", mean: "出生，天生（nature 自然）" },
    { type: "root", aff: "prim", mean: "第一，首要（primary 首要的）" },
    { type: "root", aff: "sen", mean: "老，年长（senior 年长的）" },
    { type: "root", aff: "mort", mean: "死（mortal 必死的）" },
    { type: "root", aff: "viv", mean: "活，生命（vivid 生动的）" },
    { type: "root", aff: "vit", mean: "生命（vital 至关重要的）" },
    { type: "root", aff: "sol", mean: "单独；太阳（solo 独奏）" },
    { type: "root", aff: "ann", mean: "年（annual 每年的）" },
    { type: "root", aff: "enn", mean: "年（centennial 百年纪念）" },
    { type: "root", aff: "cent", mean: "百；百分（century 世纪）" },
    { type: "root", aff: "corp", mean: "身体，团体（corporation 公司）" },
    { type: "root", aff: "dent", mean: "牙齿（dentist 牙医）" },
    { type: "root", aff: "equ", mean: "相等（equal 相等的）" },
    { type: "root", aff: "fac", mean: "做，制作（factory 工厂）" },
    { type: "root", aff: "fact", mean: "做，制作（manufacture 制造）" },
    { type: "root", aff: "flu", mean: "流动（fluent 流利的）" },
    { type: "root", aff: "frag", mean: "打破，破碎（fragment 碎片）" },
    { type: "root", aff: "ject", mean: "投掷（project 投射，项目）" },
    { type: "root", aff: "journ", mean: "日，一天（journal 日记）" },
    { type: "root", aff: "liber", mean: "自由（liberty 自由）" },
    { type: "root", aff: "liter", mean: "文字，字母（literature 文学）" },
    { type: "root", aff: "loc", mean: "地方（local 当地的）" },
    { type: "root", aff: "medi", mean: "中间（medium 媒介）" },
    { type: "root", aff: "neg", mean: "否定（negative 消极的）" },
    { type: "root", aff: "nov", mean: "新（novel 小说）" },
    { type: "root", aff: "opt", mean: "选择；光（option 选项）" },
    { type: "root", aff: "ori", mean: "升起，开始（origin 起源）" },
    { type: "root", aff: "pac", mean: "和平（pacific 和平的）" },
    { type: "root", aff: "pend", mean: "悬挂，支付（depend 依靠）" },
    { type: "root", aff: "plic", mean: "折叠，重叠（complicate 使复杂）" },
    { type: "root", aff: "pon", mean: "放置（component 组成部分）" },
    { type: "root", aff: "pos", mean: "放置（position 位置）" },
    { type: "root", aff: "popul", mean: "人民（popular 受欢迎的）" },
    { type: "root", aff: "press", mean: "压（express 表达）" },
    { type: "root", aff: "pur", mean: "纯净（pure 纯净的）" },
    { type: "root", aff: "quest", mean: "寻求，询问（question 问题）" },
    { type: "root", aff: "rect", mean: "直，正（correct 正确的）" },
    { type: "root", aff: "rupt", mean: "断裂（erupt 喷发）" },
    { type: "root", aff: "sci", mean: "知道（science 科学）" },
    { type: "root", aff: "sec", mean: "切，分割（section 部分）" },
    { type: "root", aff: "sent", mean: "感觉（sentiment 情感）" },
    { type: "root", aff: "sequ", mean: "跟随（sequence 顺序）" },
    { type: "root", aff: "sign", mean: "标记，记号（signal 信号）" },
    { type: "root", aff: "sist", mean: "站立（assist 帮助）" },
    { type: "root", aff: "son", mean: "声音（sonic 声波的）" },
    { type: "root", aff: "tact", mean: "触摸（contact 接触）" },
    { type: "root", aff: "tang", mean: "触摸（tangent 切线）" },
    { type: "root", aff: "tend", mean: "伸展，趋向（extend 延伸）" },
    { type: "root", aff: "tent", mean: "伸展（attention 注意）" },
    { type: "root", aff: "tract", mean: "拉，拖（attract 吸引）" },
    { type: "root", aff: "turb", mean: "搅动，骚乱（disturb 打扰）" },
    { type: "root", aff: "uni", mean: "一，单一（unite 联合）" },
    { type: "root", aff: "val", mean: "强壮，价值（value 价值）" },
    { type: "root", aff: "ven", mean: "来（convenient 方便的）" },
    { type: "root", aff: "ver", mean: "真实（verify 证实）" },
    { type: "root", aff: "vert", mean: "转，翻转（convert 转换）" },
    { type: "root", aff: "vol", mean: "意志，愿望；卷（volunteer 志愿者）" },
    { type: "root", aff: "xero", mean: "干燥（xerox 复印）" }
  ];

  /* ============================================================
   * 三、配置
   * ============================================================ */
  const DEFAULTS = {
    enabled: true,          // 总开关
    autoSpeak: true,        // 悬停/打开卡片后自动发音
    minLength: 3,           // 单词最短标记长度
    color: "#fff1a8",       // 高亮背景色
    underline: true,        // 下划线标记
    userWords: [],          // 自定义已掌握词表
    knownWords: [],         // 等级词表快筛：已认识的词（从高亮中移除）
    level: "none",          // 当前词汇等级（none=默认不启用生词高亮）
    theme: "light",         // light | dark | auto
    quickTip: true,         // 悬停显示简略翻译
    translateEnabled: false, // 网页翻译（手动开启）
    translateService: "auto", // auto | mymemory | google | custom:<id>
    translateMode: "replace", // replace 覆盖原文翻译（默认，类似浏览器整页翻译）| inline 保留原文并翻译
    noTranslateSites: [],   // 网页翻译白名单：命中的网址不进行网页翻译（存 hostname，支持子域匹配）
    modeMigrated266: false,  // v2.6.6 一次性迁移标记：旧 inline 默认 → replace
    ttsVoice: "",            // 【v2.10.9】发音统一由 tts_util.js 处理；此处仅保留语速供降级朗读
    ttsRate: 0.85,           // 语速
    ttsOnlineUrl: "",        // 在线 TTS 接口（OpenAI 兼容 audio/speech）
    ttsOnlineKey: "",
    ttsOnlineVoice: "",
    ytCaptionSingleLine: true,  // 【v2.17.9】YouTube 字幕始终单行显示（默认打开）
    ytCaptionTrMode: "sentence", // 【v2.17.9】接管字幕翻译模式（默认逐句）：word 逐词 | sentence 逐句 | word2 逐词2.0
    compatMode: false       // 【v2.18.3】兼容模式：React/Vue 等框架挂载点内跳过高亮（高亮需拆分文本节点，
                            //  会让框架卸载节点时抛 removeChild 并可能整页报错）；翻译/词典不受影响
  };
  let CONFIG = { ...DEFAULTS };
  let USER_WORDS = new Set();
  let KNOWN_WORDS = new Set();
  let STYLE_TAG = null;

  /* 【v2.17.20】会员门禁：非 PRO 会员不启用任何功能。
   *  状态缓存在 local.wh_membership（由 background / options 页维护），
   *  本地判定避免每个页面都走网络；变更经 onChanged 实时生效。
   *  v2.18.1：同时校验 signed_in 与到期时间；读取期间若状态变化则不被旧值覆盖。 */
  let MEM_PRO = false;
  let membershipEpoch = 0;

  function membershipIsPro(m) {
    if (!m || !m.signed_in || !m.pro) return false;
    if (!m.expires_at) return true;
    const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
    return Number.isFinite(t) && t > Date.now();
  }

  function loadMembership() {
    return new Promise((resolve) => {
      const epoch = membershipEpoch;
      try {
        chrome.storage.local.get("wh_membership", (o) => {
          const m = o && o.wh_membership;
          // 读取期间已收到 storage 变更：以监听器的新值为准，避免旧值覆盖
          if (epoch === membershipEpoch) MEM_PRO = membershipIsPro(m);
          resolve(MEM_PRO);
        });
      } catch (e) { MEM_PRO = false; resolve(false); }
    });
  }

  /** 网页翻译白名单匹配：当前页 hostname 是否在白名单内。
   *  条目支持 hostname（如 github.com，含子域匹配）或粘贴完整 URL（自动取 hostname）；www. 前缀忽略 */
  function siteInWhitelist(hostname, list) {
    const host = String(hostname || "").trim().toLowerCase().replace(/^www\./, "");
    if (!host) return false;
    for (const raw of (list || [])) {
      let entry = String(raw || "").trim().toLowerCase();
      if (!entry) continue;
      if (entry.includes("://")) {
        try { entry = new URL(entry).hostname; } catch (e) { continue; }
      }
      entry = entry.replace(/^www\./, "");
      if (host === entry || host.endsWith("." + entry)) return true;
    }
    return false;
  }

  function isNoTranslateSite() {
    let host = "";
    try { host = location.hostname; } catch (e) { return false; }
    return siteInWhitelist(host, CONFIG.noTranslateSites);
  }

  /** 网页翻译总开关：插件启用 + 手动开启 且 当前页不在白名单 且 PRO 会员 */
  function translateActive() {
    return !!CONFIG.enabled && !!CONFIG.translateEnabled && !isNoTranslateSite() && MEM_PRO;
  }

  /* ============================================================
   * 四、分级词库（来自 vocab-data.js，内置释义/音标/等级）
   * ============================================================ */
  const VOCAB = (typeof window.__WH_VOCAB__ !== "undefined" && window.__WH_VOCAB__) || null;
  const LEVEL_ORDER = (VOCAB && VOCAB.order) || [];
  const LEVEL_LABELS = (VOCAB && VOCAB.labels) || {};
  const META = (VOCAB && VOCAB.meta) || {};
  /** 高亮白名单：仅「等于所选等级」的词库词 + 收藏生词（红标强制）。
   *  旧实现是"黑名单"（不在已知集合 KNOWN_SET 即高亮）——词库未收录的词
   *  （人名/俚语/网络用语等）不属于任何集合 → 被误当生词大量高亮，
   *  等级为「无」时页面依旧满屏高亮；改为白名单后未收录词一律不高亮。 */
  let HIGHLIGHT_SET = new Set();

  /** 构建高亮白名单：
   *  - 等级为「无」（默认）→ 无任何等级词高亮（默认没有任何生词）；
   *  - 选择等级 → 仅「等于所选等级」的词库词高亮（低于/高于该等级、未收录词均不高亮），
   *    且排除自定义已掌握（userWords）与快筛已认识（knownWords）；
   *  - 收藏生词（生词本）始终红标强制高亮，不受等级影响。 */
  function buildHighlightSet(level, userWords, knownWords, wordbookSet) {
    const s = new Set();
    if (level && level !== "none" && VOCAB && LEVEL_ORDER.includes(level)) {
      const list = (VOCAB.lists && VOCAB.lists[level]) || [];
      for (const w of list) {
        if (!userWords.has(w) && !knownWords.has(w)) s.add(w);
      }
    }
    for (const w of wordbookSet) s.add(w); // 收藏生词：红标强制高亮
    return s;
  }

  /** 重建高亮白名单（等级/已掌握/已认识/生词本任一变化后调用） */
  function rebuildKnownSet() {
    HIGHLIGHT_SET = buildHighlightSet(CONFIG.level, USER_WORDS, KNOWN_WORDS, currentWordbookSet);
  }

  /* ============================================================
   * 五、工具函数
   * ============================================================ */
  const WORD_RE = /[A-Za-z][A-Za-z'’\-]*[A-Za-z]|[A-Za-z]/g;

  /** 图标字体检测（学习自 Read Frog）：Material Icons / Font Awesome 等图标字体用
   *  连字（ligature）渲染图标，文本内容是 "home"/"search" 等单词——被翻译会破坏图标。
   *  WeakMap 缓存计算结果，避免重复 getComputedStyle 开销。 */
  const ICON_FONT_RE = /material[- ]?icons|font[ -]?awesome|glyphicon|^oi$|icomoon|fontello|feather/i;
  const iconFontCache = new WeakMap();
  function isIconFontElement(el) {
    if (!el) return false;
    if (iconFontCache.has(el)) return iconFontCache.get(el);
    let hit = false;
    try {
      const ff = (getComputedStyle(el).fontFamily || "").toLowerCase();
      hit = ICON_FONT_RE.test(ff);
    } catch (e) { /* ignore */ }
    iconFontCache.set(el, hit);
    return hit;
  }

  function isIgnoredElement(el) {
    if (!el) return true;
    if (el.closest) {
      if (el.closest("script,style,noscript,textarea,input,select,option,code,pre,kbd,samp,svg,math,canvas,iframe,embed,object,head")) return true;
      if (el.isContentEditable) return true;
      // notranslate 标记（学习自 Read Frog / Google 翻译通用约定）：站点明确声明不翻译的区域
      // （html/body 整页级标记视为无——部分站点把 notranslate 挂在 body 上但正文仍需翻译）
      const ntEl = el.closest(".notranslate");
      if (ntEl && !/^(HTML|BODY)$/.test(ntEl.tagName)) return true;
      // 图标字体（Material Icons 连字等）：翻译会破坏图标
      if (isIconFontElement(el)) return true;
    }
    return false;
  }

  /** 【v2.17.27 框架安全】判断元素是否由 React/Vue 等框架渲染管理。
  /** 【v2.18.2 框架安全】判断元素是否落在"框架应用挂载点"里。
   *  注意：内容脚本运行在**隔离世界**，读不到页面世界挂在节点上的 expando
   *  （`__reactFiber$xxx` / `__vue__` 等），所以只能靠挂载点选择器判断：
   *  React(#root/#react-root/[data-reactroot])、Next(#__next)、Nuxt(#__nuxt)、
   *  Vue(#app/[data-v-app]/[data-server-rendered])。
   *  命中时：覆盖式翻译降级为对照式（只追加、不替换节点），避免框架卸载节点时抛
   *  "Failed to execute 'removeChild' on 'Node': The node to be removed is not a child of this node."
   *  （Supabase 仪表盘整页报错就是这个）。结果缓存到 WeakMap，避免重复 closest。 */
  const FW_ROOT_SELECTOR = "[data-reactroot],#root,#react-root,#app,#__next,#__nuxt,[data-v-app],[data-server-rendered]";
  const frameworkNodeCache = new WeakMap();
  function isFrameworkNode(el) {
    if (!el || el.nodeType !== 1) return false;
    if (frameworkNodeCache.has(el)) return frameworkNodeCache.get(el);
    let hit = false;
    try { hit = !!(el.closest && el.closest(FW_ROOT_SELECTOR)); } catch (e) { hit = false; }
    frameworkNodeCache.set(el, hit);
    return hit;
  }

  /** 【v2.18.3】已知会被"拆分文本节点"打崩的站点：无论兼容模式开关如何都按兼容处理
   *  （用户在这些站点上会被整页报错挡住，不能指望他自己想起去开开关）。 */
  const COMPAT_HOSTS = ["supabase.com", "supabase.co"];
  function onCompatHost() {
    const h = (location.hostname || "").toLowerCase();
    return COMPAT_HOSTS.some((d) => h === d || h.endsWith("." + d));
  }

  function cleanWord(w) {    return String(w).toLowerCase().replace(/^['’\-]+|['’\-]+$/g, "");
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function splitPos(text) {
    const s = String(text || "").trim();
    const m = s.match(/^([a-z]+)\.(?:\s+|)(.*)$/i);
    if (m) return { pos: m[1] + ".", body: m[2] };
    const m2 = s.match(/^（([a-z]+)）\s*(.*)$/i);
    if (m2) return { pos: m2[1] + ".", body: m2[2] };
    const m3 = s.match(/^【(\S+)】\s*(.*)$/);
    if (m3) return { pos: "【" + m3[1] + "】", body: m3[2] };
    return { pos: "", body: s };
  }

  function groupTranslations(translations) {
    const map = new Map();
    for (const t of translations) {
      const { pos, body } = splitPos(t);
      if (!map.has(pos)) map.set(pos, []);
      map.get(pos).push(body);
    }
    return [...map.entries()].map(([pos, lines]) => ({ pos, lines }));
  }

  function splitFirstSegment(body) {
    const idx = body.search(/[；;]/);
    if (idx <= 0) return [body, ""];
    return [body.slice(0, idx), body.slice(idx + 1)];
  }

  /** 根据实际宽度隐藏/显示释义“展开”按钮（单行溢出才显示） */
  function updateDefExpandButtons(defBlock) {
    requestAnimationFrame(() => {
      defBlock.querySelectorAll(".wh-tip-def").forEach((line) => {
        const text = line.querySelector(".wh-tip-def-text");
        const btn = line.querySelector(".wh-tip-def-more");
        if (!text || !btn) return;
        if (text.scrollWidth > text.clientWidth + 1) btn.classList.remove("hidden");
        else btn.classList.add("hidden");
      });
    });
  }

  function isWord(w) {
    if (!w) return false;
    const lower = cleanWord(w);
    if (!lower) return false;
    // 生词本显式收藏的词：豁免最小长度与全大写过滤（用户主动行为优先级最高）
    const isWb = currentWordbookSet.has(lower);
    // 【v2.17.14】生词本词豁免最小长度："on"/"an" 等 2 字母词显式收藏后必须强制高亮
    // （此前 minLen 过滤拦在 HIGHLIGHT_SET 判定之前，生词本词也被杀掉）
    if (lower.length < CONFIG.minLength && !isWb) return false;
    // 白名单判定：不在 HIGHLIGHT_SET（未收录/非所选等级/已掌握/已认识/未收藏）→ 一律不高亮
    if (!HIGHLIGHT_SET.has(lower)) return false;
    // 【v2.17.16】全大写词不高亮（缩写/标题/字幕大写样式，如 "LEGEND OF HEI 2"）。
    // 旧规则 {3,} 只排除 3+ 字母（LEGEND/HEI），2 字母的 "OF" 漏网 → 全大写标题里
    // 只有 "OF" 孤零零被高亮。
    // 【v2.17.17】生词本词豁免：用户显式收藏的大写词（如 "WHET"）必须高亮
    if (!isWb && /^[A-Z]{2,}$/.test(w)) return false;
    if (/\d/.test(w)) return false;
    return true;
  }

  function normalizeUserWords(list) {
    return (list || []).map((w) => cleanWord(w)).filter(Boolean);
  }

  /** 只接受 #RGB/#RGBA/#RRGGBB/#RRGGBBAA，避免把 storage 中的任意字符串拼进 style */
  function safeCssColor(c) {
    const s = String(c || "").trim();
    return /^#(?:[0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(s) ? s : "#fff1a8";
  }

  /** 生成生词高亮样式文本（日间/夜间使用不同模板：夜间暗色低亮，避免刺眼） */
  function buildHighlightCss(color, underline, isDark) {
    const hlBg = isDark ? "#4a4220" : safeCssColor(color);
    const hlHover = isDark ? "#5c532a" : "#ffe08a";
    const hlLine = isDark ? "rgba(255,200,100,.5)" : "rgba(255,180,0,.55)";
    const markBg = isDark ? "rgba(255,90,110,.14)" : "rgba(232,65,92,.10)";
    const markLine = isDark ? "rgba(255,90,110,.85)" : "rgba(232,65,92,.9)";
    return ".wh-highlight{background-color:" + hlBg +
      ";border-radius:2px;cursor:pointer;transition:background-color .12s;}" +
      ".wh-highlight:hover{background-color:" + hlHover + ";}" +
      ".wh-marked{box-shadow:inset 0 -2px 0 " + markLine + ", inset 0 0 0 999px " + markBg + ";}" +
      (underline ? ".wh-highlight{box-shadow:inset 0 -2px 0 " + hlLine + ";}" : "");
  }

  function applyGlobalStyle() {
    if (!STYLE_TAG) {
      STYLE_TAG = document.createElement("style");
      STYLE_TAG.id = "__wh_style__";
      document.documentElement.appendChild(STYLE_TAG);
    }
    STYLE_TAG.textContent = buildHighlightCss(CONFIG.color, !!CONFIG.underline, resolveTheme() === "dark");
  }

  /* 【v2.17.5】YouTube 字幕接管（替代 CSS 改写方案）：
   * 设置开关开启 → YouTube 播放器控制栏（进度条下方右侧）出现插件按钮，
   * 点击接管：隐藏原生字幕窗口（DOM 仍在更新，仅作文本源），
   * 由插件自绘单行字幕条同步展示完整句 —— 完全绕开 YouTube 两行布局与滚动机制 */
  let YT_CAPTION_STYLE_TAG = null;
  const YT_TAKEOVER = { btn: null, bar: null, capObserver: null, playerObserver: null, timer: null, trTimer: null, active: false,
    // 【v2.17.7】逐句模式 cue 引擎（学习 read-frog：timedtext 数据驱动 + 前瞻批量翻译 + 时间轴调度）
    cueEngineOn: false, cueReady: false, cueVid: "", cueSentences: [], cueFlight: false,
    cueVideo: null, cueVideoListener: null, cueNavListener: null, cueRenderKey: "",
    cueRaf: null, cueLastTr: 0,
    // 【v2.17.24】"点了接管没反应"修复：字幕容器懒创建等待 + timedtext 数据重试
    pendingStart: false, pendingTimer: null, cueRetryTimer: null, cueTries: 0, cuePlayListener: null, cueLoading: false };

  function isYtHost() {
    try {
      return /(^|\.)(youtube\.com|youtube-nocookie\.com)$/.test(location.hostname.toLowerCase());
    } catch (e) { return false; }
  }

  function ytTakeoverEnsureStyle() {
    if (!YT_CAPTION_STYLE_TAG) {
      YT_CAPTION_STYLE_TAG = document.createElement("style");
      YT_CAPTION_STYLE_TAG.id = "__wh_yt_singleline__";
      (document.head || document.documentElement).appendChild(YT_CAPTION_STYLE_TAG);
    }
    YT_CAPTION_STYLE_TAG.textContent = [
      // 接管激活：隐藏原生字幕窗口（display:none 不影响 MutationObserver 监听其更新）
      ".wh-yt-takeover .ytp-caption-window-container{display:none !important;}",
      // 控制栏按钮激活态：金色光晕（svg 描边与 img 图标两种形态都覆盖）
      ".ytp-panda-caption.on svg path{stroke:#fbbf24 !important;}",
      ".ytp-panda-caption.on img{filter:drop-shadow(0 0 4px rgba(251,191,36,.95)) brightness(1.1);}",
      // 自绘字幕条：宽度上限为播放器的 88%，最多约 6 行（不缩字号，超出截断避免撑出画面）
      ".wh-yt-caption-bar{position:absolute;left:50%;transform:translateX(-50%);bottom:110px;z-index:60;" +
        "max-width:88%;overflow:hidden;pointer-events:none;color:#fff;background:rgba(8,8,8,.75);padding:4px 14px;" +
        "border-radius:4px;line-height:1.4;font-weight:500;text-shadow:0 1px 2px rgba(0,0,0,.8);display:none;text-align:center;}",
      ".wh-yt-caption-inner{display:block;white-space:normal;max-height:8.4em;overflow:hidden;}",
      // 逐词翻译：词内不换行（词与它的译文保持同框），译文略透明作视觉区分
      ".wh-cap-word{white-space:nowrap;}",
      ".wh-cap-gloss{color:inherit;opacity:.85;margin-left:1px;}",
      // 逐句翻译：英文原句一行，整句译文独立一行（略透明区分）
      ".wh-cap-en{display:block;}",
      ".wh-cap-sent-tr{display:block;margin-top:2px;opacity:.92;}",
      // 播放器控制栏隐藏时（观看中）字幕条下移贴近底部
      ".wh-yt-caption-bar.wh-low{bottom:56px;}"
    ].join("");
  }

  /** 开启接管：隐藏原生字幕、自绘单行字幕条并监听同步 */
  function startYtTakeover() {
    if (!MEM_PRO) return; // 【v2.17.20】PRO 专属功能
    const player = document.querySelector(".html5-video-player");
    if (!player) return; // 播放器尚未就绪（首页/Shorts/未开始播放）→ 由按钮轮询稍后再试
    // 【v2.17.24 字幕延迟/点了没反应修复】必须先确保 CC 已开启：
    // YouTube 只在开启 CC 后才创建 .ytp-caption-window-container，而旧实现要求容器已存在才继续，
    // 于是"未开 CC 时点击接管按钮"直接 return —— 既不自动开 CC、也不显示字幕，
    // 用户看到的就是"有时点了没反应/字幕过一会儿才出来"（概率取决于他此前是否开过 CC）。
    const sub = document.querySelector(".ytp-subtitles-button");
    if (sub && sub.getAttribute("aria-pressed") === "false") {
      try { sub.click(); } catch (e) { /* ignore */ }
    }
    const cap = document.querySelector(".ytp-caption-window-container");
    if (!cap) {
      // 容器是异步创建的：轮询等待最多约 3s（CC 轨道不可用时放弃，避免死循环）
      if (YT_TAKEOVER.pendingStart) return;
      YT_TAKEOVER.pendingStart = true;
      let tries = 0;
      YT_TAKEOVER.pendingTimer = setInterval(() => {
        tries++;
        const c = document.querySelector(".ytp-caption-window-container");
        if (c || tries > 12) {
          clearInterval(YT_TAKEOVER.pendingTimer);
          YT_TAKEOVER.pendingTimer = null;
          YT_TAKEOVER.pendingStart = false;
          if (c && !YT_TAKEOVER.active) startYtTakeover();
        }
      }, 250);
      return;
    }
    YT_TAKEOVER.active = true;
    ytTakeoverEnsureStyle();
    player.classList.add("wh-yt-takeover");
    if (YT_TAKEOVER.btn) YT_TAKEOVER.btn.classList.add("on");
    // 原生字幕的渲染已被隐藏，仅作文本来源；CC 在上方已确保开启
    // 自绘字幕条（挂到播放器上，全屏/窗口均跟随）；内层 span 承载文本，超长时横向滚动
    const bar = document.createElement("div");
    bar.className = "wh-yt-caption-bar notranslate";
    const inner = document.createElement("span");
    inner.className = "wh-yt-caption-inner";
    bar.appendChild(inner);
    player.appendChild(bar);
    YT_TAKEOVER.bar = bar;
    // 单句显示：从累积文本中取出"当前句"——最后一个句末标点之后的未完句；
    // 恰好整句结束时显示最后那个完整句，下一句开始即切换，不会整段越拼越长
    const extractCurrentSentence = (full) => {
      const breaks = [".", "!", "?", ";", "。", "！", "？", "；"];
      let cut = -1;
      for (const ch of breaks) { const i = full.lastIndexOf(ch); if (i > cut) cut = i; }
      let cur = full.slice(cut + 1).trim();
      if (!cur) {
        // 刚结束的整句：取倒数第二个句末标点之后的部分（即最后一句）
        const head = full.slice(0, cut);
        let cut2 = -1;
        for (const ch of breaks) { const i = head.lastIndexOf(ch); if (i > cut2) cut2 = i; }
        cur = head.slice(cut2 + 1).trim();
      } else if (cur.length > 140) {
        // 长时间无句末标点的流式句：退化为按逗号取尾段，避免无限增长
        let c = Math.max(cur.lastIndexOf("，"), cur.lastIndexOf(","));
        if (c > 0 && cur.length - c < 140) cur = cur.slice(c + 1).trim();
      }
      return cur || full;
    };
    /* 【v2.17.6】接管字幕翻译渲染（两种模式，由设置 ytCaptionTrMode 控制）：
     * - word（逐词翻译，默认）：当前句按"原词+译文"渲染（批量翻译单词，trCache 缓存）
     * - sentence（逐句翻译）：英文原句一行 + 下方整句译文一行；句子流式增长期间
     *   防抖 500ms 再请求整句翻译（避免每个词都触发一次请求），
     *   fillTranslations 命中 trCache 的已完成句直接秒出
     * 句子均由 extractCurrentSentence 统一提取——最后一个词永远与原句同框 */
    let lastRendered = "";
    let lastTrState = null;
    let lastCapMode = "";
    const renderSentence = (cur) => {
      const trOn = translateActive();
      const mode = CONFIG.ytCaptionTrMode === "sentence" ? "sentence" : (CONFIG.ytCaptionTrMode === "word2" ? "word2" : "word");
      if (!YT_TAKEOVER.forceRender && cur === lastRendered && trOn === lastTrState && mode === lastCapMode) return;
      YT_TAKEOVER.forceRender = false;
      lastRendered = cur;
      lastTrState = trOn;
      lastCapMode = mode;
      if (YT_TAKEOVER.trTimer) { clearTimeout(YT_TAKEOVER.trTimer); YT_TAKEOVER.trTimer = null; }
      inner.style.transform = "";
      if (!trOn) { inner.textContent = cur; return; }
      if (mode === "sentence" || mode === "word2") {
        // 【v2.17.7/2.17.9】cue 引擎就绪（timedtext 数据驱动）→ DOM 提取路径让位，
        // 显示由 cueTick 按时间轴接管（含前瞻翻译，译文零延迟）；
        // word2 未就绪时与 word 一样走下方 DOM 兜底（逐词渲染复刻）
        if (YT_TAKEOVER.cueReady) return;
        if (mode === "sentence") {
        // DOM 兜底：英文原句（一行）+ 下方译文（一行）
        inner.textContent = "";
        const en = document.createElement("span");
        en.className = "wh-cap-en";
        en.textContent = cur;
        inner.appendChild(en);
        const tr = document.createElement("span");
        tr.className = "wh-cap-sent-tr";
        inner.appendChild(tr);
        // 防抖：句子增长期间不断重置计时，停止增长 250ms 后才请求整句翻译
        // （【v2.17.24】500→250ms：字幕场景下译文出现得越早越好，250ms 仍足以合并连续增量）
        YT_TAKEOVER.trTimer = setTimeout(() => {
          YT_TAKEOVER.trTimer = null;
          if (!tr.isConnected) return; // 期间已被新句替换
          fillTranslations([{ span: tr, text: cur, lang: "en" }]);
        }, 250);
        return;
        }
      }
      // 逐词模式（word；word2 的 cue 未就绪时同样落到此 DOM 渲染）：原词 + 词后跟小译文
      inner.textContent = "";
      const pendings = [];
      for (const tk of (cur.match(/\S+|\s+/g) || [])) {
        if (!/\S/.test(tk)) { inner.appendChild(document.createTextNode(" ")); continue; }
        const w = document.createElement("span");
        w.className = "wh-cap-word";
        w.textContent = tk;
        inner.appendChild(w);
        const core = tk.replace(/^[^A-Za-z0-9'’]+|[^A-Za-z0-9'’]+$/g, "");
        if (!core) continue; // 纯标点/数字 token 不需要译文
        const g = document.createElement("span");
        g.className = "wh-cap-gloss";
        w.appendChild(g);
        pendings.push({ span: g, text: core, lang: "en" });
      }
      if (pendings.length) fillTranslations(pendings);
    };
    // 文本同步：原生字幕 DOM 更新 → 取出当前句展示；超长句在 max-height 内自然折行（约 6 行）
    //（翻译流程已跳过字幕文本节点，s.textContent 读到的就是纯原文，无需额外过滤）
    const sync = () => {
      // 【v2.17.7】逐句/逐词2.0 模式且 cue 数据就绪 → 显示完全由 cueTick 按时间轴管理
      if (YT_TAKEOVER.cueReady && (CONFIG.ytCaptionTrMode === "sentence" || CONFIG.ytCaptionTrMode === "word2")) return;
      const segs = cap.querySelectorAll(".ytp-caption-segment");
      const text = Array.from(segs).map((s) => s.textContent).join(" ").replace(/\s+/g, " ").trim();
      if (text) {
        bar.style.display = "block";
        // 字号跟随播放器缩放：抄原生 segment 的计算字号（仅跟随，不再主动缩放）
        const seg = cap.querySelector(".ytp-caption-segment");
        if (seg) {
          const fs = getComputedStyle(seg).fontSize;
          if (fs) { bar.style.fontSize = fs; inner.style.fontSize = ""; }
        }
        const cur = extractCurrentSentence(text);
        renderSentence(cur);
      } else {
        bar.style.display = "none";
      }
    };
    YT_TAKEOVER.capObserver = new MutationObserver(sync);
    YT_TAKEOVER.capObserver.observe(cap, { childList: true, subtree: true, characterData: true });
    // 控制栏显隐（ytp-autohide）→ 字幕条下移/上移
    YT_TAKEOVER.playerObserver = new MutationObserver(() => {
      bar.classList.toggle("wh-low", player.classList.contains("ytp-autohide"));
    });
    YT_TAKEOVER.playerObserver.observe(player, { attributes: true, attributeFilter: ["class"] });
    YT_TAKEOVER.sync = sync; // 【v2.17.6】设置变更（翻译模式等）时可立即触发重渲染
    sync();
    ensureCueEngine(); // 【v2.17.7】逐句模式 → 启动 cue 引擎（timedtext 数据驱动）
  }

  /** 关闭接管（幂等）：恢复原生字幕、移除自绘字幕条与监听 */
  function stopYtTakeover() {
    YT_TAKEOVER.active = false;
    stopCueEngine(); // 【v2.17.7】
    // 【v2.17.24】取消"等待字幕容器"的轮询（用户可能在等待期间又点了关闭）
    if (YT_TAKEOVER.pendingTimer) { clearInterval(YT_TAKEOVER.pendingTimer); YT_TAKEOVER.pendingTimer = null; }
    YT_TAKEOVER.pendingStart = false;
    if (YT_TAKEOVER.trTimer) { clearTimeout(YT_TAKEOVER.trTimer); YT_TAKEOVER.trTimer = null; }
    YT_TAKEOVER.sync = null;
    if (YT_TAKEOVER.capObserver) { YT_TAKEOVER.capObserver.disconnect(); YT_TAKEOVER.capObserver = null; }
    if (YT_TAKEOVER.playerObserver) { YT_TAKEOVER.playerObserver.disconnect(); YT_TAKEOVER.playerObserver = null; }
    if (YT_TAKEOVER.bar) { YT_TAKEOVER.bar.remove(); YT_TAKEOVER.bar = null; }
    const player = document.querySelector(".html5-video-player");
    if (player) player.classList.remove("wh-yt-takeover");
    if (YT_TAKEOVER.btn) YT_TAKEOVER.btn.classList.remove("on");
  }

  /* ============================================================
   * 【v2.17.7】逐句模式 cue 引擎（学习 read-frog subtitles 模块设计）：
   * 不再从字幕 DOM 猜句子，而是拿到完整字幕数据（timedtext JSON3，带时间轴），
   * 监听 video timeupdate 按时间轴选句显示，并前瞻批量翻译未来 30s 内的句子——
   * 播放到哪句，译文早已就绪（零延迟）。数据拿不到时自动回落 DOM 提取路径。
   *
   * 流程（对照 read-frog）：
   *   拦截 XHR 拿带 pot 的 timedtext URL（yt-timedtext-bridge.js，MAIN world）
   *   → fetch JSON3 → 解析（含滚动 ASR aAppend 累积）→ 切句
   *   → timeupdate/seeked 调度：显示当前句 + 前瞻 [t-2s, t+30s] 未译句
   *   → 每批 ≤5 条并发翻译（单飞锁 + 状态去重，translateSentence 自带 trCache）
   * ============================================================ */
  const CUE_LOOK_AHEAD_MS = 30000; // 前瞻窗口（read-frog 同款 30s）
  const CUE_BEHIND_MS = 2000;      // 回看窗口（当前句稍早开始也纳入）
  const CUE_BATCH_SIZE = 5;        // 每批翻译条数（read-frog 同款 5 条）
  const CUE_LEAD_MS = 120;         // 【v2.17.7a】显示提前量：字幕略先于语音，抵消渲染链路延迟

  /** 向 MAIN world 桥接脚本询问某视频的 timedtext URL（轮询等待 YouTube 发出请求，带超时） */
  function whTttGetUrl(vid, timeoutMs) {
    return new Promise((resolve) => {
      const reqId = "wh" + Date.now() + Math.random().toString(36).slice(2);
      const t0 = Date.now();
      let done = false;
      const finish = (url) => {
        if (done) return;
        done = true;
        window.removeEventListener("message", onMsg);
        clearInterval(timer);
        resolve(url || "");
      };
      const onMsg = (e) => {
        if (e.source !== window) return;
        if (e.origin && e.origin !== location.origin) return;
        const d = e.data;
        if (!d || d.type !== "WH_TTT_RESP" || d.reqId !== reqId) return;
        finish(d.url);
      };
      window.addEventListener("message", onMsg);
      const ask = () => window.postMessage({ type: "WH_TTT_REQ", reqId, videoId: vid }, "*");
      const timer = setInterval(() => {
        if (Date.now() - t0 > (timeoutMs || 10000)) { finish(""); return; }
        ask();
      }, 300);
      ask();
    });
  }

  /** 【v2.17.8】解析 timedtext JSON3 → 句子列表（算法移植 read-frog scrolling-asr-parser，
   *  这是"字幕延迟"的真正修复）：
   *  旧实现把 aAppend 事件当"窗口全量文本"拼接后按字符比例线性分配时间——ASR 窗口
   *  跨 10 秒以上，线性估算与真实语音偏差可达数秒，字幕因此"延迟"。
   *  read-frog 的正确做法：
   *  - aAppend 事件是"分隔符"，不参与文本拼接，只用其时间戳给出上一片段的真实结束时间；
   *  - 文本与时间来自非 aAppend 事件的 segs，每个 seg 带 tOffsetMs（相对事件的词级偏移）
   *    → segStart = event.tStartMs + seg.tOffsetMs，片段 start 为首个非空 seg 的精确时间戳；
   *  - 句末标点（含逗号，read-frog SENTENCE_END_PATTERN）或超 15 词（MAX_WORDS）→ 标记待切，
   *    下一个 seg / 事件 / 分隔符到达时输出片段 → 片段边界与真实语音对齐，无估算漂移 */
  const ASR_WORD_DUR_MS = 200;  // read-frog ESTIMATED_WORD_DURATION_MS：末 seg 无后续锚点时的词时长
  const ASR_MAX_WORDS = 15;     // read-frog MAX_WORDS：片段词数上限

  function parseJson3ToSentences(data) {
    const events = (data && data.events) || [];
    const result = [];
    let currentText = "";
    let currentStart = 0;
    let lastSegEnd = 0;
    let isFirstSeg = true;
    let pendingSplit = false;

    const pushFragment = (frag) => {
      // 修复前一片段 end 避免重叠（read-frog pushFragment）
      const last = result[result.length - 1];
      if (last && last.end > frag.start) last.end = frag.start;
      result.push(frag);
    };
    const flush = () => {
      const trimmed = currentText.replace(/\s+/g, " ").trim();
      if (trimmed && !/^\[.+\]$/.test(trimmed)) {
        pushFragment({ start: currentStart, end: lastSegEnd, text: trimmed, tr: "", state: 0 });
      }
    };

    for (const e of events) {
      // 分隔符事件：更新真实结束时间；若上一片段已到句末 → 输出
      if (e.aAppend === 1) {
        if (currentText) {
          lastSegEnd = (e.tStartMs || 0) + (e.dDurationMs || 0);
          if (pendingSplit) {
            flush();
            currentText = "";
            isFirstSeg = true;
            pendingSplit = false;
          }
        }
        continue;
      }
      if (!e.segs || !e.segs.length) continue;
      // 待切片段 + 新事件到达 → 先输出旧片段
      if (pendingSplit && currentText) {
        flush();
        currentText = "";
        isFirstSeg = true;
        pendingSplit = false;
      }
      const segs = e.segs;
      for (let i = 0; i < segs.length; i++) {
        const seg = segs[i] || {};
        const text = seg.utf8 || "";
        const segStart = (e.tStartMs || 0) + (seg.tOffsetMs || 0);
        // 待切 + 新 seg → 输出旧片段（seg 边界触发切分）
        if (pendingSplit && currentText) {
          flush();
          currentText = "";
          isFirstSeg = true;
          pendingSplit = false;
        }
        if (isFirstSeg && text.trim()) {
          currentStart = segStart; // 片段 start = 首个非空 seg 的精确时间戳
          isFirstSeg = false;
        }
        // 英语跨事件拼接补空格（read-frog isSpaceSeparated）
        if (currentText && text && i === 0 && !currentText.endsWith(" ") && !text.startsWith(" ")) {
          currentText += " ";
        }
        currentText += text;
        // 片段 end：下一个 seg 锚点 / 事件 duration，保底词时长 200ms
        const nextOff = segs[i + 1] && segs[i + 1].tOffsetMs;
        lastSegEnd = (nextOff !== undefined && nextOff !== null)
          ? Math.max(segStart + ASR_WORD_DUR_MS, (e.tStartMs || 0) + nextOff)
          : Math.max(segStart + ASR_WORD_DUR_MS, (e.tStartMs || 0) + (e.dDurationMs || 0));
        // 句末标点（含逗号）或超长 → 标记待切（read-frog SENTENCE_END_PATTERN / MAX_WORDS）
        const isSentenceEnd = /[,._{。?？！!；;…\n]$/.test(text.trim());
        const words = currentText.trim().split(/\s+/).filter(Boolean).length;
        if (isSentenceEnd || words >= ASR_MAX_WORDS) pendingSplit = true;
      }
    }
    flush();
    return result.filter((s) => s.text.length > 1);
  }

  /** 【v2.17.24】cue 数据获取失败后的退避重试：
   *  旧实现只等一次（12s）就永久放弃 → 若 YouTube 那次 timedtext 请求晚了、pot token 过期、
   *  或用户是"先点接管、后开 CC"，本次播放就永远退回 DOM 兜底：字幕只能跟着原生 DOM 更新，
   *  比语音晚 200~500ms（用户看到的"字幕延迟"），而 cue 模式是提前 ~100ms 显示的。
   *  这里按 2s→4s→8s→15s→30s 退避重试（最多 5 次），期间 DOM 兜底照常工作。 */
  const CUE_RETRY_DELAYS = [2000, 4000, 8000, 15000, 30000];
  function cueRetryLater(attempt) {
    if (!YT_TAKEOVER.cueEngineOn || YT_TAKEOVER.cueReady) return;
    if (attempt >= CUE_RETRY_DELAYS.length) return; // 放弃 → DOM 兜底继续
    const delay = CUE_RETRY_DELAYS[Math.min(attempt, CUE_RETRY_DELAYS.length - 1)];
    if (YT_TAKEOVER.cueRetryTimer) clearTimeout(YT_TAKEOVER.cueRetryTimer);
    YT_TAKEOVER.cueRetryTimer = setTimeout(() => {
      YT_TAKEOVER.cueRetryTimer = null;
      if (YT_TAKEOVER.cueEngineOn && !YT_TAKEOVER.cueReady) loadYtCues(attempt + 1);
    }, delay);
  }

  /** 拉取当前视频的字幕数据并切句（SPA 换视频后重调；失败自动退避重试） */
  async function loadYtCues(attempt) {
    const n = attempt || 0;
    if (YT_TAKEOVER.cueLoading) return; // 并发保护：play/导航/退避同时触发时只跑一次
    YT_TAKEOVER.cueLoading = true;
    YT_TAKEOVER.cueReady = false;
    YT_TAKEOVER.cueSentences = [];
    YT_TAKEOVER.cueRenderKey = "";
    let vid = "";
    try { vid = new URLSearchParams(location.search).get("v") || ""; } catch (e) { /* ignore */ }
    if (!vid) { YT_TAKEOVER.cueLoading = false; return; } // 非 watch 页（首页/Shorts）→ 一直走 DOM 兜底
    YT_TAKEOVER.cueVid = vid;
    try {
      // 接管时已自动开启 CC → YouTube 会发出 timedtext 请求 → 桥接脚本捕获 URL
      // 首次等久一点（用户可能刚点开 CC），重试时短一些以免拖长退避周期
      const url = await whTttGetUrl(vid, n === 0 ? 12000 : 6000);
      if (YT_TAKEOVER.cueVid !== vid || !YT_TAKEOVER.cueEngineOn) return;
      if (!url) { cueRetryLater(n); return; } // 这次没抓到 URL → 稍后重试
      let u = url;
      if (!/([?&])fmt=json3/.test(u)) {
        u = /([?&])fmt=\w+/.test(u) ? u.replace(/([?&])fmt=\w+/, "$1fmt=json3") : (u + "&fmt=json3");
      }
      const resp = await fetch(u, { credentials: "include" });
      if (YT_TAKEOVER.cueVid !== vid || !YT_TAKEOVER.cueEngineOn) return;
      if (!resp.ok) {
        // pot token 过期/403：让桥接丢弃这条 URL，重试时等播放器发出新请求（退避重试兜住）
        try { window.postMessage({ type: "WH_TTT_DROP", videoId: vid }, "*"); } catch (e) { /* ignore */ }
        cueRetryLater(n);
        return;
      }
      const data = await resp.json();
      const sents = parseJson3ToSentences(data);
      if (YT_TAKEOVER.cueVid !== vid || !YT_TAKEOVER.cueEngineOn) return;
      if (!sents.length) { cueRetryLater(n); return; } // 空数据（轨道还没准备好）→ 重试
      YT_TAKEOVER.cueSentences = sents;
      YT_TAKEOVER.cueReady = true;
      YT_TAKEOVER.cueTries = 0;
      if (YT_TAKEOVER.cueRetryTimer) { clearTimeout(YT_TAKEOVER.cueRetryTimer); YT_TAKEOVER.cueRetryTimer = null; }
      cueRenderCurrent(); // 立即渲染当前时间句
      cueTranslateNearby(); // 立即开译
    } catch (e) {
      cueRetryLater(n); // 拿不到数据 → 稍后重试（DOM 兜底继续工作）
    } finally {
      YT_TAKEOVER.cueLoading = false;
    }
  }

  /** 按时间轴渲染当前句。sentence：原文行+译文行；word2：原词+词后小译文（逐词效果） */
  function cueRenderCurrent(leadMs) {
    if (!YT_TAKEOVER.cueReady || !YT_TAKEOVER.bar) return;
    const bar = YT_TAKEOVER.bar;
    const inner = bar.firstChild;
    const player = document.querySelector(".html5-video-player");
    const video = player ? player.querySelector("video") : null;
    if (!inner || !video) return;
    // 【v2.17.7a】leadMs：显示提前量补偿（timeupdate 250ms 粒度 + 字幕通常略先于语音）
    const t = video.currentTime * 1000 + (leadMs || 0);
    const sents = YT_TAKEOVER.cueSentences;
    const word2 = CONFIG.ytCaptionTrMode === "word2";
    let idx = -1;
    for (let i = 0; i < sents.length; i++) {
      if (sents[i].start <= t) idx = i; else break;
    }
    if (idx < 0) { bar.style.display = "none"; return; } // 字幕间隙（开场前）
    const s = sents[idx];
    // 句尾超时 1.5s（间隙/结尾）→ 隐藏，避免上一句一直挂在屏幕上
    if (s.end && t > s.end + 1500) { bar.style.display = "none"; return; }
    const key = (word2 ? "w2:" : "") + idx + "|" + s.state + "|" + s.tr;
    if (key === YT_TAKEOVER.cueRenderKey && bar.style.display === "block") return;
    YT_TAKEOVER.cueRenderKey = key;
    bar.style.display = "block";
    // 字号跟随播放器缩放（与 DOM 路径一致：抄原生 segment 计算字号）
    const cap = document.querySelector(".ytp-caption-window-container");
    const seg = cap && cap.querySelector(".ytp-caption-segment");
    if (seg) {
      const fs = getComputedStyle(seg).fontSize;
      if (fs) bar.style.fontSize = fs;
    }
    inner.textContent = "";
    if (word2) {
      // 【v2.17.9】逐词 2.0：cue 时间轴 + 原词/小译文渲染；词译文经 cueTranslateNearby
      // 预热进 trCache，fillTranslations 命中即秒填，未命中的词走批量请求
      const pendings = [];
      for (const tk of (s.text.match(/\S+|\s+/g) || [])) {
        if (!/\S/.test(tk)) { inner.appendChild(document.createTextNode(" ")); continue; }
        const w = document.createElement("span");
        w.className = "wh-cap-word";
        w.textContent = tk;
        inner.appendChild(w);
        const core = tk.replace(/^[^A-Za-z0-9'’]+|[^A-Za-z0-9'’]+$/g, "");
        if (!core) continue; // 纯标点不译
        const g = document.createElement("span");
        g.className = "wh-cap-gloss";
        w.appendChild(g);
        pendings.push({ span: g, text: core, lang: "en" });
      }
      if (pendings.length) fillTranslations(pendings);
      return;
    }
    const en = document.createElement("span");
    en.className = "wh-cap-en";
    en.textContent = s.text;
    inner.appendChild(en);
    const tr = document.createElement("span");
    tr.className = "wh-cap-sent-tr";
    tr.textContent = s.state === 2 ? s.tr : (s.state === 1 ? "…" : "");
    inner.appendChild(tr);
  }

  /** 前瞻批量翻译（学习 read-frog TranslationCoordinator）：
   *  取 [t-2s, t+30s] 内未翻译句，每批 ≤5 条并发；单飞锁防堆积；
   *  完成后链式续批 + 刷新当前句显示（译文往往在句子播出前就已就绪） */
  async function cueTranslateNearby() {
    if (!YT_TAKEOVER.cueReady || YT_TAKEOVER.cueFlight || !translateActive()) return;
    const player = document.querySelector(".html5-video-player");
    const video = player ? player.querySelector("video") : null;
    if (!video) return;
    const t = video.currentTime * 1000;
    const sents = YT_TAKEOVER.cueSentences;
    const batch = [];
    for (let i = 0; i < sents.length; i++) {
      const s = sents[i];
      if (s.state !== 0) continue; // 1 翻译中 / 2 完成 / 3 失败（本会话跳过）
      if (s.start < t - CUE_BEHIND_MS) continue;
      if (s.start > t + CUE_LOOK_AHEAD_MS) break;
      batch.push(i);
      if (batch.length >= CUE_BATCH_SIZE) break;
    }
    if (!batch.length) return;
    YT_TAKEOVER.cueFlight = true;
    batch.forEach((i) => { sents[i].state = 1; });
    cueRenderCurrent(CUE_LEAD_MS); // 立刻显示 … 占位
    try {
      if (CONFIG.ytCaptionTrMode === "word2") {
        // 【v2.17.9】逐词 2.0：预热片段内所有词的译文（写 trCache，渲染时秒出）；
        // 每批 ≤5 片段的词去重后并发，translateSentence 自带缓存与超时
        const cores = new Set();
        for (const i of batch) {
          for (const tk of (sents[i].text.match(/\S+/g) || [])) {
            const core = tk.replace(/^[^A-Za-z0-9'’]+|[^A-Za-z0-9'’]+$/g, "");
            if (core) cores.add(core);
          }
        }
        await Promise.all([...cores].map(async (w) => {
          try { await translateSentence(w, "en"); } catch (e) { /* ignore */ }
        }));
        batch.forEach((i) => { sents[i].state = 2; }); // 片段词已预热（渲染不依赖 s.tr）
      } else await Promise.all(batch.map(async (i) => {
        const s = sents[i];
        try {
          const r = await translateSentence(s.text, "en");
          if (r && r.ok) { s.tr = r.text; s.state = 2; } else { s.state = 3; }
        } catch (e) { s.state = 3; }
      }));
    } finally {
      YT_TAKEOVER.cueFlight = false;
      if (YT_TAKEOVER.cueEngineOn && YT_TAKEOVER.cueReady) {
        cueRenderCurrent(CUE_LEAD_MS);  // 当前句译文刚到 → 刷新
        cueTranslateNearby(); // 链式续批
      }
    }
  }

  /** cue 引擎调度入口（seeked / 导航触发；常规刷新由 rAF 循环负责） */
  function cueTick() {
    if (!YT_TAKEOVER.cueEngineOn) return;
    if (YT_TAKEOVER.cueReady) {
      cueRenderCurrent(CUE_LEAD_MS);
      cueTranslateNearby();
    }
  }

  /** 启动 cue 引擎（接管激活 + 逐句模式） */
  function startCueEngine() {
    if (YT_TAKEOVER.cueEngineOn) return;
    YT_TAKEOVER.cueEngineOn = true;
    const bindVideo = () => {
      const player = document.querySelector(".html5-video-player");
      const video = player ? player.querySelector("video") : null;
      if (!video || video === YT_TAKEOVER.cueVideo) return;
      if (YT_TAKEOVER.cueVideo && YT_TAKEOVER.cueVideoListener) {
        YT_TAKEOVER.cueVideo.removeEventListener("seeked", YT_TAKEOVER.cueVideoListener);
      }
      YT_TAKEOVER.cueVideo = video;
      YT_TAKEOVER.cueVideoListener = cueTick;
      video.addEventListener("seeked", cueTick);
    };
    bindVideo();
    // 【v2.17.7a】rAF 逐帧调度替代 timeupdate（后者 ~250ms 一 tick，句切换可感知滞后）：
    // 播放中每帧按 currentTime 渲染（提前量 CUE_LEAD_MS），翻译前瞻扫描节流 200ms；
    // 暂停/后台标签页 rAF 自动停发，恢复时 cueTick(seeked) 兜底刷新
    const loop = () => {
      if (!YT_TAKEOVER.cueEngineOn) { YT_TAKEOVER.cueRaf = null; return; }
      const v = YT_TAKEOVER.cueVideo;
      if (YT_TAKEOVER.cueReady && v) {
        if (!v.paused && !v.ended) cueRenderCurrent(CUE_LEAD_MS);
        const now = Date.now();
        if (now - (YT_TAKEOVER.cueLastTr || 0) > 200) {
          YT_TAKEOVER.cueLastTr = now;
          cueTranslateNearby();
        }
      }
      YT_TAKEOVER.cueRaf = requestAnimationFrame(loop);
    };
    YT_TAKEOVER.cueRaf = requestAnimationFrame(loop);
    // 【v2.17.24】用户重新开播 / 拖动进度 → 若 cue 数据仍未就绪，立刻再试一次
    // （真实场景：先点接管（CC 刚被打开，timedtext 请求还没发出）、或长时间暂停后恢复）
    YT_TAKEOVER.cuePlayListener = () => {
      if (!YT_TAKEOVER.cueEngineOn || YT_TAKEOVER.cueReady) return;
      if (YT_TAKEOVER.cueRetryTimer) return; // 已有退避计划，交给它
      loadYtCues(1);
    };
    const v0 = YT_TAKEOVER.cueVideo;
    if (v0) { v0.addEventListener("play", YT_TAKEOVER.cuePlayListener); v0.addEventListener("playing", YT_TAKEOVER.cuePlayListener); }
    // SPA 导航（换视频）：重绑 video（可能被替换）+ 重载字幕数据
    YT_TAKEOVER.cueNavListener = () => {
      if (!YT_TAKEOVER.cueEngineOn) return;
      setTimeout(() => { // 导航完成后播放器才就绪（read-frog 同样有 1s 延迟）
        bindVideo();
        const v1 = YT_TAKEOVER.cueVideo;
        if (v1 && YT_TAKEOVER.cuePlayListener) {
          v1.addEventListener("play", YT_TAKEOVER.cuePlayListener);
          v1.addEventListener("playing", YT_TAKEOVER.cuePlayListener);
        }
        loadYtCues();
      }, 1000);
    };
    document.addEventListener("yt-navigate-finish", YT_TAKEOVER.cueNavListener);
    loadYtCues();
  }

  /** 停止 cue 引擎（关闭接管 / 切到逐词模式） */
  function stopCueEngine() {
    YT_TAKEOVER.cueEngineOn = false;
    YT_TAKEOVER.cueReady = false;
    YT_TAKEOVER.cueSentences = [];
    YT_TAKEOVER.cueFlight = false;
    YT_TAKEOVER.cueRenderKey = "";
    YT_TAKEOVER.cueTries = 0;
    YT_TAKEOVER.cueLoading = false;
    if (YT_TAKEOVER.cueRetryTimer) { clearTimeout(YT_TAKEOVER.cueRetryTimer); YT_TAKEOVER.cueRetryTimer = null; }
    if (YT_TAKEOVER.cueVideo && YT_TAKEOVER.cuePlayListener) {
      YT_TAKEOVER.cueVideo.removeEventListener("play", YT_TAKEOVER.cuePlayListener);
      YT_TAKEOVER.cueVideo.removeEventListener("playing", YT_TAKEOVER.cuePlayListener);
    }
    YT_TAKEOVER.cuePlayListener = null;
    if (YT_TAKEOVER.cueRaf) { cancelAnimationFrame(YT_TAKEOVER.cueRaf); YT_TAKEOVER.cueRaf = null; }
    if (YT_TAKEOVER.cueVideo && YT_TAKEOVER.cueVideoListener) {
      YT_TAKEOVER.cueVideo.removeEventListener("seeked", YT_TAKEOVER.cueVideoListener);
    }
    YT_TAKEOVER.cueVideo = null;
    YT_TAKEOVER.cueVideoListener = null;
    if (YT_TAKEOVER.cueNavListener) {
      document.removeEventListener("yt-navigate-finish", YT_TAKEOVER.cueNavListener);
      YT_TAKEOVER.cueNavListener = null;
    }
  }

  /** 按当前模式维护 cue 引擎（接管激活 + sentence/word2 模式时启动） */
  function ensureCueEngine() {
    const want = YT_TAKEOVER.active && (CONFIG.ytCaptionTrMode === "sentence" || CONFIG.ytCaptionTrMode === "word2");
    if (want && !YT_TAKEOVER.cueEngineOn) startCueEngine();
    if (!want && YT_TAKEOVER.cueEngineOn) {
      stopCueEngine();
      // 切回逐词/关闭翻译 → 恢复 DOM 路径渲染
      if (YT_TAKEOVER.active && YT_TAKEOVER.sync) { YT_TAKEOVER.forceRender = true; YT_TAKEOVER.sync(); }
    }
  }

  /** 按设置开关维护接管按钮（YouTube 页面 + 开关开启 + PRO 时，控制栏常驻插件按钮；SPA 导航/重建后自动补插） */
  function ensureYtTakeover() {
    const want = !!CONFIG.enabled && !!CONFIG.ytCaptionSingleLine && isYtHost() && MEM_PRO;
    if (!want) {
      stopYtTakeover();
      if (YT_TAKEOVER.timer) { clearInterval(YT_TAKEOVER.timer); YT_TAKEOVER.timer = null; }
      if (YT_TAKEOVER.btn) { YT_TAKEOVER.btn.remove(); YT_TAKEOVER.btn = null; }
      if (YT_CAPTION_STYLE_TAG) { YT_CAPTION_STYLE_TAG.remove(); YT_CAPTION_STYLE_TAG = null; }
      return;
    }
    if (YT_TAKEOVER.timer) return;
    YT_TAKEOVER.timer = setInterval(() => {
      if (document.querySelector(".ytp-panda-caption")) return;
      const rc = document.querySelector(".ytp-right-controls");
      if (!rc) return;
      const b = document.createElement("button");
      b.className = "ytp-button ytp-panda-caption" + (YT_TAKEOVER.active ? " on" : "");
      b.title = "Panda 字幕接管：单行显示（点击开启/关闭）";
      // 【v2.17.9】按钮用插件自身图标（web_accessible_resources 已放行 icons/*）
      const iconUrl = (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL)
        ? chrome.runtime.getURL("icons/icon48.png") : "";
      b.innerHTML = iconUrl
        ? '<img src="' + iconUrl + '" alt="Panda" style="width:26px;height:26px;display:block;margin:11px auto 0;pointer-events:none;">'
        : '<svg height="100%" viewBox="0 0 36 36" width="100%"><path d="M10 12h16v12H10z" fill="none" stroke="#fff" stroke-width="2"/><path d="M14 17h8M14 20h5" fill="none" stroke="#fff" stroke-width="2"/></svg>';
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        if (YT_TAKEOVER.active) stopYtTakeover(); else startYtTakeover();
      });
      rc.insertBefore(b, rc.firstChild);
      YT_TAKEOVER.btn = b;
    }, 1500);
  }

  /* ============================================================
   * 六、主题
   * ============================================================ */
  function resolveTheme() {
    if (CONFIG.theme === "dark") return "dark";
    if (CONFIG.theme === "light") return "light";
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) return "dark";
    return "light";
  }
  function applyTheme() {
    document.documentElement.setAttribute("data-wh-theme", resolveTheme());
  }

  /* ============================================================
   * 七、扫描与高亮
   * ============================================================ */
  function extractContext(text, idx) {
    const seps = [".", "!", "?", "\n", "。", "！", "？"];
    let start = 0;
    for (const s of seps) {
      const i = text.lastIndexOf(s, idx);
      if (i > start) start = i + 1;
    }
    let end = text.length;
    for (const s of seps) {
      const i = text.indexOf(s, idx);
      if (i >= 0 && i < end) end = i + 1;
    }
    let ctx = text.slice(start, end).replace(/\s+/g, " ").trim();
    if (ctx.length > 130) {
      const keep = Math.max(0, Math.floor(ctx.length / 2) - 60);
      ctx = ctx.slice(0, 60) + " …… " + ctx.slice(keep, keep + 60);
    }
    return ctx;
  }

  function highlightNode(node) {
    if (!node || node.nodeType !== Node.TEXT_NODE) return;
    const text = node.nodeValue;
    if (!text || !/[A-Za-z]/.test(text)) return;
    const parent = node.parentElement;
    if (!parent) return;
    if (parent.classList && (parent.classList.contains("wh-highlight") || parent.classList.contains("wh-marked"))) return;
    if (isIgnoredElement(parent)) return;
    // 【v2.18.4】译文 span 内部不得高亮：那是我们追加的译文，拆分它会产生空高亮/错位
    if (parent.closest && parent.closest(".wh-tr")) return;
    // 【v2.18.3 兼容模式】框架挂载点（React/Vue/Next/Nuxt）内跳过高亮：
    //  高亮必须把文本节点拆成 [文本][span][文本]（本质是替换），框架随后卸载该节点时会抛
    //  "Failed to execute 'removeChild' on 'Node'" 并可能整页报错；
    //  翻译是纯追加（安全），词典/生词本/发音也不受影响。
    //  触发条件：用户开启兼容模式，或当前站点在已知脆弱名单（COMPAT_HOSTS）里。
    if ((CONFIG.compatMode || onCompatHost()) && isFrameworkNode(parent)) return;
    // 【v2.17.6】YouTube 字幕节点不高亮（原生字幕保持纯净文本源；逐词译文由接管条渲染）
    if (isInsideYtCaption(parent)) return;

    WORD_RE.lastIndex = 0;
    let m, lastIdx = 0;
    const frag = document.createDocumentFragment();
    let changed = false;
    while ((m = WORD_RE.exec(text)) !== null) {
      if (!isWord(m[0])) continue;
      const idx = m.index;
      if (idx > lastIdx) frag.appendChild(document.createTextNode(text.slice(lastIdx, idx)));
      const span = document.createElement("span");
      span.className = "wh-highlight";
      const lower = cleanWord(m[0]);
      span.setAttribute("data-wh-word", lower);
      span.setAttribute("data-wh-ctx", extractContext(text, idx));
      span.textContent = m[0];
      if (currentWordbookSet.has(lower)) span.classList.add("wh-marked");
      frag.appendChild(span);
      lastIdx = idx + m[0].length;
      changed = true;
    }
    if (changed) {
      if (lastIdx < text.length) frag.appendChild(document.createTextNode(text.slice(lastIdx)));
      parent.replaceChild(frag, node);
    }
  }

  function createTextWalker(root) {
    return document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        const p = n.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        if (p.classList && (p.classList.contains("wh-highlight") || p.classList.contains("wh-marked"))) return NodeFilter.FILTER_REJECT;
        // 【v2.17.5c】YouTube 字幕由接管条自渲染，避免被翻译/高亮/生词覆盖原文
        if (isInsideYtCaption(p)) return NodeFilter.FILTER_REJECT;
        if (isIgnoredElement(p)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
  }

  /* 【v2.17.5c】判断元素是否位于 YouTube 字幕节点（.ytp-caption-segment）内，
   * 用于翻译/高亮/生词本等流程统一跳过字幕文本节点，避免污染接管条的文本来源 */
  function isInsideYtCaption(el) {
    if (!el || !el.closest) return false;
    return !!el.closest(".ytp-caption-segment");
  }

  function scan(root) {
    if (!CONFIG.enabled || !root || !MEM_PRO) return;
    const nodes = [];
    const walker = createTextWalker(root);
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const n of nodes) highlightNode(n);
  }

  /** 【v2.17.13 取消高亮误译修复】取消单个高亮：裸文本替换后手动合并相邻文本节点
   *  （等价 normalize，但能拿到合并后的存活节点）。合并避免原句碎片化——碎片会被
   *  MutationObserver 当独立句子走逐句 fallback 逐词翻译（"Btw"→"增值税"、"Stand"→
   *  "布斯"等错译）。若该句已有对应译文（.wh-tr 的 src 与合并文本全等/双向包含），
   *  把存活节点标记为已翻译，防止 observer/补漏重扫对取消高亮产生的裸文本重译。 */
  function unhighlightSpan(span) {
    const parent = span.parentNode;
    if (!parent) return;
    // 【v2.17.14】还原前解码实体（页面翻译回写可能已把 span 文本中的撇号写成 &#39;）
    const txt = document.createTextNode(decodeEnt(span.textContent));
    parent.replaceChild(txt, span);
    let first = txt;
    while (first.previousSibling && first.previousSibling.nodeType === Node.TEXT_NODE) first = first.previousSibling;
    const parts = [];
    for (let n = first; n && n.nodeType === Node.TEXT_NODE; n = n.nextSibling) parts.push(n);
    if (parts.length > 1) {
      first.nodeValue = parts.map((p) => p.nodeValue || "").join("");
      for (let i = 1; i < parts.length; i++) parent.removeChild(parts[i]);
    }
    try {
      if (first.nodeValue && first.isConnected && hasDupTranslation(first, first.nodeValue)) {
        translatedNodes.add(first);
      }
    } catch (e) { /* ignore */ }
  }

  function unhighlightAll() {
    document.querySelectorAll(".wh-highlight, .wh-marked").forEach(unhighlightSpan);
  }

  /** 【v2.18.4】只就地更新"已收录生词"标记（.wh-marked），不改动 DOM 结构。
   *  用于翻译进行中的场景：此时重扫会拆分"原文 + 译文"混排的文本节点，产生空高亮块。 */
  function markWordbookOnPage() {
    document.querySelectorAll(".wh-highlight[data-wh-word]").forEach((span) => {
      const w = span.getAttribute("data-wh-word") || "";
      span.classList.toggle("wh-marked", currentWordbookSet.has(w) && !KNOWN_WORDS.has(w));
    });
  }

  /* ============================================================
   * 八、网页翻译（句子级，手动开启后全程自动）
   * ============================================================ */
  const trCache = new Map();
  const TR_QUEUE_MAX = 240;
  let translatedNodes = new WeakSet(); // 已翻译处理的文本节点（防重复翻译）
  const translatedBlocks = new Set();  // 已做块级合并翻译的整段文本（防同一段被再次翻译）
  /** 合并翻译失败过的容器（WeakSet：元素/容器 → 合并译文重试耗尽仍失败）。
   *  对照式的块级/跨节点合并会把标题+段落+按钮等多个 UI 元素消费成一个翻译单元并全部标记，
   *  合并译文一旦持续失败，补漏重扫又走同样合并 → 整组永久漏译（覆盖式逐节点翻译则全部成功）。
   *  标记后这些容器跳过合并、退回逐节点翻译（对齐 read-frog "每个元素独立翻译单元"）。 */
  let mergeFailedBlocks = new WeakSet();

  /** 检测页面背景明暗（采样 body→html 背景色亮度），深色页面时译文用浅色字 */
  function detectPageDark() {
    let el = document.body;
    let bg = "";
    while (el) {
      const cs = getComputedStyle(el).backgroundColor;
      if (cs && cs !== "rgba(0, 0, 0, 0)" && cs !== "transparent") { bg = cs; break; }
      el = el.parentElement;
    }
    if (!bg || bg === "rgba(0, 0, 0, 0)" || bg === "transparent") bg = getComputedStyle(document.documentElement).backgroundColor;
    const m = bg.match(/\d+(\.\d+)?/g);
    if (m && m.length >= 3) {
      const lum = 0.299 * +m[0] + 0.587 * +m[1] + 0.114 * +m[2];
      return lum < 128;
    }
    return false;
  }
  function applyPageDark() {
    try {
      document.documentElement.dataset.whPage = detectPageDark() ? "dark" : "light";
    } catch (e) { /* ignore */ }
  }

  /** 简单语言检测：日/韩/俄/阿拉伯/其他非 ASCII（重音拉丁等）/auto（emoji、汉字、全角符号不计）。
   *  学习 read-frog：能可靠判定的语种显式传码（Edge/MyMemory 免检测），拉丁语系交给服务端 auto——
   *  实测 Edge/MyMemory 在 from=en 时会把葡语等无变音符拉丁语原样返回（"返回原文"→判定失败→漏译） */
  function detectLang(text) {
    if (/[\u3040-\u30ff]/.test(text)) return "ja";
    if (/[\uac00-\ud7af]/.test(text)) return "ko";
    if (/[\u0400-\u04ff]/.test(text)) return "ru";
    if (/[\u0600-\u06ff]/.test(text)) return "ar";
    const noCjk = text.replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2190}-\u{21FF}\u{FE0F}\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]/gu, "");
    if (/[^\x00-\x7F]/.test(noCjk)) return "auto";
    // 纯 ASCII 拉丁文本无法本地区分英语/印尼语/西语/法语等 → 交服务端自动检测
    // （曾固定返回 en，导致印尼语/西语等评论被当英语翻译 → 返回原文/漏译）
    return "auto";
  }

  /** 从文本中提取外语句子（≥2 个英文单词或含非拉丁字母；含汉字比例高则视为中文跳过）；
   *  句子含句末标点以便判断完整性；每句附带语言；
   *  trans 为"用于翻译请求的文本"（混合中文时截断中文，译文不含中文） */
  function extractSentences(text) {
    const out = [];
    // 句中紧跟字母/数字的点不视为句末（Node.js / nodejs.org / v20.1.0 / e5.example 等），
    // 否则 "Get Node.js®" 会被切成 "Get Node." + "js®" 两段分别翻译 → "获取Node。js®"
    // 起始字符含全语种（学习 read-frog 全语种支持）：拉丁变音符/希腊/西里尔/希伯来/阿拉伯/泰文/日韩/汉字——
    // 汉字起始修复日语句首为汉字时被截断（"日本語のテスト" 曾只从 "の" 开始匹配）；
    // 纯中文由后续"截断中文"规则排除（zhIdx=0 → trans 为空 → 跳过）
    const re = /[A-Za-zÀ-ÖØ-öø-ÿ\u0370-\u03ff\u0400-\u04ff\u0590-\u05ff\u0600-\u06ff\u0e00-\u0e7f\u3040-\u30ff\uac00-\ud7af\u4e00-\u9fff](?:[^.!?。！？\n]|\.(?=[A-Za-z0-9]))*[.!?。！？]?\s*/g;
    let m;
    while ((m = re.exec(text))) {
      const seg = m[0];
      let trimmed = seg.trim();
      if (!trimmed) continue;
      const words = trimmed.match(/[A-Za-z]+/g) || [];
      const nonLatin = /[\u3040-\u30ff\uac00-\ud7af\u0400-\u04ff]/.test(trimmed);
      const noEmoji = trimmed.replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2190}-\u{21FF}\u{FE0F}]/gu, "");
      const nonAscii = /[^\x00-\x7F]/.test(noEmoji);
      if ((words.length >= 1 || nonLatin || nonAscii) && trimmed.length >= 2) {
        const alphaLen = trimmed.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ ]/g, "").length;
        const ratio = alphaLen / Math.max(1, trimmed.length);
        if (ratio > 0.3 || nonLatin || nonAscii) {
          // 翻译请求文本：混合中文时截断中文部分（译文不包含中文；日文/韩文含汉字不受此限）
          const hasJpKo = /[\u3040-\u30ff\uac00-\ud7af]/.test(trimmed);
          const zhIdx = hasJpKo ? -1 : trimmed.search(/[\u4e00-\u9fff]/);
          const trans = zhIdx >= 0 ? trimmed.slice(0, zhIdx).trim() : trimmed;
          if (zhIdx >= 0 && trans.length < 6) continue; // 混合中文截断后英文过短 → 中文主体，不翻译
          let lang = detectLang(trimmed);
          // 【v2.17.13】单个纯 ASCII 拉丁词强制按英语送检：单词级文本交服务端 auto
          // 检测极易误判语种（"Btw"→荷兰语"增值税"、"Stand"→德语），错译比漏译更糟
          if (lang === "auto" && !nonAscii && words.length === 1) lang = "en";
          out.push({ text: trimmed, trans, start: m.index, end: m.index + seg.length, lang });
        }
      }
    }
    return out;
  }

  /* 跨节点合并所需：块级容器与需跳过的元素 */
  const BLOCK_TAGS = new Set(["DIV","P","LI","UL","OL","H1","H2","H3","H4","H5","H6","TD","TH","BLOCKQUOTE","SECTION","HEADER","FOOTER","ARTICLE","PRE","TABLE","TR","FIGURE","FIGCAPTION","FORM","NAV","MAIN","ASIDE"]);
  const TR_SKIP_TAGS = new Set(["SCRIPT","STYLE","NOSCRIPT","SVG","IFRAME","TEXTAREA","INPUT","SELECT","OPTION","CODE","PRE","KBD","SAMP","MATH","CANVAS","EMBED","OBJECT"]);
  /** 【v2.17.22 整段翻译修复】语义段落单元：P/标题/列表项/引用/单元格本身就是"一个翻译单元"，
   *  段内被 <code>/<a>/<em> 等内联元素切成多少个文本节点都必须整段合并翻译。
   *  旧实现用"文本节点数 ≤6 才合并"的评论容器规则判断所有块 → nodejs.org 这种内联 <code>
   *  密集的文档段落（9 个文本节点）永远不合并 → 逐片段送翻译，机上翻译器对"半句"会截断
   *  （" statement is the string after the " → "语句是"、"expression." → "表情。"），
   *  页面渲染成"英文-中文-英文-中文"交错混排（格式错乱 + 大面积漏译）。 */
  const SEMANTIC_BLOCK_TAGS = new Set(["P","H1","H2","H3","H4","H5","H6","LI","BLOCKQUOTE","FIGCAPTION","TD","TH","DD","DT","CAPTION","SUMMARY"]);
  /** 内联代码类元素：其文本是句子的上下文（参与整段翻译请求），但不作为独立翻译单元 */
  const INLINE_CODE_TAGS = new Set(["CODE","KBD","SAMP","VAR","TT"]);
  /** 硬跳过元素：内容永远不属于句子（代码块/脚本/矢量图/表单控件），必须作为合并边界 */
  const HARD_SKIP_TAGS = new Set(["PRE","SCRIPT","STYLE","NOSCRIPT","TEXTAREA","SELECT","OPTION","INPUT","SVG","MATH","CANVAS","IFRAME","EMBED","OBJECT","VIDEO","AUDIO","TEMPLATE","MAP"]);
  /** 硬跳过元素的祖先查询（用于判断内联代码是否位于代码块内） */
  const HARD_SKIP_SELECTOR = "pre,script,style,noscript,textarea,select,option,svg,math,canvas,iframe,embed,object,head";
  /** 【v2.9.3 学习 read-frog】块级判定 = 标签 + computed display（不只看标签名）：
   *  侧栏项 <a>/<div> 行是 CSS display:block/flex，必须按渲染特征断开合并，
   *  否则多个导航项被并成一个翻译单元（display 结果缓存，避免频繁重排计算） */
  let blockDisplayCache = new WeakSet();
  let inlineDisplayCache = new WeakSet();
  function isBlockEl(el) {
    if (!el || el.nodeType !== 1) return false;
    // 【v2.17.22】不再把"忽略元素"一律当块级：内联 <code>/<kbd>/<samp>/<span class=notranslate>
    // 曾被 isIgnoredElement 判定为块 → 段落"含块级子元素"→ 整段合并被否决、跨节点合并也在此断开
    // → 每段碎成多个翻译单元（nodejs.org 文档页面的交错混排根因）。
    // 只有真正的块级非文本内容（pre/script/svg/表单控件等）才是合并边界。
    if (BLOCK_TAGS.has(el.tagName) || HARD_SKIP_TAGS.has(el.tagName)) return true;
    if (inlineDisplayCache.has(el)) return false;
    if (blockDisplayCache.has(el)) return true;
    let disp = "";
    try { disp = getComputedStyle(el).display; } catch (e) { disp = ""; }
    // 【v2.9.7 对齐 read-frog isInlineDisplay】所有 inline 前缀 display（inline-block/
    // inline-flex/inline-grid）都算内联、不破坏段落——TikTok 等评论区 emoji 是
    // display:inline-block 的 span/img，旧判定把它们当块级 → 评论正文被 v2.9.3
    // 段落不变量（含块级子元素不得整块合并）拒绝 → 多句评论退回逐句翻译（原句被拆）。
    // read-frog: normalizedDisplay.startsWith("inline") → inline
    const blockish = !!disp && !disp.startsWith("inline") && disp !== "contents";
    if (blockish) blockDisplayCache.add(el); else inlineDisplayCache.add(el);
    return blockish;
  }
  /** 【v2.17.22】内联代码元素（<code>/<kbd>/<samp>… 且不在代码块内）：
   *  其文本参与整段翻译请求，但不单独翻译、也不切断句子 */
  function isInlineCodeEl(el) {
    if (!el || el.nodeType !== 1 || !INLINE_CODE_TAGS.has(el.tagName)) return false;
    if (el.closest && el.closest(HARD_SKIP_SELECTOR)) return false;
    return !isBlockEl(el);
  }
  /** 【v2.17.22】可并入"整段翻译请求文本"的内联忽略元素文本节点：
   *  内联 <code>/<kbd> 与 notranslate 内联标记（如 <span class="notranslate">Node.js</span>）。
   *  它们本身不翻译（DOM 保留原文），但缺失会让机翻拿到残句 → 译文大幅缩水/漏译。 */
  function isMergeContextText(t) {
    const p = t && t.parentElement;
    if (!p || !isIgnoredElement(p)) return false;
    if (p.closest && p.closest(".wh-tr")) return false; // 自家译文 span 不参与
    if (isInlineCodeEl(p)) return true;
    if (p.closest && p.closest(HARD_SKIP_SELECTOR)) return false;
    if (p.isContentEditable) return false;
    if (isIconFontElement(p)) return false;
    return !isBlockEl(p); // 只吸收内联呈现的部分
  }
  /** 【v2.9.3 read-frog 不变量】容器含任何块级子元素 → 不是真正的"段落单元"，
   *  不得整块合并（translateWalkedElement 的 hasBlockNodeChild 分支）——
   *  卡片(标题+段落+按钮)、侧栏(多个导航项)等容器各自子元素独立翻译，杜绝合并消费漏译 */
  function hasBlockElementChild(el) {
    for (const c of el.children) {
      if (isBlockEl(c)) return true;
    }
    return false;
  }

  /** 找到最近的块级祖先容器 */
  function findBlockRoot(node) {
    let el = node.parentElement;
    while (el && el !== document.body) {
      if (BLOCK_TAGS.has(el.tagName)) return el;
      el = el.parentElement;
    }
    return null;
  }

  /** 拼接合并文本：相邻词字符之间补空格（多行评论拼接时防止单词粘连） */
  function joinMergeTexts(list) {
    let s = "";
    for (const t of list) {
      const v = t.nodeValue || "";
      if (s && /\w$/.test(s) && /^\w/.test(v)) s += " ";
      s += v;
    }
    return s;
  }

  /** 收集块容器内所有文本节点（跳过译文/代码等；跳过中文为主与纯数字/时间的元信息节点；
   *  高亮 span 内的文本是原文，参与合并拼接） */
  function collectBlockTexts(blockRoot) {
    const texts = [];
    const w = document.createTreeWalker(blockRoot, NodeFilter.SHOW_TEXT);
    while (w.nextNode()) {
      const t = w.currentNode;
      const p = t.parentElement;
      if (p && p.classList && p.classList.contains("wh-tr")) continue;
      if (!shouldJoinForMerge(t)) continue;
      // 【v2.17.22】内联代码/notranslate 标记的文本参与整段请求（否则机翻拿到残句）
      if (p && isIgnoredElement(p) && !isMergeContextText(t)) continue;
      texts.push(t);
    }
    return texts;
  }

  /** 【v2.17.22】候选块内是否存在"块级控件"（按钮/表单控件/块级链接卡片/导航项）。
   *  read-frog 原则：交互控件是独立翻译单元——否则导航多项/按钮组/标签页会被拼成一整串
   *  翻译、译文插在最后一个控件里（位置错乱，如 nodejs.org 的导航与
   *  "Get Node.js® / Get security support" 按钮组）。
   *  但句中的内联链接（display:inline 的 <a>）与 `<a href="#x">#</a>` 锚点是句子/标题的
   *  一部分：旧实现用"任何后代 a[href]"否决合并，导致 nodejs.org 正文段落（几乎每段都有
   *  链接、几乎每个标题都有 # 锚点）全部退回逐节点碎片翻译。 */
  const blockControlCache = new WeakSet();
  function hasBlockLevelControl(el) {
    if (blockControlCache.has(el)) return true;
    let hit = false;
    try {
      if (el.querySelector('button, [role="button"], input, select, textarea, iframe, video, audio')) hit = true;
      if (!hit) {
        for (const a of el.querySelectorAll('a[href], [role="link"]')) {
          if (isBlockEl(a)) { hit = true; break; } // 块级链接（导航项/卡片链接）→ 独立翻译单元
        }
      }
    } catch (e) { /* ignore */ }
    if (hit) blockControlCache.add(el);
    return hit;
  }

  /** 找用于整段合并的块容器：从最近的块祖先开始，若该块只有一个可合并文本节点
   *  （如评论被拆成多行、每行一个 div），则向上扩展到更大的块（评论容器），
   *  直到找到包含多个文本节点的评论级块（≤6 个节点，避免跨评论合并）。
   *  【v2.9.3 read-frog 不变量】候选容器必须"无块级子元素"才是真正段落单元
   *  （translateWalkedElement: hasBlockNodeChild → 拆 run / 递归，绝不整块合并）——
   *  否则卡片(标题+段落+按钮)、侧栏(多个导航项)被合并消费成一个请求：
   *  即使合并翻译成功，译文也只是塞在末尾的一个 blob，各 UI 元素表现为漏译 */
  function findBlockRootForMerge(node) {
    let el = node.parentElement;
    let lastSingle = null;
    let depth = 0;
    while (el && el !== document.body && depth < 5) {
      if (BLOCK_TAGS.has(el.tagName) && !TR_SKIP_TAGS.has(el.tagName) && !hasBlockElementChild(el)) {
        const semantic = SEMANTIC_BLOCK_TAGS.has(el.tagName);
        // 【v2.17.22】语义段落（p/标题/li/引用/单元格）就是翻译单元：内联 <code>/<a>/<em>
        // 切成多少节点都整段合并；通用容器（div/section/评论）同样只把"块级控件"
        // （按钮/表单控件/块级链接导航项）视为合并禁区——句中的内联链接是一句话的一部分。
        // 旧实现对两者都用"任何后代 a[href] 即否决合并"→ 含链接的段落/评论
        // 全部退回逐节点碎片翻译（nodejs.org 正文、TikTok 含链接评论的"英文-中文"交错混排根因）
        const usable = !hasBlockLevelControl(el);
        if (usable) {
          const texts = collectBlockTexts(el);
          if (semantic) {
            if (texts.length >= 1 && texts.length <= 60) return el;
            break; // 异常巨型段落（>60 文本节点）→ 不向上找容器，退回逐节点翻译
          }
          if (texts.length > 1 && texts.length <= 6) return el; // 评论级块 → 用它
          if (texts.length === 1) lastSingle = el;              // 单行块 → 记住，继续向上
          if (texts.length > 6) break;                          // 外层大容器 → 停止，避免跨评论
        }
      }
      el = el.parentElement;
      depth++;
    }
    return lastSingle;
  }

  /** 是否参与句子合并/拼接：非空、含外语字母、非中文为主、非数字为主
   *  （纯数字/时间/点赞量节点如 "9-16"、"59.4K"、"3522" 视为句子边界，防止元信息混入译文） */
  /** 判断文本节点是否为用户名/句柄（学习 read-frog：唯一排除规则是纯 @handle，零猜测）：
   *  仅单 token 且含数字/下划线/点等特殊字符（Dobby_theELF、user.123、@xxx）才算句柄；
   *  纯字母单词（Facebook、janky）不算；多词文本一律不算——
   *  旧"多词首字母大写人名"规则把 "RemixAI Copilot" 等首字母大写 UI 文案误判为人名 → 状态栏/按钮漏译 */
  function isHandleTextNode(t) {
    const v = (t.nodeValue || "").trim();
    if (!v) return false;
    const noEmoji = v.replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2190}-\u{21FF}\u{FE0F}]/gu, "").trim();
    // 句尾标点不算"特殊字符"（v2.9.1）：单词条目如 "Learn." / "Explore."（句尾句点）曾被误判为
    // @handle 而跳过 → "Learn. Explore. Create." 只译出 "Create."；剥离尾部标点后再判
    const noTrail = noEmoji.replace(/[.!?,;:。！？，；…]+$/, "");
    // 【v2.17.22】纯"字母-字母"连字符词是正常英文复合词（percent-encoded、state-of-the-art），
    // 不是句柄。旧规则把连字符也算句柄特征 → 链接/span 中的复合词永不翻译、也不并入整段请求
    // （nodejs.org 的 "percent-encoded" 链接、文档里大量复合词因此漏译）。
    if (/^[A-Za-z]+(?:-[A-Za-z]+)+$/.test(noTrail)) return false;
    if (!/\s/.test(noEmoji) && /^@?[\w.\-_\d]{1,40}$/.test(noEmoji) && /[^A-Za-z]/.test(noTrail)) return true;
    return false;
  }

  function shouldJoinForMerge(t) {
    const v = t.nodeValue || "";
    if (!/\S/.test(v) || translatedNodes.has(t)) return false;
    // 用户名/句柄：a/span/strong/b 内的句柄与多词人名不参与合并与翻译
    // （TikTok 等评论区用户名常在 span/strong 中，曾把用户名拼进整段导致翻译失败/正文漏译）
    const pEl = t.parentElement;
    // 【v2.17.22】内联代码的文本是句子的一部分（"import"、"'node:path'" 等单 token 也含特殊字符，
    // 会被下面的句柄规则误杀）→ 内联代码豁免句柄判定，保证整段请求文本完整
    const inInlineCode = isInlineCodeEl(pEl);
    if (!inInlineCode && pEl && ["A", "SPAN", "STRONG", "B"].includes(pEl.tagName)
      && !pEl.classList.contains("wh-highlight") && !pEl.classList.contains("wh-marked")
      && isHandleTextNode(t)) return false;
    if (!inInlineCode && /^@[\w.\-_\d]+\s*$/.test(v)) return false;
    // 含任一外语字符即可参与（全语种：拉丁/希腊/西里尔/希伯来/阿拉伯/泰文/日韩）
    if (!/[A-Za-z\u00C0-\u024F\u0370-\u03ff\u0400-\u04ff\u0590-\u05ff\u0600-\u06ff\u0e00-\u0e7f\u3040-\u30ff\uac00-\ud7af]/.test(v)) return false;
    const hanRatio = (v.match(/[\u4e00-\u9fff]/g) || []).length / Math.max(1, v.length);
    // 含假名 → 日语（汉字占比高也算），否则汉字为主视为中文跳过
    if (hanRatio > 0.5 && !/[\u3040-\u30ff]/.test(v)) return false;
    const digitRatio = (v.replace(/[^0-9]/g, "")).length / Math.max(1, v.length);
    if (digitRatio > 0.5) return false;
    return true;
  }

  /** 收集某文本节点之后的兄弟文本节点（含内联元素后代），供跨节点句子合并 */
  function collectFollowingTexts(node, maxParts) {
    const parts = [];
    let sibling = node.nextSibling;
    while (sibling && parts.length < (maxParts || 24)) {
      if (sibling.nodeType === Node.TEXT_NODE) {
        if (shouldJoinForMerge(sibling)) parts.push(sibling);
      } else if (sibling.nodeType === Node.ELEMENT_NODE) {
        // 跳过译文 span；高亮 span 内部文本是原文，参与合并
        if (sibling.classList && sibling.classList.contains("wh-tr")) {
          // 跳过译文
        } else if (sibling.tagName === "BUTTON" || sibling.tagName === "SELECT" || sibling.tagName === "TEXTAREA"
          || (sibling.tagName === "A" && isBlockEl(sibling)) || hasBlockLevelControl(sibling)) {
          // 【v2.17.22】只有块级控件（按钮/导航项/卡片链接）才是独立翻译单元并断开合并；
          // 句中的内联 <a>/<code> 属于同一句话，不再断开（旧实现遇到任何 <a> 或含链接的子元素即断句
          // → "…see the ⟨Determining module system⟩ for more details." 被切成三份各自翻译）
          break;
        } else if ((!TR_SKIP_TAGS.has(sibling.tagName) || isInlineCodeEl(sibling)) && !isBlockEl(sibling)) {
          const w = document.createTreeWalker(sibling, NodeFilter.SHOW_TEXT);
          while (w.nextNode()) {
            const t = w.currentNode;
            // 【v2.9.3】子树内出现块级元素 → 后续文本属于独立段落单元，立即断开合并
            let anc = t.parentElement, crossedBlock = false;
            while (anc && anc !== sibling) {
              if (isBlockEl(anc)) { crossedBlock = true; break; }
              anc = anc.parentElement;
            }
            if (crossedBlock) break;
            if (shouldJoinForMerge(t)) parts.push(t);
          }
        } else if (isBlockEl(sibling)) {
          break; // 遇到块级边界停止合并（computed display 判定，含 CSS block 的 <a>/<div> 项）
        }
      }
      sibling = sibling.nextSibling;
    }
    return parts;
  }

  /** 翻译单个句子（经 background 代理，内存缓存） */
  function translateSentence(text, lang) {
    const L = lang || "en";
    const key = L + "|" + text;
    if (trCache.has(key)) return trCache.get(key);
    const p = new Promise((resolve) => {
      const timer = setTimeout(() => { trCache.delete(key); resolve({ ok: false, text, error: "请求超时" }); }, 30000);
      try {
        chrome.runtime.sendMessage({ type: "WH_TRANSLATE", text, service: CONFIG.translateService, lang: L }, (resp) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) {
            trCache.delete(key); // 失败不缓存（旧实现缓存失败结果 → 重试永远命中失败 → 该句永久漏译）
            resolve({ ok: false, text, error: chrome.runtime.lastError.message });
            return;
          }
          const out = resp || { ok: false, text };
          if (!out.ok) trCache.delete(key); // 失败不缓存，重试时真正重新请求
          resolve(out);
        });
      } catch (e) {
        clearTimeout(timer);
        trCache.delete(key);
        // 扩展重载/更新后旧页面 content script 上下文失效 → 所有 chrome.runtime 调用同步抛异常
        if (/context invalidated/i.test(String((e && e.message) || e))) notifyCtxInvalidated();
        resolve({ ok: false, text });
      }
    });
    trCache.set(key, p);
    return p;
  }

  /** 【生词高亮拆句修复】收集被高亮 span 切开的"同一原句"文本片段：
   *  高亮把一个文本节点拆成 [文本][span.wh-highlight 词][文本]，各片段单独翻译会产生错译
   *  （如 "…of cattle " + 高亮"grubs" + " start…" → "cattle" 单独译成"牛皮"）。
   *  返回与 node 同属一个连续 [文本|高亮span] 序列的全部文本节点（DOM 序），无拆分返回 null */
  function highlightSplitRun(node) {
    // 向上 ≤3 层找"直接子级中含高亮 span"的容器（node 可能嵌在高亮 span 内）
    let p = node.parentElement;
    let container = null;
    for (let i = 0; p && i < 3; i++, p = p.parentElement) {
      const hasHl = Array.from(p.childNodes).some((c) => c.nodeType === 1 && c.classList
        && (c.classList.contains("wh-highlight") || c.classList.contains("wh-marked")));
      if (hasHl) { container = p; break; }
    }
    if (!container) return null;
    // node 在 container 中的顶层祖先（嵌在高亮 span 内时取该 span）
    let top = node;
    while (top.parentElement && top.parentElement !== container) top = top.parentElement;
    if (top.parentElement !== container) return null;
    const kids = Array.from(container.childNodes);
    const idx = kids.indexOf(top);
    if (idx < 0) return null;
    const isRunNode = (c) => c.nodeType === Node.TEXT_NODE
      || (c.nodeType === 1 && c.classList && (c.classList.contains("wh-highlight") || c.classList.contains("wh-marked"))
        && !(c.querySelector && c.querySelector("a,button")));
    // 向两侧扩展连续的 [文本|高亮span] 序列（遇到其他元素——链接/译文/换行——即停，防止跨句拼接）
    let lo = idx, hi = idx;
    while (lo > 0 && isRunNode(kids[lo - 1])) lo--;
    while (hi < kids.length - 1 && isRunNode(kids[hi + 1])) hi++;
    if (hi - lo < 1) return null; // 序列内无相邻节点 → 非拆分
    const parts = [];
    let sawHl = false;
    for (let i = lo; i <= hi; i++) {
      const c = kids[i];
      if (c.nodeType === Node.TEXT_NODE) {
        if (/\S/.test(c.nodeValue || "")) parts.push(c);
      } else {
        sawHl = true;
        const w = document.createTreeWalker(c, NodeFilter.SHOW_TEXT);
        while (w.nextNode()) if (/\S/.test(w.currentNode.nodeValue || "")) parts.push(w.currentNode);
      }
    }
    if (!sawHl || parts.length < 2 || !parts.includes(node)) return null;
    // 【v2.17.15】同时返回 run 容器与 run 末节点：parts[0]/末位可能是高亮 span 内部
    // 文本节点（句首/句尾词被高亮时），其 parentElement 是高亮 span 而非句子容器——
    // 调用方若用 parts[0].parentElement 做去重/插入，会在高亮 span 内查 0 条已有译文
    // → 去重失效（每次重扫重复插入整句译文）/译文插进高亮 span 内部
    return { parts, container, end: kids[hi] };
  }

  /** 被高亮拆句时的统一翻译：整句（含高亮词文本）拼接后作为一个翻译单元；
   *  若完整句已有译文（先翻译后高亮）只标记不重复翻译；若已有片段级译文则撤销后重译整句 */
  function tryHighlightStitch(node) {
    const run = highlightSplitRun(node);
    if (!run) return null;
    const parts = run.parts;
    const full = joinMergeTexts(parts).trim();
    if (full.length < 7 || full.length > 800) return null;
    const sents = extractSentences(full);
    if (!sents.length) return null;
    const fullKey = full.toLowerCase();
    // 【v2.17.15】去重/插入/撤销统一用 run 容器（highlightSplitRun 向上找到的
    // 直接含高亮 span 的祖先）。旧代码用 parts[0].parentElement——句首词被高亮时
    // parts[0] 是高亮 span 内部文本节点 → 在高亮 span 内查已有译文恒为 0 条
    // → 去重失效，每次生词本变更重扫都重复插入一条整句译文
    const container = run.container;
    if (!container) return null;
    // 已有完整句译文（src === full）→ 只标记，防重复
    const existing = container.querySelectorAll('.wh-tr[data-wh-src]');
    const fk = normTrKey(full);
    for (const s of existing) {
      const src = normTrKey(s.getAttribute("data-wh-src"));
      // 【v2.9.5】规范化比较（空白差异归一），跨粒度键也防重；
      // 【v2.17.13】双向包含（≥12 字符）也视为重复：run 被已有译文 span/链接截断时
      // 重组出的只是原句真子串，精确比较不命中 → 截断句被当新句重译、译文插进句中
      if (src === fk
        || (fk.length >= 12 && src.includes(fk))
        || (src.length >= 12 && fk.includes(src))) {
        for (const t of parts) translatedNodes.add(t);
        return { pendings: [], textNodes: parts };
      }
    }
    // 撤销片段级旧译文（src 是完整句的真子串）——直接扫 run 容器子节点（含高亮
    // span 内部的历史脏数据），与去重查询同一范围
    for (const s of Array.from(container.childNodes)) {
      if (s.nodeType === 1 && s.classList && s.classList.contains("wh-tr")) {
        const src = normTrKey(s.getAttribute("data-wh-src"));
        if (src && src !== fk && fk.includes(src)) s.remove();
      }
    }
    if (translatedBlocks.has(fullKey)) {
      // 键在但完整句译文 span 已不存在（早前翻译失败撤销后键残留）→ 清除陈旧键，继续重译
      translatedBlocks.delete(fullKey);
    }
    translatedBlocks.add(fullKey);
    for (const t of parts) translatedNodes.add(t);
    const span = document.createElement("span");
    span.className = "notranslate wh-tr wh-tr-pending wh-tr-inline";
    span.setAttribute("data-wh-tr", "1");
    span.setAttribute("data-wh-src", full);
    span.textContent = "⋯";
    // 【v2.17.15】插到 run 末节点（容器直接子级）之后——旧代码用末位 part 的
    // parentNode，末位是高亮 span 内部文本时译文会被插进高亮 span 内部
    container.insertBefore(span, run.end.nextSibling);
    // 句级键一并注册（失败随 keys 回滚），后续逐句路径命中即跳过；
    // 修复：onFail 引用了不存在的 stitchContainer（ReferenceError 被 try/catch 吞掉 →
    // 拼接失败从不加入 mergeFailedBlocks）→ 改为 container
    for (const s of sents) translatedBlocks.add(s.text.trim().toLowerCase());
    fillTranslations([{ span, text: full, lang: sents[0].lang, nodes: parts, keys: [fullKey].concat(sents.map((s) => s.text.trim().toLowerCase())), onFail: () => mergeFailedBlocks.add(container) }]);
    return { pendings: [], textNodes: parts };
  }

  /**
   * 重构一个文本节点：原句保留（或存于 data-wh-src）+ 译文占位 span。
   * 返回 { pendings: [{span,text}], textNodes: [原文句文本节点] }
   */
  /** 【v2.17.14 实体污染修复】解码常见 HTML 实体：浏览器内置页面翻译回写文本节点时
   *  会把撇号写成字面 &#39;（&%39; 为其变体），污染原文导致与 data-wh-src 永久失配
   *  → 每次添加/取消生词都被判为"新句"重译重插（重复译文），且显示层露出实体 */
  function decodeEnt(s) {
    if (!s || s.indexOf("&") < 0) return s;
    const map = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
    let t = s;
    for (let i = 0; i < 3; i++) {
      const next = t.replace(/&(amp|lt|gt|quot|apos|nbsp|#0*39|#x0*27);/gi, (m, e) => {
        if (e.charAt(0) === "#") return "'";
        return map[e.toLowerCase()];
      });
      if (next === t) break;
      t = next;
    }
    return t;
  }
  /** 【v2.9.5 重复译文修复】规范化译文来源键（空白差异归一）；v2.17.14 先解码实体 */
  function normTrKey(s) {
    return decodeEnt(s || "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  /** 【v2.9.5 重复译文修复】DOM 级兜底查重：在锚点附近（向上最多 3 层容器）查找
   *  已存在且来源文本相同的译文 span。块级合并/整段/跨节点合并/逐句各路径注册的
   *  去重键粒度不同（fullKey/wholeKey/mergedKey/句键），同一段文本以不同粒度被
   *  二次扫描（渐进渲染、重渲染、块组成变化）时键互不命中 → 各插一条相同译文；
   *  DOM 级按"规范化后来源文本相同"判定，跨粒度也防重 */
  function hasDupTranslation(anchor, srcText) {
    const key = normTrKey(srcText);
    if (!key) return false;
    let el = anchor ? (anchor.nodeType === 1 ? anchor : anchor.parentElement) : null;
    // 只查最近 2 层容器（父/祖父）：各插入路径的译文 span 均与锚点同父或近邻，
    // 层数过大（如整个评论区列表）会把"不同位置的相同文本"误判为重复 → 漏译
    for (let up = 0; el && el !== document.body && up < 2; up++) {
      // 【v2.17.22 漏译修复】第 2 层（祖父容器：整个 section / 评论列表）里必须"同一分支"才算重复：
      // 兄弟段落/兄弟 <li> 里的同文译文不代表本节点已翻译。
      // 实测 nodejs.org：链接 "Bare specifiers" 的译文（16 字符）恰好是长句
      // "For details on these package resolution rules that apply to bare specifiers in…"
      // 的子串 → 整段被判定"已翻译"→ 永久没有任何译文（用户看到的漏译）。
      const branch = up === 0 ? null : directChildOf(el, anchor);
      let spans = null;
      try { spans = el.querySelectorAll(".wh-tr[data-wh-src]"); } catch (e) { spans = null; }
      if (spans) {
        for (const s of spans) {
          if (branch && directChildOf(el, s) !== branch) continue;
          const src = normTrKey(s.getAttribute("data-wh-src"));
          if (!src) continue;
          // 三向匹配：全等 / 已有译文覆盖该句（整段译文 src ⊃ 逐句查询）/ 查询整段包含已有逐句译文
          if (src === key) return true;
          if (key.length >= 12 && src.includes(key)) return true;
          // 【v2.17.22】反向包含必须"长度相当"：已有译文只覆盖本段一小部分（如句中的链接文本）
          // 时不能判定整段已翻译，否则长段落会因为某个短译文而永久漏译
          if (src.length >= 12 && src.length * 4 >= key.length * 3 && key.includes(src)) return true;
        }
      }
      el = el.parentElement;
    }
    return false;
  }
  /** el 下、node 所在的直接子节点（判断两节点是否在同一分支） */
  function directChildOf(el, node) {
    let x = node;
    let guard = 0;
    while (x && x.parentElement !== el && guard++ < 40) x = x.parentElement;
    return x;
  }
  /** 【v2.17.22】译文插入锚点：默认紧跟 textNode，但若它位于内联 <code>/notranslate 标记/
   *  生词高亮 span 内部，则上移到该元素之后——否则译文会落进 <code> 里继承等宽代码样式，
   *  或被高亮背景整块染色。
   *  【v2.17.23】链接要分情况：散文里的**内联链接**（前后还有正文文字）上移，避免译文变成
   *  蓝色下划线、点击跳转；而**导航项/按钮/卡片这类"整块就是链接"**的不上移——译文留在里面
   *  才能跟着按钮/导航一起排版（旧实现一律外移 → nodejs.org 首页按钮旁多出一行悬空译文，
   *  连 light/dark 双份里被 display:none 隐藏的那份也把译文暴露到了页面外）。 */
  function insertionRef(textNode) {
    let n = textNode;
    let guard = 0;
    while (n && n.parentElement && guard++ < 6) {
      const p = n.parentElement;
      const inHighlight = p.classList && (p.classList.contains("wh-highlight") || p.classList.contains("wh-marked"));
      const inNotranslate = p.classList && p.classList.contains("notranslate") && !p.classList.contains("wh-tr");
      const linkLike = p.tagName === "A" || p.tagName === "BUTTON";
      const isBox = inHighlight || isInlineCodeEl(p) || inNotranslate
        || (linkLike && !isWholeLinkLabel(p));
      if (!isBox) break;
      n = p;
    }
    return n;
  }
  /** 【v2.17.23】元素本身"整块就是一个链接/按钮"（导航项、CTA 按钮、卡片链接）：
   *  这类元素不做 display:block 布局，译文应留在元素内部；配合其父元素里没有其他正文文字判断 */
  function isWholeLinkLabel(el) {
    if (!el || (el.tagName !== "A" && el.tagName !== "BUTTON")) return false;
    if (isBlockEl(el)) return true; // 块级/隐藏（display:none 也算块级）链接：整块即标签
    const parent = el.parentElement;
    if (!parent) return true;
    for (const c of parent.childNodes) {
      if (c === el || c.nodeType !== Node.TEXT_NODE) continue;
      if (/\S/.test(c.nodeValue || "")) return false; // 同级还有正文文字 → 散文内联链接
    }
    return true;
  }
  /** 【v2.17.22】该文本节点能否作为"整段合并"的触发节点：
   *  translateNode 会拒绝代码/字幕/句柄等节点（返回空），若用它们当触发节点，
   *  递归无产出 → 整段合并被放弃 → 段落退回逐节点碎片翻译 */
  function canTriggerMerge(t) {
    const p = t && t.parentElement;
    if (!p || !t.isConnected) return false;
    if (p.classList && p.classList.contains("wh-tr")) return false;
    if (isInsideYtCaption(p)) return false;
    if (isIgnoredElement(p)) return false; // 内联代码文本只并入请求，不能独立触发整段翻译
    if (["A", "SPAN", "STRONG", "B"].includes(p.tagName)
      && !(p.classList && (p.classList.contains("wh-highlight") || p.classList.contains("wh-marked")))
      && isHandleTextNode(t)) return false;
    return true;
  }
  function translateNode(node) {
    const text = node.nodeValue;
    // 全语种门槛（学习 read-frog）：拉丁/希腊/西里尔/希伯来/阿拉伯/泰文/日韩均可翻译——
    // 旧实现仅认 [A-Za-z]，纯俄语/日语/阿拉伯语文本节点在入口即被跳过 → 整页不翻译
    if (!text || !/[A-Za-z\u00C0-\u024F\u0370-\u03ff\u0400-\u04ff\u0590-\u05ff\u0600-\u06ff\u0e00-\u0e7f\u3040-\u30ff\uac00-\ud7af]/.test(text)) {
      return { pendings: [], textNodes: [] };
    }
    if (translatedNodes.has(node)) return { pendings: [], textNodes: [] };
    const parent = node.parentElement;
    if (!parent || !node.isConnected) return { pendings: [], textNodes: [] };
    // 只跳过译文 span；高亮 span 内的文本是原文，仍可翻译
    if (parent.classList && parent.classList.contains("wh-tr")) return { pendings: [], textNodes: [] };
    if (isIgnoredElement(parent)) return { pendings: [], textNodes: [] };
    // 【v2.17.6】YouTube 字幕节点不翻译：动态监听（characterData/新增节点）此前绕过了
    // walker 的 isInsideYtCaption 过滤 → rollup 逐词更新的每个词被当独立翻译单元，
    // 且句尾词被 YouTube 放进新字幕窗口后译文孤立成单独条目。统一在此拦截。
    if (isInsideYtCaption(parent)) return { pendings: [], textNodes: [] };
    // 用户名/句柄（a/span/strong/b 内，非高亮 span）：单节点直接处理时也不翻译
    // （曾导致 Saibu Abdul Wadudu、Dobby_theELF 等用户名被译、正文被连带标记漏译）
    if (["A", "SPAN", "STRONG", "B"].includes(parent.tagName)
      && !(parent.classList && (parent.classList.contains("wh-highlight") || parent.classList.contains("wh-marked")))
      && isHandleTextNode(node)) return { pendings: [], textNodes: [] };
    // 【生词高亮拆句修复 v2.8.4】被高亮切碎的同句片段（"…cattle " + 高亮"grubs" + " start…"）
    // 拼成完整句统一翻译——各片段单独翻译会产生错译（"cattle"→"牛皮"）与重复译文
    if (CONFIG.translateMode === "inline") {
      const stitched = tryHighlightStitch(node);
      if (stitched) return stitched;
    }
    const sentences = extractSentences(text);
    if (!sentences.length) return { pendings: [], textNodes: [] };

    const mode = CONFIG.translateMode;
    // 【v2.17.27 框架安全】React/Vue 等框架管理的文本节点上只能"追加"、不能"替换"：
    //  覆盖式（replace）会移除框架持有的原文节点 → 框架随后 removeChild 时抛错、整页崩。
    //  因此框架节点上屏蔽点式降级为对照式（原文保留 + 译文追加）。
    const fwSafe = isFrameworkNode(parent);
    const effMode = fwSafe ? "inline" : mode;

    // 【块级合并】inline 模式：优先把整个块容器（段落）合并翻译 ——
    // 被内联元素/换行拆开的句子只产生"一组译文"插在段末，杜绝半句+整句两个译文并存；
    // 同一块内只由"第一个含外语字符的文本节点"触发，其余外语节点一律跳过（防同句双译）
    if (effMode === "inline") {
      const blockRoot = findBlockRootForMerge(node);
      if (blockRoot && !mergeFailedBlocks.has(blockRoot)) { // 合并失败过的块 → 退回逐节点翻译
        const texts = collectBlockTexts(blockRoot);
        if (texts.length > 1 && texts.indexOf(node) >= 0) {
          // 【v2.17.22】触发节点必须是 translateNode 真正会处理的节点：内联 <code>/<kbd> 里的
          // 文本只能作为"上下文"并入请求（isIgnoredElement → translateNode 直接返回空），
          // 旧实现用它当触发节点 → 递归无产出 → 整段合并被放弃 → 段落退回逐节点碎片翻译
          // （如 nodejs.org 的 "data: URLs are supported…"、"<code>x</code> for ES modules"）
          const firstPart = texts.find((t) => canTriggerMerge(t) && extractSentences(t.nodeValue || "").length);
          let skipBlockMerge = false;
          if (firstPart && firstPart !== node) {
            // 本块由首个外语节点统一合并；若它尚未处理（如翻译失败撤销标记后），递归处理它避免整块漏译。
            // 递归无产出（如首个外语节点是 "REMIX 混音版" 这类中英混合节点，被"截断中文"规则跳过）
            // 或它已被单独翻译 → 本节点不再走整块合并，落到下方自身翻译路径——
            // 旧实现直接 return 丢弃本节点 → 同块内 "Learn.Explore.Create."、"FILE EXPLORER" 等漏译
            if (!translatedNodes.has(firstPart)) {
              const r = translateNode(firstPart);
              if (r.pendings.length || r.textNodes.length) return r;
            } else if (effMode === "inline") {
              // 首节点已被【单独】翻译（TikTok 等渐进渲染：评论各部分分批进入 DOM，
              // 先到部分先译 → 长评论被拆成多段翻译）→ 整块尚未合并过时，
              // 撤销块内已有零散译文、解除已译标记，递归由首节点按整块重新合并为一个译文
              const fullTxt = joinMergeTexts(texts);
              const fullKey0 = fullTxt.trim().toLowerCase();
              const sents0 = (fullTxt.length > 6 && fullTxt.length <= 2000) ? extractSentences(fullTxt) : [];
              if (sents0.length && !translatedBlocks.has(fullKey0)) {
                let removed = false;
                for (const t of texts) {
                  if (t.nodeType !== Node.TEXT_NODE || !t.parentNode) continue;
                  for (const s of Array.from(t.parentNode.childNodes)) {
                    if (s.nodeType === 1 && s.classList && s.classList.contains("wh-tr")) {
                      const src = s.getAttribute("data-wh-src") || "";
                      if (src && fullTxt.includes(src)) { s.remove(); removed = true; }
                    }
                  }
                }
                if (removed) {
                  for (const t of texts) translatedNodes.delete(t);
                  const r = translateNode(firstPart);
                  if (r.pendings.length || r.textNodes.length) return r;
                }
              }
            }
            skipBlockMerge = true;
          }
          if (!skipBlockMerge) {
          const full = joinMergeTexts(texts);
          // 【v2.17.10】上限 800→2000：YouTube 长评论（约 1300 字符）超旧上限 → 逐句翻译
          // 导致"英文-中文-英文-中文"交错混排；放宽后整段合并为一条完整译文跟在评论后
          if (full.length > 6 && full.length <= 2000) {
            const fullKey = full.trim().toLowerCase();
            const sents = extractSentences(full);
            if (sents.length) {
              // 整段内容已翻译过（如普通分支先翻译、生词高亮拆分后再次走到块级合并）→ 只标记不再插译文
              if (translatedBlocks.has(fullKey)) {
                for (const t of texts) translatedNodes.add(t);
                return { pendings: [], textNodes: texts };
              }
              translatedBlocks.add(fullKey);
              for (const t of texts) translatedNodes.add(t);
              const lastText = texts[texts.length - 1];
              // 语义段落（p/标题/引用/图注/列表项/单元格）整段合并 → 译文块级显示在段落后
              // （read-frog 块级双语效果）；DIV 等容器（评论区）保持 inline 追加，避免改变既有排版
              const trDisp = /^(P|H1|H2|H3|H4|H5|H6|BLOCKQUOTE|FIGCAPTION|LI|TD|TH|DD|DT|CAPTION|SUMMARY)$/.test(blockRoot.tagName) ? "wh-tr-block" : "wh-tr-inline";
              // 多句段落（≤2000 字符且 ≤40 句）→ 整段一个译文（与单节点整段分支一致，防止译文被拆成多段）；
              // 旧上限 300 字符/8 句把 TikTok 长评论（约 420 字符 3 句）拆成 3 段翻译 → v2.7.8 放宽至 800/20；
              // v2.17.10 再放宽至 2000/40（YouTube 长评论约 1300 字符超 800 上限 → 逐句交错混排）；
              // 句数上限仍防止单词枚举类文本（"A. B. C. ..."）被整段合并
              if (sents.length > 1 && sents.length <= 40 && full.length <= 2000) {
                // 【v2.9.5 重复译文修复】DOM 级兜底查重：块组成变化（渐进渲染/重渲染）导致
                // fullKey 变化时键查重失效，同段文本已被其他粒度翻译过 → 不再插第二条译文
                if (hasDupTranslation(lastText, full)) {
                  return { pendings: [], textNodes: texts };
                }
                const span = document.createElement("span");
                span.className = "notranslate wh-tr wh-tr-pending " + trDisp;
                span.setAttribute("data-wh-tr", "1");
                span.setAttribute("data-wh-src", full);
                span.textContent = "⋯";
                // 【v2.17.22】块级译文直接挂在块容器末尾（该容器已保证只有内联内容）：
                // 段末是内联 <a> 时，旧实现会把译文插进链接内部（译文继承链接颜色/下划线、
                // 点击译文会跳转），如 nodejs.org "…see the packages documentation⟨译文⟩."
                if (trDisp === "wh-tr-block") blockRoot.appendChild(span);
                else {
                  const ref0 = insertionRef(lastText);
                  if (ref0 && ref0.parentNode) ref0.parentNode.insertBefore(span, ref0.nextSibling);
                  else lastText.parentNode.insertBefore(span, lastText.nextSibling);
                }
                // 句级键一并注册（失败时随 keys 回滚），后续逐句路径命中即跳过
                const sentKeys = sents.map((s) => s.text.trim().toLowerCase());
                for (const k of sentKeys) translatedBlocks.add(k);
                fillTranslations([{ span, text: full, lang: sents[0].lang, nodes: texts, keys: [fullKey].concat(sentKeys) }]);
                return { pendings: [], textNodes: texts };
              }
              const spans = [];
              let guard = 0;
              for (const s of sents) {
                if (guard++ > 12) break;
                // 【v2.9.6】防重只认 DOM 实存同文译文（键残留时译文可能已随重渲染丢失 → 允许重译防漏）
                if (hasDupTranslation(lastText, s.text)) continue;
                const span = document.createElement("span");
                span.className = "notranslate wh-tr wh-tr-pending " + trDisp;
                span.setAttribute("data-wh-tr", "1");
                span.setAttribute("data-wh-src", s.text);
                span.textContent = "⋯";
                // 译文插在原文段末（最后一个参与文本节点之后），紧跟原文，避免落在评论区元信息之后
                if (trDisp === "wh-tr-block") blockRoot.appendChild(span);
                else {
                  const ref1 = insertionRef(lastText);
                  if (ref1 && ref1.parentNode) ref1.parentNode.insertBefore(span, ref1.nextSibling);
                  else lastText.parentNode.insertBefore(span, lastText.nextSibling);
                }
                const sKey = s.text.trim().toLowerCase();
                translatedBlocks.add(sKey);
                spans.push({ span, text: s.trans || s.text, lang: s.lang, nodes: texts, keys: [fullKey, sKey] });
              }
              if (spans.length) fillTranslations(spans.map((s2) => ({ ...s2, onFail: () => mergeFailedBlocks.add(blockRoot) })));
              return { pendings: [], textNodes: texts };
            }
          }
          } // 整块合并仅由首个外语节点触发；skipBlockMerge 时本节点落到下方自身路径
        }
      }
    }

    // 【跨节点合并】inline 模式：首句为片段（不以句末标点结尾，接续上一节点的半句），
    // 或末句为片段（本节点被高亮 span/换行/DOM 切分截断，句子续于后续兄弟节点）→
    // 把本节点全文 + 后续兄弟文本合并为完整句，译文 span 追加在合并范围末尾（保留全部原文）。
    // 【v2.17.11 交错混排修复】旧判定只看首句：被高亮/DOM 切开的 "…today. While" +
    // "slightly" + " more surface…" 三个片段各自整段合并翻译，评论区出现
    // "原文-译文-原文-译文" 交错混排；末句为片段时先与后续兄弟合并为一个翻译单元。
    // 合并失败过的容器 → 退回逐节点翻译（防止整组 UI 元素被合并消费后永久漏译）
    const firstSentFragment = !/[.!?。！？]$/.test(sentences[0].text.trim());
    const lastSentFragment = !/[.!?。！？]$/.test(sentences[sentences.length - 1].text.trim());
    if (effMode === "inline" && !mergeFailedBlocks.has(parent) && (firstSentFragment || lastSentFragment)) {
      const parts = collectFollowingTexts(node, 20);
      if (parts.length) {
        const merged = joinMergeTexts([node].concat(parts)).trim();
        // 翻译请求文本：混合中文时截断（译文不含中文）
        let transText = merged;
        if (!/[\u3040-\u30ff\uac00-\ud7af]/.test(merged)) {
          const zhIdx = merged.search(/[\u4e00-\u9fff]/);
          if (zhIdx >= 0) transText = merged.slice(0, zhIdx).trim();
        }
        // merged 超过整段合并上限（2000）→ 不再合并（单次巨型请求易超时），
        // 本节点落到下方自身翻译路径（超长时由逐句兜底 + 段末成组译文承接）
        if (transText.length >= 6 && merged.length <= 2000 && merged.length > sentences[0].text.trim().length + 2) {
          const mergedKey = merged.trim().toLowerCase();
          if (!translatedBlocks.has(mergedKey)) {
            // 【v2.9.5 重复译文修复】同段文本已以其他粒度翻译过 → 只标记不再插第二条译文
            const lastCand = parts[parts.length - 1];
            if (hasDupTranslation(lastCand, merged)) {
              translatedBlocks.add(mergedKey);
              translatedNodes.add(node);
              for (const p of parts) translatedNodes.add(p);
              return { pendings: [], textNodes: [node].concat(parts) };
            }
            translatedBlocks.add(mergedKey);
            translatedNodes.add(node);
            for (const p of parts) translatedNodes.add(p);
            const span = document.createElement("span");
            span.className = "notranslate wh-tr wh-tr-pending wh-tr-inline";
            span.setAttribute("data-wh-tr", "1");
            span.setAttribute("data-wh-src", merged);
            span.textContent = "⋯";
            const last = parts[parts.length - 1];
            const ref2 = insertionRef(last);
            if (ref2 && ref2.parentNode) ref2.parentNode.insertBefore(span, ref2.nextSibling);
            else last.parentNode.insertBefore(span, last.nextSibling);
            fillTranslations([{ span, text: transText, lang: sentences[0].lang, nodes: [node].concat(parts), keys: [mergedKey], onFail: () => mergeFailedBlocks.add(parent) }]);
            return { pendings: [], textNodes: [node].concat(parts) };
          }
          translatedNodes.add(node);
          for (const p of parts) translatedNodes.add(p);
          return { pendings: [], textNodes: [node].concat(parts) };
        }
      }
    }

    // 【整段一个译文】单文本节点含多个句子（如评论）→ 整段合并翻译为一个译文
    // （inline：完整原文保留 + 一个译文 span；≤2000 字符且 ≤40 句，超长仍逐句——
    //   v2.7.8 放宽 300→800 对齐 read-frog 整段翻译；v2.17.10 放宽 800→2000 消除 YouTube
    //   长评论逐句交错的"英文-中文-英文-中文"混排）
    const wholeText = text.trim();
    if (effMode === "inline" && !mergeFailedBlocks.has(parent) && sentences.length > 1 && sentences.length <= 40 && wholeText.length <= 2000) {
      let wholeTrans = wholeText;
      if (!/[\u3040-\u30ff\uac00-\ud7af]/.test(wholeText)) {
        const zhIdx = wholeText.search(/[\u4e00-\u9fff]/);
        if (zhIdx >= 0) wholeTrans = wholeText.slice(0, zhIdx).trim();
      }
      if (wholeTrans.length >= 6) {
        const wholeKey = wholeText.trim().toLowerCase();
        // 【v2.9.6】防重只认 DOM 实存同文译文（键残留 + 译文已随重渲染丢失 → 允许重译防漏）
        const dupWhole = hasDupTranslation(parent, wholeText);
        if (dupWhole) {
          translatedNodes.add(node);
          return { pendings: [], textNodes: [] };
        }
        translatedBlocks.add(wholeKey);
        for (const s of sentences) translatedBlocks.add(normTrKey(s.text));
        const span = document.createElement("span");
        span.className = "notranslate wh-tr wh-tr-pending wh-tr-inline";
        span.setAttribute("data-wh-tr", "1");
        span.setAttribute("data-wh-src", wholeText);
        span.textContent = "⋯";
        // 【v2.17.27 框架安全】只追加不替换：原文节点保持原样（连空白也保留），译文插在其后。
        // 旧实现 parent.replaceChild(frag2, node) 会移除框架持有的文本节点 → 框架 removeChild 时抛错。
        const anchorW = insertionRef(node) || node;
        if (!anchorW.parentNode) { translatedNodes.add(node); return { pendings: [], textNodes: [] }; }
        anchorW.parentNode.insertBefore(span, anchorW.nextSibling);
        translatedNodes.add(node);
        fillTranslations([{ span, text: wholeTrans, lang: sentences[0].lang, nodes: [node], keys: [wholeKey].concat(sentences.map((s) => s.text.trim().toLowerCase())), onFail: () => mergeFailedBlocks.add(parent) }]);
        return { pendings: [], textNodes: [node] };
      }
    }

    // ---------- 覆盖式（replace）：译文 span 直接替换原文，整段无痕 ----------
    // 【v2.18.2】只在"非框架挂载点"内使用：replaceChild 会摘掉框架持有的文本节点，
    // 框架随后 removeChild 时抛 NotFoundError 并可能整页报错（Supabase 仪表盘）；
    // 框架页面已由上方 effMode 降级为对照式（只追加，见下面的 inline 分支）。
    if (effMode === "replace") {
      const frag = document.createDocumentFragment();
      let rpos = 0;
      const rPendings = [];
      const rTextNodes = [];
      translatedBlocks.add(text.trim().toLowerCase());
      for (const s of sentences) {
        if (s.start > rpos) frag.appendChild(document.createTextNode(text.slice(rpos, s.start)));
        // 已有同文译文 → 保留原文，不重复插
        if (hasDupTranslation(parent, s.text)) {
          frag.appendChild(document.createTextNode(s.text));
          rpos = s.end;
          continue;
        }
        // 句子含中文（trans 被截断）→ 不覆盖中文，保留原文
        if (s.trans !== s.text) {
          frag.appendChild(document.createTextNode(s.text));
          rpos = s.end;
          continue;
        }
        translatedBlocks.add(s.text.trim().toLowerCase());
        const span = document.createElement("span");
        span.className = "notranslate wh-tr wh-tr-pending wh-tr-replace";
        span.setAttribute("data-wh-tr", "1");
        span.setAttribute("data-wh-src", s.text);
        span.title = s.text; // 悬停查看被覆盖的原句
        span.textContent = s.text;
        frag.appendChild(span);
        rPendings.push({ span, text: s.trans || s.text, lang: s.lang, nodes: [node], keys: [s.text.trim().toLowerCase(), text.trim().toLowerCase()] });
        rpos = s.end;
      }
      if (rpos < text.length) frag.appendChild(document.createTextNode(text.slice(rpos)));
      const fragChildren = [];
      for (let i = 0; i < frag.childNodes.length; i++) fragChildren.push(frag.childNodes[i]);
      parent.replaceChild(frag, node);
      translatedNodes.add(node);
      for (const ch of fragChildren) {
        translatedNodes.add(ch);
        if (ch.nodeType === Node.TEXT_NODE) rTextNodes.push(ch);
      }
      // 重试锚点必须是替换后仍在 DOM 中的文本节点（原 node 已被 detach）
      for (const p of rPendings) p.nodes = rTextNodes;
      return { pendings: rPendings, textNodes: rTextNodes };
    }

    // ---------- 对照式（inline）：只追加、不动原节点 ----------
    // 【v2.18.2 框架安全】旧实现把原文文本节点 replaceChild 成"新文本节点 + 译文 span"，
    // 框架（React/Vue）持有原文本节点引用 → 卸载/重排时抛
    // "Failed to execute 'removeChild' on 'Node': The node to be removed is not a child of this node."
    // 现在原文节点原样保留，译文 span 追加在其后。
    let pos = 0;
    const pendings = [];
    // 【v2.17.12 交错混排修复】inline 模式：译文 span 统一收集后追加在原文末尾
    // （旧实现逐句插在句后 → "英文-中文-英文-中文"交错混排）
    const inlineTrSpans = [];
    // 记录整段去重 key：生词高亮把节点拆分后块级合并拼接的全文与此相同 → 命中即不再重复翻译
    translatedBlocks.add(text.trim().toLowerCase());
    for (const s of sentences) {
      pos = s.end;
      // 【v2.9.6 原文消失修复】防重只认"DOM 中实际存在的同文译文"（hasDupTranslation）：
      // 纯键命中不可靠——站点重渲染会把译文 span 与原文节点一起重建，键却残留。
      if (hasDupTranslation(parent, s.text)) continue;
      // 记录整段去重：生词高亮把文本节点拆分后再次走到块级合并时，命中此处 key 则不再重复翻译
      translatedBlocks.add(s.text.trim().toLowerCase());
      const span = document.createElement("span");
      span.className = "notranslate wh-tr wh-tr-pending wh-tr-inline";
      span.setAttribute("data-wh-tr", "1");
      span.setAttribute("data-wh-src", s.text);
      span.textContent = "⋯";
      inlineTrSpans.push(span);
      pendings.push({ span, text: s.trans || s.text, lang: s.lang, nodes: [node], keys: [s.text.trim().toLowerCase(), text.trim().toLowerCase()] });
    }
    if (!pendings.length) {
      translatedNodes.add(node);
      return { pendings: [], textNodes: [node] };
    }
    // 插入位置：原文节点本身，或它所在的内联容器（<a>/<code>/高亮 span）之后——同样只是追加
    const anchorNode = insertionRef(node) || node;
    const box = anchorNode.parentNode;
    if (!box) { translatedNodes.add(node); return { pendings: [], textNodes: [node] }; }
    let ref = anchorNode;
    for (let i = 0; i < inlineTrSpans.length; i++) {
      if (i > 0) box.insertBefore(document.createTextNode(" "), ref.nextSibling);
      box.insertBefore(inlineTrSpans[i], ref.nextSibling);
      ref = inlineTrSpans[i];
    }
    translatedNodes.add(node);
    // 重试/高亮锚点：原文节点仍在 DOM 中（不再被替换），本身就是最好的锚点
    for (const p of pendings) p.nodes = [node];
    return { pendings, textNodes: [node] };
  }

  /** 批量翻译请求（学习自 Read Frog 的批处理思路）：
   *  一次消息把多句发往 background，支持批量的服务（Edge）合并为一次 HTTP 请求，
   *  大幅减少整页翻译的往返次数（实测 25 句/批 746ms）。失败返回 null。 */
  function translateBatchRequest(texts, lang) {
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve(null), 30000);
      try {
        chrome.runtime.sendMessage({ type: "WH_TRANSLATE_BATCH", texts, service: CONFIG.translateService, lang: lang || "en" }, (resp) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) { resolve(null); return; }
          resolve(resp || null);
        });
      } catch (e) {
        clearTimeout(timer);
        resolve(null);
      }
    });
  }

  /** 并发翻译并填充译文（批量优先 + 多路并发；inline 失败自动撤销标记并在稍后有限重试，避免漏译） */
  async function fillTranslations(pendings) {
    if (!translateActive()) return;
    let queue = pendings.slice();
    const retryItems = [];
    /** 回滚"整段去重键 + 节点已翻译标记"：
     *  虚拟列表（如 TikTok/微博评论区）滚动时会移除并重建节点，重建的同文本节点
     *  会命中 translatedBlocks 里"上次失败尝试"留下的键 → 被标记已翻译却不翻译 → 永久漏译。
     *  因此请求断连（节点已被移除）或重试耗尽时，必须回滚键与标记，让重建节点可重新翻译。 */
    const rollback = (p, detachOnly) => {
      if (p.keys) for (const k of p.keys) translatedBlocks.delete(k);
      if (p.nodes) p.nodes.forEach((x) => translatedNodes.delete(x));
      // 【v2.17.22】"译文 span 被站点重渲染/清空翻译移除"不算合并失败：旧实现照样把容器
      // 加入 mergeFailedBlocks → 该容器此后永久退回逐节点翻译（原文/译文交错混排），
      // 仅仅因为一次 DOM 重渲染或一次配置刷新
      if (!detachOnly && p.onFail) { try { p.onFail(); } catch (e) { /* ignore */ } }
    };
    /** 把单句翻译结果应用到占位 span（批量路径与逐句 worker 共用） */
    const applyResult = (p, r) => {
      // 翻译关闭 / 会员失效 / 白名单变化后在途结果不再写入页面（否则会重新插入译文）
      if (!translateActive()) {
        if (p.span && p.span.isConnected) {
          if (p.span.classList.contains("wh-tr-replace")) {
            const src = p.span.getAttribute("data-wh-src") || p.text || "";
            p.span.replaceWith(document.createTextNode(src));
          } else {
            p.span.remove();
          }
        }
        rollback(p, true);
        return;
      }
      if (!p.span.isConnected) { rollback(p, true); return; }
      p.span.classList.remove("wh-tr-pending");
      if (r.ok) {
        // 【v2.17.12 译文换行修复】多段落原文（含空行）整段合并翻译时，服务端会按段
        // 返回带换行/前导空格的译文，而评论区容器多为 white-space:pre-line——译文 span
        // 里的换行会渲染成错位的独立行（缩进不一、夹空行）。展示前折叠为单行。
        p.span.textContent = String(r.text || "").replace(/\s*\n+\s*/g, " ").trim();
      } else if (p.span.classList && (p.span.classList.contains("wh-tr-replace")
        || (!p.span.classList.contains("wh-tr-inline") && CONFIG.translateMode === "replace"))) {
        // 【v2.17.27】按 span 自身类别判断，而不是全局 CONFIG：框架节点上覆盖式会降级为对照式，
        //  此时失败应走"移除占位"分支，而非把英文塞进译文 span
        p.span.textContent = p.text; // 失败时保留原文
        p.span.classList.add("wh-tr-fail");
        if (p.keys) for (const k of p.keys) translatedBlocks.delete(k); // 回滚键允许后续重译
      } else {
        p.span.remove(); // inline 失败：原文已在旁边，直接移除占位
        // 撤销节点标记，允许重试（防止翻译失败导致永久漏译）
        if (p.nodes) p.nodes.forEach((n2) => translatedNodes.delete(n2));
        if ((p.retries || 0) < 3 && p.nodes && p.nodes.length) {
          retryItems.push({ ...p, retries: (p.retries || 0) + 1 });
        } else {
          rollback(p); // 重试耗尽：回滚去重键，节点重建后可重新翻译
        }
      }
    };

    // 【批量路径】句子较多（≥3 句）时按语言分组、20 句一批请求，减少往返
    if (queue.length >= 3) {
      const BATCH_SIZE = 20;
      // 先应用缓存命中的；未命中的按语言分组
      const byLang = new Map();
      const rest = [];
      for (const p of queue) {
        const key = (p.lang || "en") + "|" + p.text;
        if (trCache.has(key)) {
          trCache.get(key).then((r) => applyResult(p, r)).catch(() => rollback(p));
        } else {
          const L = p.lang || "en";
          if (!byLang.has(L)) byLang.set(L, []);
          byLang.get(L).push(p);
          rest.push(p);
        }
      }
      // 各语言组并行分批发送（组内串行批次，避免一次打满）
      const groups = [...byLang.values()].filter((g) => g.length >= 3);
      const groupResults = await Promise.all(groups.map(async (items) => {
        const done = new Set();
        for (let i = 0; i < items.length; i += BATCH_SIZE) {
          const batch = items.slice(i, i + BATCH_SIZE);
          const resp = await translateBatchRequest(batch.map((x) => x.text), batch[0].lang);
          if (resp && Array.isArray(resp.results) && resp.results.length === batch.length) {
            batch.forEach((p, j) => {
              const r = resp.results[j];
              if (r && r.ok) trCache.set((p.lang || "en") + "|" + p.text, Promise.resolve(r)); // 成功入缓存
              applyResult(p, r || { ok: false });
              done.add(p);
            });
          }
        }
        return done;
      }));
      // 批量未覆盖的（批失败或组太小）→ 剩余走逐句 worker
      const batched = new Set();
      for (const done of groupResults) for (const p of done) batched.add(p);
      queue = rest.filter((p) => !batched.has(p));
    }

    const n = Math.min(6, queue.length);
    const workers = [];
    for (let i = 0; i < n; i++) {
      workers.push((async () => {
        while (queue.length) {
          const p = queue.shift();
          if (!p.span.isConnected) { rollback(p, true); continue; }
          const r = await translateSentence(p.text, p.lang);
          applyResult(p, r);
        }
      })());
    }
    await Promise.all(workers);
    if (retryItems.length) {
      const items = retryItems;
      setTimeout(() => {
        if (!translateActive()) return;
        for (const it of items) {
          if (!it.nodes || !it.nodes.length) continue;
          const anchor = it.nodes[it.nodes.length - 1];
          if (!anchor || !anchor.isConnected) { rollback(it, true); continue; }
          // 【v2.17.14】重插前 DOM 级查重：unhighlightAll+scan 循环中占位 span 常已
          // 被完整句译文取代，无查重重插会造成同一句译文重复追加
          if (hasDupTranslation(anchor, it.text)) { rollback(it, true); continue; }
          const span = document.createElement("span");
          // 【v2.17.22】沿用原译文的排版方式（块级/内联）；【v2.17.23】但必须补回 wh-tr-pending：
          // 失败路径已先把 pending 类摘掉再移除旧 span，直接复制 className 会让重试中的占位
          // 显示成"实心 ⋯"（既不淡显、也不被 pending 判定识别，看起来像卡住的漏译）
          span.className = ((it.span && it.span.className) ? it.span.className : "notranslate wh-tr wh-tr-inline")
            .replace(/\bwh-tr-pending\b/g, "").trim() + " wh-tr-pending";
          span.setAttribute("data-wh-tr", "1");
          span.setAttribute("data-wh-src", it.text);
          span.textContent = "⋯";
          const ref = insertionRef(anchor);
          if (ref && ref.parentNode) ref.parentNode.insertBefore(span, ref.nextSibling);
          else anchor.parentNode.insertBefore(span, anchor.nextSibling);
          fillTranslations([{ ...it, span }]);
        }
      }, 2500);
    }
  }

  /** 翻译整个区域（返回翻译后新增的原句文本节点） */
  async function translateRoot(root) {
    if (!translateActive() || !root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        const p = n.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        // 只跳过译文 span；生词高亮 span 内的文本是原文，仍可翻译（防止高亮后整句漏译）
        if (p.classList && p.classList.contains("wh-tr")) return NodeFilter.FILTER_REJECT;
        // 【v2.17.5c】跳过 YouTube 字幕（接管后由插件自渲染，无需网页翻译）
        if (isInsideYtCaption(p)) return NodeFilter.FILTER_REJECT;
        if (isIgnoredElement(p)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    const pendings = [];
    const textNodes = [];
    // 全部节点进入同一队列（不截断），由 fillTranslations 内多路并发逐项处理——
    // 大量评论时后端不遗漏、也不会因逐批 await 阻塞页面
    for (const n of nodes) {
      const r = translateNode(n);
      for (const x of r.pendings) pendings.push(x);
      for (const t of r.textNodes) textNodes.push(t);
    }
    await fillTranslations(pendings);
    return textNodes;
  }

  /** 清理翻译痕迹（关闭翻译 / 切换模式 / 切换服务时调用） */
  function clearTranslations() {
    document.querySelectorAll(".wh-tr").forEach((span) => {
      const isReplace = span.classList.contains("wh-tr-replace");
      if (isReplace) {
        const src = span.getAttribute("data-wh-src") || span.textContent;
        span.replaceWith(document.createTextNode(src));
      } else {
        span.remove();
      }
    });
    translatedNodes = new WeakSet(); // 重置去重记录，允许重新翻译
    translatedBlocks.clear();        // 重置整段去重记录
    mergeFailedBlocks = new WeakSet(); // 重置合并失败降级记录（模式切换后重新尝试合并）
    blockDisplayCache = new WeakSet(); // 重置 display 缓存（响应式布局可能已改变）
    inlineDisplayCache = new WeakSet();
  }

  /* ============================================================
   * 九、动态内容监听
   * ============================================================ */
  let observer = null;
  function initObserver() {
    if (!MEM_PRO || !document.body) return;
    if (observer) observer.disconnect();
    observer = new MutationObserver((mutations) => {
      const queue = [];
      for (const mut of mutations) {
        // characterData（学习 read-frog 全量监听）：React/Vue 常复用已有文本节点、直接改
        // nodeValue 更新文字（状态栏 "Initialization as git repo"、终端日志等）——
        // 旧实现仅监听 childList，这类更新永远观察不到 → 漏译
        if (mut.type === "characterData") {
          if (mut.target && mut.target.nodeType === Node.TEXT_NODE) queue.push(mut.target);
          continue;
        }
        for (const n of mut.addedNodes) {
          if (n.nodeType === Node.TEXT_NODE) {
            queue.push(n);
          } else if (n.nodeType === Node.ELEMENT_NODE && !(n.classList && (n.classList.contains("wh-highlight") || n.classList.contains("wh-marked") || n.classList.contains("wh-tr")))) {
            const walker = createTextWalker(n);
            while (walker.nextNode()) queue.push(walker.currentNode);
          }
        }
      }
      if (queue.length) requestAnimationFrame(() => {
        // 【v2.17.11 交错混排修复】先按 DOM 顺序排序：MutationObserver 的 mutations
        // 顺序不保证与文档一致（高亮拆分/站点渐进渲染时尤其乱），乱序处理会让
        // "前半句片段"尚未合并就被单独整段翻译、后续片段再各自翻译 → 原文/译文交错
        if (queue.length > 1) {
          try {
            queue.sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1);
          } catch (e) { /* 节点已脱离文档等异常：保持原顺序继续 */ }
        }
        if (translateActive()) {
          // 翻译优先（重构节点），再高亮原句文本
          const pendings = [];
          const textNodes = [];
          for (const node of queue) {
            const r = translateNode(node);
            for (const x of r.pendings) pendings.push(x);
            for (const t of r.textNodes) textNodes.push(t);
          }
          fillTranslations(pendings);
          textNodes.forEach(highlightNode);
        }
        queue.forEach(highlightNode);
      });
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  function stopObserver() {
    if (observer) { observer.disconnect(); observer = null; }
  }

  /* ============================================================
   * 九、词典查询（词库内置离线释义 → 后台代理）
   * ============================================================ */
  const dictCache = new Map();
  // 【v2.17.4】在线升级缓存：离线释义先秒出，在线结果（带词性/例句）回来后升级
  const onlineUpgradeCache = new Map();
  // 当前卡片渲染句柄，在线结果回来时原地刷新
  let lastCardRender = null;

  /* 【v2.17.5】在线释义持久化缓存：在线查询成功后写入 chrome.storage.local，
   * 下次（含重启浏览器后）打开同一单词直接命中本地缓存，不再发起在线查询 */
  const DICT_CACHE_KEY = "whDictOnlineCache";
  // chrome.storage.local 默认约 10MB；单条释义含例句可达 1~2KB，
  // 原来 10000 条可能撑爆配额导致整次写入失败。3000 条约 3~6MB，留出余量。
  const DICT_CACHE_MAX = 3000;
  const persistentDictCache = new Map();
  let dictCacheReady = false;
  let dictCacheLoadPromise = null;
  let dictCacheSaveTimer = null;

  /** 启动时读取持久化的在线释义缓存 */
  async function loadPersistentDict() {
    try {
      const s = await chrome.storage.local.get(DICT_CACHE_KEY);
      const obj = s[DICT_CACHE_KEY];
      if (obj && typeof obj === "object") {
        for (const k of Object.keys(obj)) persistentDictCache.set(k, obj[k]);
      }
    } catch (e) { /* ignore */ }
    dictCacheReady = true;
  }

  /** 懒加载：只有真正查词时才读取持久化缓存，避免每个网页启动都解析几 MB JSON */
  function ensureDictCache() {
    if (dictCacheReady) return Promise.resolve();
    if (!dictCacheLoadPromise) dictCacheLoadPromise = loadPersistentDict();
    return dictCacheLoadPromise;
  }

  /** 防抖写回：1s 内多次命中只写一次 storage */
  function scheduleDictCacheSave() {
    if (dictCacheSaveTimer) return;
    dictCacheSaveTimer = setTimeout(async () => {
      dictCacheSaveTimer = null;
      try {
        if (persistentDictCache.size > DICT_CACHE_MAX) {
          const entries = [...persistentDictCache.entries()].sort((a, b) => (a[1].ts || 0) - (b[1].ts || 0));
          while (entries.length > DICT_CACHE_MAX) {
            const [k] = entries.shift();
            persistentDictCache.delete(k);
          }
        }
        await chrome.storage.local.set({ [DICT_CACHE_KEY]: Object.fromEntries(persistentDictCache) });
      } catch (e) { /* 存储写入失败不影响本次展示 */ }
    }, 1000);
  }

  /** 在线查询成功 → 写入持久化缓存 */
  function cacheOnlineDict(word, resp) {
    if (!resp || !resp.ok) return;
    persistentDictCache.set(word, { ...resp, ts: Date.now() });
    scheduleDictCacheSave();
  }

  /** 词库内置释义（离线，秒出） */
  function offlineDict(word) {
    const m = META[word];
    if (m && m[0] && m[0].length) {
      return {
        ok: true,
        source: "vocab",
        word,
        usphone: m[1] || "",
        ukphone: "",
        translations: m[0],
        examples: []
      };
    }
    return null;
  }

  /** 【v2.17.4】离线释义先展示，同时后台在线查词；在线结果带词性/例句时升级缓存并原地刷新当前卡片 */
  function upgradeWithOnline(word, off) {
    try {
      chrome.runtime.sendMessage({ type: "WH_DICT", word }, (resp) => {
        if (chrome.runtime.lastError) return;
        if (!resp || !resp.ok || resp.source !== "youdao") return;
        const hasPos = (resp.translations || []).some((t) => /^\w+\.\s/.test(String(t)));
        const hasEx = (resp.examples || []).some((ex) => ex && ex.en);
        if (!hasPos && !hasEx) return; // 在线结果不比离线丰富，不覆盖
        onlineUpgradeCache.set(word, resp);
        cacheOnlineDict(word, resp); // 【v2.17.5】持久化，下次免在线查询
        if (lastCardRender && lastCardRender.word === cleanWord(word) && cardEl && cardEl.className === "wh-card-visible") {
          renderCardBody(lastCardRender.body, lastCardRender.ph, resp);
          if (resp.phonetic || resp.usphone || resp.ukphone) {
            const phText = resp.usphone || resp.ukphone || resp.phonetic || "";
            if (phText) lastCardRender.ph.textContent = phText;
          }
          positionCard(cardEl._x, cardEl._y);
        }
      });
    } catch (e) { /* 后台不可用时静默跳过 */ }
  }

  /** 后台不可用/查询失败时的直连兜底（dictionaryapi.dev / MyMemory 均支持 CORS，
   *  content script 可直接 fetch；返回结构与 background 词典链一致） */
  async function fetchDictDirect(word) {
    if (!MEM_PRO) return { ok: false, word, error: "需要 PRO 会员：点击浏览器工具栏的 Panda 图标 → 账号，登录并激活" };
    try {
      const res = await fetch("https://api.dictionaryapi.dev/api/v2/entries/en/" + encodeURIComponent(word), { signal: AbortSignal.timeout(9000) });
      if (res.ok) {
        const data = await res.json();
        const e0 = Array.isArray(data) && data[0];
        if (e0) {
          const meanings = ((e0.meanings || []).slice(0, 3)).map((m) => ({
            pos: m.partOfSpeech || "",
            defs: (m.definitions || []).slice(0, 2).map((d) => ({ def: d.definition || "", ex: d.example || "" }))
          }));
          if (meanings.length) {
            return {
              ok: true,
              source: "en",
              word,
              phonetic: e0.phonetic || ((e0.phonetics || []).find((p) => p.text) || {}).text || "",
              meanings,
              examples: []
            };
          }
        }
      }
    } catch (e) { /* ignore，继续 MyMemory 兜底 */ }
    try {
      const res = await fetch("https://api.mymemory.translated.net/get?q=" + encodeURIComponent(word) + "&langpair=Autodetect|zh-CN", { signal: AbortSignal.timeout(9000) });
      const j = await res.json();
      const t = j && j.responseData && j.responseData.translatedText;
      if (t && t.toLowerCase() !== String(word).toLowerCase() && !/MYMEMORY WARNING/i.test(t)) {
        return { ok: true, source: "ai", word, usphone: "", ukphone: "", translations: ["[AI 翻译] " + t], examples: [] };
      }
    } catch (e) { /* ignore */ }
    return { ok: false, word, error: "未找到该词的释义" };
  }

  /** 扩展重载/更新后旧页面上下文失效的一次性提示（此时翻译/释义均不可用，刷新页面即恢复） */
  let ctxToastShown = false;
  function notifyCtxInvalidated() {
    if (ctxToastShown) return;
    ctxToastShown = true;
    try {
      const t = document.createElement("div");
      t.className = "notranslate";
      t.style.cssText = "position:fixed;z-index:2147483647;right:16px;bottom:16px;background:#1f2937;color:#fff;padding:10px 14px;border-radius:8px;font:13px/1.5 system-ui,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.3);";
      t.textContent = "生词高亮助手已更新，请刷新页面以恢复翻译和释义";
      (document.body || document.documentElement).appendChild(t);
      setTimeout(() => t.remove(), 8000);
    } catch (e) { /* ignore */ }
  }

  /** 词典查询失败收尾：直连兜底 → 按错误类型给出明确提示 */
  async function resolveDictFailure(word, resolve, bgError) {
    const direct = await fetchDictDirect(word);
    if (direct.ok) { resolve(direct); return; }
    if (/context invalidated/i.test(String(bgError))) {
      notifyCtxInvalidated();
      resolve({ ok: false, word, error: "扩展已更新，请刷新页面" });
    } else {
      resolve({ ok: false, word, error: bgError || "扩展后台不可用" });
    }
  }

  async function fetchDict(word) {
    // 【v2.17.5】持久化缓存命中（上次会话在线查到的释义）→ 直接返回，无需在线查询
    await ensureDictCache();
    // 【v2.17.4】已有在线升级结果（带词性/例句）优先返回
    if (onlineUpgradeCache.has(word)) return onlineUpgradeCache.get(word);
    if (persistentDictCache.has(word)) {
      const c = persistentDictCache.get(word);
      onlineUpgradeCache.set(word, c);
      return c;
    }
    const off = offlineDict(word);
    if (off) {
      // 离线释义先秒出，同时后台在线查词升级（词性、双语例句等）
      upgradeWithOnline(word, off);
      return Promise.resolve(off);
    }
    if (dictCache.has(word)) return dictCache.get(word);
    const p = new Promise((resolve) => {
      let settled = false;
      const finish = (r) => { if (!settled) { settled = true; resolve(r); } };
      const timer = setTimeout(() => {
        // 后台 15s 无响应（如 service worker 未唤醒）→ 直连兜底，稍后后台应答作废
        resolveDictFailure(word, finish, "查询超时").catch(() => finish({ ok: false, word, error: "查询超时" }));
      }, 15000);
      try {
        chrome.runtime.sendMessage({ type: "WH_DICT", word }, (resp) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) {
            // 后台不可达（如扩展重载后旧页上下文失效）→ 直连兜底
            resolveDictFailure(word, finish, chrome.runtime.lastError.message).catch(() => finish({ ok: false, word }));
            return;
          }
          // 后台正常应答：有结果直接用（含"未找到释义"，不再 9~18s 直连重试）；结构异常也兜底提示
          if (!resp || !resp.ok) {
            finish(resp && resp.error ? resp : { ok: false, word, error: "未找到该词的释义" });
            return;
          }
          const hasContent = ((resp.translations || []).some((t) => typeof t === "string" && t.trim())) || ((resp.meanings || []).length > 0);
          if (!hasContent) { finish({ ok: false, word, error: "未找到该词的释义" }); return; }
          finish(resp);
        });
      } catch (e) {
        clearTimeout(timer);
        // chrome.runtime 同步抛异常：扩展重载/更新后旧页面的 content script 上下文已失效
        resolveDictFailure(word, finish, String((e && e.message) || e)).catch(() => finish({ ok: false, word, error: "扩展后台不可用" }));
      }
    });
    // 失败不缓存（旧实现把失败结果永久缓存 → 本次会话内该词永远无释义、无法重试）
    // 【v2.17.5】在线查询成功 → 持久化，下次（含重启浏览器后）免在线查询
    p.then((r) => {
      if (!r || !r.ok) dictCache.delete(word);
      else if (r.source !== "vocab") cacheOnlineDict(word, r);
    });
    dictCache.set(word, p);
    return p;
  }

  /* ============================================================
   * 十、发音（v2.10.8 起统一由 tts_util.js 共享模块实现：
   * 本地 speechSynthesis 多语音 / 在线 OpenAI 兼容·有道·Google）
   * ============================================================ */
  function speak(word) {
    try {
      // 【v2.10.8】统一走共享 TTS 模块（本地多语音 / 在线 OpenAI 兼容·有道·Google，
      // 读取设置页实时配置；tts_util.js 未加载时降级本地朗读）
      if (window.WH_TTS && window.WH_TTS.speakText) {
        window.WH_TTS.speakText(word);
        return;
      }
      if (!("speechSynthesis" in window)) return;
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(word);
      u.lang = "en-US";
      u.rate = parseFloat(CONFIG.ttsRate) || 0.85;
      window.speechSynthesis.speak(u);
    } catch (e) { /* ignore */ }
  }

  /* ============================================================
   * 十一、生词本（storage.local）
   * ============================================================ */
  const WB_KEY = "wh_wordbook";
  let currentWordbookSet = new Set();

  async function loadWordbookSet() {
    try {
      const s = await chrome.storage.local.get(WB_KEY);
      const wb = s[WB_KEY] || [];
      currentWordbookSet = new Set(wb.map((e) => e.word));
    } catch (e) {
      currentWordbookSet = new Set();
    }
    return currentWordbookSet;
  }

  async function addToWordbook(word, ctx) {
    const w = cleanWord(word);
    try {
      const s = await chrome.storage.local.get(WB_KEY);
      const wb = s[WB_KEY] || [];
      const i = wb.findIndex((e) => e.word === w);
      if (i >= 0) {
        wb[i].ctx = ctx || wb[i].ctx;
        wb[i].ts = Date.now();
      } else {
        wb.unshift({ word: w, ctx: ctx || "", ts: Date.now() });
      }
      await chrome.storage.local.set({ [WB_KEY]: wb });
      currentWordbookSet.add(w);
    } catch (e) { /* ignore */ }
  }

  async function removeFromWordbook(word) {
    const w = cleanWord(word);
    try {
      const s = await chrome.storage.local.get(WB_KEY);
      const wb = s[WB_KEY] || [];
      const nw = wb.filter((e) => e.word !== w);
      await chrome.storage.local.set({ [WB_KEY]: nw });
      currentWordbookSet.delete(w);
    } catch (e) { /* ignore */ }
  }

  async function toggleWordbook(word, ctx) {
    if (currentWordbookSet.has(word)) {
      await removeFromWordbook(word);
      return false;
    }
    await addToWordbook(word, ctx);
    return true;
  }

  /* ============================================================
   * 十二、悬浮卡片（详细释义，右键打开）
   * ============================================================ */
  let cardEl = null;
  let cardWord = null;
  let cardCtx = ""; // 卡片对应单词所在句子（点"加入生词本"时一并保存为生词语境）
  let cardOpenedAt = 0; // 【v2.17.3】开卡时间戳：内部页面点击开卡的同一次 click 冒泡到 document 时不当作"点外部关闭"
  let quickTipEl = null;
  let quickTipTimer = null;

  function ensureCard() {
    if (cardEl) return cardEl;
    cardEl = document.createElement("div");
    cardEl.id = "wh-tooltip";
    cardEl.className = "wh-card-hidden";
    document.documentElement.appendChild(cardEl);
    return cardEl;
  }

  function ensureQuickTip() {
    if (quickTipEl) return quickTipEl;
    quickTipEl = document.createElement("div");
    quickTipEl.id = "wh-quicktip";
    quickTipEl.className = "wh-qt-hidden";
    document.documentElement.appendChild(quickTipEl);
    return quickTipEl;
  }

  function positionCard(x, y) {
    if (!cardEl) return;
    const rect = cardEl.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let left = x + 12;
    let top = y + 18;
    if (left + rect.width > vw - 8) left = x - rect.width - 12;
    if (left < 8) left = 8;
    if (top + rect.height > vh - 8) top = y - rect.height - 10;
    if (top < 8) top = 8;
    cardEl.style.left = left + "px";
    cardEl.style.top = top + "px";
  }

  function positionQuickTip(x, y) {
    if (!quickTipEl) return;
    const rect = quickTipEl.getBoundingClientRect();
    const vw = window.innerWidth;
    let left = x;
    let top = y - rect.height - 8;
    if (left + rect.width > vw - 8) left = vw - rect.width - 8;
    if (left < 8) left = 8;
    if (top < 8) top = y + 18;
    quickTipEl.style.left = left + "px";
    quickTipEl.style.top = top + "px";
  }

  function hideCard() {
    cardWord = null;
    cardCtx = ""; // 关闭卡片时清空语境，避免下次开卡时残留
    lastCardRender = null; // 【v2.17.4】卡片关闭后不再接受在线结果刷新
    if (cardEl) cardEl.className = "wh-card-hidden";
  }

  function hideQuickTip() {
    clearTimeout(quickTipTimer);
    if (quickTipEl) quickTipEl.className = "wh-qt-hidden";
  }

  /* ---------- 词根词缀分析 ---------- */
  // 常见整词黑名单：避免 en-/ex-/im- 等前缀误命中（english、example、important 等）
  const AFFIX_STOP_WORDS = new Set([
    "english", "energy", "enjoy", "enter", "entire", "entity", "every", "ever", "evening", "even", "event",
    "example", "except", "exact", "examine", "exist", "exercise", "interest", "important", "imagine",
    "image", "issue", "information", "include", "increase", "indeed", "inside", "insist", "instant",
    "instead", "invent", "involve", "open", "over", "under", "until", "upon", "use", "usual", "unit",
    "union", "unique", "universe", "united", "inform", "item", "in", "on", "at", "out", "off"
  ]);

  function analyzeAffixes(word) {
    if (AFFIX_STOP_WORDS.has(word)) return [];
    const hits = [];
    for (const a of AFFIXES) {
      if (a.type === "prefix" && word.startsWith(a.aff)) {
        // 前缀后必须还有至少 2 个字母成词
        if (word.length - a.aff.length >= 2) hits.push(a);
      } else if (a.type === "suffix" && word.endsWith(a.aff)) {
        if (word.length - a.aff.length >= 2) hits.push(a);
      } else if (a.type === "root" && word.startsWith(a.aff)) {
        if (word.length - a.aff.length >= 2) hits.push(a);
      }
    }
    // 去重（同 aff 不同 type），限制 4 条
    const seen = new Set();
    const out = [];
    for (const h of hits) {
      if (seen.has(h.aff + h.type)) continue;
      seen.add(h.aff + h.type);
      out.push(h);
      if (out.length >= 4) break;
    }
    return out;
  }

  /* ---------- 关联词汇（词库内同根词，带等级与释义） ---------- */
  const relatedCache = new Map();
  const firstCharIndex = (() => {
    const m = new Map();
    if (!VOCAB) return m;
    for (const lv of LEVEL_ORDER) {
      const list = VOCAB.lists[lv] || [];
      for (const w of list) {
        const c = w.charAt(0);
        if (!m.has(c)) m.set(c, []);
        m.get(c).push(w);
      }
    }
    return m;
  })();

  function commonPrefixLen(a, b) {
    const n = Math.min(a.length, b.length);
    let i = 0;
    while (i < n && a[i] === b[i]) i++;
    return i;
  }

  function isRelated(a, b) {
    if (a === b) return false;
    const cp = commonPrefixLen(a, b);
    if (cp < 4) return false;
    const minLen = Math.min(a.length, b.length);
    const maxLen = Math.max(a.length, b.length);
    if (cp < minLen - 1) return false;
    if (maxLen - minLen > 5) return false;
    return true;
  }

  function relatedWords(word) {
    if (relatedCache.has(word)) return relatedCache.get(word);
    const group = firstCharIndex.get(word.charAt(0)) || [];
    const out = [];
    for (const cand of group) {
      if (!isRelated(word, cand)) continue;
      const m = META[cand];
      out.push({
        word: cand,
        lv: (m && m[2] !== undefined) ? m[2] : -1,
        trans: (m && m[0]) || []
      });
      if (out.length >= 6) break;
    }
    relatedCache.set(word, out);
    return out;
  }

  /* ---------- 渲染卡片 ---------- */
  async function showCard(word, x, y, ctx) {
    // 内部页面（生词本/背单词）由 pro-gate.js 负责遮罩；普通网页在此再做一次本地门禁
    if (!IS_INTERNAL_PAGE && (!MEM_PRO || !CONFIG.enabled)) return;
    hideQuickTip();
    hideCard();
    cardWord = cleanWord(word);
    cardOpenedAt = Date.now(); // 【v2.17.3】标记本次开卡，防止开卡点击冒泡到 document 被立即关闭
    cardCtx = (typeof ctx === "string" ? ctx : "") || ""; // 生词语境（右键时所在句子）；高亮 span 路径会从 data-wh-ctx 传入
    const card = ensureCard();
    card._x = x;
    card._y = y;
    card.className = "wh-card-visible";
    card.textContent = "";

    // 头部
    const head = document.createElement("div");
    head.className = "wh-tip-head";
    const wSpan = document.createElement("span");
    wSpan.className = "wh-tip-word";
    wSpan.textContent = word;
    head.appendChild(wSpan);
    const ph = document.createElement("span");
    ph.className = "wh-tip-phonetic";
    head.appendChild(ph);
    const speakBtn = document.createElement("button");
    speakBtn.className = "wh-tip-speak";
    speakBtn.textContent = "🔊";
    speakBtn.title = "播放发音";
    speakBtn.addEventListener("click", (e) => { e.stopPropagation(); speak(word); });
    head.appendChild(speakBtn);
    const closeBtn = document.createElement("button");
    closeBtn.className = "wh-tip-close";
    closeBtn.textContent = "✕";
    closeBtn.title = "关闭卡片（Esc）";
    closeBtn.addEventListener("click", (e) => { e.stopPropagation(); hideCard(); });
    head.appendChild(closeBtn);
    card.appendChild(head);

    // 主体
    const body = document.createElement("div");
    body.className = "wh-tip-body";
    card.appendChild(body);

    // 生词语境预览（点 ＋ 加入生词本时会随句保存到生词条目）
    const ctxPreview = document.createElement("div");
    ctxPreview.className = "wh-tip-ctx";
    if (cardCtx) {
      ctxPreview.innerHTML = '<div class="wh-tip-ctx-en">「' + escapeHtml(cardCtx) + '」</div>'
        + '<div class="wh-tip-ctx-zh wh-tip-ctx-loading">翻译中…</div>';
      ctxPreview.style.display = "block";
      translateSentence(cardCtx, "zh").then((res) => {
        const zhEl = ctxPreview.querySelector(".wh-tip-ctx-zh");
        if (!zhEl) return;
        if (res.ok && res.text && res.text.trim()) {
          zhEl.textContent = res.text.trim();
          zhEl.classList.remove("wh-tip-ctx-loading");
        } else {
          zhEl.style.display = "none";
        }
      }).catch(() => {
        const zhEl = ctxPreview.querySelector(".wh-tip-ctx-zh");
        if (zhEl) zhEl.style.display = "none";
      });
    } else {
      ctxPreview.style.display = "none";
    }
    card.appendChild(ctxPreview);

    // 底部操作条
    const foot = document.createElement("div");
    foot.className = "wh-tip-foot";
    const markBtn = document.createElement("button");
    markBtn.className = "wh-tip-markbtn";
    const syncMarkBtn = () => {
      const inWb = currentWordbookSet.has(cardWord);
      if (inWb) markBtn.textContent = "✓ 在生词本（点击移除）";
      else markBtn.textContent = cardCtx ? "＋ 加入生词本（含语境）" : "＋ 加入生词本";
    };
    syncMarkBtn();
    markBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const added = await toggleWordbook(cardWord, cardCtx);
      syncMarkBtn();
      rebuildKnownSet();
      flashFeedback(cardWord, added, cardCtx);
      // 页面标记由 storage.onChanged 监听（重扫）自动更新，此处无需手动处理
    });
    foot.appendChild(markBtn);

    const knownBtn = document.createElement("button");
    knownBtn.className = "wh-tip-knownbtn";
    knownBtn.textContent = "✓ 已掌握（不再高亮）";
    knownBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      await markAsKnown(cardWord);
      hideCard();
      flashFeedback(cardWord, false, "已标记为已掌握");
    });
    foot.appendChild(knownBtn);

    const copyBtn = document.createElement("button");
    copyBtn.className = "wh-tip-copy";
    copyBtn.textContent = "复制";
    copyBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      try {
        await navigator.clipboard.writeText(cardWord);
        copyBtn.textContent = "已复制";
        setTimeout(() => (copyBtn.textContent = "复制"), 1200);
      } catch (err) { /* ignore */ }
    });
    foot.appendChild(copyBtn);
    card.appendChild(foot);

    positionCard(x, y);

    // 加载占位（防止查询期间卡片主体空白）
    const loading = document.createElement("div");
    loading.className = "wh-tip-empty";
    loading.textContent = "查询中…";
    body.appendChild(loading);

    let result;
    try {
      result = await fetchDict(cardWord);
      if (cardWord !== cleanWord(word)) return;
      renderCardBody(body, ph, result);
      // 【v2.17.4】记录渲染句柄：离线释义秒出后，在线结果（带词性/例句）回来时原地刷新
      lastCardRender = { word: cardWord, body, ph };
    } catch (err) {
      // 渲染链路异常也不留空白卡片：显示具体错误便于排查
      body.textContent = "";
      const errDiv = document.createElement("div");
      errDiv.className = "wh-tip-empty";
      errDiv.textContent = "释义加载失败：" + String((err && err.message) || err);
      body.appendChild(errDiv);
    }
    if (result && result.ok && CONFIG.autoSpeak) speak(word);
  }

  function renderCardBody(body, phEl, result) {
    body.textContent = "";

    if (result.error || !result.ok) {
      const empty = document.createElement("div");
      empty.className = "wh-tip-empty";
      empty.textContent = (result.error || "未找到该词的释义") + "，请检查拼写";
      body.appendChild(empty);
      positionCard(cardEl._x, cardEl._y);
      return;
    }

    // 音标
    const phText = result.usphone || result.ukphone || result.phonetic || "";
    if (phEl && phText) phEl.textContent = phText;

    // 释义（按词性分组，每个词性默认单行显示，超出一行则折叠，点击展开）
    const defBlock = document.createElement("div");
    defBlock.className = "wh-tip-meaning";
    const src = result.source === "vocab" ? "" : (result.source === "ai" ? "[AI 翻译] " : "");
    if (src) {
      const srcLine = document.createElement("div");
      srcLine.className = "wh-tip-def";
      srcLine.textContent = src;
      defBlock.appendChild(srcLine);
    }

    const groups = groupTranslations(result.translations || []);
    for (const g of groups.slice(0, 6)) {
      // 去除“【名】……（人名）”这类专有名词说明
      if (/^【.*名.*】$/.test(g.pos)) continue;
      const defLine = document.createElement("div");
      defLine.className = "wh-tip-def";

      const posSpan = document.createElement("span");
      posSpan.className = "wh-tip-pos";
      posSpan.textContent = g.pos || "释义";
      defLine.appendChild(posSpan);

      const textSpan = document.createElement("span");
      textSpan.className = "wh-tip-def-text";
      textSpan.textContent = g.lines.join("；");
      defLine.appendChild(textSpan);

      const moreBtn = document.createElement("button");
      moreBtn.type = "button";
      moreBtn.className = "wh-tip-def-more";
      moreBtn.textContent = "展开";
      moreBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const expanding = !textSpan.classList.contains("expanded");
        textSpan.classList.toggle("expanded");
        moreBtn.textContent = expanding ? "收起" : "展开";
      });
      defLine.appendChild(moreBtn);
      defBlock.appendChild(defLine);
    }
    // 渲染完成后根据实际高度隐藏不需要的展开按钮
    updateDefExpandButtons(defBlock);

    if (result.source === "en") {
      for (const m of (result.meanings || []).slice(0, 2)) {
        const pos = m.pos || "";
        for (const d of m.defs) {
          const defLine = document.createElement("div");
          defLine.className = "wh-tip-def";
          defLine.textContent = (pos ? pos + " " : "· ") + d.def;
          defBlock.appendChild(defLine);
        }
      }
    }
    body.appendChild(defBlock);

    // 例句（双语，优先取后台返回的 examples）
    const examples = (result.examples || []).filter((ex) => ex && (ex.en || typeof ex === "string"));
    if (examples.length) {
      const exBlock = document.createElement("div");
      exBlock.className = "wh-tip-section";
      const exTitle = document.createElement("div");
      exTitle.className = "wh-tip-section-title";
      exTitle.textContent = "💬 例句";
      exBlock.appendChild(exTitle);
      for (const ex of examples.slice(0, 3)) {
        const en = ex.en || (typeof ex === "string" ? ex : "");
        const zh = ex.zh || "";
        const line = document.createElement("div");
        line.className = "wh-tip-example";
        line.innerHTML = '<div class="wh-tip-ex-en">' + escapeHtml(en) + '</div>'
          + (zh ? '<div class="wh-tip-ex-zh">' + escapeHtml(zh) + '</div>' : "");
        exBlock.appendChild(line);
      }
      body.appendChild(exBlock);
    }

    // 词根词缀
    const affixes = analyzeAffixes(result.word);
    if (affixes.length) {
      const affBlock = document.createElement("div");
      affBlock.className = "wh-tip-section";
      const title = document.createElement("div");
      title.className = "wh-tip-section-title";
      title.textContent = "词根词缀";
      affBlock.appendChild(title);
      for (const a of affixes.slice(0, 3)) {
        const line = document.createElement("div");
        line.className = "wh-tip-affix";
        line.textContent = (a.type === "prefix" ? "前缀 " : a.type === "suffix" ? "后缀 " : "词根 ") + a.aff + "： " + a.mean;
        affBlock.appendChild(line);
      }
      body.appendChild(affBlock);
    }

    // 关联词汇
    const rels = relatedWords(result.word);
    if (rels.length) {
      const relBlock = document.createElement("div");
      relBlock.className = "wh-tip-section";
      const title = document.createElement("div");
      title.className = "wh-tip-section-title";
      title.textContent = "关联词汇";
      relBlock.appendChild(title);
      for (const r of rels.slice(0, 5)) {
        const line = document.createElement("button");
        line.type = "button";
        line.className = "wh-tip-related";
        const wSpan = document.createElement("span");
        wSpan.className = "wh-rel-word";
        wSpan.textContent = r.word;
        line.appendChild(wSpan);
        if (r.lv >= 0) {
          const lv = document.createElement("span");
          lv.className = "wh-rel-lv";
          lv.textContent = LEVEL_LABELS[LEVEL_ORDER[r.lv]] || "";
          line.appendChild(lv);
        }
        const t = (r.trans || [])[0] || "";
        if (t) {
          const tSpan = document.createElement("span");
          tSpan.className = "wh-rel-trans";
          tSpan.textContent = t;
          line.appendChild(tSpan);
        }
        line.title = "点击查看该词释义";
        line.addEventListener("click", (e) => {
          e.stopPropagation();
          showCard(r.word, cardEl._x + 20, cardEl._y + 20);
        });
        relBlock.appendChild(line);
      }
      body.appendChild(relBlock);
    }
    positionCard(cardEl._x, cardEl._y);
  }

  /* ============================================================
   * 十三、简略翻译气泡（悬停显示）
   * ============================================================ */
  let quickTipWord = null;
  let qtFetchSeq = 0;

  function showQuickTip(word, x, y) {
    clearTimeout(quickTipTimer);
    const seq = ++qtFetchSeq;
    quickTipWord = cleanWord(word);
    const tip = ensureQuickTip();
    tip.className = "wh-qt-visible";
    tip.textContent = "";
    const wSpan = document.createElement("span");
    wSpan.className = "wh-qt-word";
    wSpan.textContent = word;
    tip.appendChild(wSpan);
    const tSpan = document.createElement("span");
    tSpan.className = "wh-qt-trans";
    tSpan.textContent = "…";
    tip.appendChild(tSpan);
    positionQuickTip(x, y);

    fetchDict(quickTipWord).then((result) => {
      if (seq !== qtFetchSeq) return;
      const cur = tip.querySelector(".wh-qt-trans");
      if (!cur) return;
      if (result.ok) {
        const zh = result.source === "youdao" || result.source === "vocab" || result.source === "ai"
          ? ((result.translations || [])[0] || "（无中文释义）")
          : ((result.meanings || []).map((m) => m.defs[0] ? m.defs[0].def : "").filter(Boolean).join("；") || "（无释义）");
        cur.textContent = zh;
      } else {
        cur.textContent = "未找到释义";
      }
      positionQuickTip(x, y);
    });
    if (CONFIG.autoSpeak) speak(word);
  }

  function scheduleHideQuickTip() {
    clearTimeout(quickTipTimer);
    quickTipTimer = setTimeout(hideQuickTip, 220);
  }

  /* ============================================================
   * 十四、取鼠标位置处的单词
   * ============================================================ */
  function wordAtPoint(x, y) {
    try {
      const range = document.caretRangeFromPoint ? document.caretRangeFromPoint(x, y) : null;
      if (!range) return null;
      const node = range.startContainer;
      if (!node || node.nodeType !== Node.TEXT_NODE) return null;
      const text = node.nodeValue;
      if (!text) return null;
      let s = range.startOffset;
      let e = range.startOffset;
      while (s > 0 && /[A-Za-z'’\-]/.test(text[s - 1])) s--;
      while (e < text.length && /[A-Za-z'’\-]/.test(text[e])) e++;
      const raw = text.slice(s, e);
      if (!/[A-Za-z]/.test(raw)) return null;
      return { word: cleanWord(raw), ctx: extractContext(text, s), node, start: s, end: e };
    } catch (err) {
      return null;
    }
  }

  /* ============================================================
   * 十五、生词管理（已掌握 / 移出生词本）
   * ============================================================ */
  async function markAsKnown(word) {
    const w = cleanWord(word);
    USER_WORDS.add(w);
    try {
      await chrome.storage.sync.set({ userWords: [...USER_WORDS] });
    } catch (e) { /* ignore */ }
    if (currentWordbookSet.has(w)) await removeFromWordbook(w);
    rebuildKnownSet();
    // 移除该词在页面上的标记与高亮（【v2.17.13】合并回原句并防重译，见 unhighlightSpan）
    const sel = 'span[data-wh-word="' + CSS.escape(w) + '"]';
    document.querySelectorAll(sel).forEach(unhighlightSpan);
  }

  /* ============================================================
   * 十六、事件绑定
   * ============================================================ */
  // 悬停 → 简略气泡
  document.addEventListener("mouseover", (e) => {
    if (!CONFIG.enabled || !CONFIG.quickTip || !MEM_PRO) return;
    if (cardWord) return; // 卡片打开时不显示气泡
    const span = e.target.closest ? e.target.closest(".wh-highlight,.wh-marked") : null;
    if (!span) return;
    clearTimeout(quickTipTimer);
    const rect = span.getBoundingClientRect();
    showQuickTip(span.getAttribute("data-wh-word"), rect.left, rect.top);
  });

  document.addEventListener("mouseout", (e) => {
    const span = e.target.closest ? e.target.closest(".wh-highlight,.wh-marked") : null;
    if (!span) return;
    const rt = e.relatedTarget;
    if (rt && rt.closest && (rt.closest("#wh-quicktip") || rt.closest("#wh-tooltip"))) return;
    scheduleHideQuickTip();
  });

  // 点击卡片外部 → 关闭卡片
  document.addEventListener("click", (e) => {
    if (cardWord && cardEl && cardEl.className === "wh-card-visible") {
      // 【v2.17.3】内部页面点击单词开卡：开卡的同一次 click 事件会继续冒泡到 document，
      // 不处理，否则卡片刚打开就被立即关闭（表现为"点击没反应"）
      if (Date.now() - cardOpenedAt < 300) return;
      if (!(e.target.closest && e.target.closest("#wh-tooltip"))) hideCard();
    }
  });

  // 取词开卡共享逻辑（右键与 A 键共用）：在 (x,y) 处取词并打开/关闭详细释义卡片
  function openWordCardAt(x, y, targetEl) {
    const wp = wordAtPoint(x, y);
    const span = targetEl && targetEl.closest ? targetEl.closest(".wh-highlight,.wh-marked") : null;
    const word = span ? span.getAttribute("data-wh-word") : (wp ? wp.word : null);
    if (!word) return false; // 非单词区域
    if (cardWord === word && cardEl && cardEl.className === "wh-card-visible") {
      hideCard(); // 再按一次 → 关闭（与右键 toggle 行为一致）
      return true;
    }
    // 收集语境：高亮 span 已存 data-wh-ctx；普通文本节点由 wordAtPoint 实时从所在句切出
    const cardCtxHere = span
      ? (span.getAttribute("data-wh-ctx") || "")
      : (wp ? (wp.ctx || "") : "");
    showCard(word, x, y, cardCtxHere);
    return true;
  }

  // 暴露卡片接口，供内部页面（背单词 / 生词本 / 设置 / popup）复用
  window.WH_SHOW_CARD = showCard;

  // 内部页面只提供悬浮查词能力，不执行网页高亮/翻译/监听
  if (IS_INTERNAL_PAGE) {
    loadWordbookSet().catch(() => {});
    return;
  }

  // 右键 → 打开/关闭详细释义卡片
  document.addEventListener("contextmenu", (e) => {
    if (!CONFIG.enabled || !MEM_PRO) return;
    if (e.target.closest && e.target.closest("#wh-tooltip,#wh-quicktip")) return;
    if (openWordCardAt(e.clientX, e.clientY, e.target)) e.preventDefault();
  });

  // 后台消息（重新扫描）
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg) return false;
    if (msg.type === "WH_RESCAN") {
      // 先刷新配置再重扫，确保等级/主题等最新设置立即生效
      loadConfig().then(() => {
        unhighlightAll();
        scan(document.body);
        sendResponse({ ok: true });
      });
      return true;
    }
    return false;
  });

  window.addEventListener("scroll", (e) => {
    // 【v2.9.9】卡片自身滚动（内容超长时）不关闭卡片——capture 监听会捕获
    // #wh-tooltip 内部的 scroll 事件，旧逻辑导致用户在卡片内滚轮一滚即被关闭
    if (e.target && e.target.closest && e.target.closest("#wh-tooltip,#wh-quicktip")) return;
    hideCard();
    hideQuickTip();
  }, true);
  window.addEventListener("resize", () => { hideCard(); hideQuickTip(); });

  // 跟踪最近一次鼠标位置（A 键取词的锚点：与右键同在鼠标处取词）
  let lastMouse = null;
  document.addEventListener("mousemove", (e) => {
    lastMouse = { x: e.clientX, y: e.clientY };
  }, { passive: true });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { hideCard(); hideQuickTip(); return; }
    // A 键 → 与右键相同的取词开卡（Ctrl/Meta/Alt 修饰键组合不拦截，如 Ctrl+A 全选；
    // 焦点在输入框/可编辑区域/翻译卡片内时不触发，避免影响打字）
    if ((e.key === "a" || e.key === "A") && !e.ctrlKey && !e.metaKey && !e.altKey
      && !e.repeat && CONFIG.enabled && MEM_PRO) {
      const ae = document.activeElement;
      if (ae && (ae.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(ae.tagName))) return;
      // 锚点优先用最近鼠标位置；页面加载后鼠标未动过则用当前选区中心（双击选中场景）
      let x = null, y = null;
      if (lastMouse) {
        x = lastMouse.x; y = lastMouse.y;
      } else {
        try {
          const sel = window.getSelection();
          if (sel && !sel.isCollapsed && sel.rangeCount) {
            const r = sel.getRangeAt(0).getBoundingClientRect();
            if (r && (r.width || r.height)) { x = r.left + r.width / 2; y = r.top + r.height / 2; }
          }
        } catch (err) { /* ignore */ }
      }
      if (x == null || y == null) return;
      const el = document.elementFromPoint(x, y);
      if (!el) return;
      if (el.closest && el.closest("#wh-tooltip,#wh-quicktip")) return;
      openWordCardAt(x, y, el);
    }
  });

  function flashFeedback(word, added, altText, withCtx) {
    try {
      const fb = document.createElement("div");
      fb.className = added ? "wh-feedback wh-feedback-add" : "wh-feedback wh-feedback-remove";
      const baseText = altText || (added ? "✓ 已加入生词本" : "已移出生词本");
      fb.textContent = added && withCtx ? baseText + "（含语境）" : baseText;
      document.documentElement.appendChild(fb);
      setTimeout(() => fb.remove(), 1200);
    } catch (e) { /* ignore */ }
  }

  /* ============================================================
   * 十七、配置加载与响应
   * ============================================================ */
  async function loadConfig() {
    try {
      const s = await chrome.storage.sync.get(DEFAULTS);
      CONFIG = { ...DEFAULTS, ...s };
      // v2.6.6 一次性迁移：旧版默认"对照式(inline)"并排堆叠导致页面排版混乱
      // → 迁移为"覆盖式(replace)"（仅一次；此后用户可在设置页自由改回 inline）
      if (!s.modeMigrated266) {
        CONFIG.translateMode = "replace";
        chrome.storage.sync.set({ modeMigrated266: true, translateMode: "replace" }).catch(() => {});
      }
      USER_WORDS = new Set(normalizeUserWords(s.userWords));
      KNOWN_WORDS = new Set(normalizeUserWords(s.knownWords));
    } catch (e) {
      CONFIG = { ...DEFAULTS };
      USER_WORDS = new Set();
    }
    rebuildKnownSet();
    applyGlobalStyle();
    applyTheme();
    ensureYtTakeover(); // 【v2.17.5】YouTube 字幕接管按钮随配置显示/隐藏
    // 【v2.17.6】接管中时，翻译模式等设置变更立即重渲染字幕条（无需等下一次字幕更新）
    if (YT_TAKEOVER.active && YT_TAKEOVER.sync) {
      ensureCueEngine(); // 【v2.17.7】逐句↔逐词切换：启/停 cue 引擎
      YT_TAKEOVER.forceRender = true;
      YT_TAKEOVER.sync();
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    // 【v2.17.20】会员状态变化（登录/兑换/登出）→ 立即生效
    if (area === "local" && changes.wh_membership) {
      const m = changes.wh_membership.newValue;
      const wasPro = MEM_PRO;
      membershipEpoch++;
      MEM_PRO = membershipIsPro(m);
      if (wasPro === MEM_PRO) return;
      if (MEM_PRO) {
        // 变为 PRO：按当前配置启用高亮/翻译
        if (CONFIG.enabled) {
          if (translateActive()) applyTranslation();
          else { scan(document.body); initObserver(); }
        }
      } else {
        // 失去 PRO：清掉页面上的高亮与译文
        hideCard();
        hideQuickTip();
        stopObserver();
        unhighlightAll();
        clearTranslations();
        try { stopYtTakeover(); } catch (e) { /* ignore */ }
      }
      // 会员变化时同步维护 YouTube 接管按钮（非 PRO 不显示入口）
      try { ensureYtTakeover(); } catch (e) { /* ignore */ }
      return;
    }
    // 生词本变化（生词本页面添加/移除）→ 立即更新页面标记与高亮
    if (area === "local" && changes[WB_KEY]) {
      const nv = (changes[WB_KEY].newValue) || [];
      currentWordbookSet = new Set(nv.map((e) => e.word));
      rebuildKnownSet();
      if (CONFIG.enabled) {
        if (translateActive()) {
          // 【v2.18.4 空高亮/文字错位修复】翻译进行中不做 unhighlightAll + 重扫：
          //  译文 span 已经插在原文节点之间，此时取消高亮会合并相邻文本节点（可能吞掉
          //  被译文切开的原文片段），随后重扫又在"原文 + 译文"混排的结构上拆分文本节点，
          //  页面会出现**空的高亮色块**和文字错位（实测：翻译 + 加入生词本 → 空黄块）。
          //  这里只就地更新"已收录"标记（.wh-marked），不碰 DOM 结构。
          markWordbookOnPage();
        } else {
          unhighlightAll();
          scan(document.body);
        }
      }
      return;
    }
    if (area !== "sync") return;
    const trChanged = changes.translateEnabled || changes.translateService || changes.translateMode || changes.noTranslateSites;
    const wasEnabled = CONFIG.enabled;
    loadConfig().then(() => {
      const isEnabled = CONFIG.enabled;
      if (wasEnabled && !isEnabled) {
        hideCard();
        hideQuickTip();
        stopObserver();
        unhighlightAll();
        clearTranslations();
      } else if (!wasEnabled && isEnabled) {
        scan(document.body);
        initObserver();
        if (translateActive()) applyTranslation();
      } else if (isEnabled) {
        if (trChanged) {
          applyTranslation();
        } else {
          unhighlightAll();
          scan(document.body);
        }
      }
    });
  });

  /** 补漏重扫：个别节点因服务瞬时失败/处理竞态被跳过（失败路径已回滚去重键）→
   *  延迟重走一遍翻译（已译节点有 translatedNodes/translatedBlocks 标记，不会重复翻译） */
  function schedulePatchSweep() {
    const sweep = () => { if (translateActive()) translateRoot(document.body).catch(() => {}); };
    setTimeout(sweep, 4000);
    setTimeout(sweep, 10000);
  }

  /** 按当前翻译设置（重新）应用网页翻译 */
  async function applyTranslation() {
    clearTranslations();
    if (!translateActive()) {
      // 关闭翻译（或当前页在白名单）：移除译文后恢复高亮
      stopObserver();
      unhighlightAll();
      scan(document.body);
      initObserver();
      return;
    }
    if (CONFIG.translateMode === "replace") {
      stopObserver();
      unhighlightAll(); // 覆盖模式先清掉英文高亮，避免漏译
    }
    await translateRoot(document.body);
    scan(document.body);
    initObserver();
    schedulePatchSweep();
  }

  /* ============================================================
   * 十八、启动
   * ============================================================ */
  (async () => {
    // 检测页面背景明暗：深色网页 → 译文用浅色字（与深色网页上的可读性一致）
    applyPageDark();
    // 清理上一脚本实例残留的译文（扩展更新/重载后 content script 重新注入，
    // 旧 DOM 里的译文 span 若不清理会被再次翻译，造成重复译文）
    try {
      if (document.querySelectorAll(".wh-tr").length) clearTranslations();
    } catch (e) { /* ignore */ }
    // 清理页面上残留的高亮（旧版注入 / 上次会话遗留的高亮 span，如"无"等级仍显示高亮），
    // 再按当前配置重新扫描 —— 否则 scan 会跳过已高亮 span 导致残留永不消失
    try {
      unhighlightAll();
    } catch (e) { /* ignore */ }
    await loadConfig();
    await loadWordbookSet();
    await loadMembership(); // 【v2.17.20】先判定会员，非 PRO 不启用任何功能
    ensureYtTakeover();    // PRO 状态确定后再决定是否显示 YouTube 接管入口
    rebuildKnownSet();
    if (CONFIG.enabled && MEM_PRO) {
      if (translateActive()) {
        if (CONFIG.translateMode === "replace") {
          stopObserver();
          unhighlightAll();
        }
        await translateRoot(document.body);
        scan(document.body);
        initObserver();
        schedulePatchSweep();
      } else {
        scan(document.body);
        initObserver();
      }
    }
  })();
})();
