/* 生词高亮 & 翻译助手 —— popup 逻辑 v2.1 */
"use strict";

const $ = (sel) => document.querySelector(sel);
const IS_EXT = WH_STORE.IS_EXT;

/* 存储 helper：使用共享 storage.js 模块 */
const STORE = {
  async get(defs) { return WH_STORE.syncGet(defs); },
  async set(patch) { return WH_STORE.syncSet(patch); },
  async localGet(key) { return WH_STORE.localGet(key); }
};

function isProMembership(st) {
  if (!st || !st.signed_in || !st.pro) return false;
  if (!st.expires_at) return true;
  const t = typeof st.expires_at === "number" ? st.expires_at : Date.parse(st.expires_at);
  return Number.isFinite(t) && t > Date.now();
}

async function refreshState() {
  const s = await STORE.get({ enabled: true, theme: "light", translateEnabled: false, level: "none", translateMode: "replace", noTranslateSites: [] });
  $("#toggle").checked = s.enabled;
  updateThemeBtn(s.theme);
  updateTrBtn(s.translateEnabled);
  updateTrModeBtn(s.translateMode);
  // 白名单按钮状态（当前标签页 hostname 是否已加入）
  updateWlBtn(await currentTabInWhitelist(s.noTranslateSites || []));
  // 小窗口自身跟随主题（与设置页一致）
  let resolved = s.theme;
  if (s.theme === "auto") {
    resolved = (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light";
  }
  document.documentElement.setAttribute("data-wh-theme", resolved);
  const levelLabel = { none: "未选择", primary: "小学", junior: "初中", senior: "高中", cet4: "四级", cet6: "六级", kaoyan: "考研", toefl: "托福", sat: "SAT" }[s.level] || s.level;
  const hint = $("#hint");
  if (hint) {
    hint.textContent = "悬停生词看简略翻译 · 右键详细释义\n当前词汇等级：" + levelLabel + "（设置页可改）";
    hint.style.whiteSpace = "pre-line";
  }
  const ver = $("#ver");
  if (ver && IS_EXT && chrome.runtime && chrome.runtime.getManifest) {
    ver.textContent = "v" + chrome.runtime.getManifest().version;
  }
  try {
    const w = await STORE.localGet("wh_wordbook");
    const wb = w.wh_wordbook || [];
    const cnt = $("#wb-count");
    const prev = cnt.textContent;
    cnt.textContent = wb.length;
    // 数字变化时轻微回弹（prefers-reduced-motion 时 ui-tokens.css 已禁用）
    if (prev !== String(wb.length)) {
      cnt.classList.remove("ui-pop");
      void cnt.offsetWidth;
      cnt.classList.add("ui-pop");
    }
  } catch (e) { /* ignore */ }
  // 账号状态：先读缓存立即渲染（PRO 用户不会因后台网络慢被误禁用），
  // 再等后台最新结果；超时则保留缓存，避免 1.5s 直接把 PRO 按钮锁死。
  if (IS_EXT) {
    let cached = null;
    try {
      const c = await STORE.localGet("wh_membership");
      cached = (c && c.wh_membership) || null;
    } catch (e) { /* ignore */ }
    updateAcctBtn(cached);
    applyProGate(cached);

    const st = await new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        resolve(cached);
      }, 6000);
      try {
        chrome.runtime.sendMessage({ type: "WH_AUTH_STATE" }, (r) => {
          void chrome.runtime.lastError;
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          resolve(r || cached);
        });
      } catch (e) {
        clearTimeout(timer);
        if (!settled) { settled = true; resolve(cached); }
      }
    });
    updateAcctBtn(st);
    applyProGate(st);
  }
}

/* 【v2.17.20】会员门禁：非 PRO 禁用 popup 内所有功能入口，显示激活横幅 */
function applyProGate(st) {
  const pro = isProMembership(st);
  const gate = $("#pro-gate");
  if (gate) gate.classList.toggle("hidden", pro);
  const ids = ["#toggle", "#tr-btn", "#trmode-btn", "#wl-btn", "#wordlist-btn", "#learn-btn", "#rescan"];
  for (const id of ids) {
    const el = $(id);
    if (el) el.disabled = !pro;
  }
  const toggle = $("#toggle");
  if (toggle && toggle.closest) {
    const row = toggle.closest(".switch-row");
    if (row) row.classList.toggle("is-disabled", !pro);
  }
}

/* 账号按钮：未登录显示“登录 / 注册”；已登录显示邮箱前缀，PRO 加金色徽章 */
function updateAcctBtn(st) {
  const lbl = document.querySelector("#acct-btn .lbl");
  const badge = $("#acct-badge");
  if (!lbl) return;
  if (!st || !st.signed_in) {
    lbl.textContent = "登录 / 注册";
    if (badge) badge.classList.add("hidden");
    return;
  }
  const prefix = (st.email || "").split("@")[0] || st.email || "";
  const pro = isProMembership(st);
  lbl.textContent = "账号：" + (prefix.length > 12 ? prefix.slice(0, 12) + "…" : prefix);
  if (badge) {
    badge.textContent = "PRO";
    badge.classList.toggle("hidden", !pro);
    badge.classList.toggle("pro", pro);
  }
}

/* 点击账号按钮 → 打开（或聚焦已打开的）设置页并定位到账号分区 */
async function openAccountPage() {
  if (!IS_EXT) return;
  const url = chrome.runtime.getURL("options.html#account");
  try {
    const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL("options.html") + "*" });
    if (tabs && tabs.length) {
      const t = tabs[0];
      await chrome.tabs.update(t.id, { url, active: true });
      if (t.windowId) { try { await chrome.windows.update(t.windowId, { focused: true }); } catch (e) { /* ignore */ } }
    } else {
      await chrome.tabs.create({ url });
    }
  } catch (e) {
    await chrome.tabs.create({ url });
  }
}

$("#acct-btn").addEventListener("click", async () => { await openAccountPage(); window.close(); });
$("#pro-gate-btn").addEventListener("click", async () => { await openAccountPage(); window.close(); });

/* 日/月线性图标（黑白极简风，stroke=currentColor 跟随按钮颜色） */
const ICON_MOON = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
const ICON_SUN = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';

function setLbl(sel, text) {
  const el = document.querySelector(sel + " .lbl");
  if (el) el.textContent = text;
}

function updateThemeBtn(theme) {
  const dark = theme === "dark";
  const btn = $("#theme-btn");
  if (btn) btn.innerHTML = (dark ? ICON_MOON : ICON_SUN) + '<span class="lbl">' + (dark ? "夜间" : "日间") + "</span>";
}

function updateTrBtn(on) {
  setLbl("#tr-btn", on ? "翻译：开" : "翻译：关");
}

function updateTrModeBtn(mode) {
  setLbl("#trmode-btn", mode === "replace" ? "覆盖式" : "对照式");
}

/* ============ 网页翻译白名单（命中的网址不进行网页翻译，生词高亮不受影响） ============ */

/** 当前标签页 hostname */
async function currentTabHost() {
  if (!IS_EXT) return "";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return (new URL(tab.url).hostname || "").replace(/^www\./, "");
  } catch (e) { return ""; }
}

/** 当前标签页是否已在白名单（hostname 匹配，支持子域） */
async function currentTabInWhitelist(list) {
  const host = await currentTabHost();
  if (!host) return false;
  return (list || []).some((raw) => {
    let entry = String(raw || "").trim().toLowerCase().replace(/^www\./, "");
    if (entry.includes("://")) { try { entry = new URL(entry).hostname.replace(/^www\./, ""); } catch (e) { return false; } }
    return host === entry || host.endsWith("." + entry);
  });
}

function updateWlBtn(inList) {
  setLbl("#wl-btn", inList ? "本站已不翻译（点击恢复）" : "本站不翻译");
  const btn = $("#wl-btn");
  if (btn) btn.classList.toggle("wl-active", inList);
}

$("#wl-btn").addEventListener("click", async () => {
  const host = await currentTabHost();
  if (!host) return;
  const s = await STORE.get({ noTranslateSites: [] });
  const list = (s.noTranslateSites || []).map((x) => String(x || "").trim().toLowerCase()).filter(Boolean);
  const i = list.findIndex((e) => e.replace(/^www\./, "") === host);
  let added;
  if (i >= 0) { list.splice(i, 1); added = false; } else { list.push(host); added = true; }
  await STORE.set({ noTranslateSites: list });
  updateWlBtn(added);
});

$("#tr-btn").addEventListener("click", async () => {
  const s = await STORE.get({ translateEnabled: false });
  const next = !s.translateEnabled;
  await STORE.set({ translateEnabled: next });
  updateTrBtn(next);
});

/* 翻译效果切换：覆盖原文（整页翻译风格）/ 保留原文对照 */
$("#trmode-btn").addEventListener("click", async () => {
  const s = await STORE.get({ translateMode: "replace" });
  const next = s.translateMode === "replace" ? "inline" : "replace";
  await STORE.set({ translateMode: next, modeMigrated266: true });
  updateTrModeBtn(next);
});

$("#toggle").addEventListener("change", async (e) => {
  await STORE.set({ enabled: e.target.checked });
  $("#hint").textContent = e.target.checked
    ? "悬停生词看简略翻译 · 右键详细释义"
    : "已停用，页面中的生词将不再高亮。";
});

$("#theme-btn").addEventListener("click", async () => {
  const s = await STORE.get({ theme: "light" });
  const next = s.theme === "dark" ? "light" : "dark";
  await STORE.set({ theme: next });
  updateThemeBtn(next);
  // 实时同步小窗口自身主题（此前仅存 storage，需关闭重开 popup 才变化）
  document.documentElement.setAttribute("data-wh-theme", next);
});

$("#wordlist-btn").addEventListener("click", () => {
  if (!IS_EXT) return;
  chrome.tabs.create({ url: chrome.runtime.getURL("wordlist.html") });
});

/* 【v2.12.0】背单词：独立页面（与生词本模块分离） */
$("#learn-btn").addEventListener("click", () => {
  if (!IS_EXT) return;
  chrome.tabs.create({ url: chrome.runtime.getURL("learn.html") });
});

$("#rescan").addEventListener("click", async () => {
  if (!IS_EXT) { window.close(); return; }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id) {
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "WH_RESCAN" });
    } catch (e) { /* ignore */ }
  }
  window.close();
});

$("#open-options").addEventListener("click", (e) => {
  e.preventDefault();
  if (!IS_EXT) return;
  chrome.runtime.openOptionsPage();
});

if (!IS_EXT) {
  const w = $("#env-warn");
  if (w) w.classList.remove("hidden");
  document.querySelectorAll("button").forEach((b) => (b.disabled = true));
  $("#toggle").disabled = false;
}

refreshState();
