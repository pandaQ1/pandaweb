/* 生词高亮 & 翻译助手 —— 生词本页面 v2.1（含陌生词等级筛选） */
"use strict";

const $ = (sel) => document.querySelector(sel);
const WB_KEY = "wh_wordbook";
const VOCAB = (typeof window.__WH_VOCAB__ !== "undefined") ? window.__WH_VOCAB__ : null;
const IS_EXT = WH_STORE.IS_EXT;

let wordbook = [];
let filter = "";
let sort = "new";
const detailCache = new Map();

/* ---------- 存储（使用共享 storage.js 模块） ---------- */
const STORE = {
  async syncGet(defs) { return WH_STORE.syncGet(defs); },
  async syncSet(patch) { return WH_STORE.syncSet(patch); },
  async localGet(key) { return WH_STORE.localGet(key); },
  async localSet(patch) { return WH_STORE.localSet(patch); }
};

/* ---------- 主题 ---------- */
async function applyTheme() {
  const s = await STORE.syncGet({ theme: "light" });
  const dark = s.theme === "dark" ||
    (s.theme === "auto" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.body.classList.toggle("dark", dark);
  document.documentElement.setAttribute("data-wh-theme", dark ? "dark" : "light");
  $("#theme-btn").textContent = dark ? "☀️ 日间" : "🌙 夜间";
}

/* ---------- 生词本数据 ---------- */
async function loadWordbook() {
  const s = await STORE.localGet(WB_KEY);
  const raw = s[WB_KEY];
  wordbook = Array.isArray(raw) ? raw.filter((e) => e && typeof e.word === "string") : [];
  render();
}

function filtered() {
  let list = wordbook.slice();
  if (filter) {
    const f = filter.toLowerCase();
    list = list.filter((e) => e.word.includes(f) || String(e.ctx || "").toLowerCase().includes(f));
  }
  if (sort === "new") list.sort((a, b) => (b.ts || 0) - (a.ts || 0));
  else if (sort === "old") list.sort((a, b) => (a.ts || 0) - (b.ts || 0));
  else list.sort((a, b) => a.word.localeCompare(b.word));
  return list;
}

/* ---------- 检测网页右键卡片的样式表是否已加载 ---------- */
function hasWebCardStyles() {
  try {
    for (const sheet of document.styleSheets) {
      const rules = sheet.cssRules || sheet.rules;
      if (!rules) continue;
      for (const r of rules) {
        if (r.selectorText && /#wh-tooltip\b/.test(r.selectorText)) return true;
      }
    }
  } catch (e) { /* 跨域样式表会抛错，忽略 */ }
  return false;
}

/* ---------- 悬浮查词（复用网页右键卡片，未加载时降级内置卡片） ---------- */
function tryShowCard(word, anchor, ctx) {
  const rect = anchor.getBoundingClientRect();
  try {
    if (typeof window.WH_SHOW_CARD === "function" && hasWebCardStyles()) {
      window.WH_SHOW_CARD(word, rect.left, rect.bottom, ctx || "");
      return true;
    }
  } catch (err) { console.warn("WH_SHOW_CARD failed:", err); }
  // 兜底：复用详情页内置的悬浮卡片
  if (window.WH_DETAIL_FLOAT && typeof window.WH_DETAIL_FLOAT.show === "function") {
    window.WH_DETAIL_FLOAT.show(word, anchor);
    return true;
  }
  return false;
}

/* ---------- 渲染生词本 ---------- */
function render() {
  $("#count").textContent = wordbook.length + " 个生词";
  const listEl = $("#list");
  const emptyEl = $("#empty");
  const items = filtered();
  listEl.textContent = "";
  emptyEl.classList.toggle("hidden", items.length > 0);

  for (const e of items) {
    const item = document.createElement("div");
    item.className = "item";
    item.dataset.word = e.word;

    const head = document.createElement("div");
    head.className = "item-head";

    const wordBtn = document.createElement("button");
    wordBtn.className = "item-word";
    wordBtn.textContent = e.word;
    wordBtn.title = "点击查看释义";
    wordBtn.addEventListener("click", () => {
      if (tryShowCard(e.word, wordBtn, e.ctx)) return;
      speak(e.word); // 【v2.10.4】点击单词自动发音
      toggleDetail(item, e.word);
    });
    head.appendChild(wordBtn);

    const ph = document.createElement("span");
    ph.className = "item-phonetic";
    if (VOCAB && VOCAB.meta && VOCAB.meta[e.word]) {
      ph.textContent = VOCAB.meta[e.word][1] || "";
    }
    head.appendChild(ph);
    // 【v2.10.5】词库没有音标的生词（如 nerfed/qualified 等屈折形式）自动后台查词典补全，
    // 无需用户点击；并发限流避免列表过长时请求风暴
    if (!ph.textContent && IS_EXT) {
      phonQueuePush(async () => {
        const p = await fetchPhonetic(e.word);
        if (p) ph.textContent = p;
      });
    }

    const speakBtn = document.createElement("button");
    speakBtn.className = "item-speak";
    speakBtn.textContent = "🔊";
    speakBtn.title = "发音";
    speakBtn.addEventListener("click", () => speak(e.word));
    head.appendChild(speakBtn);

    const meta = document.createElement("span");
    meta.className = "item-meta";
    meta.textContent = e.ts ? new Date(e.ts).toLocaleString("zh-CN", { hour12: false }) : "";
    head.appendChild(meta);

    const rm = document.createElement("button");
    rm.className = "item-remove";
    rm.textContent = "删除";
    rm.addEventListener("click", async () => {
      wordbook = wordbook.filter((x) => x.word !== e.word);
      await STORE.localSet({ [WB_KEY]: wordbook });
      render();
      refreshNewView();
    });
    head.appendChild(rm);

    item.appendChild(head);

    if (e.ctx) {
      const ctx = document.createElement("div");
      ctx.className = "item-ctx";
      // 【v2.10.3】语境句中每个单词可点击：点哪个查哪个的释义（与点击生词一致，toggleDetail 链路）
      const WORD_RE = /[A-Za-z][A-Za-z'’-]*/g;
      let last = 0;
      const appendChunk = (text, clickable) => {
        if (!text) return;
        if (clickable) {
          const b = document.createElement("button");
          b.className = "item-ctx-word";
          b.textContent = text;
          b.title = "点击查看「" + text + "」的释义";
          b.addEventListener("click", () => {
            if (tryShowCard(text, b, e.ctx)) return;
            speak(text); // 【v2.10.4】点击单词自动发音
            toggleDetail(item, text);
          });
          ctx.appendChild(b);
        } else {
          ctx.appendChild(document.createTextNode(text));
        }
      };
      const s = "「" + e.ctx + "」";
      WORD_RE.lastIndex = 0;
      let m;
      while ((m = WORD_RE.exec(e.ctx)) !== null) {
        appendChunk(s.slice(last, "「".length + m.index), false); // 「与前缀杂项
        appendChunk(m[0], true);                                  // 单词 → 可点击
        last = "「".length + m.index + m[0].length;
      }
      appendChunk(s.slice(last), false); // 剩余（含 」）
      // 【v2.10.1】查看句子翻译（懒加载 WH_TRANSLATE，再点收起）
      const stBtn = document.createElement("button");
      stBtn.className = "item-ctx-btn";
      stBtn.textContent = "译句";
      stBtn.title = "查看句子翻译";
      stBtn.addEventListener("click", () => toggleCtxTrans(item, e.ctx));
      ctx.appendChild(stBtn);
      // 【v2.10.7】生词语境发音：整句朗读
      const cspBtn = document.createElement("button");
      cspBtn.className = "item-ctx-btn";
      cspBtn.textContent = "🔊 朗读";
      cspBtn.title = "朗读语境句";
      cspBtn.addEventListener("click", () => speakSentence(e.ctx));
      ctx.appendChild(cspBtn);
      item.appendChild(ctx);
    }

    listEl.appendChild(item);
  }
}

/* ---------- 释义展开 ---------- */
function toggleDetail(item, word) {
  let detail = item.querySelector(".item-detail");
  if (detail && detail.dataset.word === word) {
    detail.remove(); // 同一个词再点 → 收起
    return;
  }
  if (detail) detail.remove(); // 换了词 → 替换为新词释义（语境句点不同单词直接切换）
  detail = document.createElement("div");
  detail.className = "item-detail";
  detail.dataset.word = word;
  detail.innerHTML = '<span class="loading">查询中…</span>';
  item.appendChild(detail);
  loadDetail(detail, item, word);
}

function loadDetail(detail, item, word) {
  // 词库内置释义（离线）
  const off = (VOCAB && VOCAB.meta && VOCAB.meta[word]);
  if (off && off[0] && off[0].length) {
    renderDetailResult(detail, item, { ok: true, source: "vocab", word, usphone: off[1] || "", translations: off[0], meanings: [] });
    return;
  }
  const get = detailCache.get(word) || fetchDict(word);
  detailCache.set(word, get);
  get.then((result) => renderDetailResult(detail, item, result));
}

function renderDetailResult(detail, item, result) {
  const ph = item.querySelector(".item-phonetic");
  detail.textContent = "";
  if (result.error || !result.ok) {
    const err = document.createElement("div");
    err.className = "err";
    err.textContent = "未找到释义：" + (result.error || "未知原因");
    detail.appendChild(err);
    return;
  }
  // 【v2.10.4 修复】只有查询的是生词本身才更新头部音标——
  // 点语境句中其他单词（如 soviet）不能覆盖生词（clashes）的音标
  if (ph && result.word === item.dataset.word
    && (result.usphone || result.ukphone || result.phonetic)) {
    ph.textContent = result.usphone || result.ukphone || result.phonetic;
  }
  const trans = result.translations || [];
  for (const t of trans.slice(0, 4)) {
    const div = document.createElement("div");
    div.textContent = "· " + t;
    detail.appendChild(div);
  }
  if (result.source === "en") {
    for (const m of (result.meanings || []).slice(0, 3)) {
      for (const d of m.defs) {
        const div = document.createElement("div");
        div.textContent = "· " + d.def;
        detail.appendChild(div);
      }
    }
  }
}

function fetchDict(word) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve({ ok: false, error: "查询超时" }), 15000);
    try {
      chrome.runtime.sendMessage({ type: "WH_DICT", word }, (resp) => {
        clearTimeout(timer);
        resolve(resp || { ok: false, error: "无响应" });
      });
    } catch (e) {
      clearTimeout(timer);
      resolve({ ok: false, error: "后台不可用" });
    }
  });
}

/* ---------- 音标懒加载补全（v2.10.5：词库没有的生词自动查词典） ---------- */
const PHON_CACHE = new Map(); // word -> Promise<phonetic 字符串>
let phonQueue = [];
let phonActive = 0;
const PHON_MAX = 3; // 并发限流：列表生词多时避免请求风暴

function phonQueuePush(task) {
  phonQueue.push(task);
  phonPump();
}
function phonPump() {
  while (phonActive < PHON_MAX && phonQueue.length) {
    const t = phonQueue.shift();
    phonActive++;
    t().catch(() => {}).then(() => { phonActive--; phonPump(); });
  }
}

/** 屈折变化还原候选：nerfed→nerf、qualified→qualify、playing→play 等（原形优先） */
function lemmaCandidates(word) {
  const list = [word];
  if (/ied$/.test(word)) {
    list.push(word.replace(/ied$/, "y"));       // qualified → qualify
  } else if (/eed$/.test(word) === false && /ed$/.test(word)) {
    list.push(word.replace(/ed$/, "e"));        // banned → bane? (少见，无害)
    list.push(word.replace(/ed$/, ""));         // nerfed → nerf
  }
  if (/ing$/.test(word)) { list.push(word.replace(/ing$/, "e")); list.push(word.replace(/ing$/, "")); }
  if (/es$/.test(word)) list.push(word.replace(/es$/, ""));
  if (/s$/.test(word) && !/ss$/.test(word)) list.push(word.replace(/s$/, ""));
  return list;
}

/** 查音标：逐个候选词走 WH_DICT（background 有缓存），首个带音标的结果胜出 */
async function fetchPhonetic(word) {
  if (PHON_CACHE.has(word)) return PHON_CACHE.get(word);
  const p = (async () => {
    for (const w of lemmaCandidates(word)) {
      const r = await fetchDict(w);
      if (r && r.ok) {
        const ph = r.usphone || r.ukphone || r.phonetic;
        if (ph) return ph;
      }
    }
    return "";
  })();
  PHON_CACHE.set(word, p);
  return p;
}

/* ---------- 语境句翻译（v2.10.1 懒加载，与 fetchDict 同模式） ---------- */
const TR_CACHE = new Map();
function fetchSentenceTrans(text) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve({ ok: false, error: "翻译超时" }), 20000);
    try {
      chrome.runtime.sendMessage({ type: "WH_TRANSLATE", text, service: "auto", lang: "auto" }, (resp) => {
        clearTimeout(timer);
        resolve(resp || { ok: false, error: "无响应" });
      });
    } catch (e) {
      clearTimeout(timer);
      resolve({ ok: false, error: "后台不可用" });
    }
  });
}

/** 展开/收起语境句的译文行（插在 .item-ctx 之后） */
async function toggleCtxTrans(item, text) {
  const ctxEl = item.querySelector(".item-ctx");
  let trans = item.querySelector(".item-ctx-trans");
  if (trans) {
    trans.remove(); // 再点一次收起
    return;
  }
  trans = document.createElement("div");
  trans.className = "item-ctx-trans";
  trans.innerHTML = '<span class="loading">翻译中…</span>';
  if (ctxEl) ctxEl.after(trans); else item.appendChild(trans);
  const get = TR_CACHE.get(text) || fetchSentenceTrans(text);
  TR_CACHE.set(text, get);
  const result = await get;
  trans.textContent = "";
  if (result.ok && result.text) {
    trans.textContent = "↳ " + result.text;
  } else {
    const err = document.createElement("span");
    err.className = "err";
    err.textContent = "翻译失败：" + (result.error || "未知原因");
    trans.appendChild(err);
  }
}

function speak(word) {
  // 【v2.10.8】统一走共享 TTS 模块（本地多语音 / 在线 OpenAI 兼容·有道·Google，
  // 读取设置页实时配置与语速；模块未加载时降级本地朗读）
  try {
    if (window.WH_TTS && window.WH_TTS.speakText) {
      window.WH_TTS.speakText(word);
      return;
    }
  } catch (e) { /* fallthrough */ }
  try {
    if (!("speechSynthesis" in window)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(word);
    u.lang = "en-US";
    u.rate = 0.85;
    speechSynthesis.speak(u);
  } catch (e) { /* ignore */ }
}

/** 朗读语境句（v2.10.7）：略慢于单词朗读，便于听清整句 */
function speakSentence(text) {
  try {
    if (window.WH_TTS && window.WH_TTS.speakText) {
      window.WH_TTS.speakText(text, { sentence: true });
      return;
    }
  } catch (e) { /* fallthrough */ }
  try {
    if (!("speechSynthesis" in window) || !text) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US";
    u.rate = 0.78;
    speechSynthesis.speak(u);
  } catch (e) { /* ignore */ }
}

/* ---------- 等级词表快筛（陌生词筛选） ---------- */
let newLevel = "primary";
let newFilter = "";
let newShown = 200;

function buildNewList() {
  if (!VOCAB || !VOCAB.meta) return [];
  const idx = VOCAB.order.indexOf(newLevel);
  if (idx < 0) return [];
  const f = newFilter.toLowerCase();
  const out = [];
  for (const w of Object.keys(VOCAB.meta)) {
    const m = VOCAB.meta[w];
    if (m[2] === undefined || m[2] !== idx) continue;   // 只留「等于所选等级」的词（快筛目标）
    if (f && !w.includes(f)) continue;
    out.push({ word: w, meta: m });
  }
  out.sort((a, b) => a.word.localeCompare(b.word));
  return out;
}

async function renderNew() {
  const sel = $("#lv-select");
  sel.textContent = "";
  if (!VOCAB) return;
  for (const lv of VOCAB.order) {
    const opt = document.createElement("option");
    opt.value = lv;
    opt.textContent = VOCAB.labels[lv];
    sel.appendChild(opt);
  }
  sel.value = newLevel;
  const list = buildNewList();
  const s = await STORE.syncGet({ userWords: [], knownWords: [] });
  const knownSet = new Set(s.userWords || []);       // 已掌握（选项页词表）
  const quickSet = new Set(s.knownWords || []);      // 快筛：已认识 → 页面不高亮
  const wb = await STORE.localGet(WB_KEY);
  const wbSet = new Set((wb[WB_KEY] || []).map((e) => e.word));

  $("#nv-stats").textContent = "「" + VOCAB.labels[newLevel] + "」词库共 " + list.length + " 词：页面默认全部高亮，点击「✓ 认识」快速筛掉已认识的词（即时生效，页面不再高亮）。";
  const slice = list.slice(0, newShown);
  const listEl = $("#nv-list");
  listEl.textContent = "";
  for (const item of slice) {
    const card = document.createElement("div");
    card.className = "item nv-item";

    const head = document.createElement("div");
    head.className = "item-head";
    const w = document.createElement("span");
    w.className = "nv-word";
    w.textContent = item.word;
    w.style.cursor = "pointer";
    w.title = "点击查词";
    w.addEventListener("click", () => tryShowCard(item.word, w, ""));
    head.appendChild(w);
    if (item.meta[1]) {
      const p = document.createElement("span");
      p.className = "item-phonetic";
      p.textContent = item.meta[1];
      head.appendChild(p);
    }
    const speakB = document.createElement("button");
    speakB.className = "item-speak";
    speakB.textContent = "🔊";
    speakB.addEventListener("click", () => speak(item.word));
    head.appendChild(speakB);
    if (quickSet.has(item.word)) {
      const tag = document.createElement("span");
      tag.className = "tag tag-known";
      tag.textContent = "已认识";
      head.appendChild(tag);
    } else if (knownSet.has(item.word)) {
      const tag = document.createElement("span");
      tag.className = "tag tag-known";
      tag.textContent = "已掌握";
      head.appendChild(tag);
    }
    if (wbSet.has(item.word)) {
      const tag = document.createElement("span");
      tag.className = "tag tag-wb";
      tag.textContent = "已收藏";
      head.appendChild(tag);
    }
    const btns = document.createElement("span");
    btns.className = "nv-btns";
    const b1 = document.createElement("button");
    b1.className = "nv-btn nv-btn-wb";
    b1.textContent = wbSet.has(item.word) ? "移出生词本" : "＋ 收藏生词";
    b1.addEventListener("click", async (e) => {
      e.stopPropagation();
      const cur = await STORE.localGet(WB_KEY);
      const arr = cur[WB_KEY] || [];
      const i = arr.findIndex((x) => x.word === item.word);
      if (i >= 0) arr.splice(i, 1);
      else arr.unshift({ word: item.word, ctx: "", ts: Date.now() });
      await STORE.localSet({ [WB_KEY]: arr });
      renderNew();
      loadWordbook();
    });
    btns.appendChild(b1);
    const b2 = document.createElement("button");
    b2.className = "nv-btn nv-btn-known";
    b2.textContent = quickSet.has(item.word) ? "✗ 取消认识" : "✓ 认识（不高亮）";
    b2.addEventListener("click", async (e) => {
      e.stopPropagation();
      const cur = await STORE.syncGet({ knownWords: [] });
      const arr = cur.knownWords || [];
      const i = arr.indexOf(item.word);
      if (i >= 0) arr.splice(i, 1);
      else arr.push(item.word);
      await STORE.syncSet({ knownWords: arr });
      renderNew();
    });
    btns.appendChild(b2);
    head.appendChild(btns);
    card.appendChild(head);

    const t = (item.meta[0] || [])[0] || "";
    if (t) {
      const trans = document.createElement("div");
      trans.className = "nv-trans";
      trans.textContent = t;
      card.appendChild(trans);
    }
    listEl.appendChild(card);
  }
  $("#nv-more").classList.toggle("hidden", slice.length >= list.length);
}

function refreshNewView() {
  if ($("#tab-new").classList.contains("active")) renderNew();
}

/* ---------- 导出（Anki / Excel / 纯文本） ---------- */
function wordMetaOf(word) {
  return (VOCAB && VOCAB.meta && VOCAB.meta[word]) || null;
}

function downloadBlob(content, filename, mime) {
  const blob = new Blob([content], { type: mime + ";charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}

function exportText() {
  const lines = wordbook.map((e) => e.word + (e.ctx ? "  ——  " + e.ctx : ""));
  downloadBlob(lines.join("\n"), "生词本.txt", "text/plain");
}

/** Anki：单词<TAB>释义<TAB>语境（导入时选"制表符分隔"，自动生成正/反面卡片） */
function exportAnki() {
  const lines = wordbook.map((e) => {
    const m = wordMetaOf(e.word);
    const def = m && m[0] ? m[0].join("；") : "";
    return [e.word, def, (e.ctx || "").replace(/\t/g, " ")].join("\t");
  });
  downloadBlob(lines.join("\n"), "生词本-Anki.txt", "text/plain");
}

/** Excel：CSV（带 BOM，Excel 双击直接打开不乱码） */
function exportExcel() {
  const esc = (v) => '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
  const head = ["单词", "音标", "释义", "语境", "添加时间", "记忆阶段", "正确次数", "遗忘次数"];
  const rows = wordbook.map((e) => {
    const m = wordMetaOf(e.word);
    const rv = reviewData[e.word] || {};
    return [
      e.word,
      (m && m[1]) || "",
      (m && m[0]) ? m[0].join("；") : "",
      e.ctx || "",
      e.ts ? new Date(e.ts).toLocaleString("zh-CN", { hour12: false }) : "",
      rv.s || 0,
      rv.ok || 0,
      rv.fail || 0
    ].map(esc).join(",");
  });
  downloadBlob("\uFEFF" + head.map(esc).join(",") + "\n" + rows.join("\n"), "生词本.csv", "text/csv");
}

/* ============================================================
 * 艾宾浩斯记忆曲线复习 + 打卡（数据在 storage.local）
 *  wh_review: { [word]: { s: 阶段0-7, due: 下次复习时间, last, ok, fail } }
 *  wh_daily:  { "YYYY-MM-DD": { r: 复习次数, f: 遗忘次数 } }（打卡 = 当日 r>0）
 * ============================================================ */
const RV_KEY = "wh_review";
const DAILY_KEY = "wh_daily";
const DAY_MS = 24 * 3600 * 1000;
/** 复习间隔（天）：认识 → 进入下一阶段；忘了 → 回到阶段 0（10 分钟后再现）；模糊 → 同阶段重复 */
const RV_STAGES = [0, 1, 2, 4, 7, 15, 30, 60];
const RV_GRADUATED = RV_STAGES.length - 1;

let reviewData = {};
let dailyData = {};
let rvQueue = [];
let rvPending = null;

function todayStr(ts) {
  const d = new Date(ts == null ? Date.now() : ts);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

async function loadReviewData() {
  const s = await STORE.localGet(RV_KEY);
  reviewData = s[RV_KEY] || {};
  const d = await STORE.localGet(DAILY_KEY);
  dailyData = d[DAILY_KEY] || {};
}

async function saveReviewData() {
  await STORE.localSet({ [RV_KEY]: reviewData, [DAILY_KEY]: dailyData });
}

/** 构建今日待复习队列：无记录（新词，阶段 0）或 due 已到期的生词，按到期时间升序 */
function buildReviewQueue() {
  const now = Date.now();
  rvQueue = wordbook
    .filter((e) => {
      const r = reviewData[e.word];
      return !r || (r.due || 0) <= now;
    })
    .map((e) => e.word)
    .sort((a, b) => ((reviewData[a] && reviewData[a].due) || 0) - ((reviewData[b] && reviewData[b].due) || 0));
}

/** 打分并调度下次复习（ok=认识进阶 / fuzzy=模糊重复 / fail=忘了归零），同时记打卡 */
function gradeWord(word, g) {
  const r = reviewData[word] || { s: 0, due: 0, last: 0, ok: 0, fail: 0 };
  const now = Date.now();
  if (g === "ok") {
    r.s = Math.min((r.s || 0) + 1, RV_GRADUATED);
    r.ok = (r.ok || 0) + 1;
  } else if (g === "fail") {
    r.s = 0;
    r.fail = (r.fail || 0) + 1;
  } // fuzzy：阶段不变，同间隔重复
  const gapDays = RV_STAGES[r.s];
  r.due = g === "fail" ? now + 10 * 60 * 1000 : now + Math.max(gapDays, 1) * DAY_MS;
  r.last = now;
  reviewData[word] = r;
  const t = todayStr(now);
  const d = dailyData[t] || { r: 0, f: 0 };
  d.r += 1;
  if (g === "fail") d.f += 1;
  dailyData[t] = d;
  saveReviewData();
}

/** 连续打卡天数：从今天（或昨天）往前连续 r>0 的天数 */
function checkinStreak() {
  let streak = 0;
  let cur = Date.now();
  const today = dailyData[todayStr(cur)];
  if (!today || !today.r) cur -= DAY_MS; // 今天还没复习 → 从昨天数
  for (let i = 0; i < 366; i++) {
    const d = dailyData[todayStr(cur)];
    if (d && d.r > 0) { streak++; cur -= DAY_MS; }
    else break;
  }
  return streak;
}

/* ---------- 复习 UI ---------- */
let rvTotal = 0;

async function renderReview() {
  buildReviewQueue();
  rvTotal = rvQueue.length;
  const today = dailyData[todayStr()] || { r: 0 };
  $("#rv-today").textContent = rvQueue.length;
  $("#rv-done").textContent = today.r || 0;
  $("#rv-streak").textContent = checkinStreak();
  $("#rv-empty").classList.toggle("hidden", wordbook.length > 0);
  showNextReview();
}

function showNextReview() {
  const box = $("#rv-box");
  const finish = $("#rv-finish");
  const word = rvQueue[0];
  if (!word) {
    box.classList.add("hidden");
    finish.classList.toggle("hidden", rvTotal === 0 || wordbook.length === 0);
    return;
  }
  rvPending = null;
  box.classList.remove("hidden");
  finish.classList.add("hidden");
  $("#rv-count").textContent = "第 " + ((rvTotal - rvQueue.length) + 1) + " / " + rvTotal + " 个";
  $("#rv-word").textContent = word;
  const m = wordMetaOf(word);
  $("#rv-ph").textContent = (m && m[1]) || "";
  const detail = $("#rv-detail");
  detail.classList.add("hidden");
  detail.textContent = "";
  const ctx = $("#rv-ctx");
  const entry = wordbook.find((e) => e.word === word);
  ctx.classList.toggle("hidden", !(entry && entry.ctx));
  ctx.textContent = entry && entry.ctx ? "「" + entry.ctx + "」" : "";
  $("#rv-actions").classList.remove("hidden");
  $("#rv-after-actions").classList.add("hidden");
  speak(word); // 切换复习单词时自动发音一次
}

document.querySelectorAll("#rv-actions .rv-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const word = rvQueue[0];
    if (!word) return;
    rvPending = { word, grade: btn.dataset.g };
    $("#rv-actions").classList.add("hidden");
    $("#rv-after-actions").classList.remove("hidden");
    const detail = $("#rv-detail");
    window.WH_DETAIL.loading(detail);
    window.WH_DETAIL.fetch(word).then((data) => {
      window.WH_DETAIL.render(detail, data);
    });
  });
});

function finishReviewGrade() {
  if (!rvPending) return;
  gradeWord(rvPending.word, rvPending.grade);
  rvQueue.shift();
  rvPending = null;
  const today = dailyData[todayStr()] || { r: 0 };
  $("#rv-done").textContent = today.r || 0;
  $("#rv-streak").textContent = checkinStreak();
  showNextReview();
}

$("#rv-speak").addEventListener("click", () => {
  const w = rvQueue[0];
  if (w) speak(w);
});
$("#rv-word").addEventListener("click", () => {
  const w = rvQueue[0];
  if (w) tryShowCard(w, $("#rv-word"), "");
});

$("#rv-wrong").addEventListener("click", () => {
  if (!rvPending) return;
  rvPending.grade = "fail";
  finishReviewGrade();
});
$("#rv-next").addEventListener("click", finishReviewGrade);

/* ============================================================
 * 背单词模块已迁移至独立页面 learn.html（v2.12.0，与生词本模块分离）
 * ============================================================ */

/* ---------- 数据统计面板 ---------- */
function computeStats() {
  const total = wordbook.length;
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  const monthNew = wordbook.filter((e) => (e.ts || 0) >= monthStart.getTime()).length;
  // 复习完成率 = 累计复习次数 / (累计复习次数 + 当前过期未复习词数)；遗忘率 = 遗忘次数 / 累计复习次数
  let totalReviews = 0;
  let totalFails = 0;
  const now = Date.now();
  let overdue = 0;
  for (const e of wordbook) {
    const r = reviewData[e.word];
    if (r) {
      totalReviews += (r.ok || 0) + (r.fail || 0);
      totalFails += r.fail || 0;
      if ((r.due || 0) <= now) overdue += 1;
    } else {
      overdue += 1; // 未复习过的到期词
    }
  }
  const doneRate = totalReviews + overdue > 0 ? Math.round((totalReviews / (totalReviews + overdue)) * 100) : null;
  const forgetRate = totalReviews > 0 ? Math.round((totalFails / totalReviews) * 100) : null;
  const graduated = wordbook.filter((e) => reviewData[e.word] && reviewData[e.word].s >= RV_GRADUATED).length;
  return { total, monthNew, doneRate, forgetRate, overdue, graduated, totalReviews, totalFails };
}

/** 学习曲线（近 30 天）：SVG 双折线（新增生词来自 wordbook.ts；复习来自 dailyData） */
function renderChart() {
  const days = 30;
  const now = Date.now();
  const newCnt = new Array(days).fill(0);
  for (const e of wordbook) {
    const idx = Math.floor((now - (e.ts || 0)) / DAY_MS);
    if (idx >= 0 && idx < days) newCnt[days - 1 - idx] += 1;
  }
  const rvCnt = new Array(days).fill(0);
  for (let i = 0; i < days; i++) {
    const d = dailyData[todayStr(now - (days - 1 - i) * DAY_MS)];
    rvCnt[i] = (d && d.r) || 0;
  }
  const W = 700, H = 200, PAD = 34;
  const maxV = Math.max(1, ...newCnt, ...rvCnt);
  const x = (i) => PAD + (i * (W - PAD * 2)) / (days - 1);
  const y = (v) => H - PAD - (v * (H - PAD * 2)) / maxV;
  const line = (arr) => arr.map((v, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1)).join(" ");
  let labels = "";
  for (let i = 0; i < days; i += 7) {
    labels += '<text x="' + x(i).toFixed(0) + '" y="' + (H - 8) + '" class="ax">' + todayStr(now - (days - 1 - i) * DAY_MS).slice(5) + "</text>";
  }
  const gridV = Math.ceil(maxV / 2) || 1;
  let grid = "";
  for (let v = gridV; v <= maxV; v += gridV) {
    grid += '<line x1="' + PAD + '" y1="' + y(v) + '" x2="' + (W - PAD) + '" y2="' + y(v) + '" class="grid"/><text x="4" y="' + (y(v) + 4) + '" class="ax">' + v + "</text>";
  }
  const svg = '<svg viewBox="0 0 ' + W + " " + H + '" preserveAspectRatio="xMidYMid meet">'
    + grid
    + '<path d="' + line(newCnt) + '" class="ln-new" fill="none"/>'
    + '<path d="' + line(rvCnt) + '" class="ln-rv" fill="none"/>'
    + labels + "</svg>";
  $("#st-chart").innerHTML = svg;
}

function renderStats() {
  const s = computeStats();
  $("#st-total").textContent = s.total;
  $("#st-month").textContent = s.monthNew;
  $("#st-done-rate").textContent = s.doneRate == null ? "—" : s.doneRate + "%";
  $("#st-forget-rate").textContent = s.forgetRate == null ? "—" : s.forgetRate + "%";
  const ex = $("#st-extra");
  ex.textContent = "";
  const parts = [
    "累计复习 " + s.totalReviews + " 次",
    "当前过期待复习 " + s.overdue + " 词",
    "已通过全部复习阶段（60 天长期间隔）" + s.graduated + " 词",
    "累计遗忘 " + s.totalFails + " 次"
  ];
  for (const p of parts) {
    const span = document.createElement("span");
    span.className = "st-chip";
    span.textContent = p;
    ex.appendChild(span);
  }
  renderChart();
}

/* ---------- 导出菜单事件 ---------- */
$("#export-btn").addEventListener("click", (e) => {
  e.stopPropagation();
  $("#export-menu").classList.toggle("hidden");
});
document.addEventListener("click", () => $("#export-menu").classList.add("hidden"));
document.querySelectorAll("#export-menu button").forEach((btn) => {
  btn.addEventListener("click", () => {
    if (btn.dataset.fmt === "anki") exportAnki();
    else if (btn.dataset.fmt === "excel") exportExcel();
    else exportText();
  });
});

/* ---------- 事件 ---------- */
$("#filter").addEventListener("input", (e) => { filter = e.target.value; render(); });
$("#sort").addEventListener("change", (e) => { sort = e.target.value; render(); });
$("#theme-btn").addEventListener("click", async () => {
  const s = await STORE.syncGet({ theme: "light" });
  await STORE.syncSet({ theme: s.theme === "dark" ? "light" : "dark" });
  applyTheme();
});
$("#clear-btn").addEventListener("click", async () => {
  if (!wordbook.length) return;
  if (!confirm("确定清空生词本吗？共 " + wordbook.length + " 个生词。（复习记录与打卡统计将一并清除）")) return;
  await STORE.localSet({ [WB_KEY]: [] });
  reviewData = {};
  dailyData = {};
  await saveReviewData();
  wordbook = [];
  render();
  refreshNewView();
});

// 标签页
function switchTab(name) {
  const tab = document.querySelector('.tab[data-tab="' + name + '"]');
  if (!tab) return false;
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t === tab));
  document.querySelectorAll(".tab-pane").forEach((p) => {
    p.classList.toggle("active", p.id === "tab-" + tab.dataset.tab);
  });
  if (tab.dataset.tab === "new") renderNew();
  else if (tab.dataset.tab === "review") renderReview();
  else if (tab.dataset.tab === "stats") renderStats();
  else render();
  return true;
}
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => switchTab(tab.dataset.tab));
});
// 【v2.11.0】支持 #learn 等锚点直达（popup「🎯 背单词」入口）
if (location.hash && switchTab(location.hash.slice(1))) { /* 直达完成 */ }
$("#lv-select").addEventListener("change", (e) => {
  newLevel = e.target.value;
  newShown = 200;
  renderNew();
});
$("#nv-filter").addEventListener("input", (e) => {
  newFilter = e.target.value.trim();
  newShown = 200;
  renderNew();
});
$("#nv-more").addEventListener("click", () => {
  newShown += 300;
  renderNew();
});

if (!IS_EXT) {
  const w = $("#env-warn");
  if (w) w.classList.remove("hidden");
}

/* 【v2.18.0】会员门禁：使用共享 pro-gate.js 模块 */
WH_PRO_GATE.init();

applyTheme();
(async () => {
  const s = await STORE.syncGet({ level: "none" });
  if (s.level && s.level !== "none" && VOCAB && VOCAB.order.includes(s.level)) newLevel = s.level;
  await loadReviewData();
  loadWordbook();
})();
