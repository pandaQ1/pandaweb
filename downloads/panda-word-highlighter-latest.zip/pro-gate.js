/* 生词高亮 & 翻译助手 —— PRO 会员门禁遮罩 v2.18.1
 * 非 PRO 用户显示全屏遮罩，引导登录/激活。
 * 使用方：wordlist.html / learn.html ——调用 WH_PRO_GATE.init() 启动
 */
(function () {
  "use strict";

  const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);

  function isProMembership(m) {
    if (!m || !m.signed_in || !m.pro) return false;
    if (!m.expires_at) return true;
    const t = typeof m.expires_at === "number" ? m.expires_at : Date.parse(m.expires_at);
    return Number.isFinite(t) && t > Date.now();
  }

  function showOverlay() {
    if (document.getElementById("wh-pro-gate-overlay")) return;
    const d = document.createElement("div");
    d.id = "wh-pro-gate-overlay";
    d.style.cssText = "position:fixed;inset:0;z-index:2147483647;background:rgba(9,9,11,.62);backdrop-filter:blur(6px);display:grid;place-items:center;font-family:system-ui,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;";
    d.innerHTML = '<div style="max-width:360px;width:calc(100% - 48px);background:#fff;color:#18181b;border-radius:16px;padding:30px 28px;text-align:center;box-shadow:0 24px 64px rgba(0,0,0,.3)">'
      + '<div style="font-size:40px;line-height:1">🔒</div>'
      + '<div style="font-size:17px;font-weight:700;margin-top:14px">需要 PRO 会员</div>'
      + '<div id="wh-pro-gate-msg" style="font-size:13.5px;color:#71717a;margin-top:8px;line-height:1.7">登录账号并激活后即可使用；已有账号直接登录。</div>'
      + '<button id="wh-pro-gate-btn" style="margin-top:18px;border:none;background:#18181b;color:#fff;font-size:14px;font-weight:600;padding:10px 26px;border-radius:999px;cursor:pointer">去激活 / 登录 →</button>'
      + '</div>';
    (document.body || document.documentElement).appendChild(d);
    // 只靠遮罩挡不住键盘 Tab/Enter：把页面主体设为 inert，避免非会员在遮罩下操作
    const page = document.querySelector(".page");
    if (page) page.inert = true;
    const btn = d.querySelector("#wh-pro-gate-btn");
    if (btn) btn.addEventListener("click", () => {
      try { chrome.tabs.create({ url: chrome.runtime.getURL("options.html#account") }); } catch (e) { /* ignore */ }
    });
  }

  function removeOverlay() {
    const ov = document.getElementById("wh-pro-gate-overlay");
    if (ov) ov.remove();
    const page = document.querySelector(".page");
    if (page) page.inert = false;
  }

  /** 启动门禁检查（仅扩展环境生效，预览环境放行） */
  function init() {
    if (!IS_EXT) return;
    let gateEpoch = 0;
    // 初始检查
    try {
      const epoch = gateEpoch;
      chrome.storage.local.get("wh_membership", (o) => {
        // 读取期间状态已变化：交给 onChanged 的最新结果，避免旧快照把遮罩加回来
        if (epoch !== gateEpoch) return;
        const m = o && o.wh_membership;
        if (isProMembership(m)) return;
        showOverlay();
        // 首次安装/缓存被清空时，向 background 询问一次最新状态（有缓存则不额外联网）
        if (!m) {
          try {
            chrome.runtime.sendMessage({ type: "WH_AUTH_STATE" }, (r) => {
              void chrome.runtime.lastError;
              if (epoch === gateEpoch && isProMembership(r)) removeOverlay();
            });
          } catch (e) { /* ignore */ }
        }
      });
    } catch (e) { showOverlay(); }
    // 监听状态变化（登录/兑换/登出/过期）
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.wh_membership) {
        gateEpoch++;
        const m = changes.wh_membership.newValue;
        if (isProMembership(m)) removeOverlay();
        else showOverlay();
      }
    });
  }

  window.WH_PRO_GATE = { init, showOverlay, removeOverlay };
})();
