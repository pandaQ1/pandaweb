/* 【v2.17.7】YouTube timedtext 桥接（MAIN world 注入，学习 read-frog timedtext-observer）：
 * YouTube 的 /api/timedtext 接口近年要求 pot（proof of origin）token，外部无法直接拼 URL，
 * 只能拦截播放器自己发出的 XHR 拿到完整 URL。本脚本 patch XMLHttpRequest 捕获之，
 * 并通过 postMessage 提供给隔离世界的 content script（两个世界不共享 window 属性）。
 * 页面为 youtube.com 时才注入（见 manifest matches）。 */
(function () {
  "use strict";
  if (window.__whTttBridge) return; // 防重复注入
  window.__whTttBridge = true;

  // 按视频缓存最近捕获的 timedtext URL（SPA 切视频后旧 URL 失效）
  const cache = new Map(); // videoId -> { url, ts }
  const MAX = 6;

  function videoIdOf(u) {
    try {
      const m = /[?&]v=([\w-]{6,})/.exec(u);
      return m ? m[1] : "";
    } catch (e) { return ""; }
  }

  function cacheTimedtextUrl(url) {
    try {
      if (!url || url.indexOf("/api/timedtext") < 0) return;
      const vid = videoIdOf(url);
      if (!vid) return; // 无视频 id 的（如预加载）不缓存
      cache.set(vid, { url, ts: Date.now() });
      if (cache.size > MAX) {
        // 淘汰最旧
        let oldest = null;
        for (const [k, v] of cache) if (!oldest || v.ts < oldest.ts) oldest = k;
        if (oldest) cache.delete(oldest);
      }
    } catch (e) { /* ignore */ }
  }

  // patch XHR（学习 read-frog：open 记录 URL，load 后捕获 responseURL）
  try {
    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url) {
      try { this.__whUrl = String(url); } catch (e) { /* ignore */ }
      return origOpen.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
      const self = this;
      this.addEventListener("load", function () {
        try { cacheTimedtextUrl(self.responseURL || self.__whUrl || ""); } catch (e) { /* ignore */ }
      });
      return origSend.apply(this, arguments);
    };
  } catch (e) { /* ignore */ }

  // 【v2.17.24】同时 patch fetch：部分播放路径/实验特性用 fetch 拉 timedtext，
  // 只拦 XHR 时这类请求抓不到 → 扩展永远拿不到字幕数据（只能退回 DOM 兜底，字幕偏慢）
  try {
    const origFetch = window.fetch;
    if (typeof origFetch === "function") {
      window.fetch = function (input, init) {
        try {
          const raw = typeof input === "string" ? input : (input && input.url) || "";
          if (raw && raw.indexOf("/api/timedtext") >= 0) cacheTimedtextUrl(new URL(raw, location.href).href);
        } catch (e) { /* ignore */ }
        return origFetch.apply(this, arguments);
      };
    }
  } catch (e) { /* ignore */ }

  // postMessage 服务：content script 询问某视频的 timedtext URL
  window.addEventListener("message", (e) => {
    // 只接受本窗口（同源）的请求，避免页面内 iframe 读取带 pot token 的 timedtext URL
    if (!e || e.source !== window) return;
    if (e.origin && e.origin !== location.origin) return;
    const d = e.data;
    if (!d || !e.source) return;
    // 【v2.17.24】扩展发现缓存的 URL 已失效（403/空数据）→ 丢弃，等待播放器发出新请求
    if (d.type === "WH_TTT_DROP") {
      const vid = String(d.videoId || "");
      if (vid) cache.delete(vid);
      return;
    }
    if (d.type !== "WH_TTT_REQ") return;
    const vid = String(d.videoId || "");
    const hit = vid && cache.get(vid);
    const reply = { type: "WH_TTT_RESP", reqId: d.reqId, url: hit ? hit.url : "", ts: hit ? hit.ts : 0 };
    try { e.source.postMessage(reply, e.origin || location.origin); } catch (err) { /* ignore */ }
  });
})();
