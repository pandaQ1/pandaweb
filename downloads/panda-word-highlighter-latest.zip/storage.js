/* 生词高亮 & 翻译助手 —— 共享存储模块 v2.18.0
 * 扩展环境优先（chrome.storage.sync/local），非扩展环境降级 localStorage。
 * 使用方：popup.js / options.js / wordlist.js / learn.js ——统一入口 WH_STORE
 */
(function () {
  "use strict";

  const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);

  window.WH_STORE = {
    IS_EXT,

    /** 读取 sync 存储（扩展用 chrome.storage.sync，降级 localStorage） */
    async syncGet(defs) {
      if (IS_EXT) {
        try { return await chrome.storage.sync.get(defs); } catch (e) { /* fallthrough */ }
      }
      const out = {};
      for (const k of Object.keys(defs)) {
        try { out[k] = JSON.parse(localStorage.getItem("wh_" + k)); } catch (e) { out[k] = undefined; }
        if (out[k] === undefined || out[k] === null) out[k] = defs[k];
      }
      return out;
    },

    /** 写入 sync 存储 */
    async syncSet(patch) {
      if (IS_EXT) {
        try { await chrome.storage.sync.set(patch); return true; } catch (e) { /* fallthrough */ }
      }
      for (const k of Object.keys(patch)) {
        try { localStorage.setItem("wh_" + k, JSON.stringify(patch[k])); } catch (e) { /* ignore */ }
      }
      return false;
    },

    /** 读取 local 存储（扩展用 chrome.storage.local，降级 localStorage） */
    async localGet(key) {
      if (IS_EXT) {
        try { return await chrome.storage.local.get(key); } catch (e) { /* fallthrough */ }
      }
      try { return { [key]: JSON.parse(localStorage.getItem("wh_local_" + key)) }; } catch (e) { return { [key]: undefined }; }
    },

    /** 写入 local 存储 */
    async localSet(patch) {
      if (IS_EXT) {
        try { await chrome.storage.local.set(patch); return true; } catch (e) { /* fallthrough */ }
      }
      for (const k of Object.keys(patch)) {
        try { localStorage.setItem("wh_local_" + k, JSON.stringify(patch[k])); } catch (e) { /* ignore */ }
      }
      return false;
    }
  };
})();
