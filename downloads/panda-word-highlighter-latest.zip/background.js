/**
 * 生词高亮 & 翻译助手 —— Background Service Worker
 * 职责：
 *  1. 代理词典查询：有道（中文释义/音标）→ Free Dictionary（英文兜底）→ AI 机器翻译（MyMemory，确保总有释义）
 */
"use strict";

/* Supabase 鉴权模块（会员功能共用；service worker 中经 importScripts 引入） */
importScripts("auth_util.js");

/* ============ 词典查询（内存缓存，软上限 1000 条） ============ */
const CACHE = new Map();
const CACHE_MAX = 1000;

/* ============ 会员门禁（v2.17.20）：缓存 + 定时刷新 ============
 *  状态写入 local.wh_membership（content/popup/内部页本地判定，不走网络）。
 *  刷新失败（网络阻断）保留旧缓存——已激活的 PRO 不因断网掉线。
 *  v2.18.1：增加刷新并发锁 / 登录代际，避免多个页面同时查询时
 *  refresh_token 被并发轮换、旧刷新结果覆盖新登录状态。 */
const MEM_KEY = "wh_membership";
let MEM = null;
let refreshPromise = null;
let authEpoch = 0;

const memReady = (async () => {
  const epoch = authEpoch;
  try {
    const o = await chrome.storage.local.get(MEM_KEY);
    // 读取期间已有登录/同步/退出写入：不能再用旧快照覆盖内存缓存
    if (epoch === authEpoch) MEM = o[MEM_KEY] ? normalizeMembership(o[MEM_KEY], null) : null;
  } catch (e) { if (epoch === authEpoch) MEM = null; }
})();

function parseTime(v) {
  if (!v) return 0;
  const t = typeof v === "number" ? v : Date.parse(v);
  return Number.isFinite(t) ? t : NaN;
}

/** 把服务端/options 页结果与上次缓存合并，计算真实可用性。
 *  - pro 必须未过期；无到期时间视为永久；到期时间格式异常按不可用处理；
 *  - offline 时沿用上次有效 PRO（断网不能把付费用户降级）；
 *  - 未登录时不保留邮箱。 */
function normalizeMembership(m, prev) {
  const now = Date.now();
  const offline = !!(m && m.offline);
  const uncertain = !!(m && /查询失败|拒绝访问|未创建|不存在|异常|网络错误/i.test(String(m.reason || "")));
  const signedIn = !!(m && m.signed_in) || !!(offline && prev && prev.signed_in);
  let plan = (m && m.plan) || (prev && prev.plan) || "free";
  // 0 / null 表示永久有效；不能用 `|| prev`（会把永久会员错误沿用上次的过期日期）
  let expiresAt = (m && m.expires_at !== undefined) ? m.expires_at : ((prev && prev.expires_at) || 0);
  let pro = signedIn && plan === "pro";
  if (pro && expiresAt) {
    const exp = parseTime(expiresAt);
    if (!Number.isFinite(exp) || exp <= now) pro = false;
  }
  if (offline && prev && prev.signed_in && prev.pro) {
    const prevExp = parseTime(prev.expires_at);
    if (!prev.expires_at || (Number.isFinite(prevExp) && prevExp > now)) {
      pro = true;
      plan = "pro";
      expiresAt = prev.expires_at || expiresAt;
    }
  }
  // 接口/表结构临时异常不是“会员失效”：仍有效的旧 PRO 继续沿用
  if (uncertain && signedIn && prev && prev.signed_in && prev.pro) {
    const prevExp = parseTime(prev.expires_at);
    if (!prev.expires_at || (Number.isFinite(prevExp) && prevExp > now)) {
      pro = true;
      plan = "pro";
      expiresAt = prev.expires_at || expiresAt;
    }
  }
  return {
    signed_in: signedIn,
    pro,
    plan,
    expires_at: expiresAt,
    email: signedIn ? ((m && m.email) || (prev && prev.email) || "") : "",
    offline,
    reason: (m && m.reason) || (offline && prev ? "离线：沿用上次校验结果" : ""),
    checked_at: now
  };
}

async function persistMembership(m) {
  MEM = m;
  try { await chrome.storage.local.set({ [MEM_KEY]: m }); } catch (e) { /* ignore */ }
  return m;
}

function refreshMembership() {
  if (refreshPromise) return refreshPromise;
  const p = doRefreshMembership();
  refreshPromise = p;
  p.finally(() => {
    if (refreshPromise === p) refreshPromise = null;
  }).catch(() => {});
  return p;
}

async function doRefreshMembership() {
  await memReady;
  const epoch = authEpoch;
  const prev = MEM;
  let m = null;
  try {
    m = await WHAuth.getMembership();
  } catch (e) {
    const peek = await WHAuth.peekSession().catch(() => null);
    m = {
      signed_in: !!(peek && peek.signed_in),
      pro: false,
      plan: "free",
      expires_at: 0,
      email: (peek && peek.email) || "",
      offline: true,
      reason: "网络错误：" + ((e && e.message) || e)
    };
  }

  // 服务端明确判定会话失效才允许 signed_in 由 true 变 false；
  // 其余"临时性失败"在本地仍有会话时保留旧状态，避免误踢
  if (m && m.signed_in === false && prev && prev.signed_in && !/失效/.test(String(m.reason || ""))) {
    const peek = await WHAuth.peekSession().catch(() => null);
    if (peek && peek.signed_in) {
      m = {
        signed_in: true,
        pro: false,
        plan: "free",
        expires_at: prev.expires_at || 0,
        email: peek.email || prev.email || "",
        offline: true,
        reason: "网络错误：沿用上次登录状态，联网后自动校验"
      };
    }
  }

  // 登录/登出/兑换在等待网络期间发生：丢弃旧结果，避免覆盖新状态
  if (epoch !== authEpoch) return MEM;

  return persistMembership(normalizeMembership(m || { signed_in: false, pro: false }, prev));
}

async function ensureMembership() {
  await memReady;
  if (!MEM || !MEM.checked_at || Date.now() - MEM.checked_at > 6 * 3600 * 1000) {
    return refreshMembership();
  }
  // 本地有会话但缓存却是"未登录"（SW 在登录前启动过 / 缓存被旧逻辑写坏）→ 立即重查
  if (!MEM.signed_in && WHAuth.peekSession) {
    try {
      const peek = await WHAuth.peekSession();
      if (peek && peek.signed_in) return refreshMembership();
    } catch (e) { /* ignore */ }
  }
  return MEM;
}

chrome.runtime.onInstalled.addListener(() => { refreshMembership().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { refreshMembership().catch(() => {}); });
chrome.alarms.create("wh_mem_refresh", { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a && a.name === "wh_mem_refresh") refreshMembership().catch(() => {});
});

function gateBlocked(sendResponse) {
  sendResponse({ ok: false, need_pro: true, error: "需要 PRO 会员：点击浏览器工具栏的 Panda 图标 → 账号，登录并激活后使用" });
}

/* 受门禁的功能消息（词典/翻译均经 background，统一拦截） */
const GATED = ["WH_DICT", "WH_WORD_DETAIL", "WH_TRANSLATE", "WH_TRANSLATE_BATCH", "WH_AI_TEST"];

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "WH_AUTH_STATE") {
    // 账号/会员状态查询（popup、content 可随时调用；6h 内走缓存）
    ensureMembership().then(sendResponse).catch((e) =>
      sendResponse({ signed_in: false, pro: false, plan: "free", reason: e && e.message })
    );
    return true; // 异步响应
  }
  if (msg && msg.type === "WH_MEMBERSHIP_SYNC") {
    // options 页登录/兑换/登出后同步最新会员状态到缓存（立即生效，无需等定时刷新）
    const inc = (msg && msg.membership) || {};
    // 【v2.17.26】离线结果不覆盖缓存：否则 options 页一次离线刷新就把 PRO 降级成免费版
    // v2.18.1：接口/表结构异常也不是"会员失效"，同样保留旧缓存，避免误踢付费用户
    const uncertain = /查询失败|拒绝访问|未创建|不存在|异常|网络错误/i.test(String(inc.reason || ""));
    if (inc.offline || uncertain) { sendResponse({ ok: true, keptCache: true }); return true; }
    authEpoch++; // 让仍在途的旧刷新结果作废
    const next = normalizeMembership(inc, MEM);
    persistMembership(next).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg && msg.type === "WH_AUTH_LOGOUT") {
    authEpoch++;
    WHAuth.signOut().then(async () => {
      await persistMembership({
        signed_in: false,
        pro: false,
        plan: "free",
        expires_at: 0,
        email: "",
        offline: false,
        reason: "已退出登录",
        checked_at: Date.now()
      });
      sendResponse({ ok: true });
    }).catch((e) => sendResponse({ ok: false, error: e && e.message }));
    return true;
  }
  if (msg && GATED.includes(msg.type)) {
    // 【v2.17.20】会员门禁：非 PRO 拒绝所有词典/翻译服务
    ensureMembership().then((m) => {
      if (!m || !m.pro) { gateBlocked(sendResponse); return; }
      if (msg.type === "WH_DICT") lookup(msg.word).then(sendResponse);
      else if (msg.type === "WH_WORD_DETAIL") lookupDetail(msg.word).then(sendResponse);
      else if (msg.type === "WH_TRANSLATE") translate(msg.text, msg.service, msg.lang).then(sendResponse);
      else if (msg.type === "WH_TRANSLATE_BATCH") translateBatch(msg.texts, msg.service, msg.lang).then(sendResponse);
      else if (msg.type === "WH_AI_TEST") fetchAI("serendipity").then(sendResponse);
    }).catch(() => gateBlocked(sendResponse));
    return true;
  }
  // 兜底：任何未知消息也给出响应，避免 "message port closed" 报错
  sendResponse({ ok: false, error: "unknown_message" });
  return true;
});

async function lookup(word) {
  const w = String(word || "").toLowerCase().trim();
  if (!w) return { ok: false, word: "" };
  if (CACHE.has(w)) return CACHE.get(w);
  const p = (async () => {
    const zh = await fetchWordYoudao(w);
    if (zh.ok) return zh;
    const en = await fetchEnglish(w);
    if (en.ok) return en;
    const ai = await fetchAI(w);
    return ai.ok ? ai : { ok: false, word: w, error: "未找到释义（有道/词典/AI 均无结果）" };
  })();
  CACHE.set(w, p);
  // 软上限清理：超过 CACHE_MAX 时删除最早一半条目
  if (CACHE.size > CACHE_MAX) {
    const keys = [...CACHE.keys()].slice(0, CACHE_MAX / 2);
    keys.forEach((k) => CACHE.delete(k));
  }
  return p;
}

/** 有道词典（中文释义 + 美/英音标）——注意勿与网页翻译版 fetchYoudao 重名（声明提升会互相覆盖，v2.8.0 前曾因此整个词典链失效） */
async function fetchWordYoudao(word) {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 9000);
    const res = await fetch(
      "https://dict.youdao.com/jsonapi?q=" + encodeURIComponent(word) + "&le=en",
      { signal: ctrl.signal, headers: { Referer: "https://dict.youdao.com/" } }
    );
    clearTimeout(timer);
    if (!res.ok) return { ok: false, word };
    const data = await res.json();

    const ec = data && data.ec && data.ec.word && data.ec.word[0];
    const translations = [];
    function extractTrs(trsArr) {
      if (!Array.isArray(trsArr)) return;
      for (const t of trsArr) {
        const tr = t && t.tr && t.tr[0];
        if (!tr || !tr.l || !Array.isArray(tr.l.i)) continue;
        const pos = String((t && (t.pos || t.wordPos)) || "").trim();
        const prefix = pos ? (pos + " ") : "";
        for (const item of tr.l.i) {
          if (typeof item === "string" && item.trim()) translations.push(prefix + item.trim());
        }
      }
    }
    if (ec && Array.isArray(ec.trs)) extractTrs(ec.trs);
    if (!translations.length && data && data.simple && data.simple.word && data.simple.word[0]) {
      extractTrs(data.simple.word[0].trs);
    }

    // 双语例句（best effort）
    const examples = [];
    try {
      const blng = data && data.blng_sents_part && data.blng_sents_part.sentence;
      if (Array.isArray(blng)) {
        for (const s of blng.slice(0, 4)) {
          const en = String((s["sentence-eng"] || s["sentence"] || s.content || "")).trim();
          const zh = String((s["sentence-translation"] || s.translation || s.cn || "")).trim();
          if (en) examples.push({ en, zh });
        }
      }
    } catch (e) { /* ignore */ }

    return {
      ok: translations.length > 0,
      source: "youdao",
      word,
      // 【v2.10.6】部分词条（如 nerf）无 usphone/ukphone 字段，音标在 ec.word[0].phone
      usphone: (ec && ec.usphone) || "",
      ukphone: (ec && ec.ukphone) || "",
      phonetic: (ec && ec.phone) || "",
      translations,
      examples
    };
  } catch (e) {
    return { ok: false, word, error: String((e && e.message) || e) };
  }
}

/** Free Dictionary API（英文释义兜底） */
async function fetchEnglish(word) {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 9000);
    const res = await fetch(
      "https://api.dictionaryapi.dev/api/v2/entries/en/" + encodeURIComponent(word),
      { signal: ctrl.signal }
    );
    clearTimeout(timer);
    if (!res.ok) return { ok: false, word };
    const data = await res.json();
    const e0 = Array.isArray(data) && data[0];
    if (!e0) return { ok: false, word };
    const meanings = ((e0.meanings || []).slice(0, 3)).map((m) => ({
      pos: m.partOfSpeech || "",
      defs: (m.definitions || []).slice(0, 3).map((d) => ({ def: d.definition || "", ex: d.example || "" })),
      synonyms: (m.synonyms || []).slice(0, 8),
      antonyms: (m.antonyms || []).slice(0, 4)
    }));
    const phonetic = e0.phonetic || ((e0.phonetics || []).find((p) => p.text) || {}).text || "";
    return {
      ok: meanings.length > 0,
      source: "en",
      word,
      phonetic,
      meanings,
      origin: e0.origin || "",
      examples: []
    };
  } catch (e) {
    return { ok: false, word, error: String((e && e.message) || e) };
  }
}

/** AI 机器翻译兜底（自定义 AI 优先，其次 MyMemory 免费 API，英→中） */
async function fetchAI(word) {
  // 自定义 AI（若用户配置了，优先用于单词查询兜底）
  try {
    const ais = await getCustomAIs();
    if (ais.length) {
      const r = await fetchCustomAI(word, ais[0]);
      if (r.ok) {
        return {
          ok: true,
          source: "ai",
          word,
          usphone: "",
          ukphone: "",
          translations: ["[AI 翻译] " + r.text],
          examples: []
        };
      }
    }
  } catch (e) { /* fallthrough */ }

  // MyMemory（en→zh），复用 fetchMyMemoryOnce 的 responseStatus/错误文本校验
  const r = await fetchMyMemoryOnce(word, "en");
  if (r.ok) {
    return {
      ok: true,
      source: "ai",
      word,
      usphone: "",
      ukphone: "",
      translations: ["[AI 翻译] " + r.text],
      examples: []
    };
  }
  return { ok: false, word, error: r.error || "AI 翻译失败" };
}

/* ============ 单词详情（释义 + 例句 + 词组搭配 + 词根派生 + 近义词） ============ */
async function lookupDetail(word) {
  const w = String(word || "").toLowerCase().trim();
  if (!w) return { ok: false, word: "" };

  // 1) 优先使用自定义 AI 生成结构化详情
  try {
    const ais = await getCustomAIs();
    if (ais.length) {
      const ai = await fetchWordDetailAI(w, ais[0]);
      if (ai.ok) return ai;
    }
  } catch (e) { /* fallthrough */ }

  // 2) 降级到词典链，并把结果整理成结构化详情
  const dict = await lookup(w);
  if (!dict.ok) return { ok: false, word: w, error: dict.error || "未找到释义" };

  const detail = {
    ok: true,
    word: w,
    source: dict.source || "dict",
    phonetic: dict.usphone || dict.ukphone || dict.phonetic || "",
    translations: (dict.translations || []).slice(0, 8),
    examples: [],
    collocations: [],
    rootDeriv: "",
    synonyms: []
  };

  // 例句：优先用有道双语例句；其次 Free Dictionary 例句
  if (Array.isArray(dict.examples) && dict.examples.length) {
    for (const ex of dict.examples.slice(0, 4)) {
      if (typeof ex === "string" && ex.trim()) detail.examples.push({ en: ex.trim(), zh: "" });
      else if (ex && ex.en) detail.examples.push({ en: ex.en, zh: ex.zh || "" });
    }
  }
  if (Array.isArray(dict.meanings)) {
    for (const m of dict.meanings.slice(0, 3)) {
      for (const d of (m.defs || []).slice(0, 2)) {
        if (d.ex && !detail.examples.some((x) => x.en === d.ex)) {
          detail.examples.push({ en: d.ex, zh: "" });
        }
      }
      if (m.synonyms && m.synonyms.length) detail.synonyms.push(...m.synonyms);
      if (m.antonyms && m.antonyms.length) detail.synonyms.push(...m.antonyms.map((a) => "~" + a));
    }
  }

  // 词根/词源：Free Dictionary 的 origin 字段
  if (dict.origin) detail.rootDeriv = dict.origin;

  // 近义词去重
  detail.synonyms = [...new Set(detail.synonyms)].slice(0, 10);

  return detail;
}

async function fetchWordDetailAI(word, cfg) {
  const base = String(cfg.url || "").trim().replace(/\/+$/, "");
  if (!base) return { ok: false, word };
  const endpoint = /\/chat\/completions$/.test(base) ? base : base + "/chat/completions";
  const headers = { "Content-Type": "application/json" };
  if (cfg.key) headers["Authorization"] = "Bearer " + cfg.key;

  const system = "You are a concise English-Chinese dictionary assistant. Given an English word, output a single valid JSON object with these keys: translations (array of Chinese meaning strings), examples (array of {en, zh}), collocations (array of common Chinese-English collocation strings), rootDeriv (object {root: Chinese explanation of root, derivatives: array of related English words}), synonyms (array of Chinese near-synonym strings). Keep values short. Do not include markdown or explanation.";
  const user = "Word: " + word;

  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 25000);
    const res = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: cfg.model || "gpt-3.5-turbo",
        messages: [{ role: "system", content: system }, { role: "user", content: user }],
        temperature: 0.2
      }),
      signal: ctrl.signal
    });
    clearTimeout(timer);
    if (!res.ok) return { ok: false, word, error: "HTTP " + res.status };
    const j = await res.json();
    const text = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
    if (!text || typeof text !== "string") return { ok: false, word, error: "返回格式异常" };

    let parsed = null;
    try {
      parsed = JSON.parse(text.trim());
    } catch (e) {
      const m = text.match(/\{[\s\S]*\}/);
      if (m) parsed = JSON.parse(m[0]);
    }
    if (!parsed) return { ok: false, word, error: "JSON 解析失败" };

    return {
      ok: true,
      word,
      source: "ai",
      phonetic: "",
      translations: Array.isArray(parsed.translations) ? parsed.translations.slice(0, 10) : [],
      examples: Array.isArray(parsed.examples) ? parsed.examples.slice(0, 6).map((ex) => ({ en: ex.en || ex[0] || "", zh: ex.zh || ex[1] || "" })) : [],
      collocations: Array.isArray(parsed.collocations) ? parsed.collocations.slice(0, 8) : [],
      rootDeriv: parsed.rootDeriv || "",
      synonyms: Array.isArray(parsed.synonyms) ? parsed.synonyms.slice(0, 10) : []
    };
  } catch (e) {
    return { ok: false, word, error: String((e && e.message) || e) };
  }
}

/* ============ 网页翻译（句子级，内置 + 自定义 AI） ============ */
const TR_CACHE = new Map();
const TR_CACHE_MAX = 3000;

/** 读取用户自定义 AI 翻译配置（storage.sync.customAIs） */
async function getCustomAIs() {
  try {
    const s = await chrome.storage.sync.get({ customAIs: [] });
    return Array.isArray(s.customAIs) ? s.customAIs : [];
  } catch (e) {
    return [];
  }
}

/** 【v2.17.23】"伪翻译"判定：服务把原文抄一遍再补一段括号注解，例如
 *  Edge 对 "Run JavaScript Everywhere" 返回 "Run JavaScript Everywhere（随处可行）"。
 *  这不是真正的译文——页面上表现为"原文被重复一遍"（标题变得又长又错乱）。
 *  命中时视为低质量结果，改试其它服务。 */
function isEchoTranslation(out, src) {
  const o = String(out || "").trim();
  const s = String(src || "").trim();
  if (!o || !s) return false;
  const norm = (x) => x.replace(/\s+/g, " ").toLowerCase();
  const no = norm(o), ns = norm(s);
  if (no === ns) return true;
  // 太短的原文（专有名词/单个词）包含关系不可靠，不判
  if (ns.length < 8) return false;
  return no.includes(ns);
}

/** 【v2.17.23】从"原文+注解"式伪翻译里剥掉被抄了一遍的原文，只留中文注解：
 *  "Run JavaScript Everywhere（随处可行）" → "随处可行"（避免标题里英文被重复一遍）。
 *  剥不出有效中文时返回空串，调用方保留原结果。 */
function cleanEchoText(out, src) {
  const o = String(out || "");
  const s = String(src || "").trim();
  if (!o || !s) return "";
  let tail = "";
  const esc = s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+");
  const m = new RegExp(esc, "i").exec(o);
  if (m) tail = (o.slice(0, m.index) + " " + o.slice(m.index + m[0].length)).trim();
  else {
    const idx = o.toLowerCase().indexOf(s.toLowerCase());
    if (idx >= 0) tail = (o.slice(0, idx) + " " + o.slice(idx + s.length)).trim();
  }
  tail = tail.replace(/^[\s,，、;；:：\-–—!！?？.。()（）[\]［］【】]+/, "")
             .replace(/[\s,，、;；:：\-–—!！?？.。()（）[\]［］【】]+$/, "")
             .trim();
  if (!tail || !/[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]/.test(tail)) return "";
  return tail;
}

async function translate(text, service, lang) {
  const t = String(text || "").trim();
  if (!t) return { ok: false };
  const svc = service || "auto";
  const L = lang || "en"; // en(猜测值，服务层转 auto) | ja | ko | ru | ar | auto
  // 自定义 AI 翻译
  if (svc.startsWith("custom:")) {
    const id = svc.slice(7);
    const ais = await getCustomAIs();
    const cfg = ais.find((a) => a.id === id);
    if (!cfg) return { ok: false, text, error: "自定义 AI 不存在，请到设置页检查" };
    const key = "custom|" + id + "|" + t;
    if (TR_CACHE.has(key)) return TR_CACHE.get(key);
    const p = (async () => {
      const r = await fetchCustomAI(t, cfg);
      if (r.ok) return r;
      // 自定义 AI 失败 → 自动降级 MyMemory
      const fb = await fetchMyMemory(t, L);
      const out = fb.ok ? fb : r;
      if (!out.ok) TR_CACHE.delete(key); // 失败不缓存，重试时重新请求
      return out;
    })();
    TR_CACHE.set(key, p);
    return p;
  }
  const key = svc + "|" + L + "|" + t;
  if (TR_CACHE.has(key)) return TR_CACHE.get(key);
  const p = (async () => {
    if (svc === "auto" || svc === "mymemory" || svc === "microsoft" || svc === "edge") {
      // 失败即 reject → Promise.any 真正"取先成功者"
      // （旧实现失败时 resolve({ok:false})，Promise.any 会直接采用先 settle 的失败结果，
      //  另一路稍后的成功被丢弃，表现为"所有服务均不可用"）
      const attempt = (pr) => pr.then((r) => (r.ok ? r : Promise.reject(new Error(r.error || "失败"))));
      const tasks = [];
      // 第一优先：Edge 免 token（国内直连、全语种、质量好——学习自 Read Frog）
      tasks.push(attempt(fetchMicrosoftEdge(t, L)));
      tasks.push(attempt(fetchMyMemory(t, L)));
      if (svc === "auto") {
        // 并发再加：微软 Bing（token 流程）+ Google（各路失败互不阻塞，带熔断）
        tasks.push(attempt(fetchMicrosoft(t, L)), attempt(fetchGoogle(t)));
      }
      try {
        const first = await Promise.any(tasks);
        // 【v2.17.23】竞速胜出的若是"原文+括号注解"式伪翻译（页面表现为原文被重复一遍），
        // 再按固定顺序试其余服务，取真正翻译过的结果；全都如此则仍用第一个（至少有注解）
        if (!isEchoTranslation(first.text, t)) return first;
        for (const probe of [() => fetchGoogle(t), () => fetchMicrosoft(t, L), () => fetchMyMemory(t, L), () => fetchYoudao(t, L)]) {
          let r = null;
          try { r = await probe(); } catch (e) { r = null; }
          if (r && r.ok && !isEchoTranslation(r.text, t)) return r;
        }
        // 各路都只会"抄原文+注解" → 至少把重复的原文剥掉，只显示中文注解
        const cleaned = cleanEchoText(first.text, t);
        return cleaned ? { ...first, text: cleaned } : first;
      } catch (e) {
        // 全部失败（如 Edge 不可达 + MyMemory 配额耗尽 + Google/Bing 被墙）
        // → 有道兜底（国内直连，限频串行约 4 秒/句，慢但可用）
        const yd = await fetchYoudao(t, L);
        if (yd.ok) return yd;
        const errs = (e && Array.isArray(e.errors) && e.errors.map((x) => (x && x.message) || String(x)).join("; ")) || String((e && e.message) || e);
        TR_CACHE.delete(key); // 全部失败不缓存，允许重试
        return { ok: false, text, error: "所有翻译服务均失败：" + errs + (yd.error ? "；有道兜底：" + yd.error : "") };
      }
    }
    let r = svc === "google" ? await fetchGoogle(t) : svc === "youdao" ? await fetchYoudao(t, L) : await fetchMyMemory(t, L);
    // 所选服务失败 → 逐级降级：Edge → MyMemory → 有道（全部国内可直连）
    if (!r.ok && svc !== "edge" && svc !== "microsoft") {
      const e1 = await fetchMicrosoftEdge(t, L);
      if (e1.ok) r = e1;
    }
    if (!r.ok) {
      if (svc !== "mymemory") {
        const fb = await fetchMyMemory(t, L);
        if (fb.ok) r = fb;
      }
      if (!r.ok && svc !== "youdao") {
        const yd = await fetchYoudao(t, L);
        if (yd.ok) r = yd;
      }
    }
    if (!r.ok) TR_CACHE.delete(key); // 失败不缓存，允许重试
    return r;
  })();
  TR_CACHE.set(key, p);
  if (TR_CACHE.size > TR_CACHE_MAX) {
    // 简单清一半
    const keys = [...TR_CACHE.keys()].slice(0, TR_CACHE_MAX / 2);
    keys.forEach((k) => TR_CACHE.delete(k));
  }
  return p;
}

/** OpenAI 兼容 chat/completions 自定义翻译接口 */
async function fetchCustomAI(text, cfg) {
  try {
    const base = String(cfg.url || "").trim().replace(/\/+$/, "");
    if (!base) return { ok: false, text, error: "API 地址为空" };
    const endpoint = /\/chat\/completions$/.test(base) ? base : base + "/chat/completions";
    const headers = { "Content-Type": "application/json" };
    if (cfg.key) headers["Authorization"] = "Bearer " + cfg.key;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 25000);
    const res = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: cfg.model || "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a professional translator. Translate the user's text into Simplified Chinese. Reply with only the Chinese translation, no explanation or extra text." },
          { role: "user", content: text }
        ],
        temperature: 0.2
      }),
      signal: ctrl.signal
    });
    clearTimeout(timer);
    if (!res.ok) return { ok: false, text, error: "HTTP " + res.status };
    const j = await res.json();
    const t = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
    if (!t || typeof t !== "string") return { ok: false, text, error: "返回格式异常" };
    const txt = t.trim().replace(/^["'“”]+|["'“”]+$/g, "");
    if (!txt || txt.toLowerCase() === text.toLowerCase()) return { ok: false, text, error: "返回原文/空" };
    return { ok: true, text: txt, source: "custom" };
  } catch (e) {
    return { ok: false, text, error: String((e && e.message) || e) };
  }
}

/* Google 熔断：被墙网络下连续失败后暂停一段时间，避免每句都发无效请求拖慢整体 */
const GOOGLE_STATE = { failStreak: 0, skipUntil: 0 };

async function fetchGoogle(text) {
  if (Date.now() < GOOGLE_STATE.skipUntil) {
    return { ok: false, text, error: "Google 暂时跳过（此前连续失败，稍后自动恢复）" };
  }
  let lastErr = "";
  // 第一端点：translate-pa.googleapis.com（Chrome 内置翻译同款，学习自 Read Frog；
  // 国外网络质量最佳，国内被墙 → 超时后落回 clients5 镜像）
  try {
    const res = await fetch("https://translate-pa.googleapis.com/v1/translateHtml", {
      method: "POST",
      headers: {
        "Content-Type": "application/json+protobuf",
        "X-Goog-API-Key": "AIzaSyATBXajvzQLTDHEQbcpq0Ihe0vWDHmO520"
      },
      body: JSON.stringify([[[text], "auto", "zh-CN"], "wt_lib"]),
      signal: AbortSignal.timeout(6000)
    });
    if (!res.ok) { lastErr = "Google HTTP " + res.status; }
    else {
      const j = await res.json();
      const txt = String((j && j[0] && j[0][0]) || "").trim();
      if (txt && txt.toLowerCase() !== text.toLowerCase()) {
        GOOGLE_STATE.failStreak = 0;
        return { ok: true, text: txt, source: "google" };
      }
      lastErr = "Google 返回原文/空";
    }
  } catch (e) {
    lastErr = String((e && e.message) || e);
  }
  // 备用端点：clients5 镜像（响应格式相同）
  const endpoints = [
    "https://clients5.google.com/translate_a/single?client=gtx&sl=auto&tl=zh-CN&dt=t&q="
  ];
  for (const ep of endpoints) {
    try {
      const res = await fetch(ep + encodeURIComponent(text), { signal: AbortSignal.timeout(7000) });
      if (!res.ok) { lastErr = "Google HTTP " + res.status; continue; }
      const j = await res.json();
      const txt = (j && j[0] ? j[0].map((x) => (x && x[0]) || "").join("") : "").trim();
      if (!txt || txt.toLowerCase() === text.toLowerCase()) { lastErr = "Google 返回原文/空"; continue; }
      GOOGLE_STATE.failStreak = 0;
      return { ok: true, text: txt, source: "google" };
    } catch (e) {
      lastErr = String((e && e.message) || e);
    }
  }
  GOOGLE_STATE.failStreak++;
  if (GOOGLE_STATE.failStreak >= 3) GOOGLE_STATE.skipUntil = Date.now() + 10 * 60 * 1000;
  return { ok: false, text, error: "Google 不可用：" + lastErr };
}

/* ============ 微软 Edge 翻译（免 token，学习自 Read Frog） ============
 *  端点：https://edge.microsoft.com/translate/translatetext（Edge 浏览器内置翻译同款）
 *  实测（2026-09，国内直连）：
 *   - 免 token、免 key；POST body 为字符串数组（天然批量）
 *   - auto 检测全语种（英/俄/西/法/日/韩混合批量均可）
 *   - 25 句/批全成功 746ms；单句 3000 字符无压力；8 路并发全过
 *   - 质量好：正确保留 Node.js 等专有名词
 *  作为 auto 模式第一优先服务（替代旧 Bing token 流程）。 */
const EDGE_STATE = { failStreak: 0, skipUntil: 0 };

async function edgeRequest(texts, from) {
  const r = await fetch(
    "https://edge.microsoft.com/translate/translatetext?from=" + encodeURIComponent(from || "") + "&to=zh-CN&isEnterpriseClient=false",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
      },
      body: JSON.stringify(texts),
      signal: AbortSignal.timeout(12000)
    }
  );
  if (!r.ok) throw new Error("Edge HTTP " + r.status);
  const j = await r.json();
  if (!Array.isArray(j)) throw new Error("Edge 返回格式异常");
  return j;
}

/** Edge 单句翻译（保持与其他 fetch* 相同的签名与返回结构） */
async function fetchMicrosoftEdge(text, lang) {
  if (Date.now() < EDGE_STATE.skipUntil) {
    return { ok: false, text, error: "Edge 暂时跳过（此前连续失败，稍后自动恢复）" };
  }
  try {
    // en 是内容脚本的本地猜测（无法区分葡/印尼/西语等无变音符拉丁语），不能当源语言码——
    // 实测 Edge from=en 遇葡语文本会原样返回（上层判"返回原文"→失败→漏译）；auto 检测对英语同样准确
    const j = await edgeRequest([String(text || "")], (!lang || lang === "auto" || lang === "en") ? "" : lang);
    const out = j[0] && j[0].translations && j[0].translations[0] && j[0].translations[0].text;
    const txt = String(out || "").trim();
    if (!txt || txt.toLowerCase() === String(text || "").toLowerCase()) {
      return { ok: false, text, error: "Edge 返回原文/空" };
    }
    EDGE_STATE.failStreak = 0;
    return { ok: true, text: txt, source: "edge" };
  } catch (e) {
    EDGE_STATE.failStreak++;
    if (EDGE_STATE.failStreak >= 3) EDGE_STATE.skipUntil = Date.now() + 5 * 60 * 1000;
    return { ok: false, text, error: "Edge: " + String((e && e.message) || e) };
  }
}

/** 批量翻译：texts → results（与 texts 等长的数组，元素为 translate() 的返回结构）。
 *  学习自 Read Frog 的批处理思路：能批量的服务一次请求（Edge 数组），
 *  不能批量的服务（MyMemory/有道/自定义 AI）逐句走 translate()。 */
async function translateBatch(texts, service, lang) {
  const list = (Array.isArray(texts) ? texts : []).map((t) => String(t || ""));
  if (!list.length) return { ok: true, results: [] };
  const svc = service || "auto";

  // Edge 批量（auto / microsoft 服务）：失败自动回退逐句
  if (svc === "auto" || svc === "microsoft" || svc === "edge") {
    if (Date.now() >= EDGE_STATE.skipUntil) {
      try {
        const j = await edgeRequest(list, (!lang || lang === "auto" || lang === "en") ? "" : (lang || ""));
        // 逐条校验：数量不匹配、译文为原文/空、或"原文+括号注解"式伪翻译 → 该条标记失败
        // （失败条目会走内容脚本的重试，最终由 translate() 的竞速降级链挑出真正的译文）
        const results = list.map((t, i) => {
          const out = j[i] && j[i].translations && j[i].translations[0] && j[i].translations[0].text;
          const txt = String(out || "").trim();
          if (!txt || txt.toLowerCase() === t.toLowerCase() || isEchoTranslation(txt, t)) {
            return { ok: false, text: t, error: "Edge 批量：返回原文/空/伪翻译" };
          }
          return { ok: true, text: txt, source: "edge" };
        });
        EDGE_STATE.failStreak = 0;
        return { ok: true, results };
      } catch (e) {
        EDGE_STATE.failStreak++;
        if (EDGE_STATE.failStreak >= 3) EDGE_STATE.skipUntil = Date.now() + 5 * 60 * 1000;
        // 整批失败 → 落到下方逐句降级
      }
    }
  }

  // 逐句降级（走 translate() 的完整降级链：MyMemory → 有道）
  const results = [];
  for (const t of list) {
    results.push(await translate(t, svc === "edge" ? "microsoft" : svc, lang));
  }
  return { ok: true, results };
}

/* ============ 微软 Bing 翻译（免费，token 流程，Edge 不可用时的备用） ============ */
const MS_STATE = { token: null, key: "", at: 0, failAt: 0 };

/** 获取 Bing 翻译 token（www.bing.com/translator 页内 params_AbusePreventionHelper，有效期约 1 小时）。
 *  失败后 5 分钟内不再重试（被墙/不可用网络下避免每句都发无效请求）。 */
async function msGetToken() {
  if (MS_STATE.token && Date.now() - MS_STATE.at < 50 * 60 * 1000) return;
  if (Date.now() - MS_STATE.failAt < 5 * 60 * 1000) throw new Error("Bing 暂不可用（稍后自动重试）");
  try {
    const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
    const r = await fetch("https://www.bing.com/translator", {
      headers: { "User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8" },
      credentials: "include",
      signal: AbortSignal.timeout(10000)
    });
    if (!r.ok) throw new Error("Bing 主页 HTTP " + r.status);
    const html = await r.text();
    const m = html.match(/params_AbusePreventionHelper\s*=\s*(\[[^\]]+\])/);
    if (!m) throw new Error("Bing token 未找到");
    const arr = JSON.parse(m[1]);
    MS_STATE.token = String(arr[2] || "");
    MS_STATE.key = arr[0] + "_" + arr[1];
    MS_STATE.at = Date.now();
  } catch (e) {
    MS_STATE.failAt = Date.now();
    throw e;
  }
}

async function fetchMicrosoft(text, lang) {
  try {
    await msGetToken();
    const body = new URLSearchParams({
      fromLang: (!lang || lang === "auto") ? "auto" : lang,
      to: "zh-Hans",
      text,
      token: MS_STATE.token,
      key: MS_STATE.key
    });
    const res = await fetch("https://www.bing.com/ttranslatev3", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://www.bing.com/translator",
        "Origin": "https://www.bing.com"
      },
      credentials: "include",
      body,
      signal: AbortSignal.timeout(10000)
    });
    if (!res.ok) { MS_STATE.token = null; return { ok: false, text, error: "Bing HTTP " + res.status }; }
    const j = await res.json();
    // 业务错误：{"statusCode":400,"errorMessage":""} 或空体（JSON 解析失败走 catch）
    if (j && j.statusCode && Number(j.statusCode) !== 200) {
      MS_STATE.token = null;
      return { ok: false, text, error: "Bing " + j.statusCode };
    }
    // 成功：[{ translations: [{ text, to }] }, ...]
    const out = (Array.isArray(j) && j[0] && Array.isArray(j[0].translations))
      ? j[0].translations.map((x) => (x && x.text) || "").join("")
      : "";
    const txt = out.trim();
    if (!txt || txt.toLowerCase() === text.toLowerCase()) { MS_STATE.token = null; return { ok: false, text, error: "Bing 返回原文/空" }; }
    return { ok: true, text: txt, source: "microsoft" };
  } catch (e) {
    MS_STATE.token = null;
    return { ok: false, text, error: "Bing: " + String((e && e.message) || e) };
  }
}

/** MyMemory 免费接口单次限 500 字符 */
const MYMEMORY_MAX = 450;

/** MyMemory 匿名配额熔断：配额按日重置，耗尽后暂停 2 小时再探测，
 *  避免评论区大量句子每句都白发一个注定失败的请求 */
let MM_QUOTA_UNTIL = 0;

/** MyMemory 单次请求（≤500 字符）。
 *  注意：MyMemory 的业务错误以 HTTP 200 返回——
 *   - 超长：translatedText = "QUERY LENGTH LIMIT EXCEEDED. MAX ALLOWED QUERY : 500 CHARS"，responseStatus=403
 *   - 匿名配额耗尽：translatedText = "MYMEMORY WARNING: YOU USED ALL AVAILABLE FREE TRANSLATIONS..."，responseStatus=403
 *  旧实现未检查 responseStatus，错误提示被当作译文直接显示到网页上 → 必须过滤 */
async function fetchMyMemoryOnce(text, L) {
  try {
    const res = await fetch(
      "https://api.mymemory.translated.net/get?q=" + encodeURIComponent(text) + "&langpair=" + encodeURIComponent(L + "|zh-CN"),
      { signal: AbortSignal.timeout(10000) }
    );
    if (!res.ok) return { ok: false, text, error: "MyMemory HTTP " + res.status };
    const j = await res.json();
    const t = j && j.responseData && j.responseData.translatedText;
    if (!t || typeof t !== "string") return { ok: false, text, error: "MyMemory 返回格式异常" };
    const txt = t.trim();
    // responseStatus 非 200（数字或字符串）或译文为服务端错误提示 → 视为失败
    const status = j && j.responseStatus;
    const errText = /^(QUERY LENGTH LIMIT EXCEEDED|MYMEMORY WARNING|INVALID (SOURCE|TARGET|LANGUAGE)|PLEASE SELECT|SORY,|SORRY,)/i.test(txt);
    if (String(status) !== "200" || errText) {
      const detail = (txt || String((j && j.responseDetails) || status || "")).slice(0, 120);
      // 匿名日配额耗尽 → 熔断 2 小时（每句都白发请求只会拖慢兜底服务）
      if (/MYMEMORY WARNING|ALL AVAILABLE FREE TRANSLATIONS/i.test(txt)) MM_QUOTA_UNTIL = Date.now() + 2 * 60 * 60 * 1000;
      return { ok: false, text, error: "MyMemory: " + detail };
    }
    if (!txt || txt.toLowerCase() === text.toLowerCase()) return { ok: false, text, error: "MyMemory 返回原文/空" };
    return { ok: true, text: txt, source: "mymemory" };
  } catch (e) {
    return { ok: false, text, error: String((e && e.message) || e) };
  }
}

/** MyMemory 翻译：超长文本按句末标点/空格切分为多段（各 ≤450 字符）逐段翻译后拼接 */
async function fetchMyMemory(text, lang) {
  const t = String(text || "").trim();
  if (!t) return { ok: false, text };
  if (Date.now() < MM_QUOTA_UNTIL) return { ok: false, text, error: "MyMemory 免费配额已用尽（自动暂停 2 小时后重试）" };
  // en 为内容脚本本地猜测值（实测 MyMemory langpair=en|zh-CN 遇葡语原样返回）→ 一律 Autodetect
  const L = (!lang || lang === "auto" || lang === "en") ? "Autodetect" : lang;
  if (t.length <= MYMEMORY_MAX) return fetchMyMemoryOnce(t, L);

  const parts = [];
  let cur = "";
  const flush = () => { if (cur.trim()) parts.push(cur.trim()); cur = ""; };
  const add = (piece) => {
    if (!piece) return;
    if (cur && (cur + " " + piece).length > MYMEMORY_MAX) flush();
    cur = cur ? cur + " " + piece : piece;
  };
  for (const seg of t.split(/(?<=[.!?。！？;；,，])\s*/)) {
    if (seg.length > MYMEMORY_MAX) {
      // 单段仍超长（无标点长句）→ 按空格切
      seg.split(/\s+/).forEach(add);
    } else {
      add(seg);
    }
  }
  flush();
  if (!parts.length) parts.push(t.slice(0, MYMEMORY_MAX));

  const outs = [];
  for (const p of parts) {
    const r = await fetchMyMemoryOnce(p, L);
    if (!r.ok) return { ok: false, text, error: r.error };
    outs.push(r.text);
  }
  return { ok: true, text: outs.join(""), source: "mymemory" };
}

/* ============ 有道翻译（aidemo 接口，国内直连；限频严格） ============
 *  实测（2026-09）：接口免费无 key，但限频严格——
 *   - 间隔 <400ms 或并发必触发 411"请求频率过快"；持续安全速率约 1 次 / 4s
 *   - 单段 >2400 字符报 errorCode 103（文本过长）→ 按 900 字符分段
 *   - from=auto 对拉丁语系（英/西/法/德…）有效；俄语 auto 报 102 → 必须显式传码
 *  因此实现为：全局串行队列 + 最小间隔 4s + 411 自动等待重试；作为"国内直连"服务
 *  与全部外网服务失败时的最后兜底（慢但可用）。 */
let YD_MIN_GAP = 4000; // let：测试环境可调小以加速（真实环境保持 4s）
const YD_MAX = 900;
const YD_STATE = { lastAt: 0, pending: 0, chain: Promise.resolve() };

function ydSleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

/** 有道单次请求（不排队，直接发） */
async function ydRequest(text, from) {
  try {
    const res = await fetch("https://aidemo.youdao.com/trans", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://aidemo.youdao.com/",
        "Origin": "https://aidemo.youdao.com"
      },
      body: new URLSearchParams({ q: text, from, to: "zh-CHS" }),
      signal: AbortSignal.timeout(12000)
    });
    if (!res.ok) return { ok: false, text, error: "有道 HTTP " + res.status };
    const j = await res.json().catch(() => null);
    const out = j && Array.isArray(j.translation) && j.translation[0];
    if (out) {
      const txt = String(out).trim();
      if (!txt || txt.toLowerCase() === text.toLowerCase()) return { ok: false, text, error: "有道返回原文/空" };
      return { ok: true, text: txt, source: "youdao" };
    }
    // 业务错误：{"errorCode":411,"msg":"请求频率过快"} / 103 文本过长 / 102 语种不支持
    const code = j && (j.errorCode !== undefined ? j.errorCode : j.msg);
    const rate = String(code) === "411" || /频率/.test(String(j && j.msg));
    return { ok: false, text, error: "有道错误：" + String(code).slice(0, 60), rate };
  } catch (e) {
    return { ok: false, text, error: "有道: " + String((e && e.message) || e) };
  }
}

/** 有道翻译（带全局串行队列、最小间隔与 411 重试） */
async function fetchYoudao(text, lang) {
  const t = String(text || "").trim();
  if (!t) return { ok: false, text };
  // 俄/日/韩必须显式语言码（auto 检测不支持西里尔等），拉丁语系用 auto
  const from = ["ja", "ko", "ru"].includes(lang) ? lang : "auto";

  // 排队过多（如整页翻译上百句全部落到兜底）→ 快速失败，交给上层重试，避免请求堆积超时
  if (YD_STATE.pending >= 8) return { ok: false, text, error: "有道限频排队过长，请稍后重试" };
  YD_STATE.pending++;
  const run = YD_STATE.chain.then(async () => {
    const wait = Math.max(0, YD_STATE.lastAt + YD_MIN_GAP - Date.now());
    if (wait) await ydSleep(wait);
    let r = { ok: false, error: "未执行" };
    for (let i = 0; i < 3; i++) {
      YD_STATE.lastAt = Date.now();
      r = await ydRequest(t.length <= YD_MAX ? t : t.slice(0, YD_MAX), from);
      if (r.ok || !r.rate) break;
      await ydSleep(5000); // 411 限频 → 等待后重试（最多 3 次）
    }
    return r;
  });
  YD_STATE.chain = run.then(() => {}, () => {});
  const out = await run;
  YD_STATE.pending--;
  if (!out.ok) return out;
  // 超长文本：首段已译，剩余部分递归分段（每段再排队，保持限频）
  if (t.length > YD_MAX) {
    const rest = await fetchYoudao(t.slice(YD_MAX), lang);
    if (rest.ok) return { ok: true, text: out.text + rest.text, source: "youdao" };
  }
  return out;
}
